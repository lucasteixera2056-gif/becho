'use strict';
/** Painel: pedidos (lista, detalhe, andamento, rastreio, cancelamento de não pagos e reembolso). */
const { html, raw } = require('../../lib/html');
const { money, parseMoney, centsToInput, int, maskCpf, UserError, formatPhone, formatZip, trunc } = require('../../lib/util');
const { icon, csrfField, field, selectField, imgUrl, pager, qs, badge } = require('../ui');

function register(router, app, h) {
  const { L } = h;
  const { STATUS, PAYMENT_STATUS, TRANSITIONS } = app.orders;
  const KIND = { ship: 'Envio', pickup: 'Retirada na loja', local: 'Entrega local' };
  const orderTone = L.statusTone;
  const oid = (ctx) => int(ctx.params.id);
  const back = (ctx) => `/admin/pedidos/${oid(ctx)}`;
  const actor = (ctx) => ctx.staff.name;

  // ───── lista ─────
  router.get('/admin/pedidos', (ctx) => {
    const f = { q: ctx.query.q || '', status: ctx.query.status || '', payment_status: ctx.query.pagamento || '', from: ctx.query.de || '', to: ctx.query.ate || '', attention: ctx.query.atencao === '1' };
    const r = app.orders.adminList({ ...f, page: ctx.query.page });
    const counts = app.orders.statusCounts();
    const keep = { q: f.q, status: f.status, pagamento: f.payment_status, de: f.from, ate: f.to, atencao: f.attention ? '1' : '' };
    const chip = (key, label, n) => html`<a class="chip ${f.status === key && !f.attention ? 'on' : ''}" href="/admin/pedidos${qs({}, key ? { status: key } : {})}">${label}${n !== undefined ? html` <b>${n}</b>` : ''}</a>`;
    const attentionCount = app.db.value('SELECT COUNT(*) FROM orders WHERE needs_attention = 1');
    h.page(ctx, 'Pedidos', html`
<section class="card">
  <div class="chips">${chip('', 'Todos')}${['awaiting_payment', 'paid', 'preparing', 'shipped', 'in_transit', 'delivered', 'cancelled', 'refunded'].map((k) => chip(k, STATUS[k], counts[k] || 0))}${attentionCount ? html`<a class="chip bad ${f.attention ? 'on' : ''}" href="/admin/pedidos?atencao=1">Precisam de atenção <b>${attentionCount}</b></a>` : ''}</div>
  <form class="filters" method="get" action="/admin/pedidos">
    <div class="field"><label for="q">Buscar</label><input id="q" name="q" type="search" value="${f.q}" placeholder="Número, nome, e-mail ou telefone"></div>
    ${selectField({ label: 'Situação', name: 'status', value: f.status, options: Object.entries(STATUS).map(([value, label]) => ({ value, label })), blank: 'Todas' })}
    ${selectField({ label: 'Pagamento', name: 'pagamento', value: f.payment_status, options: Object.entries(PAYMENT_STATUS).map(([value, label]) => ({ value, label })), blank: 'Todos' })}
    <div class="field"><label for="de">De</label>${L.dateInput('de', f.from)}</div><div class="field"><label for="ate">Até</label>${L.dateInput('ate', f.to)}</div>
    <div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div>
  </form>
  ${L.table(['Pedido', 'Data', 'Cliente', { label: 'Itens', right: true }, { label: 'Total', right: true }, 'Pagamento', 'Situação'], r.rows.map((o) => html`<tr class="${o.needs_attention ? 'row-attn' : ''}">
    <td><a href="/admin/pedidos/${o.id}"><strong>${o.number}</strong></a>${o.needs_attention ? html` <span title="${o.attention_note || 'Precisa de atenção'}">${icon('alert', 14)}</span>` : ''}</td>
    <td>${h.ago(o.created_at)}</td>
    <td>${o.customer_name}<br><small class="muted">${o.customer_email}</small></td>
    <td class="r">${o.items_count}</td><td class="r">${money(o.total_cents)}</td>
    <td>${badge(PAYMENT_STATUS[o.payment_status], orderTone(o.payment_status))}</td>
    <td>${badge(app.orders.statusLabel(o.status, o.delivery_kind), orderTone(o.status))}<br><small class="muted">${KIND[o.delivery_kind]}</small></td></tr>`), { empty: 'Nenhum pedido encontrado com esses filtros.' })}
  ${pager(r, (n) => `/admin/pedidos${qs(keep, { page: n })}`)}
  <p class="muted small">${r.total} pedido(s). Exportar: <a href="/admin/relatorios/pedidos.csv${qs({ de: f.from, ate: f.to })}">CSV de pedidos</a> (permissão de relatórios).</p>
</section>`);
  }, h.S('orders.view'));

  // ───── detalhe ─────
  const loadOrder = (ctx) => {
    const o = app.orders.get(oid(ctx));
    if (!o) { ctx.fail(404, 'Pedido não encontrado.'); return null; }
    return o;
  };

  router.get('/admin/pedidos/:id', (ctx) => {
    const o = loadOrder(ctx); if (!o) return;
    const items = app.orders.items(o.id);
    const hist = app.orders.history(o.id);
    const pays = app.payments.forOrder(o.id);
    const refunds = app.db.all('SELECT r.*, s.name AS staff_name FROM refunds r LEFT JOIN staff_users s ON s.id = r.staff_id WHERE r.order_id = ? ORDER BY r.id DESC', o.id);
    const ship = app.shipping.shipment(o.id);
    const events = ship ? app.shipping.events(ship.id) : [];
    const canManage = h.can(ctx, 'orders.manage');
    const canRefund = h.can(ctx, 'orders.refund');
    const canPii = h.can(ctx, 'customers.pii');
    const nexts = (TRANSITIONS[o.status] || []);
    const paidPay = pays.find((p) => ['paid', 'partially_refunded'].includes(p.status));
    const open = pays.find((p) => p.status === 'pending');
    const refundable = paidPay ? paidPay.amount_cents - paidPay.refunded_cents : 0;
    const cpf = o.customer_cpf_enc ? app.cipher.decrypt(o.customer_cpf_enc) : '';
    const wa = (o.customer_phone || '').replace(/\D/g, '');
    const adr = o.delivery_kind === 'pickup' ? 'Retirada na loja' : `${o.ship_street}, ${o.ship_number}${o.ship_complement ? ` — ${o.ship_complement}` : ''} · ${o.ship_district} · ${o.ship_city}/${o.ship_state} · CEP ${formatZip(o.ship_zip)}`;

    h.page(ctx, `Pedido ${o.number}`, html`
<div class="order-head">
  ${badge(app.orders.statusLabel(o.status, o.delivery_kind), orderTone(o.status))} ${badge(`Pagamento: ${PAYMENT_STATUS[o.payment_status]}`, orderTone(o.payment_status))}
  <span class="muted">Criado em ${h.ago(o.created_at)}${o.paid_at ? ` · pago em ${h.ago(o.paid_at)}` : ''}</span>
</div>
${o.needs_attention ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span><strong>Precisa de atenção:</strong> ${o.attention_note || 'verifique este pedido.'}</span>${canManage ? html`<form method="post" action="/admin/pedidos/${o.id}/atencao" class="inline">${csrfField(ctx)}<button class="btn btn-small btn-ghost" type="submit">Marcar como resolvido</button></form>` : ''}</div>` : ''}
<div class="cols cols-wide">
<div class="stack">
  <section class="card"><h2>Itens</h2>
    ${L.table(['', 'Peça', { label: 'Valor', right: true }, { label: 'Qtd', right: true }, { label: 'Subtotal', right: true }], items.map((i) => html`<tr><td class="thumb-cell">${i.image ? html`<img src="${imgUrl(i.image)}" alt="" width="40" height="50" loading="lazy">` : ''}</td><td>${i.product_id ? html`<a href="/admin/produtos/${i.product_id}">${i.name}</a>` : i.name}<br><small class="muted">${i.sku}</small></td><td class="r">${money(i.unit_cents)}</td><td class="r">${i.qty}</td><td class="r">${money(i.unit_cents * i.qty)}</td></tr>`))}
    <dl class="totals"><div><dt>Subtotal</dt><dd>${money(o.subtotal_cents)}</dd></div>${o.discount_cents ? html`<div><dt>Desconto${o.coupon_code ? ` (${o.coupon_code})` : ''}</dt><dd>− ${money(o.discount_cents)}</dd></div>` : ''}<div><dt>Entrega (${o.shipping_method_name || '—'})</dt><dd>${o.shipping_cents ? money(o.shipping_cents) : 'Grátis'}</dd></div><div class="grand"><dt>Total</dt><dd>${money(o.total_cents)}</dd></div></dl>
  </section>

  <section class="card"><h2>Pagamento</h2>
    ${pays.length ? L.table(['Provedor', 'Situação', { label: 'Valor', right: true }, { label: 'Taxa', right: true }, { label: 'Líquido', right: true }, 'Pago em', 'Liquidação'], pays.map((p) => html`<tr><td>${p.provider}<br><small class="muted">${p.provider_payment_id || '—'}</small></td><td>${badge(PAYMENT_STATUS[p.status], orderTone(p.status))}${p.refunded_cents ? html`<br><small class="muted">Reembolsado: ${money(p.refunded_cents)}</small>` : ''}</td><td class="r">${money(p.amount_cents)}</td><td class="r">${p.fee_cents === null ? html`<span class="muted" title="O provedor não informou">—</span>` : money(p.fee_cents)}</td><td class="r">${p.net_cents === null ? html`<span class="muted" title="O provedor não informou">—</span>` : money(p.net_cents)}</td><td>${p.paid_at ? h.ago(p.paid_at) : '—'}</td><td>${p.settlement_date ? h.day(`${p.settlement_date.slice(0, 10)}T12:00:00Z`) : (p.paid_at ? html`<span class="muted">não informada</span>` : '—')}</td></tr>`)) : html`<p class="empty-note">Nenhuma cobrança gerada.</p>`}
    <p class="muted small">O pagamento só é marcado como recebido quando o provedor confirma. Não existe baixa manual neste painel.</p>
    <div class="row-actions-wrap">
      ${open && canManage ? html`<form method="post" action="/admin/pedidos/${o.id}/verificar-pagamento">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">${icon('refresh', 16)} Consultar o provedor agora</button></form>` : ''}
      ${o.status === 'awaiting_payment' && canManage ? html`<form method="post" action="/admin/pedidos/${o.id}/cancelar" class="inline-form-row" data-confirm="Cancelar este pedido não pago? As peças voltam para a loja.">${csrfField(ctx)}<input name="reason" placeholder="Motivo (opcional)" maxlength="200" aria-label="Motivo do cancelamento"><button class="btn btn-danger btn-small" type="submit">Cancelar pedido</button></form>` : ''}
    </div>
    ${refunds.length ? html`<h3>Reembolsos</h3>${L.table(['Data', { label: 'Valor', right: true }, 'Motivo', 'Devolvida ao estoque', 'Responsável'], refunds.map((r) => html`<tr><td>${h.ago(r.created_at)}</td><td class="r">${money(r.amount_cents)}</td><td>${r.reason || '—'}</td><td>${r.restocked ? 'Sim' : 'Não'}</td><td>${r.staff_name || 'sistema'}</td></tr>`))}` : ''}
    ${canRefund && refundable > 0 ? html`<details class="refund"><summary class="btn btn-ghost btn-small">Reembolsar (até ${money(refundable)})</summary>
      <form method="post" action="/admin/pedidos/${o.id}/reembolsar" data-confirm="Confirmar o reembolso? O valor será devolvido ao cliente pelo provedor e não pode ser desfeito.">${csrfField(ctx)}
      ${field({ label: 'Valor a reembolsar (R$)', name: 'amount', value: centsToInput(refundable), required: true, inputmode: 'decimal', hint: `Máximo ${money(refundable)}. Reembolso total encerra o pedido.` })}
      ${field({ label: 'Motivo', name: 'reason', maxlength: 100 })}
      <label class="check"><input type="checkbox" name="restock" value="1"> Devolver as peças ao estoque (só no reembolso total)</label>
      <button class="btn btn-danger" type="submit">Reembolsar</button></form></details>` : ''}
  </section>

  <section class="card"><h2>Histórico</h2>
    ${hist.length ? html`<ol class="timeline">${hist.map((x) => html`<li><time>${h.ago(x.created_at)}</time><span>${x.to_status ? (x.from_status === x.to_status ? '' : html`<strong>${STATUS[x.to_status] || x.to_status}</strong>`) : ''}${x.note ? html` ${x.note}` : ''}<small class="muted"> — ${x.actor}</small></span></li>`)}</ol>` : html`<p class="empty-note">Sem registros.</p>`}
  </section>
</div>

<div class="stack">
  <section class="card"><h2>Cliente</h2>
    <p><strong>${o.customer_name}</strong><br><a href="mailto:${o.customer_email}">${o.customer_email}</a>${o.customer_phone ? html`<br>${formatPhone(o.customer_phone)}${wa.length >= 10 ? html` · <a href="https://wa.me/55${wa}" target="_blank" rel="noopener">WhatsApp</a>` : ''}` : ''}</p>
    ${cpf ? html`<p class="small">CPF: ${canPii ? cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : maskCpf(cpf)}</p>` : ''}
    ${o.customer_id && h.can(ctx, 'customers.view') ? html`<p><a href="/admin/clientes/${o.customer_id}">Ver cadastro do cliente</a></p>` : ''}
    ${o.customer_note ? html`<p class="notice-inline"><strong>Observação do cliente:</strong> ${o.customer_note}</p>` : ''}
  </section>

  <section class="card"><h2>Entrega</h2>
    <p><strong>${KIND[o.delivery_kind]}</strong>${o.shipping_method_name ? ` · ${o.shipping_method_name}` : ''}${o.shipping_eta_text ? html`<br><small class="muted">${o.shipping_eta_text}</small>` : ''}</p>
    <p class="small">${adr}</p>
    ${canManage && nexts.length ? html`<form method="post" action="/admin/pedidos/${o.id}/status" class="stack-sm">${csrfField(ctx)}<label for="st">Avançar pedido</label><div class="inline-form-row"><select id="st" name="to">${nexts.map((n) => html`<option value="${n}">${app.orders.statusLabel(n, o.delivery_kind)}</option>`)}</select><input name="note" placeholder="Observação (opcional)" maxlength="200" aria-label="Observação"><button class="btn btn-small" type="submit">Atualizar</button></div><p class="muted small">O cliente recebe um e-mail a cada mudança relevante.</p></form>` : ''}
    ${['paid', 'preparing', 'shipped', 'in_transit', 'delivered'].includes(o.status) && o.delivery_kind !== 'pickup' && canManage ? html`<form method="post" action="/admin/pedidos/${o.id}/rastreio" class="stack-sm"><h3>Rastreio</h3>${csrfField(ctx)}
      ${field({ label: 'Transportadora', name: 'carrier', value: ship?.carrier || '', maxlength: 60, placeholder: 'Correios, Jadlog…' })}
      ${field({ label: 'Código de rastreio', name: 'tracking_code', value: ship?.tracking_code || '', maxlength: 40 })}
      ${field({ label: 'Link de rastreio', name: 'tracking_url', value: ship?.tracking_url || '', placeholder: 'https://…', maxlength: 300, hint: 'Opcional. Precisa começar com https://' })}
      ${field({ label: 'Prazo informado ao cliente', name: 'eta_text', value: ship?.eta_text || o.shipping_eta_text || '', maxlength: 120 })}
      <button class="btn btn-ghost btn-small" type="submit">Salvar rastreio</button></form>` : ''}
    ${ship && canManage ? html`<form method="post" action="/admin/pedidos/${o.id}/evento" class="inline-form-row">${csrfField(ctx)}<input name="note" placeholder="Novo evento visível ao cliente" maxlength="300" aria-label="Evento de rastreio" required><button class="btn btn-ghost btn-small" type="submit">Adicionar</button></form>` : ''}
    ${events.length ? html`<ol class="timeline small">${events.map((e) => html`<li><time>${h.ago(e.created_at)}</time><span>${e.note || app.orders.statusLabel(e.status, o.delivery_kind)}</span></li>`)}</ol>` : ''}
  </section>

  <section class="card"><h2>Ações</h2>
    <div class="row-actions-wrap"><a class="btn btn-ghost btn-small" href="/admin/pedidos/${o.id}/imprimir" target="_blank" rel="noopener">${icon('print', 16)} Imprimir / separação</a><a class="btn btn-ghost btn-small" href="/pedido/${o.public_token}" target="_blank" rel="noopener">Ver como o cliente ${icon('external', 14)}</a></div>
  </section>
</div></div>`);
  }, h.S('orders.view'));

  // ───── impressão (separação / etiqueta de endereço) ─────
  router.get('/admin/pedidos/:id/imprimir', (ctx) => {
    const o = loadOrder(ctx); if (!o) return;
    const items = app.orders.items(o.id);
    const s = app.settings.all();
    const adr = o.delivery_kind === 'pickup' ? 'RETIRADA NA LOJA' : `${o.ship_street}, ${o.ship_number}${o.ship_complement ? ` — ${o.ship_complement}` : ''}\n${o.ship_district} — ${o.ship_city}/${o.ship_state}\nCEP ${formatZip(o.ship_zip)}`;
    ctx.html(html`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>Pedido ${o.number}</title><link rel="stylesheet" href="/css/admin.css?v=${app.cfg.assetVersion}"></head><body class="print-body">
<main class="print-sheet"><header><h1>${s.store_name}</h1><p>Pedido <strong>${o.number}</strong> · ${h.ago(o.created_at)}</p></header>
<section><h2>Destinatário</h2><p class="addr"><strong>${o.customer_name}</strong>${o.customer_phone ? html`<br>${formatPhone(o.customer_phone)}` : ''}<br>${raw(String(adr).split('\n').map((l) => require('../../lib/html').escape(l)).join('<br>'))}</p></section>
<section><h2>Itens para separar</h2><table class="tbl"><thead><tr><th>✓</th><th>Código</th><th>Peça</th><th class="r">Qtd</th></tr></thead><tbody>${items.map((i) => html`<tr><td>☐</td><td>${i.sku}</td><td>${i.name}</td><td class="r">${i.qty}</td></tr>`)}</tbody></table></section>
${o.customer_note ? html`<p><strong>Observação do cliente:</strong> ${o.customer_note}</p>` : ''}
<p class="muted small">Entrega: ${KIND[o.delivery_kind]}${o.shipping_method_name ? ` · ${o.shipping_method_name}` : ''}</p>
<p class="no-print"><button class="btn" type="button" data-print>Imprimir</button></p></main><script src="/js/admin.js?v=${app.cfg.assetVersion}" defer></script></body></html>`);
  }, h.S('orders.view'));

  // ───── ações ─────
  router.post('/admin/pedidos/:id/status', (ctx) => h.act(ctx, back(ctx), () => app.orders.setStatus(oid(ctx), ctx.body.to, { actor: actor(ctx), note: trunc(ctx.body.note, 200), ctx }), 'Pedido atualizado. O cliente foi avisado por e-mail.'), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/rastreio', (ctx) => h.act(ctx, back(ctx), () => app.orders.updateTracking(oid(ctx), ctx.body, ctx), 'Rastreio salvo.'), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/evento', (ctx) => h.act(ctx, back(ctx), () => app.orders.addTrackingEvent(oid(ctx), ctx.body.note, ctx), 'Evento adicionado.'), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/cancelar', (ctx) => h.act(ctx, back(ctx), () => app.orders.cancelUnpaid(oid(ctx), { actor: actor(ctx), reason: trunc(ctx.body.reason, 200) || 'Cancelado pela loja' }), 'Pedido cancelado e peças liberadas.'), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/atencao', (ctx) => h.act(ctx, back(ctx), () => app.orders.clearAttention(oid(ctx), ctx), 'Marcado como resolvido.'), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/verificar-pagamento', (ctx) => h.act(ctx, back(ctx), async () => {
    const pay = app.payments.openPayment(oid(ctx));
    if (!pay) throw new UserError('Não há cobrança pendente para consultar.');
    const r = await app.payments.refreshFromProvider(pay.id, `painel:${ctx.staff.id}`);
    app.audit.staff(ctx, 'payment.checked', 'order', oid(ctx), { outcome: r?.outcome });
    return r;
  }, (r) => (r?.outcome === 'paid' ? 'Pagamento confirmado pelo provedor.' : r?.outcome === 'provider_error' ? 'Não foi possível consultar o provedor agora. Tente novamente em instantes.' : 'Consulta feita: o provedor ainda não confirmou o pagamento.')), h.S('orders.manage'));
  router.post('/admin/pedidos/:id/reembolsar', (ctx) => h.act(ctx, back(ctx), async () => {
    const amount = parseMoney(ctx.body.amount);
    if (!amount || amount <= 0) throw new UserError('Informe um valor de reembolso válido.');
    return app.payments.refund(oid(ctx), { amountCents: amount, reason: ctx.body.reason, restock: !!ctx.body.restock, ctx });
  }, (r) => `Reembolso ${r.full ? 'total' : 'parcial'} de ${money(r.amount)} enviado ao provedor.`), h.S('orders.refund'));
}

module.exports = { register };
