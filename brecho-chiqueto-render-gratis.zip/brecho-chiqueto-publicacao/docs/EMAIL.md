# E-mails da loja (Resend)

## O que a loja faz — e o que não faz

- **Envia** e-mails automáticos pelo **Resend**: confirmação de cadastro, recuperação de senha, pedido recebido, Pix gerado, pagamento confirmado, expirado, em preparação, enviado (com rastreio), entregue, cancelado, reembolso, resposta automática do formulário de contato, boas-vindas da newsletter e avisos à loja.
- **Não recebe** e-mail. Quando o cliente responde, a resposta vai para o endereço de **resposta** (`EMAIL_REPLY_TO`). **Esse endereço precisa existir de verdade** (uma caixa de entrada comum, como Gmail, Zoho, Google Workspace ou a do provedor do seu domínio). O Resend sozinho não oferece caixa de entrada.
- Nada é “fingido”: sem chave, cada e-mail fica registrado como **“não enviado”** em *E-mails enviados* com o motivo; falhas aparecem como **“falhou”**, com a mensagem do Resend, e podem ser **reenviadas** com um clique.

## Configuração

1. Crie a conta em resend.com e **adicione e verifique o seu domínio**: o Resend mostra registros **DNS** (SPF, DKIM) para você criar no lugar onde registrou o domínio. Sem domínio verificado só é possível enviar em modo de teste, para o próprio dono da conta.
2. Crie uma **chave de API** e coloque no servidor: `RESEND_API_KEY`, `EMAIL_TRANSPORT=resend`.
3. Defina o remetente `EMAIL_FROM` (ex.: `loja@seu-dominio.com.br`, do domínio verificado) e a caixa de respostas `EMAIL_REPLY_TO`.
   O nome do remetente e o endereço também podem ser ajustados em *Configurações → E-mails*.
4. Em *Configurações → E-mails*, informe o **e-mail que recebe os avisos** (novo pedido pago, mensagens, solicitações LGPD). Se deixar vazio, usa o e-mail de contato da loja.
5. Teste: crie uma conta de cliente com um e-mail seu → deve chegar a confirmação. Se não chegar, veja *E-mails enviados* (motivo do erro) e a caixa de spam. Recomenda-se também cadastrar **DMARC** no DNS.

## Textos

*Configurações → E-mails*: cada modelo tem **assunto** e **introdução** editáveis, pode ser **desativado** (menos confirmação de e-mail e recuperação de senha, que nunca são desativadas) e **restaurado** ao original. Variáveis: `{{pedido}}` (número do pedido) e `{{loja}}` (nome da loja).
O visual dos e-mails usa as **cores** e o **nome** definidos em *Aparência*.

## Newsletter

Só recebe quem marcou o consentimento; o e-mail de boas-vindas e todo envio futuro devem trazer o **link de cancelamento**. A loja registra data, texto e IP do consentimento. **Atenção:** este projeto envia apenas o e-mail de boas-vindas; **não há disparo de campanhas em massa** — para isso use uma ferramenta própria e exporte a lista (CSV, só quem não cancelou) em *Newsletter*.
