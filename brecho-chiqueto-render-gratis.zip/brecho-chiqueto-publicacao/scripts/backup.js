'use strict';
/**
 * Backup consistente do banco e das fotos, sem parar a loja.
 *
 *   npm run backup                       → cria backups/AAAA-MM-DD_HHMMSS/ (banco + fotos) e mantém os 14 mais recentes
 *   npm run backup -- --keep 30          → mantém os 30 mais recentes
 *   npm run backup -- --dir /caminho     → grava em outra pasta (ou use BACKUP_DIR)
 *   npm run backup -- --no-uploads       → só o banco
 *
 * O banco é copiado com VACUUM INTO (cópia íntegra mesmo com a loja em uso) e conferido com integrity_check.
 * A SECRET_KEY NÃO entra no backup de propósito (guarde-a separadamente, em lugar seguro): sem ela, CPFs
 * cifrados no banco não podem ser lidos. Copie a pasta de backup para FORA do servidor (outro disco/nuvem).
 * Restauração: veja docs/PUBLICACAO.md.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { buildConfig, ROOT } = require('../src/config');

const flag = (name) => process.argv.includes(`--${name}`);
const opt = (name) => {
  const i = process.argv.indexOf(`--${name}`);
  const v = i >= 0 ? process.argv[i + 1] : undefined;
  return v && !v.startsWith('--') ? v : undefined;
};

function stamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function main() {
  const cfg = buildConfig();
  if (cfg.dbFile === ':memory:') throw new Error('O banco está em memória; não há o que copiar.');
  if (!fs.existsSync(cfg.dbFile)) throw new Error(`Banco não encontrado em ${cfg.dbFile}.`);
  const root = path.resolve(ROOT, opt('dir') || process.env.BACKUP_DIR || 'backups');
  const keep = Math.max(1, Number(opt('keep') || process.env.BACKUP_KEEP || 14));
  fs.mkdirSync(root, { recursive: true });
  let dest = path.join(root, stamp());
  for (let n = 2; fs.existsSync(dest); n++) dest = path.join(root, `${stamp()}-${n}`); // dois backups no mesmo segundo
  fs.mkdirSync(dest, { recursive: true });

  // 1) banco
  const target = path.join(dest, 'loja.db');
  const src = new DatabaseSync(cfg.dbFile);
  try {
    src.exec('PRAGMA busy_timeout = 10000');
    src.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
  } finally {
    src.close();
  }
  const check = new DatabaseSync(target, { readOnly: true });
  let tables;
  try {
    const ic = check.prepare('PRAGMA integrity_check').get();
    if (Object.values(ic)[0] !== 'ok') throw new Error('A cópia do banco não passou na verificação de integridade. Backup descartado.');
    tables = check.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table'").get().n;
  } catch (e) {
    check.close();
    fs.rmSync(dest, { recursive: true, force: true });
    throw e;
  }
  check.close();

  // 2) fotos
  let photos = 0;
  if (!flag('no-uploads') && fs.existsSync(cfg.uploadDir)) {
    fs.cpSync(cfg.uploadDir, path.join(dest, 'uploads'), { recursive: true });
    const count = (d) => fs.readdirSync(d, { withFileTypes: true }).reduce((n, e) => n + (e.isDirectory() ? count(path.join(d, e.name)) : 1), 0);
    photos = count(path.join(dest, 'uploads'));
  }
  fs.chmodSync(target, 0o600);
  fs.writeFileSync(path.join(dest, 'LEIA-ME.txt'), `Backup do Brechó Chiqueto gerado em ${new Date().toISOString()}\nBanco: loja.db (${tables} tabelas, verificado)\nFotos: ${photos} arquivo(s)\nA SECRET_KEY não está neste backup: guarde-a separadamente.\nRestauração: veja docs/PUBLICACAO.md.\n`);

  // 3) retenção: apaga só pastas com o nome de data deste script
  const old = fs.readdirSync(root).filter((n) => /^\d{4}-\d{2}-\d{2}_\d{6}(-\d+)?$/.test(n)).sort().reverse().slice(keep);
  for (const n of old) fs.rmSync(path.join(root, n), { recursive: true, force: true });

  console.log(`Backup criado em ${dest}`);
  console.log(`  banco verificado (${tables} tabelas), ${photos} arquivo(s) de foto${old.length ? `, ${old.length} backup(s) antigo(s) removido(s)` : ''}.`);
  console.log('  Lembrete: copie esta pasta para fora do servidor e guarde a SECRET_KEY em separado.');
}

try {
  main();
} catch (e) {
  console.error(`Erro no backup: ${e.message}`);
  process.exit(1);
}
