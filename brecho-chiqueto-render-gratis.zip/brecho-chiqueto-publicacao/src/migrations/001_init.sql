-- Brechó Chiqueto — esquema inicial.
-- Valores monetários sempre em centavos (INTEGER). Datas em ISO 8601 UTC.

CREATE TABLE settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Perfis e permissões (RBAC) ------------------------------------------------
CREATE TABLE role_permissions (
  role       TEXT NOT NULL CHECK (role IN ('admin','gerente','atendente','estoquista')),
  permission TEXT NOT NULL,
  PRIMARY KEY (role, permission)
);

CREATE TABLE staff_users (
  id                   INTEGER PRIMARY KEY,
  name                 TEXT NOT NULL,
  email                TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash        TEXT NOT NULL,
  role                 TEXT NOT NULL CHECK (role IN ('superadmin','admin','gerente','atendente','estoquista')),
  active               INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  must_change_password INTEGER NOT NULL DEFAULT 0,
  created_by           INTEGER REFERENCES staff_users(id) ON DELETE SET NULL,
  created_at           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_login_at        TEXT
);

CREATE TABLE customers (
  id                INTEGER PRIMARY KEY,
  name              TEXT NOT NULL,
  email             TEXT NOT NULL UNIQUE COLLATE NOCASE,
  phone             TEXT,
  cpf_enc           TEXT,
  password_hash     TEXT,
  email_verified_at TEXT,
  status            TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked','anonymized')),
  block_reason      TEXT,
  marketing_consent INTEGER NOT NULL DEFAULT 0,
  marketing_consent_at TEXT,
  admin_notes       TEXT,
  created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_login_at     TEXT
);

CREATE TABLE sessions (
  id           TEXT PRIMARY KEY,                 -- sha256 do token do cookie
  kind         TEXT NOT NULL CHECK (kind IN ('staff','customer')),
  user_id      INTEGER NOT NULL,
  created_at   TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at   TEXT NOT NULL,
  ip           TEXT,
  user_agent   TEXT
);
CREATE INDEX idx_sessions_user ON sessions(kind, user_id);

CREATE TABLE auth_tokens (
  token_hash  TEXT PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  purpose     TEXT NOT NULL CHECK (purpose IN ('verify_email','reset_password')),
  expires_at  TEXT NOT NULL,
  used_at     TEXT
);

CREATE TABLE rate_limits (
  key          TEXT PRIMARY KEY,
  count        INTEGER NOT NULL,
  window_start INTEGER NOT NULL,
  locked_until INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE addresses (
  id          INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  label       TEXT,
  recipient   TEXT NOT NULL,
  zip         TEXT NOT NULL,
  state       TEXT NOT NULL,
  city        TEXT NOT NULL,
  district    TEXT NOT NULL,
  street      TEXT NOT NULL,
  number      TEXT NOT NULL,
  complement  TEXT,
  is_default  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_addresses_customer ON addresses(customer_id);

-- Catálogo -----------------------------------------------------------------
CREATE TABLE categories (
  id          INTEGER PRIMARY KEY,
  parent_id   INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  image       TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE products (
  id                 INTEGER PRIMARY KEY,
  sku                TEXT NOT NULL UNIQUE,
  slug               TEXT NOT NULL UNIQUE,
  name               TEXT NOT NULL,
  description        TEXT NOT NULL DEFAULT '',
  category_id        INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  brand              TEXT,
  size               TEXT,
  color              TEXT,
  condition          TEXT,
  measures           TEXT,
  defects            TEXT,
  cost_cents         INTEGER CHECK (cost_cents IS NULL OR cost_cents >= 0),
  price_cents        INTEGER NOT NULL CHECK (price_cents > 0),
  promo_cents        INTEGER CHECK (promo_cents IS NULL OR (promo_cents > 0 AND promo_cents < price_cents)),
  quantity           INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
  restock_alert_qty  INTEGER CHECK (restock_alert_qty IS NULL OR restock_alert_qty >= 0),
  weight_g           INTEGER CHECK (weight_g IS NULL OR weight_g > 0),
  status             TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  featured           INTEGER NOT NULL DEFAULT 0 CHECK (featured IN (0,1)),
  search_text        TEXT NOT NULL DEFAULT '',
  created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  published_at       TEXT
);
CREATE INDEX idx_products_status ON products(status, published_at);
CREATE INDEX idx_products_category ON products(category_id);

CREATE TABLE product_images (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  filename   TEXT NOT NULL,
  alt        TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_primary INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_product_images_product ON product_images(product_id, sort_order);

CREATE TABLE stock_movements (
  id            INTEGER PRIMARY KEY,
  product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  delta         INTEGER NOT NULL CHECK (delta <> 0),
  balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
  reason        TEXT NOT NULL,               -- cadastro, entrada, saida, ajuste, venda, venda_fisica, reembolso
  order_id      INTEGER,
  note          TEXT,
  staff_id      INTEGER REFERENCES staff_users(id) ON DELETE SET NULL,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_stock_movements_product ON stock_movements(product_id, id);

-- Pedidos -------------------------------------------------------------------
CREATE TABLE coupons (
  id                 INTEGER PRIMARY KEY,
  code               TEXT NOT NULL UNIQUE COLLATE NOCASE,
  description        TEXT,
  kind               TEXT NOT NULL CHECK (kind IN ('percent','fixed')),
  value              INTEGER NOT NULL CHECK (value > 0),   -- percent: 1..100 | fixed: centavos
  min_subtotal_cents INTEGER NOT NULL DEFAULT 0,
  max_uses           INTEGER,
  used_count         INTEGER NOT NULL DEFAULT 0,
  starts_at          TEXT,
  expires_at         TEXT,
  active             INTEGER NOT NULL DEFAULT 1,
  created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CHECK (kind <> 'percent' OR value <= 100)
);
CREATE TABLE coupon_products (
  coupon_id  INTEGER NOT NULL REFERENCES coupons(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (coupon_id, product_id)
);

CREATE TABLE shipping_methods (
  id              INTEGER PRIMARY KEY,
  name            TEXT NOT NULL,
  kind            TEXT NOT NULL CHECK (kind IN ('fixed','pickup','local','melhorenvio','correios')),
  price_cents     INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
  free_over_cents INTEGER CHECK (free_over_cents IS NULL OR free_over_cents > 0),
  eta_text        TEXT,
  config          TEXT NOT NULL DEFAULT '{}',
  active          INTEGER NOT NULL DEFAULT 1,
  sort_order      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE carts (
  id          INTEGER PRIMARY KEY,
  token_hash  TEXT NOT NULL UNIQUE,
  customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
  coupon_code TEXT,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE TABLE cart_items (
  cart_id    INTEGER NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  qty        INTEGER NOT NULL CHECK (qty > 0),
  added_at   TEXT NOT NULL,
  PRIMARY KEY (cart_id, product_id)
);

CREATE TABLE orders (
  id                   INTEGER PRIMARY KEY,
  number               TEXT NOT NULL UNIQUE,
  public_token         TEXT NOT NULL UNIQUE,
  customer_id          INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  status               TEXT NOT NULL DEFAULT 'awaiting_payment'
                       CHECK (status IN ('awaiting_payment','paid','preparing','shipped','in_transit','delivered','cancelled','refunded')),
  payment_status       TEXT NOT NULL DEFAULT 'pending'
                       CHECK (payment_status IN ('pending','paid','expired','failed','cancelled','refunded','partially_refunded')),
  customer_name        TEXT NOT NULL,
  customer_email       TEXT NOT NULL,
  customer_phone       TEXT,
  customer_cpf_enc     TEXT,
  delivery_kind        TEXT NOT NULL CHECK (delivery_kind IN ('ship','pickup','local')),
  ship_zip             TEXT, ship_state TEXT, ship_city TEXT, ship_district TEXT,
  ship_street          TEXT, ship_number TEXT, ship_complement TEXT,
  shipping_method_id   INTEGER REFERENCES shipping_methods(id) ON DELETE SET NULL,
  shipping_method_name TEXT,
  shipping_eta_text    TEXT,
  shipping_cents       INTEGER NOT NULL DEFAULT 0 CHECK (shipping_cents >= 0),
  subtotal_cents       INTEGER NOT NULL CHECK (subtotal_cents >= 0),
  discount_cents       INTEGER NOT NULL DEFAULT 0 CHECK (discount_cents >= 0),
  total_cents          INTEGER NOT NULL CHECK (total_cents > 0),
  coupon_id            INTEGER REFERENCES coupons(id) ON DELETE SET NULL,
  coupon_code          TEXT,
  customer_note        TEXT,
  marketing_consent    INTEGER NOT NULL DEFAULT 0,
  needs_attention      INTEGER NOT NULL DEFAULT 0,
  attention_note       TEXT,
  created_at           TEXT NOT NULL,
  expires_at           TEXT,
  paid_at              TEXT,
  cancelled_at         TEXT,
  CHECK (total_cents = subtotal_cents - discount_cents + shipping_cents)
);
CREATE INDEX idx_orders_status ON orders(status, created_at);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_created ON orders(created_at);

CREATE TABLE order_items (
  id          INTEGER PRIMARY KEY,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
  sku         TEXT NOT NULL,
  name        TEXT NOT NULL,
  image       TEXT,
  unit_cents  INTEGER NOT NULL CHECK (unit_cents > 0),
  qty         INTEGER NOT NULL CHECK (qty > 0)
);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);

CREATE TABLE order_history (
  id         INTEGER PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  from_status TEXT,
  to_status  TEXT,
  note       TEXT,
  actor      TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_order_history_order ON order_history(order_id, id);

CREATE TABLE stock_reservations (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  qty        INTEGER NOT NULL CHECK (qty > 0),
  status     TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','consumed','released')),
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (order_id, product_id)
);
CREATE INDEX idx_reservations_product ON stock_reservations(product_id, status, expires_at);

-- Pagamentos ----------------------------------------------------------------
CREATE TABLE payments (
  id                  INTEGER PRIMARY KEY,
  order_id            INTEGER NOT NULL REFERENCES orders(id),
  provider            TEXT NOT NULL,
  provider_payment_id TEXT,
  method              TEXT NOT NULL DEFAULT 'pix',
  amount_cents        INTEGER NOT NULL CHECK (amount_cents > 0),
  status              TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','paid','expired','cancelled','failed','refunded','partially_refunded')),
  pix_payload         TEXT,
  pix_qr_base64       TEXT,
  expires_at          TEXT,
  fee_cents           INTEGER,
  net_cents           INTEGER,
  paid_at             TEXT,
  settlement_date     TEXT,
  refunded_cents      INTEGER NOT NULL DEFAULT 0,
  created_at          TEXT NOT NULL,
  updated_at          TEXT NOT NULL,
  UNIQUE (provider, provider_payment_id)
);
CREATE UNIQUE INDEX idx_one_open_payment_per_order ON payments(order_id) WHERE status = 'pending';
CREATE INDEX idx_payments_status ON payments(status, expires_at);

CREATE TABLE payment_events (
  id                  INTEGER PRIMARY KEY,
  provider            TEXT NOT NULL,
  event_id            TEXT NOT NULL,
  event_type          TEXT,
  provider_payment_id TEXT,
  payload             TEXT,
  status              TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing','done','failed','ignored')),
  error               TEXT,
  received_at         TEXT NOT NULL,
  processed_at        TEXT,
  UNIQUE (provider, event_id)
);

CREATE TABLE refunds (
  id                 INTEGER PRIMARY KEY,
  payment_id         INTEGER NOT NULL REFERENCES payments(id),
  order_id           INTEGER NOT NULL REFERENCES orders(id),
  amount_cents       INTEGER NOT NULL CHECK (amount_cents > 0),
  reason             TEXT,
  provider_refund_id TEXT,
  status             TEXT NOT NULL DEFAULT 'done',
  restocked          INTEGER NOT NULL DEFAULT 0,
  staff_id           INTEGER REFERENCES staff_users(id) ON DELETE SET NULL,
  created_at         TEXT NOT NULL
);

-- Estado "do lado do provedor" usado SOMENTE pelo provedor simulado (desenvolvimento/testes).
CREATE TABLE mock_provider_charges (
  id         TEXT PRIMARY KEY,
  reference  TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  status     TEXT NOT NULL DEFAULT 'pending',
  expires_at TEXT,
  paid_at    TEXT,
  refunded_cents INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- Entrega --------------------------------------------------------------------
CREATE TABLE shipments (
  id            INTEGER PRIMARY KEY,
  order_id      INTEGER NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
  carrier       TEXT,
  tracking_code TEXT,
  tracking_url  TEXT,
  status        TEXT NOT NULL DEFAULT 'preparing',
  eta_text      TEXT,
  shipped_at    TEXT,
  delivered_at  TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE TABLE tracking_events (
  id          INTEGER PRIMARY KEY,
  shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  status      TEXT NOT NULL,
  note        TEXT,
  created_at  TEXT NOT NULL
);

-- Comunicação ---------------------------------------------------------------
CREATE TABLE emails (
  id          INTEGER PRIMARY KEY,
  to_email    TEXT NOT NULL,
  template    TEXT NOT NULL,
  subject     TEXT NOT NULL,
  html        TEXT,
  text        TEXT,
  status      TEXT NOT NULL CHECK (status IN ('queued','sent','failed','skipped','captured')),
  error       TEXT,
  provider_id TEXT,
  attempts    INTEGER NOT NULL DEFAULT 0,
  order_id    INTEGER,
  customer_id INTEGER,
  created_at  TEXT NOT NULL,
  sent_at     TEXT
);
CREATE INDEX idx_emails_created ON emails(created_at);

CREATE TABLE email_templates (
  key     TEXT PRIMARY KEY,
  subject TEXT,
  intro   TEXT,
  enabled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE notifications (
  id         INTEGER PRIMARY KEY,
  kind       TEXT NOT NULL,
  title      TEXT NOT NULL,
  body       TEXT,
  link       TEXT,
  read_at    TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE newsletter_subscribers (
  id              INTEGER PRIMARY KEY,
  email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  consent_at      TEXT NOT NULL,
  consent_text    TEXT,
  ip              TEXT,
  unsub_token     TEXT NOT NULL UNIQUE,
  unsubscribed_at TEXT,
  created_at      TEXT NOT NULL
);

CREATE TABLE contact_messages (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL,
  phone      TEXT,
  subject    TEXT,
  message    TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','answered','archived')),
  created_at TEXT NOT NULL
);

CREATE TABLE support_requests (
  id          INTEGER PRIMARY KEY,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  order_id    INTEGER REFERENCES orders(id) ON DELETE SET NULL,
  kind        TEXT NOT NULL CHECK (kind IN ('cancel','support','return')),
  message     TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','done')),
  admin_note  TEXT,
  created_at  TEXT NOT NULL,
  resolved_at TEXT
);

CREATE TABLE data_requests (
  id           INTEGER PRIMARY KEY,
  customer_id  INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  email        TEXT NOT NULL,
  kind         TEXT NOT NULL CHECK (kind IN ('access','deletion')),
  status       TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','done','rejected')),
  note         TEXT,
  created_at   TEXT NOT NULL,
  completed_at TEXT
);

-- Conteúdo ------------------------------------------------------------------
CREATE TABLE banners (
  id         INTEGER PRIMARY KEY,
  placement  TEXT NOT NULL CHECK (placement IN ('hero','news')),
  title      TEXT NOT NULL,
  subtitle   TEXT,
  image      TEXT,
  link_url   TEXT,
  cta_label  TEXT,
  active     INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  starts_at  TEXT,
  ends_at    TEXT
);

CREATE TABLE pages (
  slug       TEXT PRIMARY KEY,
  title      TEXT NOT NULL,
  body       TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT
);

-- Auditoria -----------------------------------------------------------------
CREATE TABLE audit_logs (
  id          INTEGER PRIMARY KEY,
  at          TEXT NOT NULL,
  actor_type  TEXT NOT NULL CHECK (actor_type IN ('staff','customer','system','webhook')),
  actor_id    INTEGER,
  actor_label TEXT,
  action      TEXT NOT NULL,
  entity      TEXT,
  entity_id   TEXT,
  details     TEXT,
  ip          TEXT
);
CREATE INDEX idx_audit_at ON audit_logs(at);
CREATE INDEX idx_audit_entity ON audit_logs(entity, entity_id);
