'use strict';
/**
 * Painel: configurações da loja, aparência, entrega, e-mails e situação dos pagamentos.
 * Chaves secretas (Pix, e-mail, frete) ficam em variáveis de ambiente no servidor e NUNCA são exibidas nem editáveis aqui.
 */
const { html, raw } = require('../../lib/html');
const { int, trunc, validEmail, UserError, centsToInput, money } = require('../../lib/util');
const { icon, csrfField, field, selectField, imgUrl, badge } = require('../ui');

function register(router, app, h) {
  const { L } = h;
  const { cfg } = app;
  const TABS = [['loja', 'Loja'], ['aparencia', 'Aparência e início'], ['entrega', 'Entrega'], ['email', 'E-mails'], ['pedidos', 'Pedidos e Pix']];
  const tabNav = (cur) => html`<nav class="tabs" aria-label="Seções">${TABS.map(([k, l]) => html`<a href="/admin/configuracoes?aba=${k}" ${k === cur ? raw('aria-current="page"') : ''}>${l}</a>`)}</nav>`;
  const s0 = () => app.settings.all();
  const urlOk = (u) => !u || /^https:\/\/[^\s]+$/i.test(u);

  // ───── descrição das abas de formulário simples ─────
  const FORMS = {
    loja: {
      keys: ['store_name', 'store_tagline', 'store_description', 'store_email', 'store_phone', 'store_whatsapp', 'store_instagram', 'store_address', 'store_hours', 'store_document', 'about_title', 'about_text', 'footer_text', 'pickup_note', 'checkout_note'],
      validate(b, out) {
        if (!out.store_name) throw new UserError('Informe o nome da loja.');
        if (out.store_email && !validEmail(out.store_email)) throw new UserError('E-mail da loja inválido.');
        if (!urlOk(out.store_instagram)) throw new UserError('O link do Instagram deve começar com https://');
        out.store_whatsapp = String(out.store_whatsapp).replace(/\D/g, '');
        out.store_phone = String(out.store_phone).trim();
      },
      render(ctx, s) {
        return html`<p class="muted small">Tudo o que você preencher aqui aparece no rodapé, na página de contato e nos textos legais. Campos em branco simplesmente não aparecem: a loja não inventa telefone, endereço ou horários.</p>
${field({ label: 'Nome da loja', name: 'store_name', value: s.store_name, required: true, maxlength: 60 })}
${field({ label: 'Frase de apresentação', name: 'store_tagline', value: s.store_tagline, maxlength: 140 })}
${field({ label: 'Descrição para buscadores (Google)', name: 'store_description', value: s.store_description, maxlength: 300, hint: 'Até 160 caracteres rendem melhor.' })}
<div class="grid2">${field({ label: 'E-mail de contato', name: 'store_email', type: 'email', value: s.store_email })}${field({ label: 'WhatsApp (com DDD)', name: 'store_whatsapp', value: s.store_whatsapp, inputmode: 'tel', placeholder: '11999999999' })}</div>
<div class="grid2">${field({ label: 'Telefone', name: 'store_phone', value: s.store_phone })}${field({ label: 'Link do Instagram', name: 'store_instagram', value: s.store_instagram, placeholder: 'https://www.instagram.com/…' })}</div>
${field({ label: 'Endereço da loja / retirada', name: 'store_address', value: s.store_address, maxlength: 200, hint: 'Só informe se for público. Aparece nos textos legais e na retirada.' })}
<div class="grid2">${field({ label: 'Horário de atendimento', name: 'store_hours', value: s.store_hours, maxlength: 140 })}${field({ label: 'CNPJ ou CPF do responsável', name: 'store_document', value: s.store_document, maxlength: 30, hint: 'Aparece nos textos legais. Exigido para identificação do vendedor.' })}</div>
${field({ label: 'Instruções de retirada', name: 'pickup_note', value: s.pickup_note, maxlength: 300, hint: 'Mostrada ao cliente que escolhe retirar (ex.: como combinar o horário).' })}
${field({ label: 'Aviso no checkout', name: 'checkout_note', value: s.checkout_note, maxlength: 300 })}
${field({ label: 'Título da seção “Sobre”', name: 'about_title', value: s.about_title, maxlength: 80 })}
<div class="field"><label for="about_text">Texto “Sobre o brechó” <span class="opt">(opcional)</span></label><textarea id="about_text" name="about_text" rows="5" maxlength="2000">${s.about_text}</textarea><div class="hint">Só aparece no início se você escrever algo.</div></div>
${field({ label: 'Texto extra do rodapé', name: 'footer_text', value: s.footer_text, maxlength: 200 })}`;
      },
    },
    aparencia: {
      keys: ['color_primary', 'color_accent', 'color_bg', 'color_ink', 'font_heading', 'logo_file', 'hero_title', 'hero_subtitle', 'hero_cta_label', 'hero_cta_url', 'hero_image', 'instagram_cta_title', 'instagram_cta_text'],
      files: ['logo_file', 'hero_image'],
      validate(b, out) {
        for (const k of ['color_primary', 'color_accent', 'color_bg', 'color_ink']) if (!app.settings.validColor(out[k])) throw new UserError('Use cores no formato #RRGGBB.');
        if (!['serif', 'sans'].includes(out.font_heading)) throw new UserError('Fonte inválida.');
        if (out.hero_cta_url && !/^(\/(?!\/)|https?:\/\/)/i.test(out.hero_cta_url)) throw new UserError('O link do botão deve começar com / ou https://');
      },
      render(ctx, s) {
        const colorField = (name, label) => html`<div class="field"><label for="f_${name}">${label}</label><div class="color-row"><input id="f_${name}" name="${name}" type="color" value="${s[name]}"><code>${s[name]}</code></div></div>`;
        const up = (name, label, current) => html`<div class="field"><label>${label} <span class="opt">(opcional)</span></label>${current ? html`<img src="${imgUrl(current)}" alt="${label} atual" class="mini-preview">` : ''}
<div class="uploader" data-uploader data-endpoint="/admin/uploads" data-target="#in_${name}" data-max="${name === 'logo_file' ? 600 : 1800}"><label class="btn btn-ghost btn-small" for="up_${name}">Escolher imagem</label><input id="up_${name}" type="file" accept="image/jpeg,image/png,image/webp" hidden><span class="muted small" data-status role="status"></span></div><input type="hidden" name="${name}" id="in_${name}" value="">${current ? html`<label class="check"><input type="checkbox" name="${name}__remove" value="1"> Remover a imagem atual</label>` : ''}</div>`;
        return html`<h3>Identidade visual</h3>
<p class="muted small">Ajuste conforme o perfil do Instagram da loja. As cores precisam ter bom contraste para o texto continuar legível.</p>
<div class="grid4">${colorField('color_primary', 'Cor principal')}${colorField('color_accent', 'Cor de destaque')}${colorField('color_bg', 'Fundo')}${colorField('color_ink', 'Texto')}</div>
${selectField({ label: 'Fonte dos títulos', name: 'font_heading', value: s.font_heading, options: [{ value: 'serif', label: 'Com serifa (clássica)' }, { value: 'sans', label: 'Sem serifa (moderna)' }], blank: null, required: true })}
${up('logo_file', 'Logotipo', s.logo_file)}
<h3>Início da loja</h3>
${field({ label: 'Título principal', name: 'hero_title', value: s.hero_title, maxlength: 100 })}
${field({ label: 'Texto de apoio', name: 'hero_subtitle', value: s.hero_subtitle, maxlength: 200 })}
<div class="grid2">${field({ label: 'Texto do botão', name: 'hero_cta_label', value: s.hero_cta_label, maxlength: 40 })}${field({ label: 'Link do botão', name: 'hero_cta_url', value: s.hero_cta_url, maxlength: 300 })}</div>
${up('hero_image', 'Imagem do topo', s.hero_image)}
<p class="muted small">Prefere várias imagens e agendamento? Use <a href="/admin/banners">Banners</a>.</p>
${field({ label: 'Chamada do Instagram — título', name: 'instagram_cta_title', value: s.instagram_cta_title, maxlength: 100 })}
${field({ label: 'Chamada do Instagram — texto', name: 'instagram_cta_text', value: s.instagram_cta_text, maxlength: 200 })}`;
      },
    },
    pedidos: {
      keys: ['pix_expiry_minutes', 'reservation_grace_minutes'],
      validate(b, out) {
        if (out.pix_expiry_minutes !== '') {
          const n = int(out.pix_expiry_minutes, NaN);
          if (!Number.isInteger(n) || n < 10 || n > 1440) throw new UserError('O prazo do Pix deve ficar entre 10 e 1440 minutos.');
          out.pix_expiry_minutes = String(n);
        }
        const g = int(out.reservation_grace_minutes, NaN);
        if (!Number.isInteger(g) || g < 0 || g > 120) throw new UserError('A tolerância da reserva deve ficar entre 0 e 120 minutos.');
        out.reservation_grace_minutes = String(g);
      },
      render(ctx, s) {
        return html`<p class="muted small">As peças ficam reservadas para o cliente durante o prazo do Pix mais uma pequena tolerância (para pagamentos feitos no último minuto). Depois disso, o pedido expira e as peças voltam à loja.</p>
<div class="grid2">${field({ label: 'Prazo para pagar o Pix (minutos)', name: 'pix_expiry_minutes', type: 'number', value: s.pix_expiry_minutes, attrs: 'min="10" max="1440"', hint: `Em branco usa o padrão do servidor (${cfg.payment.pixExpiryMinutes} min). Entre 10 e 1440.` })}${field({ label: 'Tolerância da reserva (minutos)', name: 'reservation_grace_minutes', type: 'number', value: s.reservation_grace_minutes, required: true, attrs: 'min="0" max="120"' })}</div>
<p><a href="/admin/pagamentos">Ver a situação do provedor de pagamentos →</a></p>`;
      },
    },
    email: {
      keys: ['admin_notify_email', 'email_from_name', 'email_from_address', 'email_reply_to'],
      validate(b, out) {
        for (const k of ['admin_notify_email', 'email_from_address', 'email_reply_to']) if (out[k] && !validEmail(out[k])) throw new UserError('Confira os e-mails informados.');
      },
      render(ctx, s) {
        const t = cfg.email.transport;
        const live = t === 'resend' && cfg.email.resendApiKey;
        const sender = app.email.sender();
        return html`<div class="flash ${live ? 'flash-success' : 'flash-info'}">${icon(live ? 'check' : 'alert', 18)}<span>${live ? 'Envio de e-mails ativo (Resend).' : 'O envio real de e-mails ainda não está configurado no servidor: os e-mails ficam apenas registrados no histórico. Configure RESEND_API_KEY e um remetente de domínio verificado.'}${sender ? html` Remetente atual: <strong>${sender}</strong>` : html` <strong>Nenhum remetente definido.</strong>`}</span></div>
${field({ label: 'Receber avisos de novos pedidos e mensagens em', name: 'admin_notify_email', type: 'email', value: s.admin_notify_email, hint: 'Se vazio, usa o e-mail de contato da loja. É apenas para AVISOS ao proprietário.' })}
<div class="grid2">${field({ label: 'Nome do remetente', name: 'email_from_name', value: s.email_from_name, placeholder: s.store_name })}${field({ label: 'E-mail do remetente', name: 'email_from_address', type: 'email', value: s.email_from_address, hint: 'Precisa pertencer a um domínio verificado no Resend (com SPF/DKIM).' })}</div>
${field({ label: 'Responder para (reply-to)', name: 'email_reply_to', type: 'email', value: s.email_reply_to, hint: 'Para onde vão as respostas dos clientes. Receber e-mails (caixa de entrada) é um serviço separado do envio: use o provedor de e-mail do seu domínio.' })}`;
      },
    },
  };

  const FILES = ['logo_file', 'hero_image'];

  // ───── páginas ─────
  router.get('/admin/configuracoes', (ctx) => {
    const aba = TABS.some(([k]) => k === ctx.query.aba) ? ctx.query.aba : 'loja';
    const s = s0();
    let body;
    if (aba === 'entrega') body = shippingTab(ctx);
    else {
      const f = FORMS[aba];
      body = html`<section class="card"><form method="post" action="/admin/configuracoes/${aba}" class="stack">${csrfField(ctx)}${f.render(ctx, s)}<div class="sticky-actions"><button class="btn" type="submit">Salvar configurações</button></div></form></section>${aba === 'email' ? templatesCard(ctx) : ''}`;
    }
    h.page(ctx, 'Configurações', html`${tabNav(aba)}${body}`);
  }, h.S('settings.manage'));

  router.post('/admin/configuracoes/:aba', (ctx) => {
    const aba = ctx.params.aba;
    const f = FORMS[aba];
    if (!f) return ctx.fail(404, 'Seção não encontrada.');
    h.act(ctx, `/admin/configuracoes?aba=${aba}`, () => {
      const out = {};
      for (const k of f.keys) {
        if (FILES.includes(k)) continue;
        out[k] = trunc(ctx.body[k], k === 'about_text' ? 2000 : 300);
      }
      f.validate(ctx.body, out);
      for (const k of FILES.filter((x) => f.keys.includes(x))) {
        if (ctx.body[`${k}__remove`]) out[k] = '';
        else if (ctx.body[k] && /^[a-f0-9]{24}\.(jpg|png|webp|gif)$/.test(ctx.body[k])) out[k] = ctx.body[k];
      }
      app.settings.setMany(out);
      app.audit.staff(ctx, 'settings.updated', 'settings', aba, { keys: Object.keys(out) });
    }, 'Configurações salvas.');
  }, h.S('settings.manage'));

  // ───── modelos de e-mail ─────
  const templatesCard = (ctx) => html`<section class="card"><h2>Textos dos e-mails</h2>
<p class="muted small">Você pode ajustar o assunto e a frase de abertura. Os dados do pedido, valores e links são inseridos automaticamente. Use <code>{{pedido}}</code> e <code>{{loja}}</code> nos assuntos. Pagamento e confirmação de conta são sempre enviados.</p>
${L.table(['E-mail', 'Assunto', 'Enviar?', ''], Object.entries(app.email.TEMPLATES).filter(([k]) => k !== 'admin_notice').map(([k, t]) => { const c = app.email.templateSettings(k); return html`<tr><td>${t.label}</td><td class="small">${c.subject}</td><td>${c.enabled ? badge('Sim', 'good') : badge('Não', 'neutral')}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/configuracoes/email/${k}">Editar</a></td></tr>`; }))}</section>`;

  router.get('/admin/configuracoes/email/:key', (ctx) => {
    const t = app.email.TEMPLATES[ctx.params.key];
    if (!t || ctx.params.key === 'admin_notice') return ctx.fail(404, 'Modelo não encontrado.');
    const c = app.email.templateSettings(ctx.params.key);
    const locked = ['verify_email', 'reset_password'].includes(ctx.params.key);
    h.page(ctx, `E-mail: ${t.label}`, html`${tabNav('email')}<section class="card narrow-lg"><form method="post" action="/admin/configuracoes/email/${ctx.params.key}" class="stack">${csrfField(ctx)}
${field({ label: 'Assunto', name: 'subject', value: c.subject, required: true, maxlength: 120 })}
<div class="field"><label for="intro">Frase de abertura</label><textarea id="intro" name="intro" rows="3" maxlength="400">${c.intro}</textarea></div>
${locked ? html`<p class="muted small">Este e-mail é essencial para a segurança da conta e sempre é enviado.</p>` : html`<label class="check"><input type="checkbox" name="enabled" value="1" ${c.enabled ? raw('checked') : ''}> Enviar este e-mail</label>`}
<div class="row-actions-wrap"><button class="btn" type="submit">Salvar</button><a class="btn btn-ghost" href="/admin/configuracoes?aba=email">Voltar</a></div></form>
<form method="post" action="/admin/configuracoes/email/${ctx.params.key}/restaurar" data-confirm="Voltar ao texto original?">${csrfField(ctx)}<button class="btn btn-ghost btn-small" type="submit">Restaurar texto original</button></form></section>`);
  }, h.S('settings.manage'));
  router.post('/admin/configuracoes/email/:key', (ctx) => h.act(ctx, '/admin/configuracoes?aba=email', () => {
    const key = ctx.params.key;
    if (!app.email.TEMPLATES[key] || key === 'admin_notice') throw new UserError('Modelo não encontrado.');
    const subject = trunc(ctx.body.subject, 120);
    if (subject.length < 3) throw new UserError('Informe o assunto.');
    const enabled = ['verify_email', 'reset_password'].includes(key) ? 1 : ctx.body.enabled ? 1 : 0;
    app.db.run('INSERT INTO email_templates (key, subject, intro, enabled) VALUES (?,?,?,?) ON CONFLICT(key) DO UPDATE SET subject = excluded.subject, intro = excluded.intro, enabled = excluded.enabled', key, subject, trunc(ctx.body.intro, 400), enabled);
    app.audit.staff(ctx, 'email_template.updated', 'email_template', key);
  }, 'Modelo de e-mail salvo.'), h.S('settings.manage'));
  router.post('/admin/configuracoes/email/:key/restaurar', (ctx) => h.act(ctx, '/admin/configuracoes?aba=email', () => { app.db.run('DELETE FROM email_templates WHERE key = ?', ctx.params.key); app.audit.staff(ctx, 'email_template.reset', 'email_template', ctx.params.key); }, 'Texto original restaurado.'), h.S('settings.manage'));

  // ───── entrega ─────
  const shippingTab = (ctx) => {
    const methods = app.shipping.methods(true);
    const ps = app.shipping.providerStatus();
    const editing = ctx.query.editar ? app.shipping.method(int(ctx.query.editar)) : null;
    const showForm = editing || ctx.query.novo;
    const conf = editing ? app.shipping.parseConfig(editing.config) : {};
    const m = editing || {};
    return html`
<section class="card"><h2>Formas de entrega</h2>
<p class="muted small">Só as formas cadastradas aqui aparecem no checkout. Valores e prazos são os que VOCÊ define, ou os cotados pelo Melhor Envio; o sistema não inventa preços.</p>
${L.table(['Nome', 'Tipo', 'Valor', 'Prazo exibido', 'Situação', ''], methods.map((x) => html`<tr><td><strong>${x.name}</strong></td><td>${app.shipping.KINDS[x.kind]}</td><td>${['melhorenvio', 'correios'].includes(x.kind) ? 'Cotação' : x.kind === 'pickup' ? 'Grátis' : x.price_cents ? money(x.price_cents) : 'Grátis'}${x.free_over_cents ? html`<br><small class="muted">Grátis acima de ${money(x.free_over_cents)}</small>` : ''}</td><td class="small">${x.eta_text || '—'}</td><td>${x.active ? badge('Ativa', 'good') : badge('Inativa', 'neutral')}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/configuracoes?aba=entrega&editar=${x.id}">Editar</a></td></tr>`), { empty: 'Nenhuma forma de entrega cadastrada. Sem isso o cliente não consegue finalizar a compra.' })}
${showForm ? '' : html`<p><a class="btn" href="/admin/configuracoes?aba=entrega&novo=1">${icon('plus', 16)} Nova forma de entrega</a></p>`}</section>
${showForm ? html`<section class="card"><h2>${editing ? `Editar: ${editing.name}` : 'Nova forma de entrega'}</h2>
<form method="post" action="/admin/configuracoes/entrega/metodos${editing ? `/${editing.id}` : ''}" class="stack">${csrfField(ctx)}
<div class="grid2">${field({ label: 'Nome exibido ao cliente', name: 'name', value: m.name, required: true, maxlength: 80, placeholder: 'Retirar na loja, Correios PAC…' })}${selectField({ label: 'Tipo', name: 'kind', value: m.kind || 'fixed', options: Object.entries(app.shipping.KINDS).map(([value, label]) => ({ value, label })), blank: null, required: true })}</div>
<div class="grid3">${field({ label: 'Valor (R$)', name: 'price', value: m.price_cents ? centsToInput(m.price_cents) : '', inputmode: 'decimal', hint: 'Frete fixo e entrega local. Em branco = grátis.' })}${field({ label: 'Grátis a partir de (R$)', name: 'free_over', value: m.free_over_cents ? centsToInput(m.free_over_cents) : '', inputmode: 'decimal' })}${field({ label: 'Ordem', name: 'sort_order', type: 'number', value: m.sort_order ?? 0 })}</div>
${field({ label: 'Prazo exibido', name: 'eta_text', value: m.eta_text, maxlength: 120, placeholder: 'Informe só o que for real', hint: 'Texto livre (ex.: “combinar pelo WhatsApp”). Em branco = não mostra prazo.' })}
${field({ label: 'Entrega local — prefixos de CEP atendidos', name: 'zip_prefixes', value: conf.zip_prefixes || '', maxlength: 200, hint: 'Só para “Entrega local”. Ex.: 13000, 13010 (separados por vírgula). Em branco = qualquer CEP.' })}
<details class="defs"><summary>Opções do Melhor Envio</summary><div class="grid3">${field({ label: 'Largura da caixa (cm)', name: 'width', type: 'number', value: conf.width })}${field({ label: 'Altura (cm)', name: 'height', type: 'number', value: conf.height })}${field({ label: 'Comprimento (cm)', name: 'length', type: 'number', value: conf.length })}</div>
<div class="grid3">${field({ label: 'Peso padrão por peça (g)', name: 'default_weight_g', type: 'number', value: conf.default_weight_g, hint: 'Usado quando a peça não tem peso cadastrado.' })}${field({ label: 'Dias extras de preparo', name: 'extra_days', type: 'number', value: conf.extra_days })}${field({ label: 'Serviços (códigos)', name: 'services', value: (conf.services || []).join(', '), hint: 'IDs de serviços do Melhor Envio, separados por vírgula. Em branco = todos.' })}</div></details>
<label class="check"><input type="checkbox" name="active" value="1" ${!editing || editing.active ? raw('checked') : ''}> Forma de entrega ativa</label>
<div class="row-actions-wrap"><button class="btn" type="submit">Salvar</button><a class="btn btn-ghost" href="/admin/configuracoes?aba=entrega">Cancelar</a></div></form>
${editing ? html`<form method="post" action="/admin/configuracoes/entrega/metodos/${editing.id}/excluir" data-confirm="Excluir esta forma de entrega? Se já foi usada em pedidos, ela será apenas desativada.">${csrfField(ctx)}<button class="btn btn-danger btn-small" type="submit">Excluir</button></form>` : ''}</section>` : ''}
<section class="card"><h2>Integrações de frete</h2><ul class="status-list">
<li><span>Melhor Envio</span>${ps.melhorenvio.configured ? badge(`Configurado (${ps.melhorenvio.env})`, 'good') : badge('Não configurado', 'warn')}</li>
<li><span>Correios (contrato próprio)</span>${badge('Ainda não integrado', 'neutral')}</li></ul>
${ps.melhorenvio.configured ? '' : html`<p class="muted small">Para cotar frete em tempo real, configure no servidor: ${ps.melhorenvio.missing.join(', ')}. Até lá, use frete fixo, retirada ou entrega local. Cotações do Correios podem ser feitas pelo Melhor Envio.</p>`}
<p class="muted small">Atenção: a integração com o Melhor Envio foi escrita conforme a documentação, mas só pode ser validada com o seu token real; teste uma cotação no checkout antes de divulgar a loja.</p></section>`;
  };

  const saveMethod = (ctx, id) => h.act(ctx, '/admin/configuracoes?aba=entrega', () => {
    const body = { ...ctx.body, active: !!ctx.body.active };
    const saved = app.shipping.saveMethod(body, id);
    app.audit.staff(ctx, id ? 'shipping.updated' : 'shipping.created', 'shipping_method', saved, { name: body.name, kind: body.kind });
  }, 'Forma de entrega salva.');
  router.post('/admin/configuracoes/entrega/metodos', (ctx) => saveMethod(ctx, null), h.S('settings.manage'));
  router.post('/admin/configuracoes/entrega/metodos/:id', (ctx) => saveMethod(ctx, int(ctx.params.id)), h.S('settings.manage'));
  router.post('/admin/configuracoes/entrega/metodos/:id/excluir', (ctx) => h.act(ctx, '/admin/configuracoes?aba=entrega', () => { const r = app.shipping.deleteMethod(int(ctx.params.id)); app.audit.staff(ctx, 'shipping.deleted', 'shipping_method', ctx.params.id, { result: r }); return r; }, (r) => (r === 'deactivated' ? 'A forma de entrega já tinha pedidos e foi apenas desativada.' : 'Forma de entrega excluída.')), h.S('settings.manage'));

  // ───── situação dos pagamentos ─────
  router.get('/admin/pagamentos', (ctx) => {
    const p = app.payments.status();
    const events = app.db.all('SELECT * FROM payment_events ORDER BY id DESC LIMIT 25');
    const stats = app.db.get("SELECT SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, SUM(CASE WHEN status IN ('paid','partially_refunded','refunded') THEN 1 ELSE 0 END) AS paid FROM payments");
    const failedEv = app.db.value("SELECT COUNT(*) FROM payment_events WHERE status = 'failed'");
    const hook = p.name === 'none' ? '' : `${cfg.baseUrl}/webhooks/${p.name}`;
    const why = { none: 'Nenhum provedor de Pix configurado. Defina PAYMENT_PROVIDER (asaas ou mercadopago) e as credenciais no servidor.', mock: 'Provedor SIMULADO (apenas desenvolvimento e testes). Nenhum dinheiro real é movimentado.' };
    h.page(ctx, 'Pagamentos (Pix)', html`
<section class="card"><h2>Provedor</h2>
<ul class="status-list">
<li><span>Provedor ativo</span><b>${p.label}</b></li>
<li><span>Credenciais</span>${p.configured ? badge('Configuradas', 'good') : badge(`Faltando: ${p.missing.join(', ') || '—'}`, 'bad')}</li>
<li><span>Ambiente</span>${p.sandbox ? badge('TESTE (sandbox) — sem dinheiro real', 'warn') : badge('Produção', 'good')}</li>
<li><span>Webhook protegido por segredo</span>${p.webhookReady ? badge('Sim', 'good') : badge('Não — configure o segredo do webhook', 'bad')}</li></ul>
${why[p.name] ? html`<p class="notice-inline">${why[p.name]}</p>` : ''}
${hook ? html`<p>Endereço do webhook a cadastrar no painel do provedor:<br><code class="copyable">${hook}</code></p><p class="muted small">O endereço precisa ser público e em HTTPS. O sistema só marca um pedido como pago depois de consultar o provedor e conferir pedido, valor e moeda. Chaves e segredos ficam em variáveis de ambiente do servidor e não aparecem aqui.</p>` : ''}
</section>
<section class="card"><h2>Resumo</h2><div class="kpis kpis-sm">${L.kpi('Pix pendentes', String(stats.pending || 0))}${L.kpi('Pagamentos confirmados', String(stats.paid || 0))}${L.kpi('Eventos com falha', String(failedEv), '', failedEv ? 'warn' : '')}</div>
<div class="row-actions-wrap"><form method="post" action="/admin/pagamentos/conciliar">${csrfField(ctx)}<button class="btn btn-ghost" type="submit" ${p.configured ? '' : raw('disabled')}>${icon('refresh', 16)} Conferir Pix pendentes no provedor</button></form></div>
<p class="muted small">A conferência consulta o provedor para cada Pix pendente (rede de segurança caso algum webhook tenha falhado). Não existe baixa manual de pagamento.</p></section>
<section class="card"><h2>Últimos eventos recebidos</h2>${L.table(['Recebido', 'Provedor', 'Evento', 'Pagamento', 'Resultado', 'Detalhe'], events.map((e) => html`<tr><td>${h.ago(e.received_at)}</td><td>${e.provider}</td><td class="small">${e.event_type || '—'}</td><td class="small">${e.provider_payment_id || '—'}</td><td>${badge({ done: 'Processado', failed: 'Falhou', ignored: 'Ignorado', processing: 'Processando' }[e.status] || e.status, { done: 'good', failed: 'bad', ignored: 'neutral', processing: 'warn' }[e.status])}</td><td class="small">${e.error || ''}</td></tr>`), { empty: 'Nenhum evento recebido ainda.' })}</section>`);
  }, h.S('settings.payments'));
  router.post('/admin/pagamentos/conciliar', (ctx) => h.act(ctx, '/admin/pagamentos', async () => { const r = await app.payments.reconcile(); app.audit.staff(ctx, 'payment.reconcile', 'payment', 'all', r); return r; }, (r) => `${r.checked} Pix conferido(s); ${r.paid} confirmado(s).`), h.S('settings.payments'));
}

module.exports = { register };
