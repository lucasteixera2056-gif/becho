# Ligando o Pix (Asaas ou Mercado Pago)

A loja funciona com **um provedor por vez**, escolhido em `PAYMENT_PROVIDER`. Sem provedor configurado a vitrine abre, mas **o checkout não finaliza pedidos** (o painel avisa).
Chaves e segredos ficam **só nas variáveis de ambiente do servidor** (`.env`): não aparecem em página nenhuma nem no navegador do cliente.

> **Aviso honesto:** as duas integrações foram escritas conforme a documentação pública dos provedores e testadas com um provedor **simulado**. Só dá para garantir que funcionam depois do **roteiro de teste no sandbox** abaixo, com a **sua conta**. Taxas, prazos de liquidação e exigências cadastrais são do provedor — consulte-os; este projeto não fixa nenhum valor.

## Como a loja confirma um pagamento (igual nos dois provedores)

1. No fechamento do pedido, a loja cria **uma cobrança Pix por pedido** no provedor e mostra o **QR Code** e o **copia e cola**.
2. O provedor avisa a loja por **webhook** em `https://SEU-DOMINIO/webhooks/asaas` (ou `/webhooks/mercadopago`).
3. A loja só confia no aviso se ele for **autêntico** (segredo/assinatura). Mesmo assim, **não usa o corpo do aviso**: ela **consulta o provedor** e só marca como pago se o **pedido, o valor e a moeda** conferem.
4. Cada evento é registrado uma única vez (aviso repetido não baixa estoque nem envia e-mail de novo).
5. Se o aviso nunca chegar, a rotina interna **consulta os Pix pendentes a cada 30 s** — o pagamento é reconhecido de qualquer forma.
6. Quando vence o prazo (padrão 30 min; em Configurações → Pedidos e Pix), a loja cancela o pedido e libera a peça. Se o cliente pagar **depois**, o sistema reativa o pedido se a peça ainda estiver livre; se já foi vendida a outra pessoa, **marca o pedido para reembolso**.

Tela de acompanhamento: **Painel → Pagamentos (Pix)** (provedor, ambiente teste/produção, webhook protegido?, últimos eventos, botão de conferência).

---

## Opção A — Asaas

**Variáveis:** `PAYMENT_PROVIDER=asaas`, `ASAAS_ENV=sandbox|production`, `ASAAS_API_KEY`, `ASAAS_WEBHOOK_TOKEN`.

1. Crie a conta de **teste** em `sandbox.asaas.com` (separada da conta real) e gere a **chave de API** em *Integrações*.
2. Invente um **token de webhook** longo e aleatório (por exemplo `node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"`) e coloque em `ASAAS_WEBHOOK_TOKEN`.
3. No painel do Asaas, em *Integrações → Webhooks*, cadastre a URL `https://SEU-DOMINIO/webhooks/asaas`, com o **mesmo token** no campo de autenticação, e marque os eventos de **pagamento** (`PAYMENT_*`). O Asaas devolve esse token no cabeçalho `asaas-access-token`; a loja compara e recusa o que não bater.
4. O Asaas **exige CPF do pagador**: o checkout passa a pedir CPF (validado) e a loja o guarda **cifrado**.
5. Para produção: troque para `ASAAS_ENV=production` e use a chave da conta real. Confira no Asaas se é necessário ter **chave Pix** cadastrada e conta aprovada para gerar Pix.

## Opção B — Mercado Pago

**Variáveis:** `PAYMENT_PROVIDER=mercadopago`, `MP_ACCESS_TOKEN`, `MP_WEBHOOK_SECRET`.

1. Em *Suas integrações* (developers do Mercado Pago), crie uma aplicação e copie o **Access Token**. Credenciais de teste começam com `TEST-` e o painel passa a mostrar “modo TESTE”.
2. Em *Webhooks*, cadastre `https://SEU-DOMINIO/webhooks/mercadopago`, marque o evento de **Pagamentos** e copie a **assinatura secreta** para `MP_WEBHOOK_SECRET`. (O webhook só é considerado protegido com HTTPS.)
3. O CPF do pagador é opcional neste provedor.
4. O Mercado Pago pode exigir validade mínima do Pix; a loja usa uma folga e controla o prazo real.

> **Ponto a validar (Mercado Pago):** o formato exato do texto assinado (`id:<data.id>;request-id:<x-request-id>;ts:<ts>;`) segue a prática descrita por implementações da comunidade; a página oficial que consegui abrir descreve o cabeçalho `x-signature` (`ts=…,v1=…`) e o segredo, mas **não** traz o texto assinado. **Teste no sandbox.** Se a assinatura for recusada, o painel mostra “assinatura inválida” em *Últimos eventos* e **nenhum pedido é marcado como pago pelo webhook** — mas a consulta automática a cada 30 s continua reconhecendo os pagamentos.

---

## Roteiro de teste no sandbox (faça antes de vender)

1. Suba a loja com HTTPS público (`docs/PUBLICACAO.md`) e as credenciais de **teste**.
2. Em *Pagamentos (Pix)* confira: “Credenciais: Configuradas”, “Ambiente: TESTE”, “Webhook protegido: Sim”.
3. Faça um pedido de uma peça de teste → deve aparecer o QR Code e o copia e cola.
4. Pague pelo simulador do provedor → o pedido deve ir para **Pagamento confirmado** em segundos, o estoque baixar e o e-mail sair.
5. Em *Últimos eventos* deve haver um evento **Processado**. Reenvie o mesmo evento pelo painel do provedor: deve ficar **Ignorado** (idempotência), sem segundo e-mail.
6. Deixe um Pix **expirar**: o pedido deve ser cancelado e a peça voltar à vitrine.
7. Faça um **reembolso** de um pedido de teste (total e parcial) e confira em *Relatórios*.
8. Só então troque para as credenciais de **produção**, faça **um pedido real de baixo valor** com você mesma e reembolse.

## Reembolsos e taxas

- Reembolso: **Pedidos → pedido → Reembolsar** (total/parcial, com motivo e opção de devolver a peça ao estoque). É executado no provedor.
- **Taxa e líquido** só aparecem nos relatórios quando o provedor **informa**; a loja nunca estima.
- Liquidação (quando o dinheiro cai): a loja mostra a data **que o provedor informa**; a conferência final é sempre no extrato do provedor.
