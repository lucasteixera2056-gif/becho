'use strict';
/** Área do cliente (/minha-conta): cadastro, login, confirmação de e-mail, recuperação de senha, perfil, endereços, pedidos e dados (LGPD). */
const { html, raw } = require('../lib/html');
const { money, UserError, formatDate, formatZip, formatPhone, UFS, int } = require('../lib/util');
const { icon, csrfField, field, selectField, badge } = require('./ui');
const { storeLayout } = require('./layout');

function register(router, app) {
  const { cfg } = app;
  const page = (ctx, title, main, o = {}) => ctx.html(storeLayout(ctx, app, { title, main, noindex: true, noFloatingWa: true, ...o }), o.status || 200);
  const safeNext = (n) => (typeof n === 'string' && /^\/(?!\/)[^\s]*$/.test(n) && !n.startsWith('/admin') ? n : '/minha-conta');

  const guard = (ctx, fn, onErr) => async () => {
    try { return await fn(); } catch (e) { if (!(e instanceof UserError)) throw e; return onErr(e); }
  };

  // ───── entrar ─────
  const loginForm = (ctx, v = {}, error = '') => html`<section class="wrap narrow auth"><h1>Entrar</h1>
<p class="muted">Acompanhe seus pedidos e salve seus endereços. Você também pode comprar sem criar conta.</p>
${error ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${error}</span></div>` : ''}
<form method="post" action="/minha-conta/entrar" class="form-card">${csrfField(ctx)}<input type="hidden" name="next" value="${v.next || ''}">
${field({ label: 'E-mail', name: 'email', type: 'email', value: v.email, required: true, autocomplete: 'username' })}
${field({ label: 'Senha', name: 'password', type: 'password', required: true, autocomplete: 'current-password' })}
<button class="btn btn-block" type="submit">Entrar</button>
<p class="center small"><a href="/minha-conta/esqueci-senha">Esqueci minha senha</a> · <a href="/minha-conta/cadastrar">Criar conta</a></p></form></section>`;

  router.get('/minha-conta/entrar', (ctx) => (ctx.customer ? ctx.redirect('/minha-conta') : page(ctx, 'Entrar', loginForm(ctx, { next: safeNext(ctx.query.next) }))));
  router.post('/minha-conta/entrar', async (ctx) => {
    const b = ctx.body;
    await guard(ctx, async () => {
      await app.auth.login(ctx, b.email, b.password);
      ctx.redirect(safeNext(b.next));
    }, (e) => page(ctx, 'Entrar', loginForm(ctx, { email: b.email, next: b.next }, e.message), { status: 422 }))();
  });

  // ───── cadastro ─────
  const signupForm = (ctx, v = {}, err = {}) => html`<section class="wrap narrow auth"><h1>Criar conta</h1>
<form method="post" action="/minha-conta/cadastrar" class="form-card" novalidate>${csrfField(ctx)}
${field({ label: 'Nome completo', name: 'name', value: v.name, required: true, autocomplete: 'name', error: err.name })}
${field({ label: 'E-mail', name: 'email', type: 'email', value: v.email, required: true, autocomplete: 'email', error: err.email })}
${field({ label: 'Telefone / WhatsApp', name: 'phone', type: 'tel', value: v.phone, autocomplete: 'tel', error: err.phone })}
${field({ label: 'Senha', name: 'password', type: 'password', required: true, autocomplete: 'new-password', error: err.password, hint: 'Mínimo de 8 caracteres.' })}
${field({ label: 'Confirmar senha', name: 'confirm', type: 'password', required: true, autocomplete: 'new-password', error: err.confirm })}
<label class="check"><input type="checkbox" name="marketing" value="1" ${v.marketing ? raw('checked') : ''}> Quero receber novidades por e-mail <span class="muted">(opcional)</span></label>
<p class="small muted">Ao criar a conta você concorda com os <a href="/p/termos-de-uso" target="_blank">Termos</a> e a <a href="/p/politica-de-privacidade" target="_blank">Política de Privacidade</a>.</p>
<button class="btn btn-block" type="submit">Criar conta</button>
<p class="center small">Já tem conta? <a href="/minha-conta/entrar">Entrar</a></p></form></section>`;
  router.get('/minha-conta/cadastrar', (ctx) => (ctx.customer ? ctx.redirect('/minha-conta') : page(ctx, 'Criar conta', signupForm(ctx))));
  router.post('/minha-conta/cadastrar', async (ctx) => {
    const b = ctx.body;
    await guard(ctx, async () => {
      await app.auth.register(ctx, { name: b.name, email: b.email, password: b.password, confirm: b.confirm, phone: b.phone, marketing: !!b.marketing });
      // Resposta idêntica para e-mail novo ou já existente.
      page(ctx, 'Confirme seu e-mail', html`<section class="wrap narrow center"><h1>Quase lá!</h1><p>Se o e-mail informado puder ser usado, enviamos uma mensagem com as próximas instruções. Confira também a caixa de spam.</p><p><a class="btn" href="/loja">Continuar comprando</a></p></section>`);
    }, (e) => page(ctx, 'Criar conta', signupForm(ctx, b, { [e.field || 'email']: e.message }), { status: 422 }))();
  });

  router.get('/minha-conta/confirmar-email/:token', (ctx) => {
    const ok = app.auth.verifyEmail(ctx.params.token);
    page(ctx, 'Confirmar e-mail', html`<section class="wrap narrow center"><h1>${ok ? 'E-mail confirmado!' : 'Link inválido ou expirado'}</h1><p>${ok ? 'Sua conta está ativa. Agora você pode entrar.' : 'Entre na sua conta e peça um novo link de confirmação.'}</p><p><a class="btn" href="/minha-conta/entrar">Entrar</a></p></section>`);
  });

  // ───── senha ─────
  router.get('/minha-conta/esqueci-senha', (ctx) => page(ctx, 'Recuperar senha', html`<section class="wrap narrow auth"><h1>Recuperar senha</h1><form method="post" action="/minha-conta/esqueci-senha" class="form-card">${csrfField(ctx)}${field({ label: 'E-mail da conta', name: 'email', type: 'email', required: true, autocomplete: 'email' })}<button class="btn btn-block" type="submit">Enviar link</button></form></section>`));
  router.post('/minha-conta/esqueci-senha', async (ctx) => {
    await guard(ctx, async () => {
      app.auth.requestPasswordReset(ctx, ctx.body.email);
      page(ctx, 'Recuperar senha', html`<section class="wrap narrow center"><h1>Verifique seu e-mail</h1><p>Se existir uma conta com esse e-mail, enviamos um link para criar uma nova senha. O link vale por 1 hora.</p></section>`);
    }, (e) => { ctx.flash('error', e.message); ctx.redirect('/minha-conta/esqueci-senha'); })();
  });
  const resetForm = (ctx, token, error = '') => html`<section class="wrap narrow auth"><h1>Nova senha</h1>${error ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${error}</span></div>` : ''}<form method="post" action="/minha-conta/redefinir-senha/${token}" class="form-card">${csrfField(ctx)}${field({ label: 'Nova senha', name: 'password', type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo de 8 caracteres.' })}${field({ label: 'Confirmar nova senha', name: 'confirm', type: 'password', required: true, autocomplete: 'new-password' })}<button class="btn btn-block" type="submit">Salvar senha</button></form></section>`;
  router.get('/minha-conta/redefinir-senha/:token', (ctx) => {
    if (!app.auth.tokenIsValid(ctx.params.token, 'reset_password')) return page(ctx, 'Link expirado', html`<section class="wrap narrow center"><h1>Link inválido ou expirado</h1><p><a class="btn" href="/minha-conta/esqueci-senha">Pedir novo link</a></p></section>`, { status: 410 });
    page(ctx, 'Nova senha', resetForm(ctx, ctx.params.token));
  });
  router.post('/minha-conta/redefinir-senha/:token', async (ctx) => {
    await guard(ctx, async () => {
      await app.auth.resetPassword(ctx, ctx.params.token, ctx.body.password, ctx.body.confirm);
      ctx.flash('success', 'Senha alterada. Entre com a nova senha.');
      ctx.redirect('/minha-conta/entrar');
    }, (e) => page(ctx, 'Nova senha', resetForm(ctx, ctx.params.token, e.message), { status: 422 }))();
  });

  router.post('/minha-conta/sair', (ctx) => { app.auth.logout(ctx); ctx.flash('success', 'Você saiu da conta.'); ctx.redirect('/'); });

  // ───── área logada ─────
  const nav = (cur) => html`<nav class="account-nav" aria-label="Minha conta">${[['/minha-conta', 'Resumo'], ['/minha-conta/pedidos', 'Pedidos'], ['/minha-conta/enderecos', 'Endereços'], ['/minha-conta/perfil', 'Perfil e senha'], ['/minha-conta/dados', 'Meus dados']].map(([h, l]) => html`<a href="${h}" ${h === cur ? raw('aria-current="page"') : ''}>${l}</a>`)}</nav>`;
  const shell = (ctx, cur, title, body) => page(ctx, title, html`<section class="wrap account"><h1>${title}</h1><div class="account-grid"><div>${nav(cur)}<form method="post" action="/minha-conta/sair" class="logout">${csrfField(ctx)}<button class="linklike" type="submit">Sair da conta</button></form></div><div>${body}</div></div></section>`);
  const C = { customer: true };

  const verifyBanner = (ctx) => (ctx.customer.email_verified_at ? '' : html`<div class="notice notice-defects"><strong>Confirme seu e-mail</strong><p>Enviamos um link para ${ctx.customer.email}. Seus pedidos só aparecem aqui depois da confirmação.</p><form method="post" action="/minha-conta/reenviar-confirmacao">${csrfField(ctx)}<button class="btn btn-small" type="submit">Reenviar e-mail de confirmação</button></form></div>`);

  const orderRow = (ctx, o) => html`<li class="order-row"><div><strong>${o.number}</strong><small class="muted">${formatDate(o.created_at, { offsetMinutes: cfg.tzOffsetMinutes })}</small></div><span class="status status-${['cancelled', 'refunded'].includes(o.status) ? 'bad' : o.status === 'awaiting_payment' ? 'warn' : 'good'}">${app.orders.statusLabel(o.status, o.delivery_kind)}</span><b>${money(o.total_cents)}</b><a class="btn btn-small btn-ghost" href="/minha-conta/pedidos/${o.number}">Ver</a></li>`;

  router.get('/minha-conta', (ctx) => {
    const c = ctx.customer;
    const orders = c.email_verified_at ? app.orders.forCustomer(c.id) : [];
    shell(ctx, '/minha-conta', `Olá, ${c.name.split(' ')[0]}`, html`${verifyBanner(ctx)}
      <h2>Pedidos recentes</h2>${orders.length ? html`<ul class="order-list">${orders.slice(0, 5).map((o) => orderRow(ctx, o))}</ul>${orders.length > 5 ? html`<p><a href="/minha-conta/pedidos">Ver todos</a></p>` : ''}` : html`<p class="muted">${c.email_verified_at ? 'Você ainda não fez pedidos.' : 'Confirme seu e-mail para ver seus pedidos.'}</p>`}`);
  }, C);
  router.post('/minha-conta/reenviar-confirmacao', (ctx) => {
    try { app.auth.resendVerification(ctx, ctx.customer); ctx.flash('success', 'Enviamos um novo link de confirmação.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect('/minha-conta');
  }, C);

  router.get('/minha-conta/pedidos', (ctx) => {
    const c = ctx.customer;
    const orders = c.email_verified_at ? app.orders.forCustomer(c.id) : [];
    shell(ctx, '/minha-conta/pedidos', 'Meus pedidos', html`${verifyBanner(ctx)}${orders.length ? html`<ul class="order-list">${orders.map((o) => orderRow(ctx, o))}</ul>` : html`<p class="muted">Nenhum pedido por aqui ainda.</p>`}`);
  }, C);

  router.get('/minha-conta/pedidos/:number', (ctx) => {
    const o = app.orders.ownedBy(ctx.customer, ctx.params.number);
    if (!o) return ctx.fail(404, 'Pedido não encontrado.');
    const reqs = app.db.all('SELECT * FROM support_requests WHERE order_id = ? AND customer_id = ? ORDER BY id DESC', o.id, ctx.customer.id);
    const items = app.orders.items(o.id);
    shell(ctx, '/minha-conta/pedidos', `Pedido ${o.number}`, html`
      <p><span class="status status-${['cancelled', 'refunded'].includes(o.status) ? 'bad' : o.status === 'awaiting_payment' ? 'warn' : 'good'}">${app.orders.statusLabel(o.status, o.delivery_kind)}</span> · ${money(o.total_cents)}</p>
      <ul class="mini-items">${items.map((i) => html`<li><span>${i.name}${i.qty > 1 ? ` × ${i.qty}` : ''}</span><b>${money(i.unit_cents * i.qty)}</b></li>`)}</ul>
      <p><a class="btn" href="/pedido/${o.public_token}">Ver acompanhamento${o.status === 'awaiting_payment' ? ' e pagar' : ''}</a></p>
      ${['paid', 'preparing', 'shipped', 'in_transit', 'delivered'].includes(o.status) ? html`<h2>Precisa de ajuda com este pedido?</h2>
      <form method="post" action="/minha-conta/pedidos/${o.number}/solicitacao" class="form-card">${csrfField(ctx)}
      <fieldset class="radio-group"><legend>Tipo de solicitação</legend><label class="check"><input type="radio" name="kind" value="support" checked> Dúvida ou problema</label><label class="check"><input type="radio" name="kind" value="cancel" ${['paid', 'preparing'].includes(o.status) ? '' : raw('disabled')}> Cancelar pedido</label><label class="check"><input type="radio" name="kind" value="return" ${['shipped', 'in_transit', 'delivered'].includes(o.status) ? '' : raw('disabled')}> Troca ou devolução</label></fieldset>
      <div class="field"><label for="msg">Mensagem</label><textarea id="msg" name="message" rows="4" required maxlength="1000"></textarea></div><button class="btn" type="submit">Enviar solicitação</button></form>` : ''}
      ${reqs.length ? html`<h2>Suas solicitações</h2><ul class="timeline">${reqs.map((r) => html`<li><time>${formatDate(r.created_at, { offsetMinutes: cfg.tzOffsetMinutes })}</time> ${{ cancel: 'Cancelamento', support: 'Atendimento', return: 'Troca/devolução' }[r.kind]}: ${r.message} — ${badge(r.status === 'done' ? 'Respondida' : 'Em análise', r.status === 'done' ? 'good' : 'warn')}${r.admin_note ? html`<br><small>Resposta: ${r.admin_note}</small>` : ''}</li>`)}</ul>` : ''}`);
  }, C);
  router.post('/minha-conta/pedidos/:number/solicitacao', (ctx) => {
    const o = app.orders.ownedBy(ctx.customer, ctx.params.number);
    if (!o) return ctx.fail(404, 'Pedido não encontrado.');
    try {
      const kind = ['cancel', 'support', 'return'].includes(ctx.body.kind) ? ctx.body.kind : 'support';
      const lim = app.limiter.hit(`support:${ctx.customer.id}`, 6, 3600);
      if (!lim.ok) throw new UserError('Muitas solicitações em pouco tempo. Tente novamente mais tarde.');
      app.orders.requestSupport(ctx.customer, o.id, kind, ctx.body.message);
      ctx.flash('success', 'Solicitação enviada. Responderemos por e-mail.');
    } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect(`/minha-conta/pedidos/${o.number}`);
  }, C);

  // ───── perfil ─────
  router.get('/minha-conta/perfil', (ctx) => {
    const c = ctx.customer;
    shell(ctx, '/minha-conta/perfil', 'Perfil e senha', html`<form method="post" action="/minha-conta/perfil" class="form-card">${csrfField(ctx)}
      ${field({ label: 'Nome completo', name: 'name', value: c.name, required: true })}
      <div class="field"><label for="em">E-mail</label><input id="em" value="${c.email}" disabled><div class="hint">Para trocar o e-mail, fale com a loja.</div></div>
      ${field({ label: 'Telefone / WhatsApp', name: 'phone', type: 'tel', value: c.phone ? formatPhone(c.phone) : '' })}
      <label class="check"><input type="checkbox" name="marketing" value="1" ${c.marketing_consent ? raw('checked') : ''}> Quero receber novidades por e-mail</label>
      <button class="btn" type="submit">Salvar</button></form>
      <h2>Alterar senha</h2><form method="post" action="/minha-conta/senha" class="form-card">${csrfField(ctx)}
      ${field({ label: 'Senha atual', name: 'current', type: 'password', required: true, autocomplete: 'current-password' })}
      ${field({ label: 'Nova senha', name: 'password', type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo de 8 caracteres.' })}
      ${field({ label: 'Confirmar nova senha', name: 'confirm', type: 'password', required: true, autocomplete: 'new-password' })}
      <button class="btn" type="submit">Alterar senha</button></form>`);
  }, C);
  router.post('/minha-conta/perfil', (ctx) => {
    try { app.auth.updateProfile(ctx, { name: ctx.body.name, phone: ctx.body.phone, marketing: !!ctx.body.marketing }); ctx.flash('success', 'Perfil atualizado.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect('/minha-conta/perfil');
  }, C);
  router.post('/minha-conta/senha', async (ctx) => {
    try { await app.auth.changePassword(ctx, ctx.body.current, ctx.body.password, ctx.body.confirm); ctx.flash('success', 'Senha alterada. Outros dispositivos foram desconectados.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect('/minha-conta/perfil');
  }, C);

  // ───── endereços ─────
  const addrForm = (ctx, a = {}, id = '') => html`<form method="post" action="/minha-conta/enderecos${id ? `/${id}` : ''}" class="form-card">${csrfField(ctx)}
    <div class="grid2">${field({ label: 'Apelido', name: 'label', value: a.label, placeholder: 'Casa, Trabalho…' })}${field({ label: 'Quem recebe', name: 'recipient', value: a.recipient || ctx.customer.name, required: true })}</div>
    <div class="grid3">${field({ label: 'CEP', name: 'zip', value: a.zip ? formatZip(a.zip) : '', required: true, inputmode: 'numeric', maxlength: 9 })}${field({ label: 'Rua', name: 'street', value: a.street, required: true, cls: 'span2' })}</div>
    <div class="grid3">${field({ label: 'Número', name: 'number', value: a.number, required: true })}${field({ label: 'Complemento', name: 'complement', value: a.complement })}${field({ label: 'Bairro', name: 'district', value: a.district, required: true })}</div>
    <div class="grid2">${field({ label: 'Cidade', name: 'city', value: a.city, required: true })}${selectField({ label: 'Estado', name: 'state', value: a.state, options: UFS, blank: 'Selecione', required: true })}</div>
    <label class="check"><input type="checkbox" name="is_default" value="1" ${a.is_default ? raw('checked') : ''}> Usar como endereço principal</label>
    <button class="btn" type="submit">Salvar endereço</button></form>`;
  router.get('/minha-conta/enderecos', (ctx) => {
    const list = app.auth.addresses(ctx.customer.id);
    const editing = ctx.query.editar ? list.find((a) => a.id === int(ctx.query.editar)) : null;
    shell(ctx, '/minha-conta/enderecos', 'Meus endereços', html`${list.length ? html`<ul class="addr-list">${list.map((a) => html`<li><div><strong>${a.label || 'Endereço'}</strong>${a.is_default ? html` ${badge('Principal', 'good')}` : ''}<br>${a.recipient}<br>${a.street}, ${a.number}${a.complement ? ` — ${a.complement}` : ''} · ${a.district}<br>${a.city}/${a.state} · CEP ${formatZip(a.zip)}</div><div class="row-actions"><a class="btn btn-small btn-ghost" href="/minha-conta/enderecos?editar=${a.id}">Editar</a><form method="post" action="/minha-conta/enderecos/${a.id}/excluir" data-confirm="Excluir este endereço?">${csrfField(ctx)}<button class="linklike danger" type="submit">Excluir</button></form></div></li>`)}</ul>` : html`<p class="muted">Nenhum endereço salvo.</p>`}
      <h2>${editing ? 'Editar endereço' : 'Novo endereço'}</h2>${addrForm(ctx, editing || {}, editing?.id || '')}`);
  }, C);
  router.post('/minha-conta/enderecos', (ctx) => { try { app.auth.saveAddress(ctx.customer.id, ctx.body); ctx.flash('success', 'Endereço salvo.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); } ctx.redirect('/minha-conta/enderecos'); }, C);
  router.post('/minha-conta/enderecos/:id', (ctx) => { try { app.auth.saveAddress(ctx.customer.id, ctx.body, int(ctx.params.id)); ctx.flash('success', 'Endereço atualizado.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); } ctx.redirect('/minha-conta/enderecos'); }, C);
  router.post('/minha-conta/enderecos/:id/excluir', (ctx) => { app.auth.deleteAddress(ctx.customer.id, int(ctx.params.id)); ctx.flash('success', 'Endereço excluído.'); ctx.redirect('/minha-conta/enderecos'); }, C);

  // ───── LGPD ─────
  router.get('/minha-conta/dados', (ctx) => {
    shell(ctx, '/minha-conta/dados', 'Meus dados (LGPD)', html`<p>Você tem direito de acessar, corrigir e pedir a eliminação dos seus dados pessoais.</p>
      <h2>Baixar meus dados</h2><p class="muted">Gera um arquivo com seu cadastro, endereços e pedidos. O CPF aparece mascarado.</p><form method="post" action="/minha-conta/dados/exportar">${csrfField(ctx)}<button class="btn" type="submit">${icon('download', 18)} Baixar arquivo (JSON)</button></form>
      <h2>Eliminar meus dados</h2><p class="muted">Sua conta e seus dados de contato serão removidos. Pedidos já feitos podem ser mantidos pelo prazo exigido em lei. A loja confirma o pedido por e-mail.</p>
      <form method="post" action="/minha-conta/dados/eliminar" data-confirm="Pedir a eliminação da sua conta e dos seus dados?">${csrfField(ctx)}<button class="btn btn-danger" type="submit">Solicitar eliminação</button></form>`);
  }, C);
  router.post('/minha-conta/dados/exportar', (ctx) => {
    const lim = app.limiter.hit(`export:${ctx.customer.id}`, 5, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas solicitações. Tente novamente mais tarde.');
    const data = app.crm.exportData(ctx.customer.id);
    app.audit.log({ type: 'customer', id: ctx.customer.id }, 'customer.data_export', 'customer', ctx.customer.id, null, ctx.ip);
    ctx.download(`meus-dados-${new Date().toISOString().slice(0, 10)}.json`, 'application/json; charset=utf-8', JSON.stringify(data, null, 2));
  }, C);
  router.post('/minha-conta/dados/eliminar', (ctx) => {
    try { app.crm.createDataRequest({ email: ctx.customer.email, kind: 'deletion', customerId: ctx.customer.id }); ctx.flash('success', 'Solicitação registrada. Entraremos em contato por e-mail dentro do prazo legal.'); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect('/minha-conta/dados');
  }, C);
}

module.exports = { register };
