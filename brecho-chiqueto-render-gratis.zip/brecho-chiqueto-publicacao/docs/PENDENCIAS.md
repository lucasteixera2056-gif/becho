# O que falta, o que não foi verificado e limites conhecidos

Este documento é a lista **honesta** do estado do projeto. Leia antes de abrir a loja ao público.

## 1. Depende de contas e credenciais do brechó (sem elas a função não opera)

| Função | O que falta | Sem isso… |
|---|---|---|
| **Vender (Pix)** | Conta no **Asaas ou Mercado Pago**, chave de API, segredo do webhook, webhook cadastrado em URL pública HTTPS | A vitrine abre, mas o checkout **não finaliza pedidos** (o painel avisa). |
| **E-mails** | Conta **Resend**, **domínio verificado** (SPF/DKIM) e `EMAIL_FROM` | Nenhum e-mail sai; ficam registrados como “não enviados”. Confirmação de conta e recuperação de senha **não funcionam** para clientes. |
| **Receber respostas** | Caixa de e-mail real em `EMAIL_REPLY_TO` | Clientes que respondem a um e-mail da loja não são lidos. |
| **Frete em tempo real** | Conta **Melhor Envio**, token e CEP de origem | A opção não é oferecida. Frete fixo, grátis acima de X, retirada e entrega local funcionam sem isso. |
| **Domínio + HTTPS + hospedagem** | Domínio, servidor com disco persistente | A loja não fica pública; webhooks dos provedores exigem HTTPS. |
| **Dados do brechó** | Contato, endereço/horário (se houver), políticas, formas e valores de entrega, logo, fotos e peças reais | A loja só exibe o que for preenchido. Nada foi inventado. |
| **Textos legais** | Revisão por advogado(a) | Os textos são **modelos** e vêm marcados como não revisados. |

## 2. Escrito pela documentação pública, mas **não executado contra o serviço real**

Neste ambiente de desenvolvimento não há credenciais do brechó nem acesso de rede a esses serviços. Os testes automatizados usam um provedor **simulado** e respostas simuladas de HTTP. Portanto, **estes itens passaram em teste simulado e continuam sem prova com a conta real**:

| Item | O que está implementado | Como validar |
|---|---|---|
| **Asaas** | Criar/reaproveitar cliente (por CPF), criar cobrança Pix, ler QR Code, consultar cobrança, excluir cobrança ao expirar, reembolso, webhook por cabeçalho `asaas-access-token`, leitura de taxa/valor líquido/data de liquidação | Roteiro de sandbox em [`PAGAMENTOS.md`](PAGAMENTOS.md) |
| **Mercado Pago** | Criar pagamento Pix, QR Code, consultar, reembolso, webhook com `x-signature`, leitura de taxas | Idem. **Dois pontos específicos:** (a) o **texto assinado** do webhook (`id:…;request-id:…;ts:…;`) não pôde ser confirmado na documentação oficial (a página aberta só descreve o cabeçalho e o segredo); (b) a **validade mínima de 30 min** do Pix, citada em comentário do código, também não foi confirmada. Se (a) estiver errado, o webhook será recusado e o pagamento ainda será reconhecido pela consulta automática (a cada 30 s). |
| **Resend** | `POST https://api.resend.com/emails` (remetente, destinatário, assunto, HTML, texto, resposta-para), tratamento de erro e reenvio | Mande um e-mail de teste (criar conta de cliente) e confira *E-mails enviados*. |
| **Melhor Envio** | Cotação (`/api/v2/me/shipment/calculate`) com peso/dimensões padrão configuráveis | Token sandbox + um pedido de teste no checkout. **Não gera etiqueta nem compra frete**: só cota. |
| **ViaCEP** | Preenchimento do endereço pelo CEP (feito no navegador do cliente) | Digite um CEP no checkout; se falhar, o cliente digita o endereço. |

**Regra de ouro:** não divulgue a loja nem aceite pedidos reais antes de concluir o roteiro de sandbox **e** um pedido real de baixo valor, pago e reembolsado por você.

## 3. O que foi testado, e como

- **50 testes automatizados** (`npm test`) — todos passaram na última execução. Cobrem pagamentos/webhooks/estoque/reembolsos/relatórios, segurança do painel e da loja, catálogo/carrinho/cupons/entrega/checkout, conta do cliente/e-mails/LGPD.
- **Navegador real (Chromium/Playwright)** durante o desenvolvimento: loja (início, catálogo, peça, carrinho, checkout, Pix, conta) e painel (login, troca obrigatória de senha, ~35 telas, cadastro de peça com fotos, ciclo de um pedido, reembolso, CSV, histórico de e-mails, auditoria), sem erros de console.
- Os testes automatizados **não substituem** o teste com contas reais (item 2) nem um teste de carga.

## 4. Limites conhecidos (por desenho ou ainda não feitos)

- **Só Pix.** Cartão e boleto não estão no escopo.
- **Sem nota fiscal.** A loja não emite NF-e/NFC-e nem calcula impostos.
- **Correios direto: não integrado** (exige contrato próprio). O tipo existe no cadastro, mas **não é oferecido** ao cliente. Use frete fixo ou Melhor Envio.
- **Melhor Envio:** só cotação; etiquetas e postagem são feitas no site do Melhor Envio. O rastreio é digitado no pedido.
- **Sem disparo de newsletter em massa** (apenas lista com consentimento e e-mail de boas-vindas).
- **Sem recebimento de e-mail** (o Resend só envia).
- **Sem autenticação em dois fatores** no painel. Mitigações: senhas fortes exigidas, bloqueio por tentativas, sessões revogáveis, auditoria. Considere ativar 2FA no e-mail e no provedor de Pix.
- **Sem CAPTCHA.** Formulários públicos usam limite por IP e campo-isca contra robôs; se houver abuso, adicione um serviço de CAPTCHA.
- **Um único servidor/processo** (SQLite). Não é para múltiplas instâncias.
- **Sem avaliações de clientes** (de propósito: nenhuma avaliação fictícia é exibida).
- **Acessibilidade e responsividade:** HTML semântico, campos com rótulo, foco visível e alvos de toque ampliados. O layout foi conferido em navegador a 360 px e 390 px (19 páginas da loja e do painel, sem rolagem lateral e sem erro de console). **Não houve auditoria formal** de acessibilidade (leitor de tela, contraste, WCAG completo) nem teste em aparelhos reais.
- **Redes por trás de CDN (Cloudflare):** a loja lê o primeiro IP de `X-Forwarded-For`; configure o proxy para entregar o IP real e substituir o cabeçalho (veja `PUBLICACAO.md`).
- **Peças demonstrativas** (`npm run seed:demo`) são **fictícias** e só para desenvolvimento; nunca rode em produção (o script recusa).
- **Instagram:** o projeto aponta para o perfil @brecho_chiqueto, mas **não** importa fotos nem produtos dele; identidade visual e peças reais precisam ser fornecidas pelo brechó.

## 5. Primeiros passos sugeridos (ordem)

1. Registrar domínio e contratar hospedagem → publicar ([`PUBLICACAO.md`](PUBLICACAO.md)).
2. Abrir conta de **teste** no Asaas ou Mercado Pago → roteiro de sandbox ([`PAGAMENTOS.md`](PAGAMENTOS.md)).
3. Configurar Resend e testar e-mails ([`EMAIL.md`](EMAIL.md)).
4. Preencher Configurações, formas de entrega e cadastrar as primeiras peças ([`MANUAL-ADMIN.md`](MANUAL-ADMIN.md)).
5. Revisão jurídica dos textos; backup agendado.
6. Trocar para produção, pedido real de baixo valor, reembolsar → divulgar.
