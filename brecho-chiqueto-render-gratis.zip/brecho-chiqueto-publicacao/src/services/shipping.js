'use strict';
/**
 * Frete e entrega. Nenhum valor ou prazo é inventado: as opções vêm das regras
 * cadastradas pela loja (fixo, grátis acima de X, retirada, entrega local) ou de um
 * provedor contratado (Melhor Envio). Correios direto exige contrato próprio (estrutura preparada).
 */
const { onlyDigits, parseMoney, int, trunc, UserError, now } = require('../lib/util');
const { makeMelhorEnvio } = require('../providers/shipping/melhorenvio');

const KINDS = {
  fixed: 'Frete fixo',
  pickup: 'Retirada presencial',
  local: 'Entrega local',
  melhorenvio: 'Melhor Envio (cotação em tempo real)',
  correios: 'Correios (requer contrato próprio — em preparação)',
};
const DELIVERY_KIND = { fixed: 'ship', melhorenvio: 'ship', correios: 'ship', pickup: 'pickup', local: 'local' };

function makeShipping(app) {
  const { db, cfg } = app;
  const me = makeMelhorEnvio(cfg);

  const parseConfig = (s) => {
    try { return JSON.parse(s || '{}') || {}; } catch { return {}; }
  };

  const shipping = {
    KINDS,
    melhorEnvio: me,
    methods: (all = false) => db.all(`SELECT * FROM shipping_methods ${all ? '' : 'WHERE active = 1'} ORDER BY sort_order, id`),
    method: (id) => db.get('SELECT * FROM shipping_methods WHERE id = ?', id),
    parseConfig,

    providerStatus() {
      return {
        melhorenvio: { configured: me.configured(), missing: me.missing(), env: cfg.shipping.melhorEnvio.env },
        correios: { configured: false, missing: ['Contrato com os Correios e integração própria'] },
      };
    },

    /**
     * Opções de entrega para o CEP e itens informados.
     * items: [{ weight_g, price_cents, qty }] — zip pode ser vazio (mostra só retirada e regras sem restrição de CEP).
     */
    async quote({ zip, subtotalCents, items }) {
      zip = onlyDigits(zip);
      const out = [];
      const warnings = [];
      for (const m of this.methods()) {
        const conf = parseConfig(m.config);
        const base = { method_id: m.id, kind: m.kind, delivery_kind: DELIVERY_KIND[m.kind], eta_text: m.eta_text || '' };
        if (m.kind === 'pickup') {
          out.push({ ...base, key: String(m.id), name: m.name, price_cents: 0, free: true });
        } else if (m.kind === 'fixed' || m.kind === 'local') {
          if (m.kind === 'local') {
            const prefixes = String(conf.zip_prefixes || '').split(/[,\s;]+/).map(onlyDigits).filter(Boolean);
            if (prefixes.length && (zip.length !== 8 || !prefixes.some((p) => zip.startsWith(p)))) continue;
          }
          if (zip.length !== 8) continue;
          const free = m.free_over_cents && subtotalCents >= m.free_over_cents;
          out.push({ ...base, key: String(m.id), name: m.name, price_cents: free ? 0 : m.price_cents, free: !!free });
        } else if (m.kind === 'melhorenvio') {
          if (zip.length !== 8) continue;
          if (!me.configured()) continue;
          try {
            const rows = await me.quote({ toZip: zip, items, methodConfig: conf });
            for (const r of rows) {
              const free = m.free_over_cents && subtotalCents >= m.free_over_cents;
              out.push({ ...base, key: `${m.id}:${r.service_id}`, name: `${m.name}: ${r.name}`.replace(/^(.+?): \1/, '$1'), price_cents: free ? 0 : r.price_cents + (m.price_cents || 0), free: !!free, eta_text: r.eta_text || m.eta_text || '' });
            }
          } catch (e) {
            console.error('[frete] Melhor Envio:', e.message);
            warnings.push('Não foi possível consultar o frete dos transportadores agora. Tente novamente em instantes.');
          }
        }
        // 'correios': sem integração direta ativa
      }
      return { options: out, warnings };
    },

    /** Recalcula no servidor e devolve a opção escolhida (nunca confia no preço enviado pelo navegador). */
    async resolve({ key, zip, subtotalCents, items }) {
      const { options } = await this.quote({ zip, subtotalCents, items });
      const opt = options.find((o) => o.key === String(key));
      if (!opt) throw new UserError('Escolha uma forma de entrega válida para o seu CEP.', 'shipping');
      return opt;
    },

    // ───── administração ─────
    saveMethod(b, id = null) {
      const kind = Object.keys(KINDS).includes(b.kind) ? b.kind : null;
      if (!kind) throw new UserError('Tipo de entrega inválido.');
      const name = trunc(b.name, 80);
      if (!name) throw new UserError('Informe o nome da forma de entrega.');
      const price = b.price === '' || b.price === undefined ? 0 : parseMoney(b.price);
      if (price === null) throw new UserError('Valor inválido.');
      const freeOver = b.free_over ? parseMoney(b.free_over) : null;
      if (b.free_over && !freeOver) throw new UserError('Valor de frete grátis inválido.');
      const conf = {};
      if (kind === 'local') conf.zip_prefixes = trunc(b.zip_prefixes, 200);
      if (kind === 'melhorenvio') {
        for (const k of ['width', 'height', 'length', 'default_weight_g', 'extra_days']) if (b[k]) conf[k] = int(b[k], 0);
        if (b.services) conf.services = String(b.services).split(/[,\s;]+/).filter(Boolean);
      }
      const args = [name, kind, price, freeOver, trunc(b.eta_text, 120), JSON.stringify(conf), b.active ? 1 : 0, int(b.sort_order, 0)];
      if (id) {
        db.run('UPDATE shipping_methods SET name=?, kind=?, price_cents=?, free_over_cents=?, eta_text=?, config=?, active=?, sort_order=? WHERE id=?', ...args, id);
        return id;
      }
      return db.run('INSERT INTO shipping_methods (name, kind, price_cents, free_over_cents, eta_text, config, active, sort_order) VALUES (?,?,?,?,?,?,?,?)', ...args).id;
    },
    deleteMethod(id) {
      if (db.get('SELECT 1 FROM orders WHERE shipping_method_id = ?', id)) {
        db.run('UPDATE shipping_methods SET active = 0 WHERE id = ?', id);
        return 'deactivated';
      }
      db.run('DELETE FROM shipping_methods WHERE id = ?', id);
      return 'deleted';
    },

    // ───── rastreamento ─────
    shipment: (orderId) => db.get('SELECT * FROM shipments WHERE order_id = ?', orderId),
    events: (shipmentId) => db.all('SELECT * FROM tracking_events WHERE shipment_id = ? ORDER BY id DESC', shipmentId),

    /** Cria/atualiza o envio e registra um evento de rastreamento. */
    upsertShipment(orderId, { carrier, tracking_code, tracking_url, eta_text, status, note }) {
      const t = now();
      const code = trunc(tracking_code, 40).replace(/[^\w.\-]/g, '');
      let url = trunc(tracking_url, 300);
      if (url && !/^https:\/\/[^\s]+$/i.test(url)) throw new UserError('O link de rastreio deve começar com https://');
      return db.tx(() => {
        let s = this.shipment(orderId);
        if (!s) {
          const id = db.run('INSERT INTO shipments (order_id, carrier, tracking_code, tracking_url, status, eta_text, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)', orderId, trunc(carrier, 60) || null, code || null, url || null, status || 'preparing', trunc(eta_text, 120) || null, t, t).id;
          s = db.get('SELECT * FROM shipments WHERE id = ?', id);
        } else {
          db.run('UPDATE shipments SET carrier = COALESCE(NULLIF(?, \'\'), carrier), tracking_code = COALESCE(NULLIF(?, \'\'), tracking_code), tracking_url = COALESCE(NULLIF(?, \'\'), tracking_url), eta_text = COALESCE(NULLIF(?, \'\'), eta_text), status = ?, updated_at = ? WHERE id = ?', trunc(carrier, 60), code, url, trunc(eta_text, 120), status || s.status, t, s.id);
        }
        if (status === 'shipped') db.run('UPDATE shipments SET shipped_at = COALESCE(shipped_at, ?) WHERE id = ?', t, s.id);
        if (status === 'delivered') db.run('UPDATE shipments SET delivered_at = COALESCE(delivered_at, ?) WHERE id = ?', t, s.id);
        if (status || note) db.run('INSERT INTO tracking_events (shipment_id, status, note, created_at) VALUES (?,?,?,?)', s.id, status || s.status, trunc(note, 300) || null, t);
        return s.id;
      });
    },
  };
  return shipping;
}

module.exports = { makeShipping, KINDS };
