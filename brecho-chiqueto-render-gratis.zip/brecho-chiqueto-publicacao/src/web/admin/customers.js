'use strict';
/** Painel: clientes (LGPD) e cupons. */
const { html, raw } = require('../../lib/html');
const { money, centsToInput, int, UserError, formatPhone, maskCpf } = require('../../lib/util');
const { icon, csrfField, field, selectField, pager, qs, badge } = require('../ui');

function register(router, app, h) {
  const { L } = h;
  const { cfg } = app;
  const cid = (ctx) => int(ctx.params.id);

  // ───── clientes ─────
  router.get('/admin/clientes', (ctx) => {
    const q = { q: ctx.query.q || '', status: ctx.query.situacao || '' };
    const r = app.crm.customers({ ...q, page: ctx.query.page });
    h.page(ctx, 'Clientes', html`
<section class="card">
  <form class="filters" method="get" action="/admin/clientes">
    <div class="field"><label for="q">Buscar</label><input id="q" name="q" type="search" value="${q.q}" placeholder="Nome, e-mail ou telefone"></div>
    ${selectField({ label: 'Filtro', name: 'situacao', value: q.status, options: [{ value: 'newsletter', label: 'Aceitam novidades' }, { value: 'blocked', label: 'Bloqueados' }], blank: 'Todos' })}
    <div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div>
  </form>
  ${L.table(['Cliente', 'Contato', { label: 'Pedidos pagos', right: true }, { label: 'Total gasto', right: true }, 'Cadastro', 'Situação'], r.rows.map((c) => html`<tr><td><a href="/admin/clientes/${c.id}"><strong>${c.name}</strong></a></td><td>${c.email}${c.phone ? html`<br><small class="muted">${formatPhone(c.phone)}</small>` : ''}</td><td class="r">${c.paid_orders}</td><td class="r">${money(c.spent)}</td><td>${h.day(c.created_at)}</td><td>${c.status === 'blocked' ? badge('Bloqueado', 'bad') : c.email_verified_at ? badge('E-mail confirmado', 'good') : badge('Sem confirmação', 'neutral')}</td></tr>`), { empty: 'Nenhum cliente encontrado. Clientes aparecem aqui quando criam conta ou compram.' })}
  ${pager(r, (n) => `/admin/clientes${qs(q, { page: n })}`)}
  <p class="muted small">${r.total} cliente(s). Compras como convidado não criam cadastro: veja-as em Pedidos.</p>
</section>`, { actions: h.can(ctx, 'customers.pii') ? html`<a class="btn btn-ghost" href="/admin/relatorios/clientes.csv">${icon('download', 16)} Exportar CSV</a>` : '' });
  }, h.S('customers.view'));

  router.get('/admin/clientes/:id', (ctx) => {
    const c = app.crm.customer(cid(ctx));
    if (!c || c.status === 'anonymized') return ctx.fail(404, 'Cliente não encontrado.');
    const orders = app.crm.customerOrders(c.id);
    const addrs = app.crm.customerAddresses(c.id);
    const manage = h.can(ctx, 'customers.manage');
    const pii = h.can(ctx, 'customers.pii');
    const cpfRaw = c.cpf_enc && pii ? app.cipher.decrypt(c.cpf_enc) : null;
    const cpfShown = cpfRaw ? cpfRaw.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : app.crm.cpfMasked(c);
    h.page(ctx, c.name, html`
<div class="cols cols-wide"><div class="stack">
  <section class="card"><h2>Pedidos</h2>${L.table(['Pedido', 'Data', { label: 'Total', right: true }, 'Situação'], orders.map((o) => html`<tr><td><a href="/admin/pedidos/${o.id}">${o.number}</a></td><td>${h.ago(o.created_at)}</td><td class="r">${money(o.total_cents)}</td><td>${badge(app.orders.statusLabel(o.status, o.delivery_kind), L.statusTone(o.status))}</td></tr>`), { empty: 'Sem pedidos.' })}</section>
  <section class="card"><h2>Endereços</h2>${addrs.length ? html`<ul class="plain-list">${addrs.map((a) => html`<li><strong>${a.label || 'Endereço'}</strong>${a.is_default ? ' (padrão)' : ''}: ${a.street}, ${a.number}${a.complement ? ` — ${a.complement}` : ''} · ${a.district} · ${a.city}/${a.state} · CEP ${a.zip}</li>`)}</ul>` : html`<p class="empty-note">Nenhum endereço salvo.</p>`}</section>
</div><div class="stack">
  <section class="card"><h2>Cadastro</h2>
    <p><strong>${c.name}</strong> ${c.status === 'blocked' ? badge('Bloqueado', 'bad') : ''}<br><a href="mailto:${c.email}">${c.email}</a>${c.email_verified_at ? '' : html` <small class="muted">(e-mail não confirmado)</small>`}${c.phone ? html`<br>${formatPhone(c.phone)}` : ''}</p>
    ${cpfShown ? html`<p class="small">CPF: ${cpfShown}${pii ? '' : html` <span class="muted">(completo só para quem tem permissão)</span>`}</p>` : ''}
    <p class="small muted">Cadastro em ${h.ago(c.created_at)}${c.last_login_at ? ` · último acesso ${h.ago(c.last_login_at)}` : ''}<br>Aceita novidades por e-mail: ${c.marketing_consent ? `sim (desde ${h.day(c.marketing_consent_at)})` : 'não'}</p>
    ${c.status === 'blocked' && c.block_reason ? html`<p class="notice-inline">Motivo do bloqueio: ${c.block_reason}</p>` : ''}
  </section>
  ${manage ? html`
  <section class="card"><h2>Anotações internas</h2><form method="post" action="/admin/clientes/${c.id}/notas">${csrfField(ctx)}<div class="field"><label class="sr-only" for="notes">Anotações</label><textarea id="notes" name="notes" rows="4" maxlength="1000">${c.admin_notes || ''}</textarea><div class="hint">Só a equipe vê. Não registre dados sensíveis.</div></div><button class="btn btn-ghost btn-small" type="submit">Salvar</button></form></section>
  <section class="card"><h2>Conta e privacidade (LGPD)</h2>
    <div class="stack-sm">
    <a class="btn btn-ghost btn-small" href="/admin/clientes/${c.id}/exportar.json">${icon('download', 16)} Exportar dados do titular (JSON)</a>
    ${c.status === 'blocked'
    ? html`<form method="post" action="/admin/clientes/${c.id}/bloquear">${csrfField(ctx)}<input type="hidden" name="blocked" value="0"><button class="btn btn-ghost btn-small" type="submit">Desbloquear acesso</button></form>`
    : html`<form method="post" action="/admin/clientes/${c.id}/bloquear" class="inline-form-row" data-confirm="Bloquear o acesso à conta? Compras como convidado continuam possíveis.">${csrfField(ctx)}<input type="hidden" name="blocked" value="1"><input name="reason" placeholder="Motivo" maxlength="200" aria-label="Motivo do bloqueio"><button class="btn btn-ghost btn-small" type="submit">Bloquear conta</button></form>`}
    <form method="post" action="/admin/clientes/${c.id}/anonimizar" data-confirm="Anonimizar este cliente? Nome, e-mail, telefone, CPF e endereços serão apagados. Esta ação não pode ser desfeita.">${csrfField(ctx)}<button class="btn btn-danger btn-small" type="submit">Anonimizar / eliminar dados</button></form>
    <p class="muted small">Pedidos já realizados permanecem registrados (obrigações legais e fiscais), sem vínculo com a pessoa. Não é possível anonimizar quem tem pedido em andamento.</p></div>
  </section>` : ''}
</div></div>`);
  }, h.S('customers.view'));

  router.post('/admin/clientes/:id/notas', (ctx) => h.act(ctx, `/admin/clientes/${cid(ctx)}`, () => app.crm.saveNotes(ctx, cid(ctx), ctx.body.notes), 'Anotação salva.'), h.S('customers.manage'));
  router.post('/admin/clientes/:id/bloquear', (ctx) => h.act(ctx, `/admin/clientes/${cid(ctx)}`, () => app.crm.setBlocked(ctx, cid(ctx), ctx.body.blocked === '1', ctx.body.reason), ctx.body.blocked === '1' ? 'Conta bloqueada.' : 'Conta desbloqueada.'), h.S('customers.manage'));
  router.post('/admin/clientes/:id/anonimizar', (ctx) => h.act(ctx, (ok) => (ok ? '/admin/clientes' : `/admin/clientes/${cid(ctx)}`), () => { app.crm.anonymize(ctx, cid(ctx)); return true; }, 'Dados do cliente anonimizados.'), h.S('customers.manage'));
  router.get('/admin/clientes/:id/exportar.json', (ctx) => {
    let data;
    try { data = app.crm.exportData(cid(ctx)); } catch (e) { if (e instanceof UserError) return ctx.fail(404, e.message); throw e; }
    app.audit.staff(ctx, 'customer.export', 'customer', cid(ctx));
    ctx.download(`dados-cliente-${cid(ctx)}.json`, 'application/json; charset=utf-8', JSON.stringify(data, null, 2));
  }, h.S('customers.manage'));

  // ───── cupons ─────
  const toDate = (iso) => (iso ? new Date(new Date(iso).getTime() + cfg.tzOffsetMinutes * 60000).toISOString().slice(0, 10) : '');
  const skuList = (id) => app.db.all('SELECT p.sku FROM coupon_products cp JOIN products p ON p.id = cp.product_id WHERE cp.coupon_id = ? ORDER BY p.sku', id).map((r) => r.sku).join(', ');
  const parseSkus = (text) => {
    const skus = String(text || '').split(/[\s,;]+/).map((s) => s.trim().toUpperCase()).filter(Boolean);
    const ids = [];
    for (const s of skus) {
      const p = app.catalog.bySku(s);
      if (!p) throw new UserError(`Não encontrei a peça com código ${s}.`);
      ids.push(p.id);
    }
    return ids;
  };

  const couponStatus = (c) => {
    const t = new Date().toISOString();
    if (!c.active) return badge('Desativado', 'neutral');
    if (c.expires_at && c.expires_at <= t) return badge('Expirado', 'bad');
    if (c.starts_at && c.starts_at > t) return badge('Agendado', 'warn');
    if (c.max_uses !== null && c.used_count >= c.max_uses) return badge('Esgotado', 'bad');
    return badge('Ativo', 'good');
  };
  const couponForm = (ctx, c = {}, error = '') => {
    const isNew = !c.id;
    const v = (k, d = '') => c[k] ?? d;
    const kind = v('kind', 'percent');
    const fromForm = !!c._raw; // reexibição após erro: os valores já são o texto digitado
    const valueShown = c.id && !fromForm ? (kind === 'fixed' ? centsToInput(c.value) : String(c.value)) : v('value');
    return html`<section class="card narrow-lg"><h2>${isNew ? 'Novo cupom' : `Cupom ${c.code}`}</h2>
${error ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${error}</span></div>` : ''}
<form method="post" action="${isNew ? '/admin/cupons' : `/admin/cupons/${c.id}`}" class="stack">${csrfField(ctx)}
<div class="grid2">${field({ label: 'Código', name: 'code', value: v('code'), required: true, maxlength: 30, hint: 'Letras, números, hífen. O cliente digita no carrinho.' })}${field({ label: 'Descrição interna', name: 'description', value: v('description'), maxlength: 200 })}</div>
<div class="grid3">${selectField({ label: 'Tipo', name: 'kind', value: kind, options: [{ value: 'percent', label: 'Porcentagem (%)' }, { value: 'fixed', label: 'Valor fixo (R$)' }], blank: null, required: true })}${field({ label: 'Valor do desconto', name: 'value', value: valueShown, required: true, inputmode: 'decimal', hint: 'Porcentagem: 1 a 100. Valor fixo: em reais.' })}${field({ label: 'Compra mínima (R$)', name: 'min_subtotal', value: c.min_subtotal_cents && !fromForm ? centsToInput(c.min_subtotal_cents) : v('min_subtotal') })}</div>
<div class="grid3">${field({ label: 'Limite de usos', name: 'max_uses', type: 'number', value: v('max_uses'), attrs: 'min="1"', hint: 'Em branco = sem limite.' })}${field({ label: 'Válido a partir de', name: 'starts_at', type: 'date', value: c.id && !fromForm ? toDate(c.starts_at) : v('starts_at') })}${field({ label: 'Válido até', name: 'expires_at', type: 'date', value: c.id && !fromForm ? toDate(c.expires_at) : v('expires_at') })}</div>
${field({ label: 'Limitar a peças (códigos SKU)', name: 'skus', value: c.id && !fromForm ? skuList(c.id) : v('skus'), hint: 'Separe por vírgula. Em branco = vale para todas as peças.' })}
<label class="check"><input type="checkbox" name="active" value="1" ${isNew || c.active ? raw('checked') : ''}> Cupom ativo</label>
<div><button class="btn" type="submit">${isNew ? 'Criar cupom' : 'Salvar'}</button> <a class="btn btn-ghost" href="/admin/cupons">Cancelar</a></div></form></section>`;
  };

  router.get('/admin/cupons', (ctx) => {
    const list = app.coupons.list();
    h.page(ctx, 'Cupons de desconto', html`<section class="card">${L.table(['Código', 'Desconto', 'Regras', { label: 'Usos', right: true }, 'Validade', 'Situação', ''], list.map((c) => html`<tr><td><strong>${c.code}</strong>${c.description ? html`<br><small class="muted">${c.description}</small>` : ''}</td><td>${c.kind === 'percent' ? `${c.value}%` : money(c.value)}</td><td class="small">${c.min_subtotal_cents ? `Mín. ${money(c.min_subtotal_cents)}` : 'Sem mínimo'}${c.restricted ? ` · ${c.restricted} peça(s)` : ''}</td><td class="r">${c.used_count}${c.max_uses !== null ? ` / ${c.max_uses}` : ''}</td><td class="small">${c.starts_at ? `de ${h.day(c.starts_at)} ` : ''}${c.expires_at ? `até ${h.day(c.expires_at)}` : c.starts_at ? '' : 'sem prazo'}</td><td>${couponStatus(c)}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/cupons/${c.id}">Editar</a></td></tr>`), { empty: 'Nenhum cupom criado.' })}</section>`, { actions: html`<a class="btn" href="/admin/cupons/novo">${icon('plus', 16)} Novo cupom</a>` });
  }, h.S('coupons.manage'));
  router.get('/admin/cupons/novo', (ctx) => h.page(ctx, 'Novo cupom', couponForm(ctx)), h.S('coupons.manage'));
  router.get('/admin/cupons/:id', (ctx) => {
    const c = app.coupons.byId(cid(ctx));
    if (!c) return ctx.fail(404, 'Cupom não encontrado.');
    h.page(ctx, `Cupom ${c.code}`, html`${couponForm(ctx, c)}
<section class="card narrow-lg"><h2>Uso</h2><p>Usado ${c.used_count} vez(es)${c.max_uses !== null ? ` de ${c.max_uses}` : ''}. Cupons cancelados ou de pedidos não pagos voltam ao saldo automaticamente.</p>
<div class="row-actions-wrap"><form method="post" action="/admin/cupons/${c.id}/${c.active ? 'desativar' : 'ativar'}">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">${c.active ? 'Desativar' : 'Ativar'}</button></form><form method="post" action="/admin/cupons/${c.id}/excluir" data-confirm="Excluir este cupom?">${csrfField(ctx)}<button class="btn btn-danger" type="submit">Excluir</button></form></div></section>`);
  }, h.S('coupons.manage'));
  const couponSave = (ctx, id) => {
    try {
      const body = { ...ctx.body, active: !!ctx.body.active, product_ids: parseSkus(ctx.body.skus) };
      const saved = app.coupons.save(body, id);
      app.audit.staff(ctx, id ? 'coupon.updated' : 'coupon.created', 'coupon', saved, { code: body.code });
      ctx.flash('success', 'Cupom salvo.');
      ctx.redirect('/admin/cupons');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      const cur = id ? app.coupons.byId(id) : {};
      h.page(ctx, id ? 'Editar cupom' : 'Novo cupom', couponForm(ctx, { ...ctx.body, _raw: true, id: id || undefined, active: !!ctx.body.active, used_count: cur?.used_count }, e.message), { status: 422 });
    }
  };
  router.post('/admin/cupons', (ctx) => couponSave(ctx, null), h.S('coupons.manage'));
  router.post('/admin/cupons/:id', (ctx) => couponSave(ctx, cid(ctx)), h.S('coupons.manage'));
  router.post('/admin/cupons/:id/ativar', (ctx) => h.act(ctx, '/admin/cupons', () => { app.coupons.setActive(cid(ctx), true); app.audit.staff(ctx, 'coupon.activated', 'coupon', cid(ctx)); }, 'Cupom ativado.'), h.S('coupons.manage'));
  router.post('/admin/cupons/:id/desativar', (ctx) => h.act(ctx, '/admin/cupons', () => { app.coupons.setActive(cid(ctx), false); app.audit.staff(ctx, 'coupon.deactivated', 'coupon', cid(ctx)); }, 'Cupom desativado.'), h.S('coupons.manage'));
  router.post('/admin/cupons/:id/excluir', (ctx) => h.act(ctx, '/admin/cupons', () => { app.coupons.remove(cid(ctx)); app.audit.staff(ctx, 'coupon.deleted', 'coupon', cid(ctx)); }, 'Cupom excluído.'), h.S('coupons.manage'));

  void maskCpf;
}

module.exports = { register };
