'use strict';
/** Painel: funcionários e permissões, atividades (auditoria), e-mails enviados, mensagens, solicitações, LGPD e newsletter. */
const { html, raw } = require('../../lib/html');
const { int, trunc, UserError, randomToken } = require('../../lib/util');
const { icon, csrfField, field, selectField, pager, qs, badge } = require('../ui');
const { ROLES, PERMISSIONS } = require('../../services/permissions');

function register(router, app, h) {
  const { L } = h;
  const sid = (ctx) => int(ctx.params.id);

  // ───── funcionários ─────
  const roleOptions = (ctx) => Object.entries(ROLES).filter(([k]) => app.permissions.canManageRole(ctx.staff, k)).map(([value, r]) => ({ value, label: r.label }));
  const isSuper = (ctx) => ctx.staff.role === 'superadmin';

  router.get('/admin/funcionarios', (ctx) => {
    const list = app.auth.listStaff();
    h.page(ctx, 'Funcionários', html`<section class="card">
${L.table(['Nome', 'E-mail', 'Função', 'Último acesso', 'Situação', ''], list.map((u) => html`<tr><td><strong>${u.name}</strong>${u.id === ctx.staff.id ? html` <small class="muted">(você)</small>` : ''}</td><td>${u.email}</td><td>${ROLES[u.role]?.label}</td><td>${u.last_login_at ? h.ago(u.last_login_at) : 'nunca'}</td><td>${u.active ? (u.must_change_password ? badge('Aguardando 1ª senha', 'warn') : badge('Ativo', 'good')) : badge('Desativado', 'neutral')}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/funcionarios/${u.id}">${app.permissions.canManageRole(ctx.staff, u.role) && u.id !== ctx.staff.id ? 'Gerenciar' : 'Ver'}</a></td></tr>`))}
<p class="muted small">Cada pessoa deve ter o seu próprio acesso. Todas as ações importantes ficam registradas em <a href="/admin/auditoria">Atividades</a>.</p></section>
<section class="card"><h2>O que cada função pode fazer</h2>${L.table(['Função', 'Permissões'], Object.keys(ROLES).map((r) => html`<tr><td><strong>${ROLES[r].label}</strong></td><td class="small">${r === 'superadmin' ? 'Tudo, inclusive editar as permissões das funções.' : [...app.permissions.forRole(r)].map((p) => PERMISSIONS[p]).join(' · ') || 'Nenhuma'}</td></tr>`))}
${isSuper(ctx) ? html`<p><a class="btn btn-ghost btn-small" href="/admin/funcionarios/permissoes">Editar permissões das funções</a></p>` : ''}</section>`, { actions: html`<a class="btn" href="/admin/funcionarios/novo">${icon('plus', 16)} Novo funcionário</a>` });
  }, h.S('staff.manage'));

  router.get('/admin/funcionarios/novo', (ctx) => {
    const opts = roleOptions(ctx);
    const temp = `${randomToken(5)}-${randomToken(5)}`;
    h.page(ctx, 'Novo funcionário', html`<section class="card narrow-lg"><form method="post" action="/admin/funcionarios" class="stack" autocomplete="off">${csrfField(ctx)}
${field({ label: 'Nome', name: 'name', value: ctx.query.nome || '', required: true, maxlength: 100 })}
${field({ label: 'E-mail (será o login)', name: 'email', type: 'email', required: true, autocomplete: 'off' })}
${selectField({ label: 'Função', name: 'role', value: 'atendente', options: opts, blank: null, required: true })}
${field({ label: 'Senha temporária', name: 'password', value: temp, required: true, hint: 'Passe esta senha à pessoa por um canal seguro. Ela será obrigada a trocá-la no primeiro acesso.', autocomplete: 'off' })}
<div class="row-actions-wrap"><button class="btn" type="submit">Criar acesso</button><a class="btn btn-ghost" href="/admin/funcionarios">Cancelar</a></div></form></section>`);
  }, h.S('staff.manage'));
  router.post('/admin/funcionarios', (ctx) => h.act(ctx, (id) => (id ? `/admin/funcionarios/${id}` : '/admin/funcionarios/novo'), () => app.auth.createStaff(ctx.staff, { name: ctx.body.name, email: ctx.body.email, password: ctx.body.password, role: ctx.body.role }, ctx), 'Acesso criado. A pessoa precisará trocar a senha no primeiro login.'), h.S('staff.manage'));

  // matriz de permissões (somente superadmin) — registrada antes de /:id
  const EDITABLE = ['admin', 'gerente', 'atendente', 'estoquista'];
  router.get('/admin/funcionarios/permissoes', (ctx) => {
    if (!isSuper(ctx)) return ctx.fail(403, 'Somente o superadministrador pode editar as permissões.');
    h.page(ctx, 'Permissões por função', html`<section class="card"><form method="post" action="/admin/funcionarios/permissoes">${csrfField(ctx)}
<p class="muted small">O superadministrador sempre tem acesso total. Marque o que cada função pode fazer. Cuidado ao liberar reembolsos, dados pessoais e configurações.</p>
<div class="tbl-wrap"><table class="tbl matrix"><thead><tr><th scope="col">Permissão</th>${EDITABLE.map((r) => html`<th scope="col" class="c">${ROLES[r].label}</th>`)}</tr></thead><tbody>
${Object.entries(PERMISSIONS).map(([p, label]) => html`<tr><th scope="row">${label}</th>${EDITABLE.map((r) => html`<td class="c"><input type="checkbox" name="p_${r}" value="${p}" aria-label="${ROLES[r].label}: ${label}" ${app.permissions.forRole(r).has(p) ? raw('checked') : ''}></td>`)}</tr>`)}
</tbody></table></div>
<div class="row-actions-wrap"><button class="btn" type="submit">Salvar permissões</button><a class="btn btn-ghost" href="/admin/funcionarios">Cancelar</a></div></form></section>`);
  }, h.S('staff.manage'));
  router.post('/admin/funcionarios/permissoes', (ctx) => {
    if (!isSuper(ctx)) return ctx.fail(403, 'Somente o superadministrador pode editar as permissões.');
    h.act(ctx, '/admin/funcionarios', () => {
      for (const r of EDITABLE) {
        const chosen = [].concat(ctx.body[`p_${r}`] || []).filter((p) => p in PERMISSIONS);
        app.permissions.setRolePermissions(r, chosen);
        app.audit.staff(ctx, 'role.permissions_updated', 'role', r, { count: chosen.length });
      }
    }, 'Permissões atualizadas.');
  }, h.S('staff.manage'));

  router.get('/admin/funcionarios/:id', (ctx) => {
    const u = app.auth.getStaffById(sid(ctx));
    if (!u) return ctx.fail(404, 'Funcionário não encontrado.');
    const mine = u.id === ctx.staff.id;
    const manage = !mine && app.permissions.canManageRole(ctx.staff, u.role);
    const sessions = manage ? app.auth.staffSessions(u.id) : [];
    h.page(ctx, u.name, html`
<section class="card narrow-lg"><h2>Dados</h2>
${manage ? html`<form method="post" action="/admin/funcionarios/${u.id}" class="stack">${csrfField(ctx)}
${field({ label: 'Nome', name: 'name', value: u.name, required: true, maxlength: 100 })}
<p class="small">E-mail: <strong>${u.email}</strong> · Criado em ${h.day(u.created_at)}</p>
${selectField({ label: 'Função', name: 'role', value: u.role, options: roleOptions(ctx), blank: null, required: true })}
<label class="check"><input type="checkbox" name="active" value="1" ${u.active ? raw('checked') : ''}> Acesso ativo</label>
<button class="btn" type="submit">Salvar</button></form>` : html`<p><strong>${u.name}</strong> · ${u.email}<br>Função: ${ROLES[u.role]?.label}</p>${mine ? html`<p class="muted small">Você não pode alterar a sua própria função ou situação. Para trocar a senha, use <a href="/admin/minha-conta">Minha conta</a>.</p>` : html`<p class="muted small">Você não tem permissão para gerenciar este acesso.</p>`}`}</section>
${manage ? html`<section class="card narrow-lg"><h2>Redefinir senha</h2><form method="post" action="/admin/funcionarios/${u.id}/senha" class="stack" autocomplete="off">${csrfField(ctx)}${field({ label: 'Nova senha temporária', name: 'password', value: `${randomToken(5)}-${randomToken(5)}`, required: true, autocomplete: 'off', hint: 'Todas as sessões da pessoa são encerradas e ela precisará trocar a senha ao entrar.' })}<button class="btn btn-ghost" type="submit" data-confirm="Redefinir a senha deste funcionário?">Redefinir senha</button></form></section>
<section class="card"><h2>Sessões ativas</h2>${L.table(['Início', 'Última atividade', 'IP', 'Navegador', ''], sessions.map((s) => html`<tr><td>${h.ago(s.created_at)}</td><td>${h.ago(s.last_seen_at)}</td><td>${s.ip}</td><td class="small">${(s.user_agent || '').slice(0, 70)}</td><td><form method="post" action="/admin/funcionarios/${u.id}/sessoes/${s.id}/encerrar">${csrfField(ctx)}<button class="linklike danger" type="submit">Encerrar</button></form></td></tr>`), { empty: 'Nenhuma sessão ativa.' })}</section>` : ''}`);
  }, h.S('staff.manage'));
  router.post('/admin/funcionarios/:id', (ctx) => h.act(ctx, `/admin/funcionarios/${sid(ctx)}`, () => app.auth.updateStaff(ctx, sid(ctx), { name: ctx.body.name, role: ctx.body.role, active: !!ctx.body.active }), 'Funcionário atualizado.'), h.S('staff.manage'));
  router.post('/admin/funcionarios/:id/senha', (ctx) => h.act(ctx, `/admin/funcionarios/${sid(ctx)}`, () => app.auth.resetStaffPassword(ctx, sid(ctx), ctx.body.password), 'Senha redefinida. Informe a nova senha temporária à pessoa por um canal seguro.'), h.S('staff.manage'));
  router.post('/admin/funcionarios/:id/sessoes/:sess/encerrar', (ctx) => h.act(ctx, `/admin/funcionarios/${sid(ctx)}`, () => {
    const s = app.db.get("SELECT user_id FROM sessions WHERE id = ? AND kind = 'staff'", ctx.params.sess);
    if (!s || s.user_id !== sid(ctx)) throw new UserError('Sessão não encontrada.');
    const target = app.auth.getStaffById(s.user_id);
    if (target.id !== ctx.staff.id && !app.permissions.canManageRole(ctx.staff, target.role)) throw new UserError('Você não pode gerenciar este funcionário.');
    app.auth.revokeStaffSession(ctx, ctx.params.sess);
  }, 'Sessão encerrada.'), h.S('staff.manage'));

  // ───── atividades (auditoria) ─────
  router.get('/admin/auditoria', (ctx) => {
    const f = { q: trunc(ctx.query.q, 60), ator: ['staff', 'customer', 'system', 'webhook'].includes(ctx.query.ator) ? ctx.query.ator : '', de: ctx.query.de || '', ate: ctx.query.ate || '' };
    const where = ['1=1']; const params = [];
    if (f.q) { const l = `%${f.q.replace(/[\\%_]/g, '\\$&')}%`; where.push("(action LIKE ? ESCAPE '\\' OR entity LIKE ? ESCAPE '\\' OR entity_id LIKE ? ESCAPE '\\' OR actor_label LIKE ? ESCAPE '\\')"); params.push(l, l, l, l); }
    if (f.ator) { where.push('actor_type = ?'); params.push(f.ator); }
    const r = app.reports.range({ from: f.de, to: f.ate, preset: f.de || f.ate ? '' : 'all' });
    if (f.de || f.ate) { where.push('at >= ? AND at < ?'); params.push(r.fromIso, r.toIso); }
    const perPage = 50;
    const total = app.db.value(`SELECT COUNT(*) FROM audit_logs WHERE ${where.join(' AND ')}`, ...params);
    const pages = Math.max(1, Math.ceil(total / perPage));
    const page = Math.min(Math.max(1, int(ctx.query.page, 1)), pages);
    const rows = app.db.all(`SELECT * FROM audit_logs WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...params, perPage, (page - 1) * perPage);
    h.page(ctx, 'Registro de atividades', html`<section class="card">
<form class="filters" method="get" action="/admin/auditoria"><div class="field"><label for="q">Buscar</label><input id="q" name="q" type="search" value="${f.q}" placeholder="Ação, pessoa ou item"></div>
${selectField({ label: 'Quem', name: 'ator', value: f.ator, options: [{ value: 'staff', label: 'Funcionários' }, { value: 'customer', label: 'Clientes' }, { value: 'system', label: 'Sistema' }, { value: 'webhook', label: 'Provedor (webhook)' }], blank: 'Todos' })}
<div class="field"><label for="de">De</label>${L.dateInput('de', f.de)}</div><div class="field"><label for="ate">Até</label>${L.dateInput('ate', f.ate)}</div><div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div></form>
${L.table(['Quando', 'Quem', 'Ação', 'Item', 'Detalhes', 'IP'], rows.map((a) => html`<tr><td class="nowrap">${h.ago(a.at)}</td><td class="small">${a.actor_label || a.actor_type}</td><td><code>${a.action}</code></td><td class="small">${a.entity ? `${a.entity}${a.entity_id ? ` #${a.entity_id}` : ''}` : ''}</td><td class="small mono-wrap">${a.details || ''}</td><td class="small">${a.ip || ''}</td></tr>`), { empty: 'Nenhuma atividade registrada com esses filtros.' })}
${pager({ page, pages }, (n) => `/admin/auditoria${qs(f, { page: n })}`)}
<p class="muted small">Senhas, tokens e CPF nunca são gravados neste registro. Registros são guardados por 2 anos.</p></section>`);
  }, h.S('audit.view'));

  // ───── e-mails enviados ─────
  const EMAIL_STATUS = { queued: ['Na fila', 'warn'], sent: ['Enviado', 'good'], failed: ['Falhou', 'bad'], skipped: ['Ignorado', 'neutral'], captured: ['Registrado (teste)', 'neutral'] };
  router.get('/admin/emails', (ctx) => {
    const status = EMAIL_STATUS[ctx.query.status] ? ctx.query.status : '';
    const list = app.email.list({ status, limit: 200 });
    const live = app.cfg.email.transport === 'resend' && app.cfg.email.resendApiKey;
    h.page(ctx, 'E-mails enviados', html`<section class="card">
${live ? '' : html`<div class="flash flash-info">${icon('alert', 18)}<span>O envio real ainda não está configurado: os e-mails abaixo ficam apenas registrados. Defina <code>RESEND_API_KEY</code> e um remetente de domínio verificado (veja Configurações → E-mails).</span></div>`}
<form class="filters" method="get" action="/admin/emails">${selectField({ label: 'Situação', name: 'status', value: status, options: Object.entries(EMAIL_STATUS).map(([value, v]) => ({ value, label: v[0] })), blank: 'Todas' })}<div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div></form>
${L.table(['Quando', 'Para', 'Modelo', 'Assunto', 'Situação', ''], list.map((e) => html`<tr><td class="nowrap">${h.ago(e.created_at)}</td><td class="small">${e.to_email}</td><td class="small">${app.email.TEMPLATES[e.template]?.label || e.template}</td><td class="small">${e.subject}</td><td>${badge(EMAIL_STATUS[e.status]?.[0] || e.status, EMAIL_STATUS[e.status]?.[1])}${e.error ? html`<br><small class="err">${e.error}</small>` : ''}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/emails/${e.id}/ver" target="_blank" rel="noopener">Ver</a>${['failed', 'captured', 'skipped'].includes(e.status) ? html` <form method="post" action="/admin/emails/${e.id}/reenviar" class="inline">${csrfField(ctx)}<button class="btn btn-small btn-ghost" type="submit">Reenviar</button></form>` : ''}</td></tr>`), { empty: 'Nenhum e-mail registrado.' })}
<p class="muted small">O conteúdo completo dos e-mails é mantido por 90 dias.</p></section>`);
  }, h.S('emails.view'));
  router.get('/admin/emails/:id/ver', (ctx) => {
    const e = app.email.get(sid(ctx));
    if (!e) return ctx.fail(404, 'E-mail não encontrado.');
    if (!e.html) return ctx.fail(404, 'O conteúdo deste e-mail já foi removido pela política de retenção.');
    app.audit.staff(ctx, 'email.viewed', 'email', e.id);
    ctx.html(e.html, 200, { 'Content-Security-Policy': "default-src 'none'; img-src https: data:; style-src 'unsafe-inline'; sandbox", 'Cache-Control': 'no-store' });
  }, h.S('emails.view'));
  router.post('/admin/emails/:id/reenviar', (ctx) => h.act(ctx, '/admin/emails', async () => { const r = await app.email.resend(sid(ctx)); app.audit.staff(ctx, 'email.resent', 'email', sid(ctx), { status: r.status }); return r; }, (r) => (r.status === 'sent' ? 'E-mail reenviado.' : r.status === 'failed' ? `Não foi possível enviar: ${r.error || 'erro'}` : 'E-mail registrado novamente (envio real não configurado).')), h.S('emails.view'));

  // ───── mensagens do formulário de contato ─────
  const STATUS_C = { open: ['Aberta', 'warn'], answered: ['Respondida', 'good'], archived: ['Arquivada', 'neutral'] };
  router.get('/admin/mensagens', (ctx) => {
    const status = STATUS_C[ctx.query.status] ? ctx.query.status : '';
    const list = app.crm.contacts({ status });
    h.page(ctx, 'Mensagens de contato', html`<section class="card">
<div class="chips"><a class="chip ${status === '' ? 'on' : ''}" href="/admin/mensagens">Todas</a>${Object.entries(STATUS_C).map(([k, v]) => html`<a class="chip ${status === k ? 'on' : ''}" href="/admin/mensagens?status=${k}">${v[0]}</a>`)}</div>
${list.length ? html`<ul class="msgs">${list.map((m) => html`<li class="msg"><header><strong>${m.name}</strong> <a href="mailto:${m.email}${m.subject ? `?subject=${encodeURIComponent(`Re: ${m.subject}`)}` : ''}">${m.email}</a>${m.phone ? html` · ${m.phone}` : ''} <time class="muted small">${h.ago(m.created_at)}</time> ${badge(STATUS_C[m.status][0], STATUS_C[m.status][1])}</header>${m.subject ? html`<p><strong>${m.subject}</strong></p>` : ''}<p class="pre">${m.message}</p>
<div class="row-actions-wrap">${['open', 'answered', 'archived'].filter((x) => x !== m.status).map((x) => html`<form method="post" action="/admin/mensagens/${m.id}/status">${csrfField(ctx)}<input type="hidden" name="status" value="${x}"><button class="btn btn-small btn-ghost" type="submit">Marcar como ${STATUS_C[x][0].toLowerCase()}</button></form>`)}</div></li>`)}</ul>` : html`<p class="empty-note">Nenhuma mensagem.</p>`}
<p class="muted small">Responda pelo seu e-mail ou WhatsApp. O sistema envia apenas a confirmação automática de recebimento ao cliente.</p></section>`);
  }, h.S('support.manage'));
  router.post('/admin/mensagens/:id/status', (ctx) => h.act(ctx, '/admin/mensagens', () => app.crm.setContactStatus(ctx, sid(ctx), ctx.body.status), 'Situação atualizada.'), h.S('support.manage'));

  // ───── solicitações de clientes (cancelamento, trocas, suporte) ─────
  const KIND_S = { cancel: 'Cancelamento', support: 'Atendimento', return: 'Troca / devolução' };
  router.get('/admin/solicitacoes', (ctx) => {
    const list = app.crm.supportRequests();
    h.page(ctx, 'Solicitações de clientes', html`<section class="card">${list.length ? html`<ul class="msgs">${list.map((s) => html`<li class="msg"><header><strong>${KIND_S[s.kind] || s.kind}</strong> ${s.order_number ? html`· pedido <a href="/admin/pedidos/${s.order_id}">${s.order_number}</a>` : ''} · ${s.customer_name || 'cliente removido'} ${s.customer_email ? html`<a href="mailto:${s.customer_email}">${s.customer_email}</a>` : ''} <time class="muted small">${h.ago(s.created_at)}</time> ${badge(s.status === 'open' ? 'Em aberto' : 'Resolvida', s.status === 'open' ? 'warn' : 'good')}</header><p class="pre">${s.message}</p>
${s.status === 'open' ? html`<form method="post" action="/admin/solicitacoes/${s.id}/resolver" class="inline-form-row">${csrfField(ctx)}<input name="note" placeholder="Observação interna (opcional)" maxlength="500" aria-label="Observação"><button class="btn btn-small" type="submit">Marcar como resolvida</button></form>` : s.admin_note ? html`<p class="muted small">Observação: ${s.admin_note}</p>` : ''}</li>`)}</ul>` : html`<p class="empty-note">Nenhuma solicitação.</p>`}
<p class="muted small">Pedidos de cancelamento de pedidos já pagos são resolvidos por reembolso na tela do pedido.</p></section>`);
  }, h.S('support.manage'));
  router.post('/admin/solicitacoes/:id/resolver', (ctx) => h.act(ctx, '/admin/solicitacoes', () => app.crm.resolveSupport(ctx, sid(ctx), ctx.body.note), 'Solicitação resolvida.'), h.S('support.manage'));

  // ───── LGPD ─────
  router.get('/admin/lgpd', (ctx) => {
    const list = app.crm.dataRequests();
    h.page(ctx, 'Solicitações LGPD', html`<section class="card">
<p class="muted small">Titulares podem pedir acesso aos dados ou a eliminação. O prazo legal de resposta é curto (a LGPD prevê 15 dias para a resposta completa ao pedido de acesso). Confirme a identidade antes de enviar dados: responda somente para o e-mail cadastrado.</p>
${L.table(['Recebida', 'Titular', 'Pedido', 'Situação', 'Ações'], list.map((r) => { const c = app.auth.findCustomerByEmail(r.email); return html`<tr><td>${h.ago(r.created_at)}</td><td>${r.email}${c && c.status !== 'anonymized' ? html`<br><a href="/admin/clientes/${c.id}">Ver cadastro</a>` : html`<br><small class="muted">sem cadastro</small>`}</td><td>${r.kind === 'access' ? 'Acesso aos dados' : 'Eliminação de dados'}${r.note ? html`<br><small class="muted">${r.note}</small>` : ''}</td><td>${badge({ open: 'Em aberto', done: 'Atendida', rejected: 'Recusada' }[r.status], { open: 'warn', done: 'good', rejected: 'neutral' }[r.status])}</td><td>${r.status === 'open' ? html`<form method="post" action="/admin/lgpd/${r.id}/resolver" class="inline-form-row">${csrfField(ctx)}<input name="note" placeholder="Observação" maxlength="500" aria-label="Observação"><select name="status" aria-label="Resultado"><option value="done">Atendida</option><option value="rejected">Recusada</option></select><button class="btn btn-small" type="submit">Registrar</button></form>` : (r.completed_at ? h.ago(r.completed_at) : '')}</td></tr>`; }), { empty: 'Nenhuma solicitação LGPD.' })}
<p class="muted small">Como atender: <strong>acesso</strong> → abra o cadastro e use “Exportar dados do titular”; <strong>eliminação</strong> → use “Anonimizar / eliminar dados” no cadastro (pedidos já realizados são mantidos por obrigação legal, sem identificar a pessoa). Depois, registre aqui o resultado.</p></section>`);
  }, h.S('support.manage'));
  router.post('/admin/lgpd/:id/resolver', (ctx) => h.act(ctx, '/admin/lgpd', () => app.crm.resolveDataRequest(ctx, sid(ctx), ctx.body.status, ctx.body.note), 'Solicitação registrada.'), h.S('support.manage'));

  // ───── newsletter ─────
  router.get('/admin/newsletter', (ctx) => {
    const list = app.crm.subscribers();
    const active = list.filter((s) => !s.unsubscribed_at).length;
    h.page(ctx, 'Newsletter', html`<section class="card">
<div class="kpis kpis-sm">${L.kpi('Inscritos ativos', String(active))}${L.kpi('Cancelaram', String(list.length - active))}</div>
<p class="muted small">Só entram aqui pessoas que marcaram o consentimento. Todo envio de novidades deve trazer o link para cancelar a inscrição. Esta lista é para você usar em uma ferramenta de e-mail marketing; o painel não dispara campanhas.</p>
${L.table(['E-mail', 'Consentimento em', 'Situação'], list.map((s) => html`<tr><td>${s.email}</td><td>${h.ago(s.consent_at)}</td><td>${s.unsubscribed_at ? badge(`Cancelou em ${h.day(s.unsubscribed_at)}`, 'neutral') : badge('Ativo', 'good')}</td></tr>`), { empty: 'Ninguém se inscreveu ainda.' })}
<p><a class="btn btn-ghost" href="/admin/newsletter.csv">${icon('download', 16)} Exportar inscritos ativos (CSV)</a></p></section>`);
  }, h.S('support.manage'));
  router.get('/admin/newsletter.csv', (ctx) => { app.audit.staff(ctx, 'export.newsletter', 'report', 'newsletter'); ctx.download('newsletter-inscritos.csv', 'text/csv; charset=utf-8', app.crm.subscribersCsv()); }, h.S('support.manage'));
}

module.exports = { register };
