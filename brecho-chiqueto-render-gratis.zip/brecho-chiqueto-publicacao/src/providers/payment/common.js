'use strict';
/** Utilitários compartilhados pelos provedores de pagamento. */

class ProviderError extends Error {
  constructor(message, { status = 0, detail = null, retryable = false } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.status = status;
    this.detail = detail;
    this.retryable = retryable;
  }
}

/** fetch JSON com timeout. Nunca registra cabeçalhos (que contêm credenciais). */
async function httpJson(url, { method = 'GET', headers = {}, body, timeoutMs = 15000 } = {}) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { Accept: 'application/json', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (e) {
    throw new ProviderError('Não foi possível falar com o provedor de pagamentos.', { retryable: true, detail: e.name === 'TimeoutError' ? 'timeout' : e.message });
  }
  let data = null;
  const text = await res.text();
  if (text) {
    try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 300) }; }
  }
  return { status: res.status, ok: res.ok, data };
}

/** 'YYYY-MM-DD' no horário de Brasília para um instante ISO. */
function brDate(iso, offsetMinutes = -180) {
  return new Date(new Date(iso).getTime() + offsetMinutes * 60000).toISOString().slice(0, 10);
}

/** ISO com offset -03:00 (formato aceito pelo Mercado Pago). */
function brIsoWithOffset(iso, offsetMinutes = -180) {
  const d = new Date(new Date(iso).getTime() + offsetMinutes * 60000);
  const sign = offsetMinutes <= 0 ? '-' : '+';
  const abs = Math.abs(offsetMinutes);
  const hh = String(Math.floor(abs / 60)).padStart(2, '0');
  const mm = String(abs % 60).padStart(2, '0');
  return `${d.toISOString().slice(0, 23)}${sign}${hh}:${mm}`;
}

const toCents = (v) => (v === null || v === undefined || v === '' || Number.isNaN(Number(v)) ? null : Math.round(Number(v) * 100));
const fromCents = (c) => Number((c / 100).toFixed(2));

module.exports = { ProviderError, httpJson, brDate, brIsoWithOffset, toCents, fromCents };
