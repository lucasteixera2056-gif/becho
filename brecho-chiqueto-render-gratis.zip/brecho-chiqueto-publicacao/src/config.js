'use strict';
/**
 * Configuração via variáveis de ambiente (e arquivo .env opcional).
 * Nenhuma credencial é gravada no código. Ver .env.example.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = val;
  }
}

function buildConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const isProd = nodeEnv === 'production';
  const baseUrl = (env.BASE_URL || env.RENDER_EXTERNAL_URL || `http://localhost:${env.PORT || 3000}`).replace(/\/+$/, '');
  const dataDir = path.resolve(ROOT, env.DATA_DIR || 'data');
  const uploadDir = path.resolve(ROOT, env.UPLOAD_DIR || 'uploads');
  fs.mkdirSync(dataDir, { recursive: true });
  fs.mkdirSync(uploadDir, { recursive: true });

  let secret = env.SECRET_KEY || '';
  if (!secret) {
    if (isProd) throw new Error('SECRET_KEY é obrigatória em produção (mínimo de 32 caracteres).');
    // Em desenvolvimento, gera e persiste uma chave local para manter sessões entre reinícios.
    const f = path.join(dataDir, '.dev-secret');
    if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(48).toString('base64url'), { mode: 0o600 });
    secret = fs.readFileSync(f, 'utf8').trim();
  }
  if (isProd && secret.length < 32) throw new Error('SECRET_KEY precisa ter pelo menos 32 caracteres.');

  const cfg = {
    nodeEnv,
    isProd,
    isTest: nodeEnv === 'test',
    root: ROOT,
    port: Number(env.PORT || 3000),
    host: env.HOST || '0.0.0.0',
    baseUrl,
    dataDir,
    uploadDir,
    dbFile: env.DB_FILE ? (env.DB_FILE === ':memory:' ? ':memory:' : path.resolve(ROOT, env.DB_FILE)) : path.join(dataDir, 'loja.db'),
    secret,
    trustProxy: env.TRUST_PROXY === '1' || env.TRUST_PROXY === 'true',
    cookieSecure: env.COOKIE_SECURE ? env.COOKIE_SECURE === 'true' || env.COOKIE_SECURE === '1' : baseUrl.startsWith('https://'),
    tzOffsetMinutes: Number(env.TZ_OFFSET_MINUTES ?? -180), // Brasil (sem horário de verão desde 2019)
    adminBootstrap: { email: env.ADMIN_EMAIL || '', password: env.ADMIN_PASSWORD || '', name: env.ADMIN_NAME || 'Proprietário(a)' },
    adminNotifyEmail: env.ADMIN_NOTIFY_EMAIL || '',
    jobsEnabled: env.JOBS_ENABLED !== '0',
    assetVersion: env.ASSET_VERSION || Date.now().toString(36),
    payment: {
      provider: (env.PAYMENT_PROVIDER || 'none').toLowerCase(), // none | mock | asaas | mercadopago
      pixExpiryMinutes: Number(env.PIX_EXPIRY_MINUTES || 30),
      asaas: {
        apiKey: env.ASAAS_API_KEY || '',
        env: (env.ASAAS_ENV || 'sandbox').toLowerCase(),
        webhookToken: env.ASAAS_WEBHOOK_TOKEN || '',
      },
      mercadopago: {
        accessToken: env.MP_ACCESS_TOKEN || '',
        webhookSecret: env.MP_WEBHOOK_SECRET || '',
      },
      mock: { webhookSecret: env.MOCK_WEBHOOK_SECRET || 'mock-secret-somente-testes' },
    },
    email: {
      transport: (env.EMAIL_TRANSPORT || (env.RESEND_API_KEY ? 'resend' : 'log')).toLowerCase(), // resend | log | capture
      resendApiKey: env.RESEND_API_KEY || '',
      from: env.EMAIL_FROM || '',
      replyTo: env.EMAIL_REPLY_TO || '',
    },
    shipping: {
      melhorEnvio: {
        token: env.MELHORENVIO_TOKEN || '',
        env: (env.MELHORENVIO_ENV || 'sandbox').toLowerCase(),
        fromZip: (env.MELHORENVIO_FROM_CEP || '').replace(/\D/g, ''),
        userAgent: env.MELHORENVIO_USER_AGENT || '',
      },
    },
  };

  if (isProd) {
    if (cfg.payment.provider === 'mock') throw new Error('PAYMENT_PROVIDER=mock é proibido em produção.');
    if (cfg.email.transport === 'capture') throw new Error('EMAIL_TRANSPORT=capture é proibido em produção.');
  }
  return cfg;
}

loadDotEnv(path.join(ROOT, '.env'));
module.exports = { buildConfig, ROOT };
