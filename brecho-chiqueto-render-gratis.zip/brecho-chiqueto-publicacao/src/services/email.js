'use strict';
/**
 * E-mails transacionais (Resend). Cada envio fica registrado em `emails` com status e erro,
 * para o administrador acompanhar e reenviar. Sem chave configurada, nada é "fingido":
 * o registro fica como `skipped` e o painel avisa.
 *
 * Importante: este módulo ENVIA e-mails automáticos. Receber/responder mensagens dos clientes
 * exige uma caixa de entrada própria (veja docs/EMAIL.md).
 */
const { html, raw, escape } = require('../lib/html');
const { now, money, formatDate, validEmail, UserError } = require('../lib/util');

// Modelos padrão: assunto e introdução podem ser editados no painel (tabela email_templates).
const TEMPLATES = {
  verify_email: { label: 'Confirmação de cadastro', subject: 'Confirme seu e-mail', intro: 'Falta só confirmar seu e-mail para ativar sua conta.' },
  account_exists: { label: 'Cadastro com e-mail já existente', subject: 'Sobre o seu cadastro', intro: 'Recebemos um pedido de cadastro com este e-mail, que já está em nossa base.' },
  reset_password: { label: 'Recuperação de senha', subject: 'Redefinição de senha', intro: 'Recebemos um pedido para redefinir a sua senha. Se não foi você, ignore este e-mail.' },
  welcome: { label: 'Boas-vindas', subject: 'Bem-vinda(o) ao {{loja}}', intro: 'Sua conta foi confirmada. Agora você pode acompanhar seus pedidos e salvar seus endereços.' },
  order_received: { label: 'Pedido recebido', subject: 'Recebemos o seu pedido {{pedido}}', intro: 'Recebemos o seu pedido. Assim que o pagamento for confirmado, avisaremos por aqui.' },
  pix_generated: { label: 'Pix gerado', subject: 'Pix do pedido {{pedido}}', intro: 'Seu Pix foi gerado. Pague até o horário indicado para garantir as peças.' },
  payment_approved: { label: 'Pagamento aprovado', subject: 'Pagamento confirmado — pedido {{pedido}}', intro: 'Recebemos o seu pagamento. Obrigada pela compra!' },
  payment_expired: { label: 'Pagamento expirado', subject: 'O Pix do pedido {{pedido}} expirou', intro: 'O prazo para pagamento terminou e as peças foram liberadas. Se ainda quiser, você pode fazer um novo pedido.' },
  order_preparing: { label: 'Pedido em preparação', subject: 'Estamos preparando o pedido {{pedido}}', intro: 'Seu pedido já está sendo separado.' },
  order_shipped: { label: 'Pedido enviado', subject: 'Seu pedido {{pedido}} foi enviado', intro: 'Seu pedido saiu para entrega.' },
  order_delivered: { label: 'Pedido entregue', subject: 'Pedido {{pedido}} entregue', intro: 'Consta como entregue. Esperamos que você goste!' },
  order_cancelled: { label: 'Cancelamento', subject: 'Pedido {{pedido}} cancelado', intro: 'Seu pedido foi cancelado e as peças foram liberadas.' },
  order_refunded: { label: 'Reembolso', subject: 'Reembolso do pedido {{pedido}}', intro: 'Efetuamos o reembolso do seu pagamento. O prazo para o valor aparecer depende do seu banco.' },
  order_update: { label: 'Atualização importante', subject: 'Atualização do pedido {{pedido}}', intro: 'Há uma novidade sobre o seu pedido.' },
  contact_ack: { label: 'Recebemos sua mensagem', subject: 'Recebemos a sua mensagem', intro: 'Obrigada por entrar em contato. Responderemos assim que possível.' },
  newsletter_welcome: { label: 'Inscrição na newsletter', subject: 'Inscrição confirmada', intro: 'Você passou a receber as novidades do brechó. Para cancelar quando quiser, use o link no fim deste e-mail.' },
  admin_notice: { label: 'Aviso ao administrador', subject: '{{assunto}}', intro: '' },
};

function makeEmail(app) {
  const { db, cfg, settings } = app;
  const inflight = new Set();

  const tpl = (key) => {
    const base = TEMPLATES[key];
    const o = db.get('SELECT * FROM email_templates WHERE key = ?', key);
    return { subject: o?.subject || base.subject, intro: o?.intro || base.intro, enabled: o ? !!o.enabled : true };
  };
  const fill = (s, vars) => String(s).replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] ?? '');

  const sender = () => {
    const name = settings.get('email_from_name') || settings.get('store_name');
    const addr = settings.get('email_from_address') || cfg.email.from;
    return addr ? `${name} <${addr.replace(/^.*<|>.*$/g, '')}>` : '';
  };

  /** Layout dos e-mails com a identidade configurada no painel. */
  function layout({ title, intro, body, footerHtml = '' }) {
    const s = settings.all();
    const base = cfg.baseUrl;
    return html`<!doctype html><html lang="pt-BR"><body style="margin:0;background:${s.color_bg};font-family:Arial,Helvetica,sans-serif;color:${s.color_ink}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #eadfd3">
<tr><td style="background:${s.color_primary};padding:20px 28px;color:#ffffff;font-size:22px;font-family:Georgia,serif">${s.store_name}</td></tr>
<tr><td style="padding:28px">
<h1 style="margin:0 0 12px;font-size:20px;color:${s.color_ink}">${title}</h1>
${intro ? html`<p style="margin:0 0 18px;line-height:1.55;font-size:15px">${intro}</p>` : ''}
${body}
</td></tr>
<tr><td style="padding:18px 28px;background:#faf6f1;color:#75685f;font-size:12px;line-height:1.5">
${s.store_instagram ? html`<a href="${s.store_instagram}" style="color:${s.color_primary}">Instagram</a> · ` : ''}<a href="${base}" style="color:${s.color_primary}">Visitar a loja</a>
${footerHtml}
${s.store_email ? html`<br>Dúvidas: ${s.store_email}` : ''}
</td></tr></table></td></tr></table></body></html>`.s;
  }

  const button = (url, label) => html`<p style="margin:22px 0"><a href="${url}" style="background:${settings.get('color_primary')};color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:8px;display:inline-block;font-weight:bold;font-size:15px">${label}</a></p>`;

  const itemsTable = (order) => {
    const rows = db.all('SELECT * FROM order_items WHERE order_id = ?', order.id);
    return html`<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #eadfd3;font-size:14px">
${rows.map((r) => html`<tr><td style="padding:10px 0;border-bottom:1px solid #eadfd3">${r.name}${r.qty > 1 ? ` × ${r.qty}` : ''}</td><td align="right" style="padding:10px 0;border-bottom:1px solid #eadfd3">${money(r.unit_cents * r.qty)}</td></tr>`)}
<tr><td style="padding:8px 0;color:#75685f">Frete</td><td align="right">${order.shipping_cents ? money(order.shipping_cents) : 'Grátis'}</td></tr>
${order.discount_cents ? html`<tr><td style="padding:8px 0;color:#75685f">Desconto</td><td align="right">− ${money(order.discount_cents)}</td></tr>` : ''}
<tr><td style="padding:8px 0;font-weight:bold">Total</td><td align="right" style="font-weight:bold">${money(order.total_cents)}</td></tr></table>`;
  };

  /** Monta assunto/HTML/texto de cada modelo. */
  function build(key, d) {
    const t = tpl(key);
    const store = settings.get('store_name');
    const vars = { loja: store, pedido: d.order?.number || '', assunto: d.subject || '' };
    const subject = fill(t.subject, vars);
    const intro = fill(t.intro, vars);
    const hello = d.name ? `Olá, ${String(d.name).split(' ')[0]}!` : 'Olá!';
    const orderUrl = d.order ? `${cfg.baseUrl}/pedido/${d.order.public_token}` : cfg.baseUrl;
    let body = '';
    let text = `${hello}\n\n${intro}\n`;
    switch (key) {
      case 'verify_email':
        body = button(d.verifyUrl, 'Confirmar e-mail');
        text += `\nConfirme aqui: ${d.verifyUrl}\n(O link vale por 3 dias.)`;
        break;
      case 'account_exists':
      case 'reset_password':
        body = html`${button(d.resetUrl, key === 'reset_password' ? 'Criar nova senha' : 'Definir ou redefinir senha')}<p style="font-size:13px;color:#75685f">O link vale por 1 hora e só pode ser usado uma vez.</p>`;
        text += `\nLink (vale por 1 hora): ${d.resetUrl}`;
        break;
      case 'welcome':
        body = button(`${cfg.baseUrl}/minha-conta`, 'Ir para minha conta');
        break;
      case 'order_received':
      case 'payment_approved':
      case 'order_preparing':
      case 'order_delivered':
      case 'order_cancelled':
      case 'order_refunded':
      case 'order_update':
        body = html`${itemsTable(d.order)}${d.note ? html`<p style="font-size:14px;line-height:1.5">${d.note}</p>` : ''}${button(orderUrl, 'Ver meu pedido')}`;
        text += `\nPedido ${d.order.number} — total ${money(d.order.total_cents)}\n${d.note ? `${d.note}\n` : ''}Acompanhe: ${orderUrl}`;
        break;
      case 'pix_generated':
        body = html`<p style="font-size:15px">Valor: <strong>${money(d.order.total_cents)}</strong>${d.expiresAt ? html`<br>Pague até <strong>${formatDate(d.expiresAt, { offsetMinutes: cfg.tzOffsetMinutes })}</strong>` : ''}</p>${button(orderUrl, 'Ver QR Code e código Pix')}`;
        text += `\nValor: ${money(d.order.total_cents)}\nPague pelo link: ${orderUrl}`;
        break;
      case 'payment_expired':
        body = button(cfg.baseUrl, 'Voltar à loja');
        break;
      case 'order_shipped': {
        const s = d.shipment;
        body = html`${s?.tracking_code ? html`<p style="font-size:15px">Código de rastreio: <strong>${s.tracking_code}</strong>${s.carrier ? html` (${s.carrier})` : ''}${s.tracking_url ? html`<br><a href="${s.tracking_url}">Acompanhar a entrega</a>` : ''}</p>` : ''}${s?.eta_text ? html`<p style="font-size:14px">Prazo estimado: ${s.eta_text}</p>` : ''}${button(orderUrl, 'Ver meu pedido')}`;
        text += `\n${s?.tracking_code ? `Rastreio: ${s.tracking_code}\n` : ''}Acompanhe: ${orderUrl}`;
        break;
      }
      case 'newsletter_welcome':
        body = '';
        break;
      case 'admin_notice':
        body = html`<p style="font-size:15px;line-height:1.5">${d.message}</p>${d.link ? button(`${cfg.baseUrl}${d.link}`, 'Abrir no painel') : ''}`;
        text = `${d.message}\n${d.link ? `${cfg.baseUrl}${d.link}` : ''}`;
        break;
      default:
        body = '';
    }
    const footerHtml = d.unsubscribeUrl ? html`<br><a href="${d.unsubscribeUrl}" style="color:#75685f">Cancelar inscrição</a>` : '';
    return { subject, text, html: layout({ title: subject, intro: key === 'admin_notice' ? '' : `${hello} ${intro}`, body, footerHtml }) };
  }

  async function deliver(id) {
    const row = db.get('SELECT * FROM emails WHERE id = ?', id);
    if (!row || !['queued', 'failed'].includes(row.status)) return;
    const transport = cfg.email.transport;
    const from = sender();
    db.run('UPDATE emails SET attempts = attempts + 1 WHERE id = ?', id);
    try {
      if (transport === 'capture') {
        db.run("UPDATE emails SET status = 'captured', sent_at = ? WHERE id = ?", now(), id);
        return;
      }
      if (transport === 'log' || !cfg.email.resendApiKey) {
        db.run("UPDATE emails SET status = 'skipped', error = ? WHERE id = ?", 'Envio não configurado (defina RESEND_API_KEY e o e-mail remetente).', id);
        if (!cfg.isTest) console.log(`[e-mail simulado] para ${row.to_email}: ${row.subject}`);
        return;
      }
      if (!from) {
        db.run("UPDATE emails SET status = 'failed', error = ? WHERE id = ?", 'Remetente não configurado (EMAIL_FROM ou configurações do painel).', id);
        return;
      }
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${cfg.email.resendApiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [row.to_email], subject: row.subject, html: row.html, text: row.text, ...(settings.get('email_reply_to') || cfg.email.replyTo ? { reply_to: settings.get('email_reply_to') || cfg.email.replyTo } : {}) }),
        signal: AbortSignal.timeout(15000),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(`Resend ${res.status}: ${data?.message || data?.name || 'erro'}`);
      db.run("UPDATE emails SET status = 'sent', provider_id = ?, sent_at = ?, error = NULL WHERE id = ?", data.id || null, now(), id);
    } catch (e) {
      db.run("UPDATE emails SET status = 'failed', error = ? WHERE id = ?", String(e.message).slice(0, 300), id);
    }
  }

  const email = {
    TEMPLATES,
    templateSettings: tpl,
    sender,

    /** Enfileira e dispara o envio em segundo plano. Nunca derruba a operação que o chamou. */
    queue(key, to, data = {}, meta = {}) {
      try {
        if (!TEMPLATES[key]) throw new Error(`modelo desconhecido: ${key}`);
        if (!validEmail(to)) return null;
        if (!tpl(key).enabled && key !== 'verify_email' && key !== 'reset_password') return null;
        const built = build(key, data);
        const id = db.run("INSERT INTO emails (to_email, template, subject, html, text, status, order_id, customer_id, created_at) VALUES (?,?,?,?,?,'queued',?,?,?)", to, key, built.subject, built.html, built.text, meta.orderId ?? data.order?.id ?? null, meta.customerId ?? null, now()).id;
        const p = deliver(id).catch((e) => console.error('[e-mail]', e.message)).finally(() => inflight.delete(p));
        inflight.add(p);
        return id;
      } catch (e) {
        console.error('[e-mail] falha ao enfileirar:', e.message);
        return null;
      }
    },

    /** Aguarda envios pendentes (usado nos testes e no encerramento do servidor). */
    async idle() {
      while (inflight.size) await Promise.allSettled([...inflight]);
    },

    async resend(id) {
      const row = db.get('SELECT * FROM emails WHERE id = ?', id);
      if (!row) throw new UserError('E-mail não encontrado.');
      db.run("UPDATE emails SET status = 'queued', error = NULL WHERE id = ?", id);
      await deliver(id);
      return db.get('SELECT status, error FROM emails WHERE id = ?', id);
    },

    /** Aviso ao administrador (e-mail + sino de notificações no painel). */
    notifyAdmin({ kind, title, body, link }) {
      db.run('INSERT INTO notifications (kind, title, body, link, created_at) VALUES (?,?,?,?,?)', kind, title, body || null, link || null, now());
      const to = settings.get('admin_notify_email') || cfg.adminNotifyEmail || settings.get('store_email');
      if (to) this.queue('admin_notice', to, { subject: title, message: body || title, link });
    },

    list({ status = '', limit = 200 } = {}) {
      return db.all(`SELECT id, to_email, template, subject, status, error, attempts, order_id, created_at, sent_at FROM emails ${status ? 'WHERE status = ?' : ''} ORDER BY id DESC LIMIT ?`, ...(status ? [status, limit] : [limit]));
    },
    get: (id) => db.get('SELECT * FROM emails WHERE id = ?', id),
    prune(days = 90) {
      db.run('UPDATE emails SET html = NULL, text = NULL WHERE created_at < ? AND html IS NOT NULL', new Date(Date.now() - days * 86400000).toISOString());
    },
    escape,
    raw,
  };
  return email;
}

module.exports = { makeEmail, TEMPLATES };
