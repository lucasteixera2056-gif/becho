/* Painel — melhorias progressivas: menu lateral, confirmações, impressão e envio de imagens (reduzidas no navegador). */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // menu lateral (telas pequenas)
  var tg = $('[data-side-toggle]');
  var setSide = function (open) {
    document.body.classList.toggle('side-open', open);
    if (tg) tg.setAttribute('aria-expanded', open ? 'true' : 'false');
  };
  if (tg) {
    tg.addEventListener('click', function () { setSide(!document.body.classList.contains('side-open')); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setSide(false); });
    document.addEventListener('click', function (e) { if (document.body.classList.contains('side-open') && !e.target.closest('.side') && !e.target.closest('[data-side-toggle]')) setSide(false); });
  }

  // confirmação em formulários destrutivos (data-confirm no <form> ou no botão)
  document.addEventListener('submit', function (e) {
    var f = e.target;
    var msg = f.getAttribute && f.getAttribute('data-confirm');
    var sub = e.submitter && e.submitter.getAttribute('data-confirm');
    if ((msg || sub) && !window.confirm(sub || msg)) e.preventDefault();
  });

  // imprimir
  $$('[data-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });

  // filtros que enviam sozinhos
  $$('[data-autosubmit]').forEach(function (s) { s.addEventListener('change', function () { s.form.submit(); }); });

  // fecha o menu do usuário ao clicar fora
  document.addEventListener('click', function (e) {
    $$('details.usermenu[open]').forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute('open'); });
  });

  // ───── envio de imagens ─────
  var csrf = (($('meta[name="csrf"]') || {}).content) || '';

  function loadBitmap(file) {
    if (window.createImageBitmap) return createImageBitmap(file);
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { var im = new Image(); im.onload = function () { resolve(im); }; im.onerror = reject; im.src = fr.result; };
      fr.onerror = reject; fr.readAsDataURL(file);
    });
  }

  /** Reduz a imagem para no máximo `max` px no maior lado. PNG pequeno (logotipo) mantém transparência. */
  function shrink(file, max) {
    return loadBitmap(file).then(function (bmp) {
      var w = bmp.width, h = bmp.height, k = Math.min(1, max / Math.max(w, h));
      var cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
      var c = document.createElement('canvas'); c.width = cw; c.height = ch;
      var ctx = c.getContext('2d');
      var keepPng = file.type === 'image/png' && max <= 800;
      if (!keepPng) { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, cw, ch); }
      ctx.drawImage(bmp, 0, 0, cw, ch);
      return new Promise(function (resolve, reject) {
        c.toBlob(function (b) { b ? resolve(b) : reject(new Error('Não foi possível processar a imagem.')); }, keepPng ? 'image/png' : 'image/jpeg', 0.86);
      });
    });
  }

  function send(endpoint, blob) {
    return fetch(endpoint, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-CSRF-Token': csrf, Accept: 'application/json' }, body: blob })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Resposta inesperada do servidor.' }; }); });
  }

  $$('[data-uploader]').forEach(function (box) {
    var input = $('input[type="file"]', box), status = $('[data-status]', box);
    var endpoint = box.getAttribute('data-endpoint');
    var max = parseInt(box.getAttribute('data-max'), 10) || 1600;
    var say = function (t, bad) { if (status) { status.textContent = t; status.style.color = bad ? '#9b2430' : ''; } };
    if (!input) return;
    input.addEventListener('change', function () {
      var files = Array.prototype.slice.call(input.files || []);
      if (!files.length) return;
      box.classList.add('busy');
      var done = 0, failed = 0, last = null;
      var next = function (i) {
        if (i >= files.length) {
          box.classList.remove('busy'); input.value = '';
          if (failed) { say(done + ' enviada(s); ' + failed + ' com erro.', true); return; }
          if (box.hasAttribute('data-reload') && done) { say('Pronto! Atualizando…'); window.location.reload(); return; }
          var tgt = box.getAttribute('data-target');
          if (tgt && last) {
            var el = $(tgt); if (el) el.value = last;
            var pv = box.getAttribute('data-preview') && $(box.getAttribute('data-preview'));
            if (pv) { pv.src = '/uploads/' + last; pv.hidden = false; }
            say('Imagem pronta. Clique em Salvar para aplicar.');
          }
          return;
        }
        say('Enviando ' + (i + 1) + ' de ' + files.length + '…');
        var f = files[i];
        shrink(f, max).catch(function () { return f.size <= 8 * 1024 * 1024 && /^image\/(jpeg|png|webp)$/.test(f.type) ? f : Promise.reject(new Error('Formato não suportado: use JPG, PNG ou WebP.')); })
          .then(function (blob) { return send(endpoint, blob); })
          .then(function (j) { if (j && j.ok) { done++; last = j.filename || last; } else { failed++; say((j && j.error) || 'Erro no envio.', true); } })
          .catch(function (e) { failed++; say(e.message || 'Erro no envio.', true); })
          .then(function () { next(i + 1); });
      };
      next(0);
    });
  });
})();
