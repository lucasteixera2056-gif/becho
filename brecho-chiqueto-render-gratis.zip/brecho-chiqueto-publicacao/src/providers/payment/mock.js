'use strict';
/**
 * Provedor SIMULADO — existe somente para desenvolvimento e testes automatizados.
 * É proibido em produção (config.js recusa PAYMENT_PROVIDER=mock com NODE_ENV=production).
 * Ele guarda o "estado do lado do provedor" em mock_provider_charges e fala com a loja exatamente
 * como um provedor real: webhook assinado (HMAC) + consulta autoritativa getPayment().
 * Nenhum dinheiro real é movimentado e as taxas abaixo são fictícias, apenas para testar os relatórios.
 */
const crypto = require('node:crypto');
const { ProviderError } = require('./common');
const { safeEqual } = require('../../lib/security');
const { now } = require('../../lib/util');

const svgQr = (id) => {
  const text = `SIMULADO ${id}`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 240 240"><rect width="240" height="240" fill="#fff"/><rect x="12" y="12" width="216" height="216" fill="none" stroke="#000" stroke-width="6" stroke-dasharray="14 8"/><text x="120" y="110" text-anchor="middle" font-family="sans-serif" font-size="20" font-weight="700">PIX SIMULADO</text><text x="120" y="140" text-anchor="middle" font-family="sans-serif" font-size="11">${text.slice(0, 28)}</text><text x="120" y="165" text-anchor="middle" font-family="sans-serif" font-size="11">(ambiente de teste)</text></svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
};

function makeMock(cfg, db) {
  const secret = cfg.payment.mock.webhookSecret;
  const sign = (raw) => crypto.createHmac('sha256', secret).update(raw).digest('hex');

  return {
    name: 'mock',
    label: 'Simulado (somente testes)',
    requiresCpf: false,
    sandbox: true,
    configured: () => true,
    webhookReady: () => true,
    missing: () => [],
    sign,

    async createPixCharge({ order, expiresAt }) {
      const id = `mock_${crypto.randomBytes(8).toString('hex')}`;
      db.run('INSERT INTO mock_provider_charges (id, reference, amount_cents, status, expires_at, created_at) VALUES (?,?,?,?,?,?)', id, order.number, order.total_cents, 'pending', expiresAt, now());
      return { providerId: id, pixPayload: `00020126MOCKPIX-${id}-${order.total_cents}-SIMULADO`, qrImage: svgQr(id), raw: {} };
    },

    async getPayment(providerId) {
      const r = db.get('SELECT * FROM mock_provider_charges WHERE id = ?', providerId);
      if (!r) throw new ProviderError('Cobrança não encontrada no provedor simulado.', { status: 404 });
      const status = r.status === 'paid' && r.refunded_cents >= r.amount_cents ? 'refunded' : r.status;
      const fee = r.status === 'paid' || r.refunded_cents ? Math.round(r.amount_cents * 0.0099) : null;
      return {
        providerId: r.id, status, rawStatus: r.status, amountCents: r.amount_cents, currency: 'BRL', reference: r.reference,
        feeCents: fee, netCents: fee === null ? null : r.amount_cents - fee, paidAt: r.paid_at, settlementDate: r.paid_at ? r.paid_at.slice(0, 10) : null, refundedCents: r.refunded_cents,
      };
    },

    async cancelCharge(providerId) {
      db.run("UPDATE mock_provider_charges SET status = 'cancelled' WHERE id = ? AND status = 'pending'", providerId);
    },

    async refund(providerId, amountCents) {
      const r = db.get('SELECT * FROM mock_provider_charges WHERE id = ?', providerId);
      if (!r || r.status !== 'paid') throw new ProviderError('Só é possível reembolsar cobranças pagas.', { status: 400 });
      if (r.refunded_cents + amountCents > r.amount_cents) throw new ProviderError('Valor acima do disponível para reembolso.', { status: 400 });
      db.run('UPDATE mock_provider_charges SET refunded_cents = refunded_cents + ? WHERE id = ?', amountCents, providerId);
      return { providerRefundId: `mockrefund_${crypto.randomBytes(4).toString('hex')}`, status: 'done' };
    },

    verifyWebhook(headers, rawBody) {
      return safeEqual(headers['x-mock-signature'], sign(rawBody)) ? { ok: true } : { ok: false, reason: 'assinatura inválida' };
    },

    parseWebhook(body) {
      if (!body || !body.payment_id) return [];
      return [{ eventId: String(body.event_id || `${body.type}:${body.payment_id}`), type: String(body.type || 'payment'), providerPaymentId: String(body.payment_id) }];
    },

    // ───── somente simulação ─────
    /** "O cliente pagou no banco." Muda o estado no provedor simulado e devolve o corpo do webhook correspondente. */
    simulatePay(providerId, eventId = null) {
      const r = db.get('SELECT * FROM mock_provider_charges WHERE id = ?', providerId);
      if (!r) throw new Error('cobrança inexistente');
      if (r.status === 'pending') db.run("UPDATE mock_provider_charges SET status = 'paid', paid_at = ? WHERE id = ?", now(), providerId);
      return { event_id: eventId || `evt_${crypto.randomBytes(6).toString('hex')}`, type: 'payment.paid', payment_id: providerId };
    },
  };
}

module.exports = { makeMock };
