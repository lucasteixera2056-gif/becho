'use strict';
/** Monta o roteador e os ganchos do servidor HTTP. */
const path = require('node:path');
const fs = require('node:fs');
const { Router, createServer } = require('../lib/router');
const { errorPage } = require('./layout');

function buildRouter(app) {
  const router = new Router();
  for (const mod of ['store', 'checkout', 'account']) require(`./${mod}`).register(router, app);
  const adminDir = path.join(__dirname, 'admin');
  if (fs.existsSync(path.join(adminDir, 'index.js'))) require('./admin').register(router, app);
  return router;
}

function buildServer(app, log = console) {
  const router = buildRouter(app);
  const adminError = fs.existsSync(path.join(__dirname, 'admin', 'index.js')) ? require('./admin').errorPage : null;
  const show = (ctx, status, message) => (adminError && ctx.path.startsWith('/admin') ? adminError(ctx, app, status, message) : errorPage(ctx, app, status, message));
  const hooks = {
    getCustomer: (ctx) => app.auth.getCustomer(ctx),
    getStaff: (ctx) => app.auth.getStaff(ctx),
    can: (staff, perm) => app.permissions.can(staff, perm),
    notFound: (ctx) => show(ctx, 404, 'Não encontramos o que você procurava.'),
    errorPage: (ctx, status, message) => show(ctx, status, message),
  };
  return createServer({ cfg: app.cfg, router, hooks, publicDir: path.join(app.cfg.root, 'public'), log });
}

module.exports = { buildRouter, buildServer };
