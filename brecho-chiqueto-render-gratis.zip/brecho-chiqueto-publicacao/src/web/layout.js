'use strict';
/** Estrutura comum das páginas públicas: cabeçalho, rodapé, SEO e Open Graph. */
const { html, raw, escape, jsonForScript } = require('../lib/html');
const { icon, csrfField, flashBox, imgUrl } = require('./ui');

const COLOR_RE = /^#[0-9a-fA-F]{6}$/;
const safeColor = (c, fallback) => (COLOR_RE.test(c || '') ? c : fallback);

/** Variáveis CSS vindas das configurações (cores validadas). */
function themeStyle(s) {
  const heading = s.font_heading === 'sans' ? 'var(--font-sans)' : 'var(--font-serif)';
  return raw(`:root{--primary:${safeColor(s.color_primary, '#8C2F39')};--accent:${safeColor(s.color_accent, '#B08D57')};--bg:${safeColor(s.color_bg, '#FAF6F1')};--ink:${safeColor(s.color_ink, '#2A2220')};--font-heading:${heading}}`);
}

const abs = (cfg, p) => (/^https?:\/\//.test(p) ? p : `${cfg.baseUrl}${p}`);

function waLink(s, text = '') {
  const n = String(s.store_whatsapp || '').replace(/\D/g, '');
  if (n.length < 10) return '';
  const full = n.length <= 11 ? `55${n}` : n;
  return `https://wa.me/${full}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
}

/**
 * @param {object} o { title, description, path, image, ogType, jsonld[], noindex, bodyClass, main }
 */
function storeLayout(ctx, app, o) {
  const { cfg } = app;
  const s = app.settings.all();
  const store = s.store_name;
  const title = o.title ? `${o.title} · ${store}` : `${store}${s.store_tagline ? ` — ${s.store_tagline}` : ''}`;
  const desc = (o.description || s.store_description || s.store_tagline || '').slice(0, 300);
  const canonical = abs(cfg, o.path ?? ctx.path);
  const ogImage = o.image ? abs(cfg, o.image) : s.logo_file ? abs(cfg, imgUrl(s.logo_file)) : '';
  const cartCount = app.cart.count(ctx);
  const tree = app.catalog.categoryTree();
  const pages = app.content.pages();
  const wa = waLink(s);
  const customer = ctx.customer;
  const q = ctx.query.q || '';

  return html`<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
${desc ? html`<meta name="description" content="${desc}">` : ''}
<link rel="canonical" href="${canonical}">
${o.noindex ? html`<meta name="robots" content="noindex, nofollow">` : ''}
<meta property="og:site_name" content="${store}">
<meta property="og:locale" content="pt_BR">
<meta property="og:type" content="${o.ogType || 'website'}">
<meta property="og:title" content="${o.title || store}">
${desc ? html`<meta property="og:description" content="${desc}">` : ''}
<meta property="og:url" content="${canonical}">
${ogImage ? html`<meta property="og:image" content="${ogImage}"><meta name="twitter:card" content="summary_large_image">` : html`<meta name="twitter:card" content="summary">`}
<meta name="theme-color" content="${safeColor(s.color_primary, '#8C2F39')}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/css/store.css?v=${cfg.assetVersion}">
<style>${themeStyle(s)}</style>
${(o.jsonld || []).map((j) => html`<script type="application/ld+json">${jsonForScript(j)}</script>`)}
</head>
<body class="${o.bodyClass || ''}">
<a class="skip" href="#conteudo">Ir para o conteúdo</a>
<header class="site-header">
  <div class="wrap bar">
    <button class="icon-btn menu-btn" type="button" data-menu-toggle aria-expanded="false" aria-controls="menu" aria-label="Abrir menu">${icon('menu', 24)}</button>
    <a class="brand" href="/" aria-label="${store} — página inicial">${s.logo_file ? html`<img src="${imgUrl(s.logo_file)}" alt="${store}" height="40">` : html`<span>${store}</span>`}</a>
    <form class="search" role="search" action="/loja" method="get">
      <label class="sr" for="busca">Buscar peças</label>
      <input id="busca" name="q" type="search" value="${q}" placeholder="Buscar vestido, marca, tamanho…" autocomplete="off">
      <button type="submit" aria-label="Buscar">${icon('search', 20)}</button>
    </form>
    <nav class="actions" aria-label="Conta e carrinho">
      <a class="icon-btn" href="${customer ? '/minha-conta' : '/minha-conta/entrar'}" aria-label="${customer ? 'Minha conta' : 'Entrar'}">${icon('user', 22)}<span class="lbl">${customer ? 'Minha conta' : 'Entrar'}</span></a>
      <a class="icon-btn cart-link" href="/carrinho" aria-label="Carrinho, ${cartCount} ${cartCount === 1 ? 'item' : 'itens'}">${icon('cart', 22)}<span class="lbl">Carrinho</span>${cartCount ? html`<span class="count" data-cart-count>${cartCount}</span>` : html`<span class="count" data-cart-count hidden>0</span>`}</a>
    </nav>
  </div>
  <nav class="site-nav" id="menu" aria-label="Categorias" data-menu>
    <div class="wrap">
      <a href="/loja?sort=novidades">Novidades</a>
      ${tree.map((c) => html`<a href="/loja/${c.slug}">${c.name}</a>`)}
      <a href="/loja?promo=1">Promoções</a>
      <a href="/contato" class="only-menu">Contato</a>
    </div>
  </nav>
</header>
<main id="conteudo" tabindex="-1">
${flashBox(ctx)}
${o.main}
</main>
<footer class="site-footer">
  <div class="wrap grid">
    <section>
      <h2 class="brand-sm">${store}</h2>
      <p>${s.footer_text || s.store_tagline}</p>
      <ul class="social">
        ${s.store_instagram ? html`<li><a href="${s.store_instagram}" target="_blank" rel="noopener noreferrer">${icon('instagram', 18)} Instagram</a></li>` : ''}
        ${wa ? html`<li><a href="${wa}" target="_blank" rel="noopener noreferrer">${icon('whatsapp', 18)} WhatsApp</a></li>` : ''}
      </ul>
    </section>
    <section>
      <h2>Ajuda</h2>
      <ul>
        <li><a href="/contato">Fale com a gente</a></li>
        ${pages.map((p) => html`<li><a href="/p/${p.slug}">${p.title}</a></li>`)}
        <li><a href="/privacidade/solicitacoes">Seus dados (LGPD)</a></li>
      </ul>
    </section>
    <section>
      <h2>Novidades por e-mail</h2>
      <form method="post" action="/newsletter" class="news-form">
        ${csrfField(ctx)}
        <label class="sr" for="news_email">Seu e-mail</label>
        <input id="news_email" name="email" type="email" placeholder="seu@email.com" required autocomplete="email">
        <label class="check small"><input type="checkbox" name="consent" value="1" required> Quero receber novidades do brechó por e-mail. Posso cancelar quando quiser.</label>
        <button class="btn btn-small" type="submit">Inscrever</button>
      </form>
      ${s.store_email || s.store_phone || s.store_address || s.store_hours ? html`<address>${s.store_address ? html`${s.store_address}<br>` : ''}${s.store_hours ? html`${s.store_hours}<br>` : ''}${s.store_phone ? html`${s.store_phone}<br>` : ''}${s.store_email}</address>` : ''}
    </section>
  </div>
  <div class="wrap legal">
    <span>© ${new Date().getFullYear()} ${store}.${s.store_document ? ` ${s.store_document}.` : ''} Todos os direitos reservados.</span>
    <span>${icon('pix', 14)} Pagamento por Pix · ${icon('lock', 14)} Ambiente seguro</span>
  </div>
</footer>
${wa && !o.noFloatingWa ? html`<a class="wa-float" href="${wa}" target="_blank" rel="noopener noreferrer" aria-label="Falar pelo WhatsApp">${icon('whatsapp', 26)}</a>` : ''}
<script src="/js/store.js?v=${cfg.assetVersion}" defer></script>
</body>
</html>`;
}

function orgJsonLd(app) {
  const { cfg } = app;
  const s = app.settings.all();
  const sameAs = [s.store_instagram].filter(Boolean);
  return {
    '@context': 'https://schema.org', '@type': 'Store', name: s.store_name, url: cfg.baseUrl,
    ...(s.logo_file ? { logo: `${cfg.baseUrl}${imgUrl(s.logo_file)}` } : {}), ...(s.store_description ? { description: s.store_description } : {}),
    ...(sameAs.length ? { sameAs } : {}), ...(s.store_email ? { email: s.store_email } : {}), ...(s.store_phone ? { telephone: s.store_phone } : {}),
  };
}

function errorPage(ctx, app, status, message) {
  const titles = { 400: 'Solicitação inválida', 401: 'Faça login', 403: 'Acesso negado', 404: 'Página não encontrada', 405: 'Método não permitido', 413: 'Conteúdo grande demais', 422: 'Não foi possível concluir', 429: 'Muitas tentativas' };
  const t = titles[status] || 'Algo deu errado';
  const main = html`<section class="wrap narrow center error-page"><p class="code">${status}</p><h1>${t}</h1><p>${message}</p><p><a class="btn" href="/">Voltar ao início</a> <a class="btn btn-ghost" href="/loja">Ver as peças</a></p></section>`;
  ctx.html(storeLayout(ctx, app, { title: t, main, noindex: true, noFloatingWa: true }), status);
}

module.exports = { storeLayout, orgJsonLd, errorPage, waLink, abs, themeStyle, safeColor };
