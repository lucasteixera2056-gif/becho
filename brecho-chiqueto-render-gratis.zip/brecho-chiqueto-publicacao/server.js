'use strict';
/** Ponto de entrada: sobe a loja. Configuração por variáveis de ambiente (.env). */
const { buildConfig } = require('./src/config');
const { buildApp } = require('./src/app');
const { buildServer } = require('./src/web');

async function main() {
  const cfg = buildConfig();
  const app = buildApp(cfg);
  await app.auth.ensureBootstrapAdmin().then((created) => {
    if (created) console.log(`[admin] Primeiro acesso criado para ${cfg.adminBootstrap.email}. A senha precisa ser trocada no primeiro login.`);
  });
  if (!app.db.value('SELECT COUNT(*) FROM staff_users')) {
    console.warn('[admin] Nenhum administrador cadastrado. Rode `npm run create-admin` ou defina ADMIN_EMAIL e ADMIN_PASSWORD no .env e reinicie.');
  }

  const server = buildServer(app);
  server.listen(cfg.port, cfg.host, () => {
    console.log(`Loja no ar: ${cfg.baseUrl} (porta ${cfg.port}, ${cfg.nodeEnv})`);
    const pay = app.payments.status();
    if (!pay.configured) console.warn(`[pagamentos] Provedor Pix NÃO configurado (faltando: ${pay.missing.join(', ')}). A loja não conseguirá finalizar pedidos.`);
    else console.log(`[pagamentos] ${pay.label}${pay.sandbox ? ' (SANDBOX/TESTE)' : ''}${pay.webhookReady ? '' : ' — webhook sem segredo configurado'}`);
    if (cfg.email.transport !== 'resend') console.warn('[e-mail] Resend não configurado: e-mails ficam registrados como "não enviados" no painel.');
    if (cfg.isProd && !cfg.cookieSecure) console.warn('[segurança] Produção sem HTTPS (BASE_URL deve começar com https://).');
  });
  app.jobs.start();

  let closing = false;
  const stop = async (sig) => {
    if (closing) return;
    closing = true;
    console.log(`\n${sig}: encerrando…`);
    server.close();
    setTimeout(() => process.exit(0), 8000).unref();
    await app.close();
    process.exit(0);
  };
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('unhandledRejection', (e) => console.error('[erro] promessa rejeitada:', e));
}

main().catch((e) => {
  console.error('Falha ao iniciar:', e.message);
  process.exit(1);
});
