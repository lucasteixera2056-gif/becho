# Manual do painel — Brechó Chiqueto

Para quem cuida da loja no dia a dia. Endereço do painel: **`https://seu-dominio.com.br/admin`**.
Não precisa saber programar. O que depende de contas externas (Pix, e-mail, frete) está em [`SERVICOS-EXTERNOS.md`](SERVICOS-EXTERNOS.md).

---

## 1. Primeiro acesso

1. Entre em `/admin` com o e-mail e a senha criados pela pessoa que instalou a loja.
2. O sistema **exige trocar a senha** no primeiro acesso (mínimo 10 caracteres, não pode ser parecida com o e-mail).
3. Abra o **Painel (início)**. A lista **“Antes de abrir a loja”** mostra, com ✔ ou aviso, o que ainda falta: Pix em produção, e-mails, forma de entrega, primeiras peças, contato, textos legais revisados.
4. Em **Configurações**, preencha com os dados reais: nome, e-mail, WhatsApp, endereço, horário (aparecem na loja só se você preencher), cores e textos do início, formas de entrega.

> **Segurança:** não compartilhe a sua senha. Cada pessoa da equipe deve ter o próprio acesso (menu **Funcionários**). Tudo o que cada um faz fica em **Atividades**.

---

## 2. Cadastrar uma peça

**Produtos → Nova peça.**

| Campo | Como preencher |
|---|---|
| Nome | Como o cliente verá. Ex.: “Vestido midi floral”. |
| Preço | Em reais, ex.: `89,90`. |
| Preço promocional | Opcional; precisa ser **menor** que o preço. Aparece riscado/em destaque. |
| Categoria, tamanho, marca, cor | Ajudam nos filtros da loja. |
| Estado de conservação, medidas, defeitos | Seja sincera: é o que evita devolução. Se houver defeito, descreva. |
| Quantidade | **Padrão 1** (peça única). Só aumente se tiver várias iguais. |
| Código (SKU) | Em branco = o sistema cria (`BC-0001`…). |
| Situação | **Rascunho** (não aparece), **Publicada** (aparece) ou **Arquivada** (guarda sem exibir). |

Depois de salvar, envie as **fotos** (JPG, PNG ou WebP, até 8 MB cada). A primeira é a principal; dá para reordenar, trocar a principal e excluir. O sistema confere se o arquivo é mesmo uma imagem.

**Ações na peça:**
- **Duplicar**: copia os dados para cadastrar outra parecida.
- **Vendida na loja física / fora do site**: zera o estoque e a peça some da loja (fica registrado como movimentação).
- **Excluir**: só se a peça **nunca foi vendida**. Se já teve pedido, arquive.

**Peça única e reservas.** Quando um cliente fecha o pedido, a peça fica **reservada** até o Pix vencer. Outra pessoa não consegue comprar. Se o Pix vence sem pagamento, a peça volta sozinha à vitrine. Uma peça vendida ou reservada **nunca** é vendida duas vezes.

---

## 3. Estoque

**Estoque** mostra, por peça: *em estoque*, *reservado* e *disponível*. Para peças com várias unidades, use **Entrada (+)**, **Saída (−)** ou **Definir para**, sempre com **motivo** (compra, ajuste, perda/dano, venda na loja física, devolução, outro). Nada é apagado: o histórico fica em **Movimentações** (com quem fez e quando) e pode ser exportado em CSV.

- O sistema **não deixa o saldo ficar negativo** nem reduzir abaixo do que está reservado em pedidos aguardando pagamento.
- No cadastro da peça, “Avisar quando restar até” coloca a peça no filtro **Estoque baixo** do início.

---

## 4. Pedidos

**Pedidos** lista tudo, com busca (número, nome, e-mail, telefone) e filtros por situação.

### Como um pedido anda

`Aguardando pagamento → Pagamento confirmado → Em preparação → Enviado → (Em transporte) → Entregue`

(Retirada na loja: *Separando para retirada → Pronto para retirada → Retirado*; entrega local: *Saiu para entrega*.)

- **Aguardando pagamento** e **Pagamento confirmado** são definidos **somente pelo sistema**, a partir do aviso do provedor de Pix. **Não existe botão para marcar como pago** — nem para você, nem para o administrador. Isso protege você de erro e de fraude.
- Você move o pedido a partir de “Pagamento confirmado”: **Em preparação → Enviado → Entregue**. Cada passo avisa o cliente por e-mail (se os e-mails estiverem configurados).
- Em **Enviado**, registre o **código de rastreio** e, se quiser, o link. O cliente recebe no e-mail e na página do pedido.
- **Cancelar pedido** só funciona para pedido **não pago** (libera a peça e devolve o cupom). Se o cliente pagar no mesmo instante, o sistema recusa o cancelamento.
- Pedido **pago** que precisa ser desfeito → **Reembolsar** (veja abaixo).
- **Imprimir** gera a folha do pedido para separar e despachar.

### Reembolso

No pedido pago: **Reembolsar**, informe o valor (total ou parcial), o motivo e se **a peça volta ao estoque**. O reembolso é feito no provedor de Pix; só quem tem a permissão “Reembolsar pagamentos” vê o botão. Reembolso total muda o pedido para *Reembolsado*; parcial registra o valor sem mudar o andamento.

### Pedidos que “precisam de atenção”

O sistema marca um pedido com **atenção** (aparece em vermelho no início) quando algo foge do normal e **exige decisão humana**, por exemplo:
- o valor pago no provedor é **diferente** do valor do pedido;
- um Pix foi pago **depois** de o pedido expirar e a peça já foi vendida a outra pessoa → o certo é **reembolsar**;
- o provedor devolveu algo inesperado.

Abra o pedido: a linha do tempo explica o que aconteceu. **Verificar pagamento** consulta o provedor de novo.

### Pix pendentes

Em **Pagamentos (Pix)** há o botão **Conferir Pix pendentes no provedor**: é uma rede de segurança caso algum aviso automático tenha falhado. O sistema também faz isso sozinho a cada 30 segundos.

---

## 5. Clientes e privacidade (LGPD)

- **Clientes**: busca, histórico de pedidos, observação interna, **bloquear** (impede novos pedidos e derruba a sessão). O CPF aparece **mascarado**; só quem tem a permissão “Ver dados pessoais completos” enxerga inteiro.
- **LGPD** (menu Atendimento): pedidos de **acesso** ou **eliminação** de dados feitos pelos clientes. O prazo para responder é de **15 dias** (o aviso aparece no início). Para eliminar: abra o cliente → **Anonimizar**. Isso apaga nome, contatos, CPF, endereços e senha, **mas mantém os pedidos** (obrigação fiscal e defesa em processos). Se houver pedido em andamento, o sistema recusa até que ele termine. Depois, marque a solicitação como atendida e responda ao titular por e-mail.
- **Newsletter**: só entra quem marcou o consentimento; cada e-mail tem link para cancelar. A lista (CSV) só traz quem **não** cancelou.
- Os **textos legais** (Privacidade, Termos, Trocas e devoluções, Cancelamento e reembolso, Entrega e retirada) vêm como **modelo**. **Peça a um(a) advogado(a) para revisar** e depois marque como revisados em **Páginas e textos**.

---

## 6. Cupons

**Cupons → Novo**: código, tipo (**percentual** ou **valor fixo**), valor, **pedido mínimo**, validade (início e fim), **limite de usos**, e, se quiser, **restrição a peças específicas**. O desconto nunca deixa o pedido de graça (sempre sobra pelo menos R$ 1,00). Cupom já usado em pedido não pode ser excluído — desative.

---

## 7. Relatórios

**Relatórios** (hoje, 7/30 dias, mês, tudo ou datas) mostra **medidas separadas** — nada de misturar:

| Número | Significa |
|---|---|
| **Pedidos criados** | Pedidos feitos no período, em qualquer situação. |
| **Faturado** | Pedidos cujo **pagamento foi confirmado** no período (antes de reembolsos). |
| **Recebido** | Pagamentos confirmados menos reembolsos do período. |
| **Pendente agora** | Pix ainda aguardando pagamento. |
| **Taxas e líquido** | **Só aparecem quando o provedor informa.** O sistema nunca estima taxa. |
| **Liquidado / A liquidar** | Conforme a data de liquidação que o provedor informa. Confira sempre o extrato do provedor. |

Exportar: **Pedidos**, **Pagamentos**, **Produtos e estoque** e **Clientes** em CSV (abre no Excel/Planilhas), e **Imprimir**. Se o provedor estiver em **modo de teste**, o relatório avisa que os valores não são dinheiro real.

---

## 8. Conteúdo da loja

- **Banners**: imagem, título, texto, link, ordem e período de exibição.
- **Páginas e textos**: edição das páginas legais e institucionais; **Restaurar texto original** desfaz suas mudanças.
- **Configurações → Aparência e início**: cores, título e botão do início, “Sobre o brechó”, chamada para o Instagram.
- Só entra na loja o que você preencher. Campos vazios (endereço, telefone…) **não aparecem**.

---

## 9. Entrega

**Configurações → Entrega.** Você pode ter várias formas ao mesmo tempo:

| Tipo | Quando usar |
|---|---|
| **Frete fixo** | Um valor único. Dá para definir “grátis acima de R$ …” e o texto do prazo. |
| **Retirada presencial** | Sem custo; cliente retira. Informe a orientação em “Retirada” (endereço e horário você preenche). |
| **Entrega local** | Valor fixo para uma lista de **prefixos de CEP** atendidos (ex.: `13000, 13010`). |
| **Melhor Envio** | Cotação em tempo real dos serviços da sua conta. Precisa de token (veja `SERVICOS-EXTERNOS.md`). |
| **Correios** | Reservado: **ainda não está integrado** (exige contrato próprio). Não aparece para o cliente. |

O sistema **não inventa preço nem prazo**: se a cotação falhar ou faltar credencial, a opção simplesmente não é oferecida. Em frete fixo, o prazo exibido é o texto que **você** escreveu.

---

## 10. E-mails

**E-mails enviados** mostra cada e-mail da loja (confirmação de cadastro, pedido recebido, Pix gerado, pagamento confirmado, enviado, entregue, cancelado, reembolso…) com situação: *enviado*, *falhou* (com o motivo), *não enviado* (sem Resend configurado). Dá para **reenviar**. Os textos e assuntos podem ser editados em **Configurações → E-mails**; dá para desativar avisos, **exceto** confirmação de e-mail e recuperação de senha. Importante: o Resend **envia**, mas **não recebe** respostas — veja [`EMAIL.md`](EMAIL.md).

---

## 11. Equipe e permissões

**Funcionários** (superadministrador e administrador). Funções:

| Função | Pode, por padrão |
|---|---|
| **Superadministrador** | Tudo, inclusive editar a tabela de permissões das outras funções. Mantenha pelo menos um. |
| **Administrador** | Tudo, exceto gerenciar superadministradores. Só cria/edita funções abaixo da dele. |
| **Gerente** | Produtos, categorias, estoque, pedidos, cupons, relatórios. |
| **Atendente** | Clientes, pedidos, atendimento (mensagens, solicitações, LGPD, newsletter), e-mails. |
| **Estoquista** | Produtos e estoque. |

Regras: ninguém altera a **própria** função; funcionário novo entra com **senha temporária** e é obrigado a trocá-la; desativar derruba as sessões abertas. **Minha conta** permite trocar a senha e **encerrar outras sessões**. A tela de **Atividades** registra quem fez o quê (login, edição, reembolso, exportação, mudança de permissão…).

**Esqueci a senha do painel:** peça a outro administrador para definir uma nova senha, ou, no servidor: `npm run create-admin -- --email seu@email --reset`.

---

## 12. Rotina sugerida

**Todo dia:** abrir o Painel → tratar “precisam de atenção”, “pagos para separar/enviar”, mensagens e solicitações.
**Ao embalar:** Imprimir pedido → mover para *Em preparação* → ao despachar, *Enviado* + rastreio.
**Toda semana:** Relatórios → conferir **Recebido** x extrato do provedor; olhar *e-mails com falha* e *estoque baixo*.
**Todo mês:** conferir se o **backup** está sendo gerado e copiado para fora do servidor (veja [`PUBLICACAO.md`](PUBLICACAO.md)).
