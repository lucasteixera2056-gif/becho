'use strict';
/** Carrinho, checkout, página do pedido/Pix, consulta de status e webhooks dos provedores. */
const { html, raw, escape } = require('../lib/html');
const { money, UserError, onlyDigits, formatZip, formatPhone, UFS, validCpf, formatDate, int } = require('../lib/util');
const { icon, csrfField, imgUrl, field, selectField } = require('./ui');
const { storeLayout, waLink } = require('./layout');

function register(router, app) {
  const { cfg } = app;
  const nf = (ctx) => ({ noindex: true, noFloatingWa: true, ctx });
  void nf;

  const back = (ctx, fallback = '/carrinho') => {
    const r = ctx.req.headers.referer;
    if (r && r.startsWith(cfg.baseUrl)) {
      try { return new URL(r).pathname + new URL(r).search; } catch { /* usa fallback */ }
    }
    return fallback;
  };

  const itemsForShipping = (cart) => cart.items.filter((i) => !i.unavailable).map((i) => ({ weight_g: i.product.weight_g, price_cents: i.unit_cents, qty: i.qty }));

  // ───── carrinho ─────
  router.get('/carrinho', async (ctx) => {
    const cart = app.cart.view(ctx);
    const s = app.settings.all();
    const zip = onlyDigits(ctx.query.cep);
    let ship = null;
    if (zip.length === 8 && cart.count) ship = await app.shipping.quote({ zip, subtotalCents: cart.subtotal_cents, items: itemsForShipping(cart) });
    let coupon = null, couponError = '';
    if (cart.coupon_code && cart.count) {
      try {
        coupon = app.coupons.evaluate(cart.coupon_code, cart.items.filter((i) => !i.unavailable).map((i) => ({ product_id: i.product.id, unit_cents: i.unit_cents, qty: i.qty })), cart.subtotal_cents);
      } catch (e) {
        if (!(e instanceof UserError)) throw e;
        couponError = e.message;
      }
    }
    const discount = coupon?.discount_cents || 0;
    const main = html`<section class="wrap cart-page"><h1>Seu carrinho</h1>
${cart.problems.map((p) => html`<div class="flash flash-info" role="status">${icon('info', 18)}<span>${p}</span></div>`)}
${cart.items.length === 0 ? html`<div class="empty"><h2>Seu carrinho está vazio</h2><p>Que tal dar uma olhada nas peças mais recentes?</p><a class="btn" href="/loja?sort=novidades">Ver novidades</a></div>` : html`
<div class="cart-grid">
  <ul class="cart-list">${cart.items.map((i) => html`<li class="cart-item${i.unavailable ? ' unavailable' : ''}">
    <a class="ph thumb" href="/produto/${i.product.slug}">${i.product.image ? html`<img src="${imgUrl(i.product.image)}" alt="" loading="lazy">` : html`<span class="ph-empty" aria-hidden="true">${s.store_name.slice(0, 1)}</span>`}</a>
    <div class="body"><h2><a href="/produto/${i.product.slug}">${i.product.name}</a></h2><p class="muted small">${[i.product.size && `Tam. ${i.product.size}`, i.product.brand, i.product.sku].filter(Boolean).join(' · ')}</p>
      ${i.unavailable ? html`<p class="err">Peça indisponível — remova para continuar.</p>` : ''}
      <div class="line-actions">${i.max > 1 ? html`<form method="post" action="/carrinho/quantidade" class="qty-form">${csrfField(ctx)}<input type="hidden" name="product_id" value="${i.product.id}"><label class="sr" for="q${i.product.id}">Quantidade</label><input id="q${i.product.id}" name="qty" type="number" min="1" max="${i.max}" value="${i.qty}" inputmode="numeric"><button class="btn btn-small btn-ghost" type="submit">Atualizar</button></form>` : ''}
        <form method="post" action="/carrinho/remover">${csrfField(ctx)}<input type="hidden" name="product_id" value="${i.product.id}"><button class="linklike danger" type="submit">${icon('trash', 16)} Remover</button></form></div></div>
    <p class="line-total">${i.unavailable ? '' : money(i.total_cents)}</p></li>`)}</ul>
  <aside class="summary"><h2>Resumo</h2>
    <dl><div><dt>Subtotal</dt><dd>${money(cart.subtotal_cents)}</dd></div>${discount ? html`<div class="disc"><dt>Cupom ${coupon.coupon.code}</dt><dd>− ${money(discount)}</dd></div>` : ''}<div class="total"><dt>Total das peças</dt><dd>${money(cart.subtotal_cents - discount)}</dd></div></dl>
    <form method="post" action="/carrinho/cupom" class="coupon">${csrfField(ctx)}<label for="coupon">Cupom de desconto</label><div class="row"><input id="coupon" name="code" value="${cart.coupon_code || ''}" placeholder="Código" autocomplete="off" maxlength="30"><button class="btn btn-small btn-ghost" type="submit">${cart.coupon_code ? 'Trocar' : 'Aplicar'}</button></div>${couponError ? html`<p class="err small">${couponError}</p>` : ''}${cart.coupon_code ? html`<button class="linklike small" name="remove" value="1" type="submit">Remover cupom</button>` : ''}</form>
    <form method="get" action="/carrinho" class="cep"><label for="cep">Calcular frete</label><div class="row"><input id="cep" name="cep" value="${ctx.query.cep || ''}" inputmode="numeric" placeholder="00000-000" maxlength="9" autocomplete="postal-code"><button class="btn btn-small btn-ghost" type="submit">Calcular</button></div></form>
    ${ship ? (ship.options.length ? html`<ul class="ship-opts">${ship.options.map((o) => html`<li><span>${o.name}${o.eta_text ? html`<small>${o.eta_text}</small>` : ''}</span><strong>${o.price_cents ? money(o.price_cents) : 'Grátis'}</strong></li>`)}</ul>` : html`<p class="muted small">Nenhuma forma de entrega disponível para este CEP. ${waLink(s) ? 'Fale com a loja para combinar.' : ''}</p>`) : ''}
    ${ship?.warnings?.map((w) => html`<p class="err small">${w}</p>`) || ''}
    <a class="btn btn-block" href="/checkout" ${cart.count ? '' : raw('aria-disabled="true"')}>Finalizar compra</a>
    <p class="muted small center">${icon('lock', 14)} Pagamento por Pix, com confirmação automática.</p>
  </aside>
</div>`}</section>`;
    ctx.html(storeLayout(ctx, app, { title: 'Carrinho', main, noindex: true, noFloatingWa: true }));
  });

  router.post('/carrinho/adicionar', (ctx) => {
    const id = int(ctx.body.product_id);
    let result;
    try {
      result = app.cart.add(ctx, id, ctx.body.qty);
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      if (ctx.wantsJson()) return ctx.json({ ok: false, error: e.message }, 422);
      ctx.flash('error', e.message);
      return ctx.redirect(back(ctx, '/loja'));
    }
    if (ctx.wantsJson()) return ctx.json({ ok: true, count: app.cart.count(ctx) });
    if (ctx.body.buy_now === '1') return ctx.redirect('/checkout');
    ctx.flash('success', `“${result.product.name}” foi adicionada ao carrinho.`);
    ctx.redirect('/carrinho');
  });

  const cartAction = (fn) => (ctx) => {
    try { fn(ctx); } catch (e) { if (!(e instanceof UserError)) throw e; ctx.flash('error', e.message); }
    ctx.redirect('/carrinho');
  };
  router.post('/carrinho/remover', cartAction((ctx) => app.cart.remove(ctx, int(ctx.body.product_id))));
  router.post('/carrinho/quantidade', cartAction((ctx) => app.cart.setQty(ctx, int(ctx.body.product_id), ctx.body.qty)));
  router.post('/carrinho/cupom', cartAction((ctx) => {
    if (ctx.body.remove === '1') return app.cart.setCoupon(ctx, null);
    const code = String(ctx.body.code || '').trim().toUpperCase().slice(0, 30);
    if (!code) return app.cart.setCoupon(ctx, null);
    const cart = app.cart.view(ctx);
    app.coupons.evaluate(code, cart.items.filter((i) => !i.unavailable).map((i) => ({ product_id: i.product.id, unit_cents: i.unit_cents, qty: i.qty })), cart.subtotal_cents);
    app.cart.setCoupon(ctx, code);
    ctx.flash('success', `Cupom ${code} aplicado.`);
  }));

  // ───── API de frete (usada pelo checkout com JavaScript) ─────
  router.get('/api/frete', async (ctx) => {
    const lim = app.limiter.hit(`ship:${ctx.ip}`, 60, 600);
    if (!lim.ok) return ctx.json({ ok: false, error: 'Muitas consultas. Aguarde um pouco.' }, 429);
    const cart = app.cart.view(ctx);
    const q = await app.shipping.quote({ zip: ctx.query.zip, subtotalCents: cart.subtotal_cents, items: itemsForShipping(cart) });
    ctx.json({ ok: true, options: q.options.map((o) => ({ key: o.key, name: o.name, price_cents: o.price_cents, price: o.price_cents ? money(o.price_cents) : 'Grátis', eta: o.eta_text, kind: o.delivery_kind })), warnings: q.warnings });
  });

  // ───── checkout ─────
  async function renderCheckout(ctx, v = {}, err = {}, status = 200) {
    const cart = app.cart.view(ctx);
    if (!cart.count) { ctx.flash('info', 'Seu carrinho está vazio.'); return ctx.redirect('/carrinho'); }
    const s = app.settings.all();
    const provider = app.payments.provider();
    const pstat = app.payments.status();
    const c = ctx.customer;
    const defAddr = c ? app.crm.customerAddresses(c.id).find((a) => a.is_default) || app.crm.customerAddresses(c.id)[0] : null;
    const val = { name: c?.name || '', email: c?.email || '', phone: c?.phone || '', zip: defAddr?.zip || '', state: defAddr?.state || '', city: defAddr?.city || '', district: defAddr?.district || '', street: defAddr?.street || '', number: defAddr?.number || '', complement: defAddr?.complement || '', ...v };
    const zip = onlyDigits(val.zip);
    const quote = await app.shipping.quote({ zip, subtotalCents: cart.subtotal_cents, items: itemsForShipping(cart) });
    let coupon = null, couponError = '';
    const code = v.coupon_code || cart.coupon_code;
    if (code) {
      try { coupon = app.coupons.evaluate(code, cart.items.filter((i) => !i.unavailable).map((i) => ({ product_id: i.product.id, unit_cents: i.unit_cents, qty: i.qty })), cart.subtotal_cents); } catch (e) { if (!(e instanceof UserError)) throw e; couponError = e.message; }
    }
    const discount = coupon?.discount_cents || 0;
    const chosen = quote.options.find((o) => o.key === String(val.shipping_key));
    const total = cart.subtotal_cents - discount + (chosen?.price_cents || 0);
    const noShipping = app.shipping.methods().length === 0;

    const main = html`<section class="wrap checkout"><h1>Finalizar compra</h1>
${!pstat.configured ? html`<div class="notice notice-sold"><strong>Os pagamentos ainda não estão ativos nesta loja.</strong><p>Você pode montar o carrinho, mas só será possível finalizar quando o pagamento por Pix for configurado.${waLink(s) ? ' Fale com a loja pelo WhatsApp.' : ''}</p></div>` : ''}
${pstat.sandbox ? html`<div class="notice notice-defects"><strong>Ambiente de testes</strong><p>Nenhum pagamento real será cobrado.</p></div>` : ''}
${cart.problems.map((p) => html`<div class="flash flash-info" role="status">${icon('info', 18)}<span>${p}</span></div>`)}
${err._ ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${err._}</span></div>` : ''}
<form method="post" action="/checkout" class="checkout-grid" novalidate data-checkout>
  ${csrfField(ctx)}
  <div class="col-main">
    <fieldset class="step"><legend><span class="n">1</span> Seus dados</legend>
      ${c ? '' : html`<p class="muted small">Você pode comprar sem criar conta. <a href="/minha-conta/entrar?next=/checkout">Já tenho conta</a></p>`}
      <div class="grid2">${field({ label: 'Nome completo', name: 'name', value: val.name, required: true, autocomplete: 'name', error: err.name, maxlength: 100 })}${field({ label: 'E-mail', name: 'email', type: 'email', value: val.email, required: true, autocomplete: 'email', error: err.email, hint: 'Enviaremos a confirmação e o acompanhamento aqui.' })}</div>
      <div class="grid2">${field({ label: 'Telefone / WhatsApp', name: 'phone', type: 'tel', value: val.phone, required: true, autocomplete: 'tel', inputmode: 'tel', error: err.phone, hint: 'Com DDD.' })}${provider.requiresCpf ? field({ label: 'CPF', name: 'cpf', value: val.cpf || '', required: true, inputmode: 'numeric', autocomplete: 'off', error: err.cpf, hint: `Exigido pelo meio de pagamento (${provider.label}). Fica guardado de forma criptografada.` }) : field({ label: 'CPF', name: 'cpf', value: val.cpf || '', inputmode: 'numeric', autocomplete: 'off', error: err.cpf, hint: 'Não é obrigatório.' })}</div>
    </fieldset>
    <fieldset class="step"><legend><span class="n">2</span> Entrega</legend>
      <div class="grid3">${field({ label: 'CEP', name: 'zip', required: true, value: val.zip ? formatZip(val.zip) : '', inputmode: 'numeric', autocomplete: 'postal-code', error: err.zip, maxlength: 9, attrs: 'data-zip' })}<div class="field span2"><label>&nbsp;</label><button class="btn btn-ghost" type="submit" name="step" value="shipping" formnovalidate>Calcular entrega</button></div></div>
      <div class="address-fields" data-address>
        <div class="grid3">${field({ label: 'Rua', name: 'street', required: true, value: val.street, autocomplete: 'address-line1', error: err.street, cls: 'span2' })}${field({ label: 'Número', name: 'number', required: true, value: val.number, autocomplete: 'off', error: err.number, maxlength: 15 })}</div>
        <div class="grid3">${field({ label: 'Complemento', name: 'complement', value: val.complement, error: err.complement })}${field({ label: 'Bairro', name: 'district', required: true, value: val.district, error: err.district })}${field({ label: 'Cidade', name: 'city', required: true, value: val.city, autocomplete: 'address-level2', error: err.city })}</div>
        ${selectField({ label: 'Estado', name: 'state', required: true, value: val.state, options: UFS, blank: 'Selecione', autocomplete: 'address-level1', error: err.state })}
      </div>
      <div class="ship-choices" data-ship-choices role="radiogroup" aria-label="Forma de entrega">
        ${noShipping ? html`<p class="err">A loja ainda não configurou formas de entrega.</p>` : quote.options.length ? quote.options.map((o) => html`<label class="choice"><input type="radio" name="shipping_key" value="${o.key}" ${String(val.shipping_key) === o.key ? raw('checked') : ''} data-price="${o.price_cents}" data-kind="${o.delivery_kind}"><span><strong>${o.name}</strong>${o.eta_text ? html`<small>${o.eta_text}</small>` : ''}${o.delivery_kind === 'pickup' && s.pickup_note ? html`<small>${s.pickup_note}</small>` : ''}</span><b>${o.price_cents ? money(o.price_cents) : 'Grátis'}</b></label>`) : html`<p class="muted">Informe o CEP e clique em “Calcular entrega”.</p>`}
        ${quote.warnings.map((w) => html`<p class="err small">${w}</p>`)}${err.shipping ? html`<p class="err">${err.shipping}</p>` : ''}
        ${zip.length === 8 && !quote.options.length && !noShipping ? html`<p class="err">Não encontramos opção de entrega para este CEP.${waLink(s) ? ' Fale com a loja para combinar.' : ''}</p>` : ''}
      </div>
      <div class="field${err.note ? ' has-error' : ''}"><label for="f_note">Observações do pedido <span class="opt">(opcional)</span></label><textarea id="f_note" name="note" rows="2" maxlength="300">${val.note || ''}</textarea></div>
    </fieldset>
    <fieldset class="step"><legend><span class="n">3</span> Pagamento</legend>
      <div class="pay-box">${icon('pix', 26)}<div><strong>Pix</strong><p class="muted small">Ao finalizar, mostramos o QR Code e o código “copia e cola”. A confirmação é automática. ${pstat.configured ? `O Pix vale por ${app.orders.pixMinutes()} minutos e as peças ficam reservadas para você nesse período.` : ''}</p></div></div>
      <label class="check"><input type="checkbox" name="marketing" value="1" ${val.marketing ? raw('checked') : ''}> Quero receber novidades do brechó por e-mail <span class="muted">(opcional)</span></label>
      <p class="small muted">Ao finalizar, você concorda com os <a href="/p/termos-de-uso" target="_blank">Termos</a> e a <a href="/p/politica-de-privacidade" target="_blank">Política de Privacidade</a>.</p>
    </fieldset>
  </div>
  <aside class="summary sticky"><h2>Resumo do pedido</h2>
    <ul class="mini-items">${cart.items.filter((i) => !i.unavailable).map((i) => html`<li><span class="ph thumb">${i.product.image ? html`<img src="${imgUrl(i.product.image)}" alt="" loading="lazy">` : ''}</span><span>${i.product.name}${i.qty > 1 ? ` × ${i.qty}` : ''}</span><b>${money(i.total_cents)}</b></li>`)}</ul>
    <div class="field"><label for="f_coupon">Cupom</label><div class="row"><input id="f_coupon" name="coupon_code" value="${code || ''}" maxlength="30" autocomplete="off"></div>${couponError ? html`<p class="err small">${couponError}</p>` : ''}</div>
    <dl data-totals data-subtotal="${cart.subtotal_cents}" data-discount="${discount}"><div><dt>Subtotal</dt><dd>${money(cart.subtotal_cents)}</dd></div>${discount ? html`<div class="disc"><dt>Cupom ${coupon.coupon.code}</dt><dd>− ${money(discount)}</dd></div>` : ''}<div><dt>Entrega</dt><dd data-ship-total>${chosen ? (chosen.price_cents ? money(chosen.price_cents) : 'Grátis') : '—'}</dd></div><div class="total"><dt>Total</dt><dd data-grand>${money(total)}</dd></div></dl>
    <button class="btn btn-block" type="submit" name="step" value="place" ${pstat.configured && !noShipping ? '' : raw('disabled')}>${icon('pix', 18)} Pagar com Pix</button>
    <p class="muted small center">${icon('lock', 14)} Seus dados são protegidos.</p>
  </aside>
</form></section>`;
    ctx.html(storeLayout(ctx, app, { title: 'Finalizar compra', main, noindex: true, noFloatingWa: true }), status);
  }

  router.get('/checkout', (ctx) => renderCheckout(ctx));

  router.post('/checkout', async (ctx) => {
    const b = ctx.body;
    if (b.step === 'shipping') return renderCheckout(ctx, { ...b });
    const lim = app.limiter.hit(`checkout:${ctx.ip}`, 20, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas tentativas de pedido. Tente novamente mais tarde.');
    const provider = app.payments.provider();
    try {
      if (!app.payments.status().configured) throw new UserError('Os pagamentos ainda não estão ativos nesta loja.');
      const cart = app.cart.view(ctx);
      if (!cart.count || cart.items.some((i) => i.unavailable)) throw new UserError(cart.count ? 'Há peças indisponíveis no carrinho. Remova-as para continuar.' : 'Seu carrinho está vazio.');
      const form = app.orders.parseCheckout(b, { requiresCpf: provider.requiresCpf });
      const opt = await app.shipping.resolve({ key: form.shipping_key, zip: form.zip, subtotalCents: cart.subtotal_cents, items: itemsForShipping(cart) });
      if (opt.delivery_kind !== 'pickup') app.orders.requireAddress(form);
      let couponResult = null;
      const code = form.coupon_code || cart.coupon_code;
      if (code) couponResult = app.coupons.evaluate(code, cart.items.map((i) => ({ product_id: i.product.id, unit_cents: i.unit_cents, qty: i.qty })), cart.subtotal_cents);
      let customerId = ctx.customer?.id ?? null;
      if (!customerId) {
        customerId = app.auth.upsertCustomerFromOrder({ name: form.name, email: form.email, phone: form.phone, cpf: form.cpf, marketing: form.marketing });
      }
      const cu = app.crm.customer(customerId);
      if (cu?.status === 'blocked') throw new UserError('Não foi possível concluir o pedido com este cadastro. Entre em contato com a loja.');

      const order = app.orders.createReserved({ cart, form, shippingOpt: opt, couponResult, customerId });
      let pay;
      try {
        pay = await app.payments.createPixForOrder(order);
      } catch (e) {
        await app.orders.cancelUnpaid(order.id, { actor: 'sistema', reason: 'Falha ao gerar o Pix', silent: true }).catch(() => {});
        throw e;
      }
      app.cart.clear(ctx);
      app.email.queue('order_received', order.customer_email, { name: order.customer_name, order, note: 'Pague o Pix no prazo para garantir as peças.' });
      app.email.queue('pix_generated', order.customer_email, { name: order.customer_name, order, expiresAt: pay.expires_at });
      app.audit.log({ type: ctx.customer ? 'customer' : 'system', id: customerId, label: order.customer_email }, 'order.created', 'order', order.id, { number: order.number, total: order.total_cents }, ctx.ip);
      return ctx.redirect(`/pedido/${order.public_token}`);
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      const errs = e.field ? { [e.field]: e.message } : { _: e.message };
      return renderCheckout(ctx, { ...b }, errs, 422);
    }
  }, { limit: 64 * 1024 });

  // ───── pedido / Pix ─────
  const STEPS = [['awaiting_payment', 'Pedido feito'], ['paid', 'Pago'], ['preparing', 'Em preparação'], ['shipped', 'Enviado'], ['delivered', 'Entregue']];
  const rank = { awaiting_payment: 0, paid: 1, preparing: 2, shipped: 3, in_transit: 3, delivered: 4 };

  const orderPage = (ctx, order, { customerView = false } = {}) => {
    const s = app.settings.all();
    const items = app.orders.items(order.id);
    const pay = app.payments.latest(order.id);
    const open = app.payments.openPayment(order.id);
    const ship = app.shipping.shipment(order.id);
    const events = ship ? app.shipping.events(ship.id) : [];
    const kind = order.delivery_kind;
    const label = app.orders.statusLabel(order.status, kind);
    const awaiting = order.status === 'awaiting_payment' && open;
    const hist = app.orders.history(order.id).filter((h) => h.to_status && (h.from_status !== h.to_status));
    const cancelled = ['cancelled', 'refunded'].includes(order.status);
    const tone = cancelled ? 'bad' : order.status === 'awaiting_payment' ? 'warn' : 'good';
    const wa = waLink(s, `Olá! Preciso de ajuda com o pedido ${order.number}.`);
    const main = html`<section class="wrap narrow order-page" ${awaiting ? raw(`data-order-poll="/api/pedido/${order.public_token}/status"`) : ''}>
  <header class="order-head"><p class="muted small">Pedido</p><h1>${order.number}</h1><p><span class="status status-${tone}">${label}</span> <span class="muted small">feito em ${formatDate(order.created_at, { offsetMinutes: cfg.tzOffsetMinutes })}</span></p></header>
  ${order.needs_attention && customerView === false ? '' : ''}
  ${awaiting ? html`
  <div class="pix-card">
    <h2>${icon('pix', 22)} Pague com Pix</h2>
    <p class="pix-total">${money(order.total_cents)}</p>
    <p class="countdown" data-expires="${open.expires_at}">${icon('clock', 16)} Pague até <strong>${formatDate(open.expires_at, { offsetMinutes: cfg.tzOffsetMinutes })}</strong> <span data-remaining></span></p>
    <div class="pix-body">
      ${open.pix_qr_base64 ? html`<img class="qr" src="${open.pix_qr_base64}" alt="QR Code do Pix no valor de ${money(order.total_cents)}" width="240" height="240">` : ''}
      <div class="pix-code"><label for="pixcode">Pix copia e cola</label><textarea id="pixcode" readonly rows="4" data-pixcode>${open.pix_payload || ''}</textarea><button type="button" class="btn" data-copy-target="#pixcode">${icon('copy', 18)} Copiar código</button></div>
    </div>
    <ol class="how"><li>Abra o app do seu banco e escolha Pix.</li><li>Escaneie o QR Code ou cole o código copiado.</li><li>Confira o valor e confirme. Esta página atualiza sozinha quando o pagamento for confirmado.</li></ol>
    ${app.payments.provider().sandbox ? html`<p class="notice notice-defects small"><strong>Ambiente de testes:</strong> nenhum dinheiro real é movimentado.</p>` : ''}
    <form method="post" action="/pedido/${order.public_token}/verificar" class="inline-form">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">Já paguei — verificar agora</button></form>
    <form method="post" action="/pedido/${order.public_token}/cancelar" class="inline-form" data-confirm="Cancelar este pedido? As peças voltarão para a loja.">${csrfField(ctx)}<button class="linklike danger" type="submit">Cancelar pedido</button></form>
  </div>` : ''}
  ${order.status === 'cancelled' && order.payment_status === 'expired' ? html`<div class="notice notice-sold"><strong>O prazo do Pix terminou e o pedido foi cancelado.</strong><p>Se a peça ainda estiver disponível, você pode gerar um novo Pix. Se você já pagou, o pagamento será identificado automaticamente.</p><form method="post" action="/pedido/${order.public_token}/novo-pix">${csrfField(ctx)}<button class="btn" type="submit">Gerar novo Pix</button></form></div>` : ''}
  ${order.status === 'cancelled' && order.payment_status !== 'expired' ? html`<div class="notice notice-sold"><strong>Este pedido foi cancelado.</strong><p>As peças foram liberadas. Nenhuma cobrança foi confirmada.</p></div>` : ''}
  ${order.status === 'refunded' ? html`<div class="notice notice-defects"><strong>Pedido reembolsado.</strong><p>O valor foi devolvido pelo mesmo meio de pagamento. O prazo para aparecer na conta depende do seu banco.</p></div>` : ''}
  ${order.payment_status === 'partially_refunded' ? html`<div class="notice notice-defects"><strong>Reembolso parcial realizado.</strong></div>` : ''}
  ${!cancelled && order.status !== 'awaiting_payment' ? html`<ol class="steps" aria-label="Andamento do pedido">${STEPS.map(([k, l], i) => html`<li class="${i <= (rank[order.status] ?? 0) ? 'done' : ''}${i === (rank[order.status] ?? 0) ? ' current' : ''}">${i === 3 && kind === 'pickup' ? 'Pronto p/ retirada' : i === 4 && kind === 'pickup' ? 'Retirado' : l}</li>`)}</ol>` : ''}
  ${order.status === 'paid' ? html`<div class="notice notice-ok"><strong>${icon('check', 16)} Pagamento confirmado!</strong><p>Obrigada pela compra. Avisaremos por e-mail a cada novidade do pedido.</p></div>` : ''}
  ${ship && (ship.tracking_code || ship.eta_text) ? html`<div class="card-box"><h2>${icon('truck', 18)} Envio</h2>${ship.carrier ? html`<p>Transportadora: <strong>${ship.carrier}</strong></p>` : ''}${ship.tracking_code ? html`<p>Código de rastreio: <strong>${ship.tracking_code}</strong>${ship.tracking_url ? html` — <a href="${ship.tracking_url}" target="_blank" rel="noopener noreferrer">acompanhar</a>` : ''}</p>` : ''}${ship.eta_text ? html`<p>Prazo estimado: ${ship.eta_text}</p>` : ''}${events.length ? html`<ul class="timeline">${events.map((e) => html`<li><time>${formatDate(e.created_at, { offsetMinutes: cfg.tzOffsetMinutes })}</time> ${e.note || app.orders.statusLabel(e.status, kind)}</li>`)}</ul>` : ''}</div>` : ''}
  <div class="card-box"><h2>${icon('box', 18)} Itens</h2><ul class="mini-items">${items.map((i) => html`<li><span class="ph thumb">${i.image ? html`<img src="${imgUrl(i.image)}" alt="" loading="lazy">` : ''}</span><span>${i.name}${i.qty > 1 ? ` × ${i.qty}` : ''}<small class="muted"> ${i.sku}</small></span><b>${money(i.unit_cents * i.qty)}</b></li>`)}</ul>
    <dl class="totals"><div><dt>Subtotal</dt><dd>${money(order.subtotal_cents)}</dd></div>${order.discount_cents ? html`<div><dt>Desconto${order.coupon_code ? ` (${order.coupon_code})` : ''}</dt><dd>− ${money(order.discount_cents)}</dd></div>` : ''}<div><dt>${order.shipping_method_name || 'Entrega'}</dt><dd>${order.shipping_cents ? money(order.shipping_cents) : 'Grátis'}</dd></div><div class="total"><dt>Total</dt><dd>${money(order.total_cents)}</dd></div></dl></div>
  <div class="card-box"><h2>${icon('home', 18)} ${kind === 'pickup' ? 'Retirada' : 'Entrega'}</h2>${kind === 'pickup' ? html`<p>${s.pickup_note || 'Retirada combinada com a loja.'}</p>${s.store_address ? html`<p>${s.store_address}</p>` : ''}` : html`<p>${order.customer_name}<br>${order.ship_street}, ${order.ship_number}${order.ship_complement ? ` — ${order.ship_complement}` : ''}<br>${order.ship_district} — ${order.ship_city}/${order.ship_state}<br>CEP ${formatZip(order.ship_zip)}</p>`}${order.shipping_eta_text ? html`<p class="muted small">Prazo informado na compra: ${order.shipping_eta_text}</p>` : ''}</div>
  ${hist.length ? html`<details class="card-box"><summary>Histórico do pedido</summary><ul class="timeline">${hist.map((h) => html`<li><time>${formatDate(h.created_at, { offsetMinutes: cfg.tzOffsetMinutes })}</time> ${app.orders.statusLabel(h.to_status, kind)}</li>`)}</ul></details>` : ''}
  <p class="center small muted">Precisa de ajuda? <a href="/contato">Fale com a gente</a>${wa ? html` ou <a href="${wa}" target="_blank" rel="noopener noreferrer">chame no WhatsApp</a>` : ''}. Guarde o link desta página para acompanhar o pedido.</p>
</section>`;
    return storeLayout(ctx, app, { title: `Pedido ${order.number}`, main, noindex: true, noFloatingWa: true });
  };

  router.get('/pedido/:token', async (ctx) => {
    const order = app.orders.byToken(ctx.params.token);
    if (!order) return ctx.fail(404, 'Pedido não encontrado.');
    if (order.status === 'awaiting_payment') await app.payments.checkNow(order).catch((e) => console.error('[pedido] verificação:', e.message));
    ctx.html(orderPage(ctx, app.orders.get(order.id)), 200, { 'Referrer-Policy': 'no-referrer' });
  });
  void orderPage;

  router.get('/api/pedido/:token/status', async (ctx) => {
    const lim = app.limiter.hit(`orderstatus:${ctx.ip}`, 240, 600);
    if (!lim.ok) return ctx.json({ ok: false }, 429);
    const order = app.orders.byToken(ctx.params.token);
    if (!order) return ctx.json({ ok: false }, 404);
    if (order.status === 'awaiting_payment') await app.payments.checkNow(order).catch(() => {});
    const o = app.orders.get(order.id);
    ctx.json({ ok: true, status: o.status, payment_status: o.payment_status, done: o.status !== 'awaiting_payment' });
  });

  router.post('/pedido/:token/verificar', async (ctx) => {
    const order = app.orders.byToken(ctx.params.token);
    if (!order) return ctx.fail(404, 'Pedido não encontrado.');
    if (order.status === 'awaiting_payment') {
      const pay = app.payments.openPayment(order.id);
      if (pay) await app.payments.refreshFromProvider(pay.id, 'verificação pelo cliente');
    }
    const o = app.orders.get(order.id);
    ctx.flash(o.status === 'awaiting_payment' ? 'info' : 'success', o.status === 'awaiting_payment' ? 'Ainda não identificamos o pagamento. Pode levar alguns segundos após pagar.' : 'Pagamento confirmado!');
    ctx.redirect(`/pedido/${order.public_token}`);
  });

  router.post('/pedido/:token/cancelar', async (ctx) => {
    const order = app.orders.byToken(ctx.params.token);
    if (!order) return ctx.fail(404, 'Pedido não encontrado.');
    try {
      await app.orders.cancelUnpaid(order.id, { actor: 'cliente', reason: 'Cancelado pelo cliente', byCustomer: true });
      ctx.flash('success', 'Pedido cancelado.');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      ctx.flash('error', e.message);
    }
    ctx.redirect(`/pedido/${order.public_token}`);
  });

  router.post('/pedido/:token/novo-pix', async (ctx) => {
    const order = app.orders.byToken(ctx.params.token);
    if (!order) return ctx.fail(404, 'Pedido não encontrado.');
    const lim = app.limiter.hit(`newpix:${order.id}`, 5, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas tentativas. Tente novamente mais tarde.');
    try {
      await app.payments.reopenExpired(order);
      ctx.flash('success', 'Novo Pix gerado.');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      ctx.flash('error', e.message);
    }
    ctx.redirect(`/pedido/${order.public_token}`);
  });

  // ───── webhooks dos provedores de pagamento ─────
  router.post('/webhooks/:provider', async (ctx) => {
    const r = await app.payments.handleWebhook(ctx.params.provider, { headers: ctx.req.headers, rawBody: ctx.rawBody, query: ctx.query, body: ctx.body, ip: ctx.ip });
    ctx.json(r.body, r.status);
  }, { csrf: false, limit: 128 * 1024 });

  void escape; void formatPhone; void validCpf;
}

module.exports = { register };
