'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { makeTestApp, seedBasics, ctxFor, placeOrder, deliverWebhook, payedDespiteCancel } = require('./helpers');

test('fluxo Pix: reserva, webhook assinado confirma, estoque baixa, e-mail e histórico', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido floral', '89,90');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });

  assert.equal(order.status, 'awaiting_payment');
  assert.equal(order.total_cents, 8990 + 1500);
  assert.equal(pay.status, 'pending');
  assert.equal(app.stock.available(p.id), 0, 'peça reservada some da disponibilidade');
  assert.equal(app.db.get('SELECT quantity FROM products WHERE id = ?', p.id).quantity, 1, 'baixa definitiva só após o pagamento');

  const ev = app.providers.get('mock').simulatePay(pay.provider_payment_id);
  const r = await deliverWebhook(app, ev);
  assert.equal(r.status, 200);
  const paid = app.orders.get(order.id);
  assert.equal(paid.status, 'paid');
  assert.equal(paid.payment_status, 'paid');
  assert.ok(paid.paid_at);
  assert.equal(app.db.get('SELECT quantity FROM products WHERE id = ?', p.id).quantity, 0);
  const pr = app.payments.byId(pay.id);
  assert.equal(pr.status, 'paid');
  assert.ok(pr.fee_cents > 0 && pr.net_cents === pr.amount_cents - pr.fee_cents);
  await app.email.idle();
  assert.ok(app.db.get("SELECT 1 FROM emails WHERE template = 'payment_approved' AND to_email = 'maria.teste@example.com'"));
  assert.ok(app.db.get("SELECT 1 FROM notifications WHERE kind = 'order_paid'"));
});

test('webhook duplicado não repete baixa de estoque nem e-mail', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const a = mk('Blusa', '40,00', { quantity: '3' });
  const ctx = ctxFor();
  app.cart.add(ctx, a.id, 1);
  const { order, pay } = await placeOrder(app, ctxFor('outro'), { items: [mk('Saia', '50,00')], shippingKey: fixed });
  const ev = app.providers.get('mock').simulatePay(pay.provider_payment_id, 'evt_fixo');
  const r1 = await deliverWebhook(app, ev);
  const r2 = await deliverWebhook(app, ev);
  const r3 = await deliverWebhook(app, { ...ev, event_id: 'evt_outro_mesmo_pagamento' });
  assert.deepEqual([r1.status, r2.status, r3.status], [200, 200, 200]);
  assert.equal(r2.body.duplicates, 1);
  await app.email.idle();
  assert.equal(app.db.value("SELECT COUNT(*) FROM emails WHERE template = 'payment_approved'"), 1);
  assert.equal(app.db.value("SELECT COUNT(*) FROM stock_movements WHERE order_id = ? AND reason = 'venda'", order.id), 1);
  assert.equal(app.db.value('SELECT COUNT(*) FROM payment_events'), 2);
});

test('webhook com assinatura inválida é rejeitado e nada é marcado como pago', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [mk('Casaco', '120,00')], shippingKey: fixed });
  const ev = app.providers.get('mock').simulatePay(pay.provider_payment_id);
  const r = await deliverWebhook(app, ev, { signature: 'deadbeef' });
  assert.equal(r.status, 401);
  assert.equal(app.orders.get(order.id).status, 'paid' === 'x' ? '' : app.orders.get(order.id).status);
  // mesmo com o provedor tendo o pagamento como "pago", sem webhook válido o pedido continua aguardando
  assert.equal(app.orders.get(order.id).status, 'awaiting_payment');
  assert.equal(app.db.value('SELECT COUNT(*) FROM payment_events'), 0);
});

test('webhook que "diz" estar pago mas o provedor não confirma: pedido segue pendente', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [mk('Calça', '70,00')], shippingKey: fixed });
  // webhook assinado e válido, porém o provedor (fonte da verdade) ainda mostra "pending"
  const r = await deliverWebhook(app, { event_id: 'evt_x', type: 'payment.paid', payment_id: pay.provider_payment_id });
  assert.equal(r.status, 200);
  assert.equal(app.orders.get(order.id).status, 'awaiting_payment');
});

test('divergência de valor no provedor não confirma e sinaliza o pedido', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [mk('Bolsa', '100,00')], shippingKey: fixed });
  app.db.run("UPDATE mock_provider_charges SET amount_cents = amount_cents - 500, status = 'paid', paid_at = ? WHERE id = ?", new Date().toISOString(), pay.provider_payment_id);
  await deliverWebhook(app, { event_id: 'evt_div', type: 'payment.paid', payment_id: pay.provider_payment_id });
  const o = app.orders.get(order.id);
  assert.equal(o.status, 'awaiting_payment');
  assert.equal(o.needs_attention, 1);
  assert.match(o.attention_note, /Divergência/);
});

test('peça única: segundo cliente não consegue reservar nem comprar a mesma peça', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido único', '99,00');
  await placeOrder(app, ctxFor('a'), { items: [p], shippingKey: fixed });
  assert.throws(() => app.cart.add(ctxFor('b'), p.id, 1), /vendida|reservada/);
});

test('corrida: dois pedidos simultâneos pela mesma peça — só um é criado', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido disputado', '99,00');
  // ambos colocaram no carrinho antes de qualquer reserva
  const ca = ctxFor('a');
  const cb = ctxFor('b');
  app.cart.add(ca, p.id, 1);
  app.cart.add(cb, p.id, 1);
  const results = await Promise.allSettled([ca, cb].map((c) => placeOrderFromCart(app, c, fixed)));
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  assert.equal(results.filter((r) => r.status === 'rejected').length, 1);
  assert.equal(app.db.value('SELECT COUNT(*) FROM orders'), 1);
});

async function placeOrderFromCart(app, ctx, fixed) {
  const cart = app.cart.view(ctx);
  const opt = await app.shipping.resolve({ key: fixed, zip: '01310100', subtotalCents: cart.subtotal_cents, items: [] });
  const f = app.orders.parseCheckout({ name: 'Cliente Teste', email: 'c@example.com', phone: '11987654321', zip: '01310100', state: 'SP', city: 'SP', district: 'Centro', street: 'Rua', number: '1', shipping_key: String(fixed) });
  return app.orders.createReserved({ cart, form: f, shippingOpt: opt, couponResult: null, customerId: null });
}

test('Pix expirado: pedido cancelado, peça liberada, cupom devolvido; pagamento tardio reativa se a peça estiver livre', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido expira', '80,00');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  app.db.run('UPDATE payments SET expires_at = ? WHERE id = ?', new Date(Date.now() - 60000).toISOString(), pay.id);
  const n = await app.payments.expireStale();
  assert.equal(n, 1);
  const o = app.orders.get(order.id);
  assert.equal(o.status, 'cancelled');
  assert.equal(o.payment_status, 'expired');
  assert.equal(app.stock.available(p.id), 1, 'peça voltou ao catálogo');

  // cliente paga depois do prazo: peça ainda livre → o pagamento é reconhecido (dinheiro recebido não é ignorado)
  const ev = payedDespiteCancel(app, pay.provider_payment_id);
  await deliverWebhook(app, ev);
  const late = app.orders.get(order.id);
  assert.equal(late.status, 'paid');
  assert.equal(late.needs_attention, 0);
  assert.equal(app.db.get('SELECT quantity FROM products WHERE id = ?', p.id).quantity, 0);
});

test('pagamento tardio com a peça já vendida a outra pessoa: sinaliza para reembolso', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido corrida', '80,00');
  const first = await placeOrder(app, ctxFor('a'), { items: [p], shippingKey: fixed });
  app.db.run('UPDATE payments SET expires_at = ? WHERE id = ?', new Date(Date.now() - 60000).toISOString(), first.pay.id);
  await app.payments.expireStale();
  const second = await placeOrder(app, ctxFor('b'), { items: [p], shippingKey: fixed });
  await deliverWebhook(app, app.providers.get('mock').simulatePay(second.pay.provider_payment_id));
  assert.equal(app.orders.get(second.order.id).status, 'paid');
  // o primeiro cliente paga atrasado, mas a peça já é do segundo
  await deliverWebhook(app, payedDespiteCancel(app, first.pay.provider_payment_id));
  const o = app.orders.get(first.order.id);
  assert.equal(o.needs_attention, 1);
  assert.match(o.attention_note, /não está\(ão\) mais disponível/);
  assert.equal(app.db.get('SELECT quantity FROM products WHERE id = ?', p.id).quantity, 0, 'estoque nunca fica negativo');
});

test('reembolso total devolve o estoque (opcional) e registra o valor; parcial não muda o pedido', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido reembolso', '100,00');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  await deliverWebhook(app, app.providers.get('mock').simulatePay(pay.provider_payment_id));
  await assert.rejects(() => app.payments.refund(order.id, { amountCents: 999999 }), /Informe um valor/);
  await app.payments.refund(order.id, { amountCents: 500, reason: 'desconto' });
  assert.equal(app.orders.get(order.id).payment_status, 'partially_refunded');
  assert.equal(app.orders.get(order.id).status, 'paid');
  const r = await app.payments.refund(order.id, { restock: true, reason: 'devolução' });
  assert.equal(r.full, true);
  assert.equal(app.orders.get(order.id).status, 'refunded');
  assert.equal(app.db.get('SELECT quantity FROM products WHERE id = ?', p.id).quantity, 1);
  assert.equal(app.payments.byId(pay.id).refunded_cents, pay.amount_cents);
  await assert.rejects(() => app.payments.refund(order.id, {}), /pagamento confirmado/);
});

test('o painel não consegue marcar pedido como pago nem cancelar pedido pago', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [mk('Vestido admin', '60,00')], shippingKey: fixed });
  assert.throws(() => app.orders.setStatus(order.id, 'paid', { actor: 'admin' }), /sistema de pagamentos/);
  assert.throws(() => app.orders.setStatus(order.id, 'preparing', { actor: 'admin' }), /Não é possível/);
  await deliverWebhook(app, app.providers.get('mock').simulatePay(pay.provider_payment_id));
  await assert.rejects(() => app.orders.cancelUnpaid(order.id, { actor: 'admin' }), /ainda não foram pagos/);
  app.orders.setStatus(order.id, 'preparing', { actor: 'admin' });
  app.orders.setStatus(order.id, 'shipped', { actor: 'admin' });
  app.orders.setStatus(order.id, 'delivered', { actor: 'admin' });
  assert.equal(app.orders.get(order.id).status, 'delivered');
});

test('cancelar pedido não pago libera a peça; se o Pix foi pago nesse meio tempo, recusa cancelar', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido cancela', '60,00');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  app.providers.get('mock').simulatePay(pay.provider_payment_id); // cliente pagou, webhook ainda não chegou
  await assert.rejects(() => app.orders.cancelUnpaid(order.id, { actor: 'cliente' }), /acabou de ser confirmado/);
  assert.equal(app.orders.get(order.id).status, 'paid');
});

test('relatórios separam faturado, recebido, pendente e liquidação sem inventar taxas', async (t) => {
  const app = makeTestApp();
  t.after(() => app.close());
  const { mk, fixed } = seedBasics(app);
  const a = await placeOrder(app, ctxFor('a'), { items: [mk('R1', '100,00')], shippingKey: fixed });
  await placeOrder(app, ctxFor('b'), { items: [mk('R2', '50,00')], shippingKey: fixed });
  await deliverWebhook(app, app.providers.get('mock').simulatePay(a.pay.provider_payment_id));
  const f = app.reports.finance(app.reports.range({ preset: 'today' }));
  assert.equal(f.created.count, 2);
  assert.equal(f.billed.cents, 11500);
  assert.equal(f.received.cents, 11500);
  assert.equal(f.pending.count, 1);
  assert.equal(f.pending.cents, 6500);
  assert.equal(f.fees.unknownCount, 0);
  assert.ok(f.fees.cents > 0);
  const csv = app.reports.csvOrders(app.reports.range({ preset: 'today' }));
  assert.ok(csv.startsWith('﻿') && csv.includes('BC-'));
});
