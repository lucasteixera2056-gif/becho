'use strict';
/** Painel administrativo (/admin): entrada, painel inicial, conta do funcionário, uploads e registro dos módulos. */
const { html, raw } = require('../../lib/html');
const { money, UserError, formatDate, int } = require('../../lib/util');
const { icon, csrfField, field, flashBox, badge } = require('../ui');
const { saveImage, MAX_BYTES } = require('../../lib/images');
const L = require('./layout');

function register(router, app) {
  const { cfg } = app;
  const can = (ctx, p) => app.permissions.can(ctx.staff, p);

  /** Ferramentas compartilhadas pelos módulos. */
  const h = {
    S: (perm, extra = {}) => ({ staff: true, perm, ...extra }),
    page: (ctx, title, main, o = {}) => ctx.html(L.adminLayout(ctx, app, { title, main, actions: o.actions }), o.status || 200),
    /** Executa uma ação de formulário; UserError vira aviso e volta para `back`. */
    async act(ctx, back, fn, okMsg) {
      try {
        const r = await fn();
        if (okMsg) ctx.flash('success', typeof okMsg === 'function' ? okMsg(r) : okMsg);
        return ctx.redirect(typeof back === 'function' ? back(r) : back);
      } catch (e) {
        if (!(e instanceof UserError)) throw e;
        ctx.flash('error', e.message);
        return ctx.redirect(typeof back === 'function' ? back(null) : back);
      }
    },
    L, app, can,
    ago: (iso) => formatDate(iso, { offsetMinutes: cfg.tzOffsetMinutes }),
    day: (iso) => formatDate(iso, { time: false, offsetMinutes: cfg.tzOffsetMinutes }),
  };

  // ───── entrada ─────
  const loginPage = (ctx, v = {}, error = '') => {
    const s = app.settings.all();
    return ctx.html(html`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><title>Entrar · Painel ${s.store_name}</title><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/css/admin.css?v=${cfg.assetVersion}"></head>
<body class="plain"><main class="login"><div class="card"><h1>${s.store_name}</h1><p class="muted">Painel administrativo</p>
${error ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${error}</span></div>` : flashBox(ctx)}
<form method="post" action="/admin/login">${csrfField(ctx)}<input type="hidden" name="next" value="${v.next || ''}">
${field({ label: 'E-mail', name: 'email', type: 'email', value: v.email, required: true, autocomplete: 'username' })}
${field({ label: 'Senha', name: 'password', type: 'password', required: true, autocomplete: 'current-password' })}
<button class="btn btn-block" type="submit">Entrar</button></form>
<p class="muted small center">Acesso restrito a funcionários autorizados.</p></div></main></body></html>`, error ? 422 : 200);
  };
  const safeNext = (n) => (typeof n === 'string' && /^\/admin(\/[^\s]*)?$/.test(n) && !n.startsWith('/admin/login') ? n : '');

  router.get('/admin/login', (ctx) => (ctx.staff ? ctx.redirect(app.permissions.landing(ctx.staff)) : loginPage(ctx, { next: safeNext(ctx.query.next) })));
  router.post('/admin/login', async (ctx) => {
    const b = ctx.body;
    try {
      const u = await app.auth.staffLogin(ctx, b.email, b.password);
      if (u.must_change_password) return ctx.redirect('/admin/minha-conta?troca=1');
      ctx.redirect(safeNext(b.next) || app.permissions.landing(u));
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      loginPage(ctx, { email: b.email, next: b.next }, e.message);
    }
  });
  router.post('/admin/sair', (ctx) => { app.auth.staffLogout(ctx); ctx.flash('success', 'Você saiu do painel.'); ctx.redirect('/admin/login'); }, { staff: true, allowPasswordChange: true });

  // ───── minha conta ─────
  router.get('/admin/minha-conta', (ctx) => {
    const sessions = app.auth.staffSessions(ctx.staff.id);
    h.page(ctx, 'Minha conta e segurança', html`
<section class="card narrow"><h2>Alterar senha</h2>${ctx.query.troca ? html`<p class="notice-inline">Defina uma nova senha para continuar.</p>` : ''}
<form method="post" action="/admin/minha-conta/senha">${csrfField(ctx)}
${field({ label: 'Senha atual', name: 'current', type: 'password', required: true, autocomplete: 'current-password' })}
${field({ label: 'Nova senha', name: 'password', type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo de 10 caracteres, sem ser fácil de adivinhar.' })}
${field({ label: 'Confirmar nova senha', name: 'confirm', type: 'password', required: true, autocomplete: 'new-password' })}
<button class="btn" type="submit">Salvar nova senha</button></form></section>
<section class="card"><h2>Sessões ativas</h2><p class="muted small">Se algum acesso não for seu, encerre-o e troque a senha.</p>
${L.table(['Início', 'Última atividade', 'IP', 'Navegador', ''], sessions.map((s) => html`<tr><td>${h.ago(s.created_at)}</td><td>${h.ago(s.last_seen_at)}</td><td>${s.ip}</td><td class="small">${(s.user_agent || '').slice(0, 70)}</td><td>${s.id === ctx.staff.sessionId ? badge('Esta sessão', 'good') : html`<form method="post" action="/admin/minha-conta/sessoes/${s.id}/encerrar">${csrfField(ctx)}<button class="linklike danger" type="submit">Encerrar</button></form>`}</td></tr>`))}</section>`);
  }, { staff: true, allowPasswordChange: true });
  router.post('/admin/minha-conta/senha', (ctx) => h.act(ctx, (ok) => (ok === null ? '/admin/minha-conta' : '/admin'), async () => { await app.auth.changeOwnPassword(ctx, ctx.body.current, ctx.body.password, ctx.body.confirm); return true; }, 'Senha alterada.'), { staff: true, allowPasswordChange: true });
  router.post('/admin/minha-conta/sessoes/:id/encerrar', (ctx) => h.act(ctx, '/admin/minha-conta', () => app.auth.revokeStaffSession(ctx, ctx.params.id), 'Sessão encerrada.'), { staff: true, allowPasswordChange: true });

  // ───── uploads de imagem (corpo binário; validado por magic bytes no servidor) ─────
  router.post('/admin/uploads', (ctx) => {
    if (!(can(ctx, 'content.manage') || can(ctx, 'settings.manage') || can(ctx, 'categories.manage'))) return ctx.fail(403, 'Sem permissão para enviar imagens.');
    try {
      const filename = saveImage(cfg.uploadDir, ctx.rawBody);
      app.audit.staff(ctx, 'upload.image', 'upload', filename);
      ctx.json({ ok: true, filename, url: `/uploads/${filename}` });
    } catch (e) {
      ctx.json({ ok: false, error: e.message }, 422);
    }
  }, { staff: true, limit: MAX_BYTES + 1024 });

  // ───── notificações ─────
  router.get('/admin/notificacoes', (ctx) => {
    const list = app.crm.notifications(100);
    app.crm.markAllRead();
    h.page(ctx, 'Notificações', html`<section class="card">${list.length ? html`<ul class="feed">${list.map((n) => html`<li class="${n.read_at ? '' : 'unread'}"><time>${h.ago(n.created_at)}</time><strong>${n.link ? html`<a href="${n.link}">${n.title}</a>` : n.title}</strong>${n.body ? html`<p class="muted small">${n.body}</p>` : ''}</li>`)}</ul>` : html`<p class="empty-note">Nenhuma notificação.</p>`}</section>`);
  }, h.S('orders.view'));

  // ───── painel inicial ─────
  router.get('/admin', (ctx) => {
    if (!can(ctx, 'dashboard.view')) return ctx.redirect(app.permissions.landing(ctx.staff));
    const d = app.reports.dashboard();
    const s = app.settings.all();
    const pay = app.payments.status();
    const mail = cfg.email.transport === 'resend' && cfg.email.resendApiKey;
    const checklist = [
      { ok: pay.configured && !pay.sandbox, warn: pay.configured && pay.sandbox, text: pay.configured ? (pay.sandbox ? `Pagamento em modo de TESTE (${pay.label}). Troque para produção antes de vender.` : `Pagamento por Pix ativo (${pay.label}).`) : `Configurar o provedor de Pix (faltando: ${pay.missing.join(', ')}).`, href: '/admin/pagamentos' },
      { ok: pay.webhookReady, text: pay.webhookReady ? 'Webhook do provedor protegido com segredo.' : 'Configurar o segredo do webhook do provedor.', href: '/admin/pagamentos' },
      { ok: !!mail, text: mail ? 'Envio de e-mails (Resend) configurado.' : 'Configurar o envio de e-mails (RESEND_API_KEY e remetente).', href: '/admin/emails' },
      { ok: app.shipping.methods().length > 0, text: app.shipping.methods().length ? 'Formas de entrega cadastradas.' : 'Cadastrar ao menos uma forma de entrega.', href: '/admin/configuracoes?aba=entrega' },
      { ok: d.products.published > 0, text: d.products.published ? `${d.products.published} peça(s) publicada(s).` : 'Cadastrar e publicar as primeiras peças.', href: '/admin/produtos/novo' },
      { ok: !!(s.store_email || s.store_whatsapp), text: s.store_email || s.store_whatsapp ? 'Contato da loja informado.' : 'Informar e-mail ou WhatsApp da loja (Configurações).', href: '/admin/configuracoes' },
      { ok: s.legal_reviewed === '1', text: s.legal_reviewed === '1' ? 'Textos legais marcados como revisados.' : 'Revisar com um(a) advogado(a) os textos de privacidade, termos e trocas.', href: '/admin/paginas' },
      { ok: cfg.isProd ? cfg.cookieSecure : true, text: cfg.cookieSecure ? 'Site em HTTPS.' : 'Publicar o site com HTTPS (BASE_URL com https://).', href: null },
    ];
    const todo = checklist.filter((c) => !c.ok);
    const m = d.month;
    const money0 = (c) => money(c);
    const alerts = [
      d.attention ? { t: `${d.attention} pedido(s) precisam de atenção`, href: '/admin/pedidos?atencao=1', tone: 'bad' } : null,
      d.toShip ? { t: `${d.toShip} pedido(s) pagos para separar/enviar`, href: '/admin/pedidos?status=paid', tone: 'warn' } : null,
      d.openSupport ? { t: `${d.openSupport} solicitação(ões) de clientes em aberto`, href: '/admin/solicitacoes', tone: 'warn' } : null,
      d.openContacts ? { t: `${d.openContacts} mensagem(ns) do formulário de contato`, href: '/admin/mensagens', tone: 'warn' } : null,
      d.openData ? { t: `${d.openData} solicitação(ões) LGPD (prazo legal para resposta)`, href: '/admin/lgpd', tone: 'bad' } : null,
      d.failedEmails ? { t: `${d.failedEmails} e-mail(s) com falha nos últimos 7 dias`, href: '/admin/emails?status=failed', tone: 'warn' } : null,
      d.lowStock.length ? { t: `${d.lowStock.length} peça(s) com estoque baixo`, href: '/admin/estoque', tone: 'warn' } : null,
    ].filter(Boolean);
    h.page(ctx, 'Painel', html`
${todo.length ? html`<section class="card setup"><h2>Para começar a vender (${checklist.length - todo.length}/${checklist.length})</h2><ul class="checklist">${checklist.map((c) => html`<li class="${c.ok ? 'ok' : c.warn ? 'warn' : 'todo'}">${icon(c.ok ? 'check' : 'alert', 16)} ${c.href && !c.ok ? html`<a href="${c.href}">${c.text}</a>` : c.text}</li>`)}</ul></section>` : ''}
<div class="kpis">
  ${L.kpi('Recebido hoje', money0(d.today.received.cents), `${d.today.billed.count} pedido(s) pago(s)`)}
  ${L.kpi('Recebido no mês', money0(m.received.cents), `${m.billed.count} pedido(s) pago(s)`)}
  ${L.kpi('Aguardando pagamento', money0(d.d30.pending.cents), `${d.d30.pending.count} pedido(s) em aberto`, d.d30.pending.count ? 'warn' : '')}
  ${L.kpi('Ticket médio (mês)', money0(m.avgTicket), m.billed.count ? '' : 'sem vendas no mês')}
  ${L.kpi('Peças à venda', String(d.products.available), `${d.products.sold} vendida(s) · estoque ${money0(d.products.stockValue)}`)}
  ${L.kpi('Clientes', String(d.customers), `${d.newsletter} na newsletter`)}
</div>
<div class="cols">
  <section class="card"><h2>Vendas dos últimos 30 dias</h2>${L.barChart(d.series.map((p) => ({ value: p.cents, label: h.day(`${p.date}T12:00:00Z`).slice(0, 5), tick: p.date.slice(8) + '/' + p.date.slice(5, 7) })), { label: 'Valor de pedidos pagos por dia' })}</section>
  <section class="card"><h2>Atenção</h2>${alerts.length ? html`<ul class="alerts">${alerts.map((a) => html`<li class="${a.tone}"><a href="${a.href}">${a.t}</a></li>`)}</ul>` : html`<p class="empty-note">Nada pendente. 🎉</p>`}</section>
</div>
<div class="cols">
  <section class="card"><h2>Mais vendidas (30 dias)</h2>${L.table(['Peça', { label: 'Qtd', right: true }, { label: 'Valor', right: true }], d.top.map((t) => html`<tr><td>${t.name}</td><td class="r">${t.qty}</td><td class="r">${money0(t.cents)}</td></tr>`), { empty: 'Sem vendas no período.' })}</section>
  <section class="card"><h2>Pedidos por situação</h2>${Object.keys(d.statusCounts).length ? html`<ul class="status-list">${Object.entries(d.statusCounts).map(([k, n]) => html`<li><a href="/admin/pedidos?status=${k}">${app.orders.STATUS[k]}</a><b>${n}</b></li>`)}</ul>` : html`<p class="empty-note">Ainda não há pedidos.</p>`}</section>
</div>`);
  }, { staff: true });

  const mods = ['catalog', 'orders', 'customers', 'reports', 'content', 'settings', 'system'];
  for (const m of mods) require(`./${m}`).register(router, app, h);
}

module.exports = { register, errorPage: L.errorPage };
