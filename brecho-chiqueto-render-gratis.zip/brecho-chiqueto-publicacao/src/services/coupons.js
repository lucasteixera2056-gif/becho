'use strict';
const { now, parseMoney, int, trunc, UserError } = require('../lib/util');

const MIN_RESIDUAL_CENTS = 100; // o pedido nunca fica com subtotal menor que R$ 1,00 depois do cupom

function makeCoupons(app) {
  const { db } = app;

  const coupons = {
    byCode: (code) => db.get('SELECT * FROM coupons WHERE code = ?', String(code || '').trim()),
    byId: (id) => db.get('SELECT * FROM coupons WHERE id = ?', id),
    productIds: (id) => db.all('SELECT product_id FROM coupon_products WHERE coupon_id = ?', id).map((r) => r.product_id),

    /**
     * Valida e calcula o desconto.
     * lines: [{ product_id, unit_cents, qty }]
     * Lança UserError com o motivo caso o cupom não possa ser usado.
     */
    evaluate(code, lines, subtotalCents) {
      const c = this.byCode(code);
      const t = now();
      if (!c || !c.active) throw new UserError('Cupom inválido.');
      if (c.starts_at && c.starts_at > t) throw new UserError('Este cupom ainda não começou a valer.');
      if (c.expires_at && c.expires_at <= t) throw new UserError('Este cupom expirou.');
      if (c.max_uses !== null && c.used_count >= c.max_uses) throw new UserError('Este cupom atingiu o limite de usos.');
      if (subtotalCents < c.min_subtotal_cents) throw new UserError(`Este cupom exige compras a partir de ${app.fmt.money(c.min_subtotal_cents)}.`);
      const restrict = this.productIds(c.id);
      const eligible = lines.filter((l) => !restrict.length || restrict.includes(l.product_id)).reduce((s, l) => s + l.unit_cents * l.qty, 0);
      if (eligible <= 0) throw new UserError('Este cupom não vale para as peças do seu carrinho.');
      let discount = c.kind === 'percent' ? Math.floor((eligible * c.value) / 100) : Math.min(c.value, eligible);
      discount = Math.min(discount, Math.max(0, subtotalCents - MIN_RESIDUAL_CENTS));
      if (discount <= 0) throw new UserError('Este cupom não gera desconto para este carrinho.');
      return { coupon: c, discount_cents: discount };
    },

    /** Conta o uso no momento do pedido (dentro da transação). Falha se esgotou entre a validação e agora. */
    redeem(couponId) {
      const r = db.run('UPDATE coupons SET used_count = used_count + 1 WHERE id = ? AND (max_uses IS NULL OR used_count < max_uses)', couponId);
      if (!r.changes) throw new UserError('Este cupom atingiu o limite de usos.');
    },
    giveBack(couponId) {
      if (couponId) db.run('UPDATE coupons SET used_count = MAX(0, used_count - 1) WHERE id = ?', couponId);
    },

    list: () => db.all('SELECT c.*, (SELECT COUNT(*) FROM coupon_products cp WHERE cp.coupon_id = c.id) AS restricted FROM coupons c ORDER BY c.active DESC, c.id DESC'),

    save(b, id = null) {
      const code = trunc(b.code, 30).toUpperCase().replace(/\s+/g, '');
      if (!/^[A-Z0-9_-]{3,30}$/.test(code)) throw new UserError('O código deve ter de 3 a 30 letras, números, hífen ou sublinhado.');
      const kind = b.kind === 'fixed' ? 'fixed' : 'percent';
      let value;
      if (kind === 'percent') {
        value = int(b.value, 0);
        if (value < 1 || value > 100) throw new UserError('O desconto percentual deve ficar entre 1 e 100.');
      } else {
        value = parseMoney(b.value);
        if (!value || value < 1) throw new UserError('Informe um valor de desconto válido.');
      }
      const min = b.min_subtotal ? parseMoney(b.min_subtotal) : 0;
      if (min === null) throw new UserError('Valor mínimo inválido.');
      const maxUses = b.max_uses === '' || b.max_uses === undefined ? null : int(b.max_uses, NaN);
      if (maxUses !== null && (!Number.isInteger(maxUses) || maxUses < 1)) throw new UserError('Limite de usos inválido.');
      const toIso = (d, end) => {
        if (!d) return null;
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
        if (!m) throw new UserError('Data inválida.');
        // Datas informadas em horário de Brasília (UTC-3).
        return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], end ? 23 + 3 : 3, end ? 59 : 0, end ? 59 : 0)).toISOString();
      };
      const starts = toIso(b.starts_at, false);
      const expires = toIso(b.expires_at, true);
      if (starts && expires && starts >= expires) throw new UserError('A validade precisa ser posterior ao início.');
      const productIds = [].concat(b.product_ids || []).map((x) => int(x)).filter(Boolean);
      return db.tx(() => {
        let cid = id;
        if (db.get('SELECT 1 FROM coupons WHERE code = ? AND id <> ?', code, id ?? -1)) throw new UserError('Já existe um cupom com este código.');
        if (id) {
          db.run('UPDATE coupons SET code=?, description=?, kind=?, value=?, min_subtotal_cents=?, max_uses=?, starts_at=?, expires_at=?, active=? WHERE id=?', code, trunc(b.description, 200), kind, value, min, maxUses, starts, expires, b.active ? 1 : 0, id);
        } else {
          cid = db.run('INSERT INTO coupons (code, description, kind, value, min_subtotal_cents, max_uses, starts_at, expires_at, active, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)', code, trunc(b.description, 200), kind, value, min, maxUses, starts, expires, b.active === undefined || b.active ? 1 : 0, now()).id;
        }
        db.run('DELETE FROM coupon_products WHERE coupon_id = ?', cid);
        for (const pid of productIds) if (db.get('SELECT 1 FROM products WHERE id = ?', pid)) db.run('INSERT OR IGNORE INTO coupon_products (coupon_id, product_id) VALUES (?,?)', cid, pid);
        return cid;
      });
    },

    setActive(id, active) {
      db.run('UPDATE coupons SET active = ? WHERE id = ?', active ? 1 : 0, id);
    },
    remove(id) {
      if (db.get('SELECT 1 FROM orders WHERE coupon_id = ?', id)) throw new UserError('Este cupom já foi usado em pedidos. Desative-o em vez de excluir.');
      db.run('DELETE FROM coupons WHERE id = ?', id);
    },
  };
  return coupons;
}

module.exports = { makeCoupons, MIN_RESIDUAL_CENTS };
