'use strict';
/**
 * Provedor Asaas (API v3) — Pix com QR Code dinâmico.
 *  - Autenticação: cabeçalho `access_token` (chave de API, só no servidor).
 *  - Webhook: o Asaas envia o `authToken` que você cadastrou no cabeçalho `asaas-access-token`.
 *    O corpo traz `id` (único por evento), `event` e `payment`. Entrega "pelo menos uma vez" → idempotência por `id`.
 *  - No Pix o fluxo é CREATED → RECEIVED (não existe CONFIRMED). RECEIVED = valor disponível.
 *  - O QR Code do Asaas vale por meses; por isso a loja controla a validade (expira o pedido e exclui a cobrança).
 * Documentação: https://docs.asaas.com
 */
const { ProviderError, httpJson, brDate, toCents, fromCents } = require('./common');
const { safeEqual } = require('../../lib/security');
const { onlyDigits } = require('../../lib/util');

const BASE = { sandbox: 'https://api-sandbox.asaas.com/v3', production: 'https://api.asaas.com/v3' };

function makeAsaas(cfg) {
  const c = cfg.payment.asaas;
  const base = BASE[c.env] || BASE.sandbox;
  const hdr = () => ({ access_token: c.apiKey, 'User-Agent': 'BrechoChiqueto/1.0 (loja virtual)' });

  async function call(method, path, body) {
    const r = await httpJson(`${base}${path}`, { method, headers: hdr(), body });
    if (!r.ok) {
      const msg = r.data?.errors?.map((e) => e.description).filter(Boolean).join('; ') || `HTTP ${r.status}`;
      throw new ProviderError('O provedor de pagamentos recusou a operação.', { status: r.status, detail: msg, retryable: r.status >= 500 });
    }
    return r.data;
  }

  const STATUS = {
    RECEIVED: 'paid', RECEIVED_IN_CASH: 'paid', REFUND_REQUESTED: 'paid', REFUND_IN_PROGRESS: 'paid', CHARGEBACK_REQUESTED: 'paid',
    REFUNDED: 'refunded', PENDING: 'pending', AWAITING_RISK_ANALYSIS: 'pending', OVERDUE: 'pending', CONFIRMED: 'pending',
  };

  return {
    name: 'asaas',
    label: 'Asaas',
    requiresCpf: true,
    sandbox: c.env !== 'production',
    configured: () => !!c.apiKey,
    webhookReady: () => !!c.webhookToken,
    missing: () => [!c.apiKey && 'ASAAS_API_KEY', !c.webhookToken && 'ASAAS_WEBHOOK_TOKEN'].filter(Boolean),

    async createPixCharge({ order, buyer, expiresAt }) {
      const cpf = onlyDigits(buyer.cpf);
      if (cpf.length !== 11) throw new ProviderError('CPF obrigatório para gerar o Pix.', { detail: 'cpf ausente' });
      // 1) cliente (reaproveita pelo CPF para não duplicar cadastros no Asaas)
      const found = await call('GET', `/customers?cpfCnpj=${cpf}&limit=1`);
      let customerId = found?.data?.[0]?.id;
      if (!customerId) {
        const created = await call('POST', '/customers', {
          name: buyer.name, cpfCnpj: cpf, email: buyer.email, mobilePhone: onlyDigits(buyer.phone) || undefined,
          notificationDisabled: true, // os e-mails ao cliente são enviados pela própria loja
        });
        customerId = created.id;
      }
      // 2) cobrança Pix
      const pay = await call('POST', '/payments', {
        customer: customerId, billingType: 'PIX', value: fromCents(order.total_cents), dueDate: brDate(expiresAt, cfg.tzOffsetMinutes),
        description: `Pedido ${order.number}`, externalReference: order.number,
      });
      // 3) QR Code
      const qr = await call('GET', `/payments/${pay.id}/pixQrCode`);
      return { providerId: pay.id, pixPayload: qr.payload, qrImage: `data:image/png;base64,${qr.encodedImage}`, raw: { status: pay.status } };
    },

    async getPayment(providerId) {
      const p = await call('GET', `/payments/${encodeURIComponent(providerId)}`);
      const value = toCents(p.value);
      const net = toCents(p.netValue);
      let status = STATUS[p.status] || 'pending';
      if (p.deleted) status = 'cancelled';
      return {
        providerId: p.id, status, rawStatus: p.status, amountCents: value, currency: 'BRL', reference: p.externalReference || null,
        feeCents: value !== null && net !== null ? value - net : null, netCents: net,
        paidAt: p.paymentDate || p.clientPaymentDate || null, settlementDate: p.creditDate || null,
        refundedCents: p.status === 'REFUNDED' ? value : 0,
      };
    },

    async cancelCharge(providerId) {
      try {
        await call('DELETE', `/payments/${encodeURIComponent(providerId)}`);
      } catch (e) {
        if (e.status === 404) return; // já removida
        throw e;
      }
    },

    async refund(providerId, amountCents, reason) {
      const r = await call('POST', `/payments/${encodeURIComponent(providerId)}/refund`, { value: fromCents(amountCents), description: String(reason || 'Reembolso').slice(0, 100) });
      return { providerRefundId: r?.id || null, status: 'done' };
    },

    verifyWebhook(headers) {
      if (!c.webhookToken) return { ok: false, reason: 'ASAAS_WEBHOOK_TOKEN não configurado' };
      return safeEqual(headers['asaas-access-token'], c.webhookToken) ? { ok: true } : { ok: false, reason: 'token inválido' };
    },

    /** Converte o corpo do webhook em eventos normalizados. */
    parseWebhook(body) {
      if (!body || typeof body.event !== 'string' || !body.event.startsWith('PAYMENT_') || !body.payment?.id) return [];
      return [{ eventId: String(body.id || `${body.event}:${body.payment.id}:${body.dateCreated || ''}`), type: body.event, providerPaymentId: String(body.payment.id) }];
    },
  };
}

module.exports = { makeAsaas };
