'use strict';
/** Estrutura do painel administrativo e componentes reutilizáveis (tabelas, indicadores, gráfico em SVG). */
const { html, raw, escape } = require('../../lib/html');
const { icon, csrfField, flashBox, badge } = require('../ui');
const { money } = require('../../lib/util');

const NAV = [
  { group: null, items: [{ href: '/admin', label: 'Painel', icon: 'home', perm: 'dashboard.view', exact: true }] },
  { group: 'Vendas', items: [
    { href: '/admin/pedidos', label: 'Pedidos', icon: 'receipt', perm: 'orders.view', badge: 'attention' },
    { href: '/admin/clientes', label: 'Clientes', icon: 'users', perm: 'customers.view' },
    { href: '/admin/cupons', label: 'Cupons', icon: 'tag', perm: 'coupons.manage' },
    { href: '/admin/relatorios', label: 'Relatórios', icon: 'chart', perm: 'reports.view' },
  ] },
  { group: 'Catálogo', items: [
    { href: '/admin/produtos', label: 'Produtos', icon: 'box', perm: 'products.view' },
    { href: '/admin/categorias', label: 'Categorias', icon: 'tag', perm: 'categories.manage' },
    { href: '/admin/estoque', label: 'Estoque', icon: 'box', perm: 'stock.view', badge: 'lowstock' },
  ] },
  { group: 'Atendimento', items: [
    { href: '/admin/mensagens', label: 'Mensagens', icon: 'mail', perm: 'support.manage', badge: 'contacts' },
    { href: '/admin/solicitacoes', label: 'Solicitações', icon: 'bell', perm: 'support.manage', badge: 'support' },
    { href: '/admin/lgpd', label: 'LGPD', icon: 'shield', perm: 'support.manage', badge: 'lgpd' },
    { href: '/admin/newsletter', label: 'Newsletter', icon: 'mail', perm: 'support.manage' },
  ] },
  { group: 'Loja', items: [
    { href: '/admin/banners', label: 'Banners', icon: 'tag', perm: 'content.manage' },
    { href: '/admin/paginas', label: 'Páginas e textos', icon: 'edit', perm: 'content.manage' },
    { href: '/admin/configuracoes', label: 'Configurações', icon: 'settings', perm: 'settings.manage' },
    { href: '/admin/pagamentos', label: 'Pagamentos', icon: 'pix', perm: 'settings.payments' },
  ] },
  { group: 'Sistema', items: [
    { href: '/admin/emails', label: 'E-mails enviados', icon: 'mail', perm: 'emails.view' },
    { href: '/admin/funcionarios', label: 'Funcionários', icon: 'users', perm: 'staff.manage' },
    { href: '/admin/auditoria', label: 'Atividades', icon: 'eye', perm: 'audit.view' },
  ] },
];

function adminLayout(ctx, app, o) {
  const s = app.settings.all();
  const staff = ctx.staff;
  const can = (p) => app.permissions.can(staff, p);
  const counts = {
    attention: app.db.value('SELECT COUNT(*) FROM orders WHERE needs_attention = 1'),
    lowstock: app.stock.lowStock().length,
    contacts: app.db.value("SELECT COUNT(*) FROM contact_messages WHERE status = 'open'"),
    support: app.db.value("SELECT COUNT(*) FROM support_requests WHERE status = 'open'"),
    lgpd: app.db.value("SELECT COUNT(*) FROM data_requests WHERE status = 'open'"),
  };
  const unread = app.crm.unreadCount();
  const active = (it) => (it.exact ? ctx.path === it.href : ctx.path === it.href || ctx.path.startsWith(`${it.href}/`));
  const must = staff.must_change_password;
  const nav = NAV.map((g) => ({ ...g, items: g.items.filter((i) => can(i.perm)) })).filter((g) => g.items.length);

  return html`<!doctype html>
<html lang="pt-BR"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow"><meta name="csrf" content="${ctx.csrf}">
<title>${o.title} · Painel ${s.store_name}</title>
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/css/admin.css?v=${app.cfg.assetVersion}">
</head><body>
<a class="skip" href="#main">Ir para o conteúdo</a>
<div class="shell">
  <aside class="side" id="side">
    <a class="side-brand" href="/admin">${s.store_name}<small>Painel</small></a>
    <nav aria-label="Menu do painel">
      ${must ? '' : nav.map((g) => html`<div class="grp">${g.group ? html`<p class="grp-t">${g.group}</p>` : ''}<ul>${g.items.map((i) => html`<li><a href="${i.href}" ${active(i) ? raw('aria-current="page"') : ''}>${icon(i.icon, 18)}<span>${i.label}</span>${i.badge && counts[i.badge] ? html`<b class="nb">${counts[i.badge]}</b>` : ''}</a></li>`)}</ul></div>`)}
    </nav>
    <div class="side-foot"><a href="/" target="_blank" rel="noopener">${icon('external', 16)} Ver a loja</a></div>
  </aside>
  <div class="main-col">
    <header class="top">
      <button class="icon-btn menu-toggle" type="button" data-side-toggle aria-label="Menu" aria-expanded="false">${icon('menu', 22)}</button>
      <h1 class="page-title">${o.title}</h1>
      <div class="top-right">
        ${can('orders.view') ? html`<a class="icon-btn" href="/admin/notificacoes" aria-label="Notificações${unread ? `, ${unread} novas` : ''}">${icon('bell', 20)}${unread ? html`<b class="nb">${unread}</b>` : ''}</a>` : ''}
        <details class="usermenu"><summary>${icon('user', 18)} <span>${staff.name.split(' ')[0]}</span></summary><div class="pop"><p class="small">${staff.email}<br><span class="muted">${app.permissions.ROLES[staff.role]?.label}</span></p><a href="/admin/minha-conta">Minha conta e segurança</a><form method="post" action="/admin/sair">${csrfField(ctx)}<button class="linklike" type="submit">Sair</button></form></div></details>
      </div>
    </header>
    <main id="main" tabindex="-1">
      ${flashBox(ctx)}
      ${must ? html`<div class="flash flash-info"><span>Por segurança, defina uma nova senha para continuar usando o painel.</span></div>` : ''}
      ${o.actions ? html`<div class="page-actions">${o.actions}</div>` : ''}
      ${o.main}
    </main>
  </div>
</div>
<script src="/js/admin.js?v=${app.cfg.assetVersion}" defer></script>
</body></html>`;
}

function errorPage(ctx, app, status, message) {
  const t = { 401: 'Faça login', 403: 'Acesso negado', 404: 'Página não encontrada', 422: 'Não foi possível concluir', 429: 'Muitas tentativas' }[status] || 'Algo deu errado';
  const body = html`<section class="card narrow"><h2>${t}</h2><p>${message}</p><p><a class="btn" href="/admin">Voltar ao painel</a></p></section>`;
  if (ctx.staff && !ctx.staff.must_change_password) return ctx.html(adminLayout(ctx, app, { title: t, main: body }), status);
  const s = app.settings.all();
  return ctx.html(html`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>${t}</title><link rel="stylesheet" href="/css/admin.css"></head><body class="plain"><main class="login"><div class="card"><h1>${s.store_name}</h1><h2>${t}</h2><p>${message}</p><p><a class="btn" href="/admin/login">Ir para o login</a></p></div></main></body></html>`, status);
}

// ───── componentes ─────
const kpi = (label, value, sub = '', tone = '') => html`<div class="kpi ${tone}"><span class="kpi-l">${label}</span><strong class="kpi-v">${value}</strong>${sub ? html`<span class="kpi-s">${sub}</span>` : ''}</div>`;

const table = (heads, rows, { empty = 'Nada por aqui ainda.', cls = '' } = {}) => (rows.length
  ? html`<div class="tbl-wrap"><table class="tbl ${cls}"><thead><tr>${heads.map((h) => html`<th scope="col" ${h.right ? raw('class="r"') : ''}>${h.label ?? h}</th>`)}</tr></thead><tbody>${rows}</tbody></table></div>`
  : html`<p class="empty-note">${empty}</p>`);

const statusTone = (st) => ({ awaiting_payment: 'warn', paid: 'good', preparing: 'good', shipped: 'good', in_transit: 'good', delivered: 'good', cancelled: 'bad', refunded: 'bad', pending: 'warn', expired: 'bad', failed: 'bad', partially_refunded: 'warn' }[st] || 'neutral');

/** Gráfico de barras em SVG (receita por dia). Acessível: título, descrição e tabela alternativa. */
function barChart(points, { height = 190, label = 'Receita por dia', fmt = (v) => money(v) } = {}) {
  const W = 760; const H = height; const padL = 8; const padB = 26; const padT = 14;
  const max = Math.max(1, ...points.map((p) => p.value));
  const bw = (W - padL * 2) / Math.max(1, points.length);
  const bars = points.map((p, i) => {
    const h = Math.round(((H - padB - padT) * p.value) / max);
    const x = padL + i * bw;
    return `<g><title>${escape(p.label)}: ${escape(fmt(p.value))}</title><rect x="${(x + bw * 0.14).toFixed(1)}" y="${H - padB - h}" width="${(bw * 0.72).toFixed(1)}" height="${Math.max(h, p.value > 0 ? 2 : 0)}" rx="2" class="bar${p.value ? '' : ' zero'}"/></g>`;
  }).join('');
  const every = Math.ceil(points.length / 8);
  const ticks = points.map((p, i) => (i % every === 0 ? `<text x="${(padL + i * bw + bw / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle" class="tick">${escape(p.tick)}</text>` : '')).join('');
  return html`<figure class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${label}" preserveAspectRatio="none"><line x1="0" x2="${W}" y1="${H - padB}" y2="${H - padB}" class="axis"/>${raw(bars)}${raw(ticks)}</svg><figcaption class="muted small">${label}. Maior valor no período: ${fmt(max === 1 && points.every((p) => !p.value) ? 0 : max)}.</figcaption></figure>`;
}

const dateInput = (name, v) => html`<input type="date" name="${name}" value="${v || ''}">`;

module.exports = { adminLayout, errorPage, kpi, table, statusTone, barChart, dateInput, badge, NAV };
