'use strict';
/**
 * Estoque por peça: movimentações auditáveis, reservas temporárias durante o checkout
 * e baixa definitiva somente após confirmação do pagamento.
 * Todas as operações que alteram quantidades rodam em transação.
 */
const { now, UserError } = require('../lib/util');

function makeStock(app) {
  const { db } = app;

  const reservedQty = (productId, exceptOrderId = null, at = now()) =>
    db.value("SELECT COALESCE(SUM(qty), 0) FROM stock_reservations WHERE product_id = ? AND status = 'active' AND expires_at > ? AND order_id <> ?", productId, at, exceptOrderId ?? -1);

  const stock = {
    reservedQty,

    available(productId) {
      const p = db.get('SELECT quantity FROM products WHERE id = ?', productId);
      return p ? Math.max(0, p.quantity - reservedQty(productId)) : 0;
    },

    /** Registra uma movimentação (o saldo já foi aplicado pelo chamador dentro da mesma transação). */
    record(productId, delta, balanceAfter, reason, { orderId = null, note = null, staffId = null } = {}) {
      if (!delta) return;
      db.run('INSERT INTO stock_movements (product_id, delta, balance_after, reason, order_id, note, staff_id, created_at) VALUES (?,?,?,?,?,?,?,?)', productId, delta, balanceAfter, reason, orderId, note, staffId, now());
    },

    /** Entrada, saída ou ajuste manual. `delta` positivo entra, negativo sai. Nunca deixa o estoque negativo nem abaixo do reservado. */
    change(productId, delta, { reason = 'ajuste', note = null, staffId = null, orderId = null } = {}) {
      if (!Number.isInteger(delta) || delta === 0) throw new UserError('Informe uma quantidade diferente de zero.');
      return db.tx(() => {
        const p = db.get('SELECT id, quantity, name FROM products WHERE id = ?', productId);
        if (!p) throw new UserError('Produto não encontrado.');
        const after = p.quantity + delta;
        if (after < 0) throw new UserError(`Estoque insuficiente: "${p.name}" tem ${p.quantity} unidade(s).`);
        if (delta < 0 && after < reservedQty(productId)) throw new UserError(`"${p.name}" tem unidades reservadas em pedidos aguardando pagamento. Não é possível reduzir abaixo de ${reservedQty(productId)}.`);
        db.run('UPDATE products SET quantity = ?, updated_at = ? WHERE id = ?', after, now(), productId);
        this.record(productId, delta, after, reason, { orderId, note, staffId });
        return after;
      });
    },

    adjustTo(productId, target, opts = {}) {
      const p = db.get('SELECT quantity FROM products WHERE id = ?', productId);
      if (!p) throw new UserError('Produto não encontrado.');
      if (target === p.quantity) return p.quantity;
      return this.change(productId, target - p.quantity, opts);
    },

    /** Marca uma peça como vendida fora da loja virtual (zera o estoque disponível). */
    markSoldOffline(productId, staffId, note = 'Vendida fora da loja virtual') {
      const p = db.get('SELECT quantity FROM products WHERE id = ?', productId);
      if (!p || p.quantity === 0) throw new UserError('Esta peça já está sem estoque.');
      return this.change(productId, -p.quantity, { reason: 'venda_fisica', note, staffId });
    },

    // ───── reservas durante o checkout ─────
    /** Reserva as peças de um pedido. Falha se alguma não estiver mais disponível. Deve rodar dentro da transação do pedido. */
    reserve(orderId, items, expiresAt) {
      const t = now();
      for (const it of items) {
        const p = db.get('SELECT id, name, quantity, status FROM products WHERE id = ?', it.product_id);
        if (!p || p.status !== 'published') throw new UserError(`"${it.name || 'Uma peça'}" não está mais disponível.`);
        const avail = p.quantity - reservedQty(p.id, null, t);
        if (avail < it.qty) {
          throw new UserError(avail <= 0 ? `"${p.name}" acabou de ser vendida ou reservada por outro cliente.` : `Só há ${avail} unidade(s) de "${p.name}" disponível(is).`);
        }
        db.run("INSERT INTO stock_reservations (product_id, order_id, qty, status, expires_at, created_at) VALUES (?,?,?,'active',?,?)", p.id, orderId, it.qty, expiresAt, t);
      }
    },

    extend(orderId, expiresAt) {
      db.run("UPDATE stock_reservations SET expires_at = ? WHERE order_id = ? AND status = 'active'", expiresAt, orderId);
    },

    release(orderId) {
      return db.run("UPDATE stock_reservations SET status = 'released' WHERE order_id = ? AND status = 'active'", orderId).changes;
    },

    /**
     * Baixa definitiva após pagamento confirmado. Retorna { ok, conflicts[] }.
     * Se a reserva já expirou/foi liberada e a peça foi vendida para outra pessoa, devolve conflito
     * (o pedido fica sinalizado para o administrador reembolsar).
     */
    consume(orderId, staffId = null) {
      const items = db.all('SELECT * FROM order_items WHERE order_id = ?', orderId);
      const conflicts = [];
      for (const it of items) {
        if (!it.product_id) continue;
        const res = db.get('SELECT * FROM stock_reservations WHERE order_id = ? AND product_id = ?', orderId, it.product_id);
        if (res && res.status === 'consumed') continue; // idempotência
        const p = db.get('SELECT id, quantity FROM products WHERE id = ?', it.product_id);
        // Se a reserva ainda é válida, a peça é nossa. Senão, só baixa se sobrar estoque livre.
        const otherReserved = reservedQty(it.product_id, orderId);
        if (!p || p.quantity - otherReserved < it.qty) {
          conflicts.push({ product_id: it.product_id, name: it.name, qty: it.qty });
          if (res) db.run("UPDATE stock_reservations SET status = 'released' WHERE id = ?", res.id);
          continue;
        }
        const after = p.quantity - it.qty;
        db.run('UPDATE products SET quantity = ?, updated_at = ? WHERE id = ?', after, now(), p.id);
        this.record(p.id, -it.qty, after, 'venda', { orderId, staffId, note: 'Pagamento confirmado' });
        if (res) db.run("UPDATE stock_reservations SET status = 'consumed' WHERE id = ?", res.id);
        else db.run("INSERT INTO stock_reservations (product_id, order_id, qty, status, expires_at, created_at) VALUES (?,?,?,'consumed',?,?)", p.id, orderId, it.qty, now(), now());
      }
      return { ok: conflicts.length === 0, conflicts };
    },

    /** Devolve ao estoque as peças de um pedido reembolsado. */
    restock(orderId, staffId, note = 'Reembolso: peça devolvida ao estoque') {
      for (const it of db.all('SELECT * FROM order_items WHERE order_id = ?', orderId)) {
        if (!it.product_id) continue;
        const p = db.get('SELECT quantity FROM products WHERE id = ?', it.product_id);
        if (!p) continue;
        const after = p.quantity + it.qty;
        db.run('UPDATE products SET quantity = ?, updated_at = ? WHERE id = ?', after, now(), it.product_id);
        this.record(it.product_id, it.qty, after, 'reembolso', { orderId, staffId, note });
      }
    },

    /** Marca reservas vencidas como liberadas (a disponibilidade já ignora reservas vencidas). */
    releaseExpired() {
      return db.run("UPDATE stock_reservations SET status = 'released' WHERE status = 'active' AND expires_at <= ?", now()).changes;
    },

    movements(productId, limit = 100) {
      return db.all('SELECT m.*, s.name AS staff_name, o.number AS order_number FROM stock_movements m LEFT JOIN staff_users s ON s.id = m.staff_id LEFT JOIN orders o ON o.id = m.order_id WHERE m.product_id = ? ORDER BY m.id DESC LIMIT ?', productId, limit);
    },
    recentMovements({ limit = 100, reason = '' } = {}) {
      return db.all(`SELECT m.*, p.name AS product_name, p.sku, s.name AS staff_name, o.number AS order_number FROM stock_movements m JOIN products p ON p.id = m.product_id LEFT JOIN staff_users s ON s.id = m.staff_id LEFT JOIN orders o ON o.id = m.order_id ${reason ? 'WHERE m.reason = ?' : ''} ORDER BY m.id DESC LIMIT ?`, ...(reason ? [reason, limit] : [limit]));
    },
    lowStock() {
      return db.all("SELECT id, sku, name, quantity, restock_alert_qty FROM products WHERE status <> 'archived' AND restock_alert_qty IS NOT NULL AND quantity <= restock_alert_qty ORDER BY quantity, name");
    },
  };
  return stock;
}

module.exports = { makeStock };
