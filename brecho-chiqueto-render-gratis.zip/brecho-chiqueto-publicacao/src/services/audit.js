'use strict';
const { now } = require('../lib/util');

const SENSITIVE = /(senha|password|token|secret|cpf|api[_-]?key|authorization)/i;

function scrub(details) {
  if (details === undefined || details === null) return null;
  const clean = (v, depth = 0) => {
    if (depth > 3) return '…';
    if (Array.isArray(v)) return v.slice(0, 30).map((x) => clean(x, depth + 1));
    if (v && typeof v === 'object') {
      const o = {};
      for (const [k, val] of Object.entries(v)) o[k] = SENSITIVE.test(k) ? '[omitido]' : clean(val, depth + 1);
      return o;
    }
    if (typeof v === 'string' && v.length > 500) return `${v.slice(0, 500)}…`;
    return v;
  };
  try {
    return JSON.stringify(clean(details));
  } catch {
    return null;
  }
}

function makeAudit(app) {
  const { db } = app;
  return {
    /** actor: { type: 'staff'|'customer'|'system'|'webhook', id?, label? } */
    log(actor, action, entity = null, entityId = null, details = null, ip = null) {
      try {
        db.run(
          'INSERT INTO audit_logs (at, actor_type, actor_id, actor_label, action, entity, entity_id, details, ip) VALUES (?,?,?,?,?,?,?,?,?)',
          now(), actor.type, actor.id ?? null, actor.label ?? null, action, entity, entityId === null ? null : String(entityId), scrub(details), ip
        );
      } catch (e) {
        console.error('[auditoria] falha ao registrar:', e.message);
      }
    },
    staff(ctx, action, entity, entityId, details) {
      const s = ctx.staff;
      this.log({ type: 'staff', id: s?.id, label: s ? `${s.name} <${s.email}>` : 'desconhecido' }, action, entity, entityId, details, ctx.ip);
    },
    system(action, entity, entityId, details) {
      this.log({ type: 'system', label: 'sistema' }, action, entity, entityId, details);
    },
    prune(days = 730) {
      db.run('DELETE FROM audit_logs WHERE at < ?', new Date(Date.now() - days * 86400000).toISOString());
    },
  };
}

module.exports = { makeAudit };
