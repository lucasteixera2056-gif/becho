'use strict';
/**
 * Configurações editáveis pelo painel (tabela settings).
 * Valores padrão são apenas provisórios e neutros: nada aqui representa dado comercial real
 * (telefone, endereço, prazos, políticas). O proprietário preenche tudo em /admin/configuracoes.
 */
const DEFAULTS = {
  store_name: 'Brechó Chiqueto',
  store_tagline: 'Moda de segunda mão, com estilo e peças únicas.',
  store_description: '',
  store_email: '',
  store_phone: '',
  store_whatsapp: '',
  store_instagram: 'https://www.instagram.com/brecho_chiqueto/',
  store_address: '',
  store_hours: '',
  store_document: '',
  logo_file: '',
  color_primary: '#8C2F39',
  color_accent: '#B08D57',
  color_bg: '#FAF6F1',
  color_ink: '#2A2220',
  font_heading: 'serif',
  hero_title: 'Brechó Chiqueto',
  hero_subtitle: 'Moda de segunda mão, com estilo e peças únicas.',
  hero_cta_label: 'Ver peças',
  hero_cta_url: '/loja',
  hero_image: '',
  about_title: 'Sobre o brechó',
  about_text: '',
  instagram_cta_title: 'Acompanhe as novidades no Instagram',
  instagram_cta_text: 'Peças novas chegam o tempo todo. Siga o perfil para não perder nada.',
  footer_text: '',
  pickup_note: '',
  admin_notify_email: '',
  email_from_name: '',
  email_from_address: '',
  email_reply_to: '',
  pix_expiry_minutes: '',
  reservation_grace_minutes: '10',
  legal_reviewed: '0',
  checkout_note: '',
};

const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

function makeSettings(app) {
  const { db } = app;
  let cache = null;

  const load = () => {
    const out = { ...DEFAULTS };
    for (const r of db.all('SELECT key, value FROM settings')) out[r.key] = r.value;
    cache = out;
    return out;
  };

  return {
    DEFAULTS,
    all() {
      return cache || load();
    },
    get(key) {
      return (cache || load())[key] ?? '';
    },
    set(key, value) {
      if (!(key in DEFAULTS)) throw new Error(`Configuração desconhecida: ${key}`);
      db.run("INSERT INTO settings (key, value, updated_at) VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at", key, String(value ?? ''));
      cache = null;
    },
    setMany(obj) {
      db.tx(() => {
        for (const [k, v] of Object.entries(obj)) this.set(k, v);
      });
    },
    /** Valida campos de aparência antes de gravar. */
    validColor: (c) => COLOR_RE.test(String(c || '')),
    invalidate() {
      cache = null;
    },
  };
}

module.exports = { makeSettings, DEFAULTS };
