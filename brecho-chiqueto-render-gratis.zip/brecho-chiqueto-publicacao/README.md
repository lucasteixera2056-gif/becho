# Brechó Chiqueto — loja virtual

Loja virtual completa para o brechó [@brecho_chiqueto](https://www.instagram.com/brecho_chiqueto/): vitrine pública, carrinho, checkout com **Pix** (QR Code dinâmico + copia e cola), painel administrativo em `/admin`, área do cliente em `/minha-conta`, estoque de peças únicas com reserva, e-mails transacionais, entrega configurável, LGPD e SEO.

> **Estado do projeto — leia antes de publicar.** O código foi escrito e testado de ponta a ponta com um provedor Pix **simulado**. A integração com **Asaas**, **Mercado Pago**, **Resend** e **Melhor Envio** foi escrita conforme a documentação pública, mas **ainda não foi executada contra as contas reais** (não existem credenciais do brechó neste ambiente). Veja [`docs/PENDENCIAS.md`](docs/PENDENCIAS.md) para o que falta e como validar cada item. Nenhum dado de produto, preço, endereço, telefone ou política do brechó foi inventado: tudo isso é preenchido por você no painel.

## O que existe

| Área | O que faz |
|---|---|
| Loja | Início com banners, catálogo com filtros (categoria, tamanho, marca, cor, preço, promoção), busca sem acento, ordenação e paginação, página da peça com galeria, carrinho que persiste, cupons, checkout como visitante ou com conta |
| Peças únicas | Estoque padrão 1. Ao fechar o pedido a peça fica **reservada** até o Pix vencer; ninguém mais consegue comprar. Vendida ou reservada nunca é vendida de novo (testado inclusive com pedidos simultâneos) |
| Pix | Cobrança por pedido no provedor, QR Code + copia e cola, validade, tela que atualiza sozinha. **Só o provedor confirma pagamento** (webhook autenticado + consulta à API + conferência de pedido, valor e moeda; idempotente). O painel **não** tem botão de “marcar como pago” |
| Painel | Indicadores, produtos (várias fotos, categorias, estado de conservação, medidas e defeitos, promoção, estoque e movimentações), pedidos (fluxo, rastreio, reembolso), clientes (LGPD), cupons, relatórios com CSV e impressão, banners, páginas, configurações, funcionários com 5 funções e permissões, registro de atividades, sessões |
| Cliente | Cadastro com confirmação de e-mail, recuperação de senha, pedidos, endereços, perfil, baixar meus dados, pedir eliminação |
| E-mails | Modelos editáveis (Resend), histórico com erro e reenvio |
| Entrega | Frete fixo, grátis acima de um valor, retirada, entrega local por CEP, Melhor Envio (cotação), rastreio. **Nunca inventa preço nem prazo** |
| Segurança | scrypt, CSRF, CSP sem script inline, limite de tentativas, sessões revogáveis, CPF cifrado, upload validado pelo conteúdo, auditoria, erros sem vazar detalhes |

## Requisitos

- **Node.js 22.13 ou superior** (usa o SQLite embutido do Node). Não há dependências para instalar: `npm install` não é necessário.
- Disco **persistente** para as pastas `data/` (banco) e `uploads/` (fotos). Não serve para hospedagem “serverless” nem sem disco persistente.
- Um único processo (SQLite + rotinas internas). Atende bem uma loja deste porte.

## Rodando localmente (teste, sem dinheiro real)

```bash
cp .env.example .env
# em .env: NODE_ENV=development, PAYMENT_PROVIDER=mock, EMAIL_TRANSPORT=log, BASE_URL=http://localhost:3000, HOST=127.0.0.1
npm run create-admin          # cria o primeiro acesso ao painel (senha digitada no terminal)
npm run seed:demo             # OPCIONAL: peças FICTÍCIAS "[DEMO]" só para ver a loja cheia
npm start                     # http://localhost:3000   |   painel: http://localhost:3000/admin
```

Com `PAYMENT_PROVIDER=mock` o Pix é simulado. Para “pagar” um pedido de teste: `node scripts/dev-pay.js NÚMERO-DO-PEDIDO`.
`mock` e `EMAIL_TRANSPORT=capture` são **recusados em produção** (a loja nem sobe).

## Comandos

| Comando | Para quê |
|---|---|
| `npm start` | Sobe a loja |
| `npm run create-admin` | Cria um acesso ao painel; `-- --email x --reset` define nova senha |
| `npm run backup` | Cópia íntegra do banco + fotos em `backups/` (mantém as 14 mais recentes) |
| `npm run seed:demo` | Peças fictícias para desenvolvimento (recusa rodar em produção) |
| `npm test` | Roda os testes automatizados |

## Testes

`npm test` roda **50 testes** (Node test runner, sem dependências), todos executados e aprovados na última rodada:

- **financeiro/Pix**: webhook assinado, duplicado, com assinatura inválida, que “diz” estar pago sem o provedor confirmar, divergência de valor, pagamento tardio, reembolsos, relatórios que separam faturado/recebido/pendente/liquidado;
- **segurança**: CSRF, login e bloqueio, RBAC no servidor, escalonamento de privilégio, XSS, cabeçalhos, upload de imagem, travessia de diretório, vazamento de segredos, CPF;
- **loja**: catálogo, cadastro de produto, carrinho, cupons, estoque e reservas, entrega, checkout pelo HTTP (com valores adulterados), painel de produtos com foto;
- **conta/e-mail/LGPD**: cadastro e confirmação, recuperação de senha, isolamento entre clientes, exportação e anonimização, newsletter com consentimento, contato, e-mails (inclusive falha da API e reenvio).

Os testes usam banco em memória e provedor simulado: **não** provam que Asaas, Mercado Pago, Resend ou Melhor Envio funcionam com a sua conta. Isso só se confirma no sandbox deles — roteiro em [`docs/PENDENCIAS.md`](docs/PENDENCIAS.md).

## Estrutura

```
server.js            ponto de entrada
src/config.js        variáveis de ambiente (.env)
src/db.js            SQLite, transações, migrações (src/migrations)
src/services/        regras de negócio (catálogo, estoque, pedidos, pagamentos, e-mail, auth, relatórios…)
src/providers/       Pix (asaas, mercadopago, mock) e frete (melhorenvio)
src/web/             rotas e telas da loja, conta e painel (src/web/admin)
public/              CSS e JS do navegador (sem scripts inline)
scripts/             create-admin, backup, seed-demo, dev-pay
test/                testes automatizados
docs/                manuais e guias
```

## Publicação de prévia grátis

Para publicar uma prévia pública no plano gratuito do Render (com limitações de suspensão e armazenamento temporário), veja [`docs/RENDER-GRATIS.md`](docs/RENDER-GRATIS.md).

## Documentação

- [`docs/MANUAL-ADMIN.md`](docs/MANUAL-ADMIN.md) — manual do painel para quem usa no dia a dia
- [`docs/PUBLICACAO.md`](docs/PUBLICACAO.md) — como colocar no ar, HTTPS, backup e restauração
- [`docs/PAGAMENTOS.md`](docs/PAGAMENTOS.md) — ligar o Pix (Asaas ou Mercado Pago) e testar no sandbox
- [`docs/EMAIL.md`](docs/EMAIL.md) — Resend, domínio, SPF/DKIM e caixa de entrada
- [`docs/SERVICOS-EXTERNOS.md`](docs/SERVICOS-EXTERNOS.md) — contas que o brechó precisa abrir
- [`docs/PENDENCIAS.md`](docs/PENDENCIAS.md) — o que depende de credenciais, o que não foi verificado e limites conhecidos

## Licença

Uso exclusivo do Brechó Chiqueto (`UNLICENSED`).
