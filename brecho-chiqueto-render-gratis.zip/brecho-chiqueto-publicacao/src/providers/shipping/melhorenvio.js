'use strict';
/**
 * Cotação de frete pelo Melhor Envio (API v2: POST /api/v2/me/shipment/calculate).
 * Requer MELHORENVIO_TOKEN e MELHORENVIO_FROM_CEP no ambiente do servidor.
 * ATENÇÃO: implementado conforme a documentação pública, mas só pode ser validado com um
 * token real do proprietário. Use o ambiente sandbox (MELHORENVIO_ENV=sandbox) para testar.
 */
const BASE = { sandbox: 'https://sandbox.melhorenvio.com.br', production: 'https://melhorenvio.com.br' };

function makeMelhorEnvio(cfg) {
  const c = cfg.shipping.melhorEnvio;
  return {
    name: 'melhorenvio',
    configured: () => !!(c.token && c.fromZip && c.fromZip.length === 8),
    missing: () => [!c.token && 'MELHORENVIO_TOKEN', (!c.fromZip || c.fromZip.length !== 8) && 'MELHORENVIO_FROM_CEP'].filter(Boolean),

    /** items: [{ weight_g, price_cents, qty }]; method config: { width, height, length, default_weight_g, extra_days, services: [ids] } */
    async quote({ toZip, items, methodConfig = {} }) {
      const num = (v, d) => (Number(v) > 0 ? Number(v) : d);
      const totalWeightG = items.reduce((s, i) => s + (i.weight_g || num(methodConfig.default_weight_g, 400)) * i.qty, 0);
      const insurance = items.reduce((s, i) => s + i.price_cents * i.qty, 0) / 100;
      const body = {
        from: { postal_code: c.fromZip },
        to: { postal_code: toZip },
        package: {
          height: num(methodConfig.height, 10),
          width: num(methodConfig.width, 25),
          length: num(methodConfig.length, 30),
          weight: Math.max(0.1, totalWeightG / 1000),
        },
        options: { receipt: false, own_hand: false, insurance_value: insurance },
      };
      const res = await fetch(`${BASE[c.env] || BASE.sandbox}/api/v2/me/shipment/calculate`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${c.token}`,
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'User-Agent': c.userAgent || 'Brecho Chiqueto (loja virtual)',
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(12000),
      });
      if (!res.ok) throw new Error(`Melhor Envio respondeu ${res.status}`);
      const data = await res.json();
      const allowed = Array.isArray(methodConfig.services) && methodConfig.services.length ? methodConfig.services.map(String) : null;
      return (Array.isArray(data) ? data : [])
        .filter((s) => s && !s.error && (s.custom_price || s.price) && (!allowed || allowed.includes(String(s.id))))
        .map((s) => {
          const price = Math.round(parseFloat(String(s.custom_price ?? s.price)) * 100);
          const days = Number(s.custom_delivery_time ?? s.delivery_time) + Number(methodConfig.extra_days || 0);
          return {
            service_id: s.id,
            name: `${s.company?.name ? `${s.company.name} ` : ''}${s.name}`.trim(),
            price_cents: price,
            eta_text: Number.isFinite(days) && days > 0 ? `${days} dia(s) úteis após o envio` : '',
          };
        })
        .filter((s) => Number.isFinite(s.price_cents) && s.price_cents >= 0);
    },
  };
}

module.exports = { makeMelhorEnvio };
