'use strict';
/** Painel: produtos (com fotos), categorias e estoque. */
const { html, raw } = require('../../lib/html');
const { money, centsToInput, UserError, int, formatDate } = require('../../lib/util');
const { icon, csrfField, field, selectField, imgUrl, pager, qs, badge } = require('../ui');
const { CONDITIONS } = require('../../services/catalog');

function register(router, app, h) {
  const { L } = h;
  const { cfg } = app;
  const statusLabel = { draft: 'Rascunho', published: 'Publicado', archived: 'Arquivado' };
  const statusTone = { draft: 'warn', published: 'good', archived: 'neutral' };

  const catOptions = () => {
    const out = [];
    for (const c of app.catalog.categoryTree(true)) {
      out.push({ value: c.id, label: c.name + (c.active ? '' : ' (inativa)') });
      for (const s of c.children) out.push({ value: s.id, label: `${c.name} › ${s.name}` });
    }
    return out;
  };

  // ───── lista de produtos ─────
  router.get('/admin/produtos', (ctx) => {
    const q = { q: ctx.query.q || '', status: ctx.query.status || '', category: ctx.query.categoria || '', stock: ctx.query.estoque || '' };
    const r = app.catalog.adminList({ ...q, page: ctx.query.page });
    const c = app.catalog.counts();
    const link = (o = {}) => `/admin/produtos${qs({ q: q.q, status: q.status, categoria: q.category, estoque: q.stock }, { page: '', ...o })}`;
    h.page(ctx, 'Produtos', html`
<section class="card">
  <form class="filters" method="get" action="/admin/produtos">
    <div class="field"><label for="q">Buscar</label><input id="q" name="q" value="${q.q}" placeholder="Nome, marca, SKU…" type="search"></div>
    ${selectField({ label: 'Situação', name: 'status', value: q.status, options: Object.entries(statusLabel).map(([value, label]) => ({ value, label })), blank: 'Todas' })}
    ${selectField({ label: 'Categoria', name: 'categoria', value: q.category, options: catOptions(), blank: 'Todas' })}
    ${selectField({ label: 'Estoque', name: 'estoque', value: q.stock, options: [{ value: 'available', label: 'Disponíveis' }, { value: 'sold', label: 'Vendidas / zerado' }, { value: 'low', label: 'Estoque baixo' }], blank: 'Todos' })}
    <div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div>
  </form>
  <p class="muted small">${c.total} no total · ${c.published} publicados · ${c.available} à venda · ${c.sold} vendidos/zerados</p>
  ${L.table(['', 'Produto', 'Categoria', { label: 'Preço', right: true }, { label: 'Estoque', right: true }, 'Situação', ''], r.items.map((p) => html`<tr>
    <td class="thumb-cell">${p.image ? html`<img src="${imgUrl(p.image)}" alt="" width="44" height="56" loading="lazy">` : html`<span class="no-img">sem foto</span>`}</td>
    <td><a href="/admin/produtos/${p.id}"><strong>${p.name}</strong></a><br><small class="muted">${p.sku}${p.size ? ` · Tam. ${p.size}` : ''}${p.brand ? ` · ${p.brand}` : ''}</small></td>
    <td>${p.category_name || '—'}</td>
    <td class="r">${p.on_sale ? html`<s class="muted">${money(p.price_cents)}</s><br>` : ''}${money(p.effective_cents)}</td>
    <td class="r">${p.quantity}${p.quantity !== p.available ? html`<br><small class="muted">${p.available} livre(s)</small>` : ''}</td>
    <td>${badge(statusLabel[p.status], statusTone[p.status])}</td>
    <td class="r"><a class="btn btn-small btn-ghost" href="/admin/produtos/${p.id}">Editar</a></td></tr>`), { empty: 'Nenhum produto encontrado.' })}
  ${pager(r, (n) => link({ page: n }))}
</section>`, { actions: h.can(ctx, 'products.edit') ? html`<a class="btn" href="/admin/produtos/novo">${icon('plus', 16)} Novo produto</a>` : '' });
  }, h.S('products.view'));

  // ───── formulário de produto ─────
  const productForm = (ctx, p = {}, errors = {}) => {
    const isNew = !p.id;
    const v = (k, d = '') => (p[k] ?? d);
    const imgs = p.id ? app.catalog.images(p.id) : [];
    return html`
<form method="post" action="${isNew ? '/admin/produtos' : `/admin/produtos/${p.id}`}" class="stack" novalidate>
  ${csrfField(ctx)}
  <section class="card"><h2>Informações</h2>
    ${field({ label: 'Nome da peça', name: 'name', value: v('name'), required: true, maxlength: 140, error: errors.name })}
    <div class="grid2">${selectField({ label: 'Categoria', name: 'category_id', value: v('category_id'), options: catOptions(), blank: 'Sem categoria', hint: 'Subcategorias aparecem como “Categoria › Sub”.' })}${field({ label: 'Código (SKU)', name: 'sku', value: v('sku'), hint: isNew ? 'Deixe em branco para gerar automaticamente.' : '', error: errors.sku, maxlength: 40 })}</div>
    <div class="grid3">${field({ label: 'Marca', name: 'brand', value: v('brand') })}${field({ label: 'Tamanho', name: 'size', value: v('size'), placeholder: 'P, M, 38, Único…' })}${field({ label: 'Cor', name: 'color', value: v('color') })}</div>
    <div class="grid2">${selectField({ label: 'Estado de conservação', name: 'condition', value: v('condition'), options: CONDITIONS, blank: 'Não informar' })}${field({ label: 'Medidas', name: 'measures', value: v('measures'), placeholder: 'Busto 90 cm · Comprimento 100 cm', hint: 'Meça a peça e informe — reduz trocas.' })}</div>
    <div class="field"><label for="f_description">Descrição <span class="opt">(opcional)</span></label><textarea id="f_description" name="description" rows="5" maxlength="5000">${v('description')}</textarea></div>
    <div class="field"><label for="f_defects">Detalhes e defeitos <span class="opt">(opcional)</span></label><textarea id="f_defects" name="defects" rows="3" maxlength="1000">${v('defects')}</textarea><div class="hint">Seja transparente: aparece em destaque na página da peça.</div></div>
  </section>
  <section class="card"><h2>Preço e estoque</h2>
    <div class="grid3">${field({ label: 'Preço de venda (R$)', name: 'price', value: p.price_cents ? centsToInput(p.price_cents) : v('price'), required: true, inputmode: 'decimal', error: errors.price })}${field({ label: 'Preço promocional (R$)', name: 'promo', value: p.promo_cents ? centsToInput(p.promo_cents) : v('promo'), inputmode: 'decimal', error: errors.promo, hint: 'Precisa ser menor que o preço de venda.' })}${field({ label: 'Custo (R$)', name: 'cost', value: p.cost_cents ? centsToInput(p.cost_cents) : v('cost'), inputmode: 'decimal', hint: 'Só você vê.' })}</div>
    <div class="grid3">${field({ label: 'Quantidade em estoque', name: 'quantity', type: 'number', value: p.quantity ?? v('quantity', '1'), required: true, attrs: 'min="0"', hint: 'Peça única = 1. Alterações ficam registradas na movimentação.', error: errors.quantity })}${field({ label: 'Avisar quando restar até', name: 'restock_alert_qty', type: 'number', value: v('restock_alert_qty'), attrs: 'min="0"' })}${field({ label: 'Peso (gramas)', name: 'weight_g', type: 'number', value: v('weight_g'), attrs: 'min="1"', hint: 'Usado no cálculo de frete por transportadora.' })}</div>
  </section>
  <section class="card"><h2>Publicação</h2>
    <div class="grid2">${selectField({ label: 'Situação', name: 'status', value: v('status', 'draft'), options: Object.entries(statusLabel).map(([value, label]) => ({ value, label })), blank: null, required: true, hint: 'Só “Publicado” aparece na loja.' })}<div class="field"><label>Destaque</label><label class="check"><input type="checkbox" name="featured" value="1" ${p.featured ? raw('checked') : ''}> Mostrar em “Em destaque” na página inicial</label></div></div>
  </section>
  <div class="sticky-actions"><button class="btn" type="submit">${isNew ? 'Salvar e adicionar fotos' : 'Salvar alterações'}</button> <a class="btn btn-ghost" href="/admin/produtos">Cancelar</a></div>
</form>
${isNew ? '' : html`
<section class="card"><h2>Fotos <small class="muted">(${imgs.length}/12)</small></h2>
  <p class="muted small">A primeira foto é a principal. As imagens são redimensionadas no seu navegador antes do envio. Formatos: JPG, PNG, WebP.</p>
  ${imgs.length ? html`<ul class="photos">${imgs.map((i, n) => html`<li><img src="${imgUrl(i.filename)}" alt="${i.alt || `Foto ${n + 1}`}" loading="lazy">${i.is_primary ? html`<span class="tag">Principal</span>` : ''}
    <div class="photo-actions">${i.is_primary ? '' : html`<form method="post" action="/admin/produtos/${p.id}/imagens/${i.id}/principal">${csrfField(ctx)}<button class="linklike" type="submit">Tornar principal</button></form>`}
    <form method="post" action="/admin/produtos/${p.id}/imagens/${i.id}/mover">${csrfField(ctx)}<input type="hidden" name="dir" value="up"><button class="linklike" type="submit" aria-label="Mover para antes" ${n === 0 ? raw('disabled') : ''}>←</button></form>
    <form method="post" action="/admin/produtos/${p.id}/imagens/${i.id}/mover">${csrfField(ctx)}<input type="hidden" name="dir" value="down"><button class="linklike" type="submit" aria-label="Mover para depois" ${n === imgs.length - 1 ? raw('disabled') : ''}>→</button></form>
    <form method="post" action="/admin/produtos/${p.id}/imagens/${i.id}/excluir" data-confirm="Excluir esta foto?">${csrfField(ctx)}<button class="linklike danger" type="submit">Excluir</button></form></div></li>`)}</ul>` : html`<p class="empty-note">Nenhuma foto ainda. Peças com fotos vendem muito mais.</p>`}
  ${imgs.length < 12 ? html`<div class="uploader" data-uploader data-endpoint="/admin/produtos/${p.id}/imagens" data-multiple data-reload><label class="btn btn-ghost" for="up">${icon('plus', 16)} Adicionar fotos</label><input id="up" type="file" accept="image/jpeg,image/png,image/webp" multiple hidden><span class="muted small" data-status role="status"></span></div>` : ''}
</section>
<section class="card"><h2>Ações</h2><div class="row-actions-wrap">
  ${p.quantity > 0 && h.can(ctx, 'stock.manage') ? html`<form method="post" action="/admin/produtos/${p.id}/vendida-fora" data-confirm="Marcar como vendida fora da loja virtual? O estoque será zerado.">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">Vendida na loja física / fora do site</button></form>` : ''}
  <form method="post" action="/admin/produtos/${p.id}/duplicar">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">Duplicar</button></form>
  ${p.status !== 'archived' ? html`<form method="post" action="/admin/produtos/${p.id}/status"><input type="hidden" name="status" value="archived">${csrfField(ctx)}<button class="btn btn-ghost" type="submit">Arquivar</button></form>` : ''}
  ${h.can(ctx, 'products.delete') ? html`<form method="post" action="/admin/produtos/${p.id}/excluir" data-confirm="Excluir definitivamente? Só é possível se a peça nunca foi vendida.">${csrfField(ctx)}<button class="btn btn-danger" type="submit">Excluir</button></form>` : ''}
  <a class="btn btn-ghost" href="/admin/estoque/${p.id}">Histórico de estoque</a>${p.status === 'published' ? html`<a class="btn btn-ghost" href="/produto/${p.slug}" target="_blank" rel="noopener">Ver na loja ${icon('external', 14)}</a>` : ''}
</div></section>`}`;
  };

  router.get('/admin/produtos/novo', (ctx) => h.page(ctx, 'Novo produto', productForm(ctx, { status: 'draft', quantity: 1 })), h.S('products.edit'));
  router.post('/admin/produtos', (ctx) => {
    try {
      const f = app.catalog.parseProductForm(ctx.body);
      const id = app.catalog.createProduct(f, ctx.staff.id);
      app.audit.staff(ctx, 'product.created', 'product', id, { name: f.name });
      ctx.flash('success', 'Produto criado. Agora adicione as fotos.');
      ctx.redirect(`/admin/produtos/${id}`);
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      const b = ctx.body;
      h.page(ctx, 'Novo produto', html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${e.message}</span></div>${productForm(ctx, { ...b, category_id: b.category_id, featured: b.featured }, e.field ? { [e.field]: e.message } : {})}`, { status: 422 });
    }
  }, h.S('products.edit'));

  router.get('/admin/produtos/:id', (ctx) => {
    const p = app.catalog.byId(int(ctx.params.id));
    if (!p) return ctx.fail(404, 'Produto não encontrado.');
    h.page(ctx, p.name, productForm(ctx, p));
  }, h.S('products.view'));
  router.post('/admin/produtos/:id', (ctx) => {
    const id = int(ctx.params.id);
    try {
      const f = app.catalog.parseProductForm(ctx.body);
      f.staffId = ctx.staff.id;
      app.catalog.updateProduct(id, f);
      app.audit.staff(ctx, 'product.updated', 'product', id, { name: f.name, status: f.status });
      ctx.flash('success', 'Produto atualizado.');
      ctx.redirect(`/admin/produtos/${id}`);
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      const cur = app.catalog.byId(id) || {};
      h.page(ctx, cur.name || 'Produto', html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${e.message}</span></div>${productForm(ctx, { ...ctx.body, id, slug: cur.slug, quantity: ctx.body.quantity }, e.field ? { [e.field]: e.message } : {})}`, { status: 422 });
    }
  }, h.S('products.edit'));

  const pid = (ctx) => int(ctx.params.id);
  router.post('/admin/produtos/:id/status', (ctx) => h.act(ctx, `/admin/produtos/${pid(ctx)}`, () => { app.catalog.setStatus(pid(ctx), ctx.body.status); app.audit.staff(ctx, 'product.status', 'product', pid(ctx), { status: ctx.body.status }); }, 'Situação atualizada.'), h.S('products.edit'));
  router.post('/admin/produtos/:id/duplicar', (ctx) => h.act(ctx, (n) => (n ? `/admin/produtos/${n}` : `/admin/produtos/${pid(ctx)}`), () => app.catalog.duplicate(pid(ctx), ctx.staff.id), 'Cópia criada como rascunho. Adicione as fotos e publique.'), h.S('products.edit'));
  router.post('/admin/produtos/:id/excluir', (ctx) => h.act(ctx, (ok) => (ok ? '/admin/produtos' : `/admin/produtos/${pid(ctx)}`), () => { app.catalog.deleteProduct(pid(ctx)); app.audit.staff(ctx, 'product.deleted', 'product', pid(ctx)); return true; }, 'Produto excluído.'), h.S('products.delete'));
  router.post('/admin/produtos/:id/vendida-fora', (ctx) => h.act(ctx, `/admin/produtos/${pid(ctx)}`, () => { app.stock.markSoldOffline(pid(ctx), ctx.staff.id); app.audit.staff(ctx, 'stock.sold_offline', 'product', pid(ctx)); }, 'Estoque zerado: peça marcada como vendida fora do site.'), h.S('stock.manage'));

  // fotos
  router.post('/admin/produtos/:id/imagens', (ctx) => {
    const { saveImage, removeImage } = require('../../lib/images');
    const id = pid(ctx);
    if (!app.catalog.byId(id)) return ctx.json({ ok: false, error: 'Produto não encontrado.' }, 404);
    let filename;
    try {
      filename = saveImage(cfg.uploadDir, ctx.rawBody);
      app.catalog.addImage(id, filename, decodeURIComponent(ctx.req.headers['x-alt'] || ''));
      app.audit.staff(ctx, 'product.image_added', 'product', id);
      ctx.json({ ok: true });
    } catch (e) {
      if (filename) removeImage(cfg.uploadDir, filename);
      ctx.json({ ok: false, error: e.message }, 422);
    }
  }, h.S('products.edit', { limit: 9 * 1024 * 1024 }));
  router.post('/admin/produtos/:id/imagens/:img/principal', (ctx) => h.act(ctx, `/admin/produtos/${pid(ctx)}`, () => app.catalog.setPrimaryImage(pid(ctx), int(ctx.params.img)), 'Foto principal atualizada.'), h.S('products.edit'));
  router.post('/admin/produtos/:id/imagens/:img/mover', (ctx) => h.act(ctx, `/admin/produtos/${pid(ctx)}`, () => app.catalog.moveImage(pid(ctx), int(ctx.params.img), ctx.body.dir === 'up' ? 'up' : 'down')), h.S('products.edit'));
  router.post('/admin/produtos/:id/imagens/:img/excluir', (ctx) => h.act(ctx, `/admin/produtos/${pid(ctx)}`, () => app.catalog.deleteImage(pid(ctx), int(ctx.params.img)), 'Foto excluída.'), h.S('products.edit'));

  // ───── categorias ─────
  router.get('/admin/categorias', (ctx) => {
    const tree = app.catalog.categoryTree(true);
    const editing = ctx.query.editar ? app.catalog.categoryById(int(ctx.query.editar)) : null;
    const used = (id) => app.db.value('SELECT COUNT(*) FROM products WHERE category_id = ?', id);
    const row = (c, depth) => html`<tr><td>${depth ? raw('&nbsp;&nbsp;&nbsp;↳ ') : ''}<strong>${c.name}</strong>${c.active ? '' : html` ${badge('Inativa', 'warn')}`}</td><td>${c.slug}</td><td class="r">${used(c.id)}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/categorias?editar=${c.id}">Editar</a> <form method="post" action="/admin/categorias/${c.id}/excluir" class="inline" data-confirm="Excluir a categoria “${c.name}”?">${csrfField(ctx)}<button class="linklike danger" type="submit">Excluir</button></form></td></tr>`;
    const rows = tree.flatMap((c) => [row(c, 0), ...c.children.map((s) => row(s, 1))]);
    h.page(ctx, 'Categorias', html`
<div class="cols"><section class="card">${L.table(['Categoria', 'Endereço', { label: 'Produtos', right: true }, ''], rows, { empty: 'Nenhuma categoria. Crie a primeira ao lado.' })}</section>
<section class="card"><h2>${editing ? 'Editar categoria' : 'Nova categoria'}</h2>
<form method="post" action="/admin/categorias${editing ? `/${editing.id}` : ''}">${csrfField(ctx)}
${field({ label: 'Nome', name: 'name', value: editing?.name, required: true, maxlength: 80 })}
${selectField({ label: 'Categoria-mãe', name: 'parent_id', value: editing?.parent_id || '', options: tree.filter((c) => c.id !== editing?.id).map((c) => ({ value: c.id, label: c.name })), blank: 'Nenhuma (categoria principal)', hint: 'Subcategorias têm apenas um nível.' })}
${field({ label: 'Descrição', name: 'description', value: editing?.description, maxlength: 400 })}
<div class="grid2">${field({ label: 'Ordem', name: 'sort_order', type: 'number', value: editing?.sort_order ?? 0 })}<div class="field"><label>Situação</label><label class="check"><input type="checkbox" name="active" value="1" ${!editing || editing.active ? raw('checked') : ''}> Ativa (aparece na loja)</label></div></div>
<div class="field"><label>Imagem <span class="opt">(opcional)</span></label>${editing?.image ? html`<img src="${imgUrl(editing.image)}" alt="" class="mini-preview">` : ''}<div class="uploader" data-uploader data-endpoint="/admin/uploads" data-target="#cat_image"><label class="btn btn-ghost btn-small" for="upc">Escolher imagem</label><input id="upc" type="file" accept="image/jpeg,image/png,image/webp" hidden><span class="muted small" data-status role="status"></span></div><input type="hidden" name="image" id="cat_image" value=""></div>
<button class="btn" type="submit">${editing ? 'Salvar' : 'Criar categoria'}</button> ${editing ? html`<a class="btn btn-ghost" href="/admin/categorias">Cancelar</a>` : ''}</form></section></div>`);
  }, h.S('categories.manage'));
  const catSave = (ctx, id) => h.act(ctx, '/admin/categorias', () => { const r = app.catalog.saveCategory({ id, name: ctx.body.name, parent_id: ctx.body.parent_id, description: ctx.body.description, sort_order: ctx.body.sort_order, active: !!ctx.body.active, image: ctx.body.image || null }); app.audit.staff(ctx, id ? 'category.updated' : 'category.created', 'category', r, { name: ctx.body.name }); }, 'Categoria salva.');
  router.post('/admin/categorias', (ctx) => catSave(ctx, null), h.S('categories.manage'));
  router.post('/admin/categorias/:id', (ctx) => catSave(ctx, int(ctx.params.id)), h.S('categories.manage'));
  router.post('/admin/categorias/:id/excluir', (ctx) => h.act(ctx, '/admin/categorias', () => { app.catalog.deleteCategory(int(ctx.params.id)); app.audit.staff(ctx, 'category.deleted', 'category', ctx.params.id); }, 'Categoria excluída.'), h.S('categories.manage'));

  // ───── estoque ─────
  const REASONS = { compra: 'Compra / nova peça', ajuste: 'Ajuste de inventário', perda: 'Perda ou dano', venda_fisica: 'Venda na loja física', devolucao: 'Devolução', outro: 'Outro' };
  router.get('/admin/estoque', (ctx) => {
    const filter = ctx.query.f || 'low';
    const r = app.catalog.adminList({ q: ctx.query.q, stock: filter === 'low' ? 'low' : filter === 'sold' ? 'sold' : filter === 'available' ? 'available' : '', page: ctx.query.page, perPage: 25 });
    const c = app.catalog.counts();
    const low = app.stock.lowStock();
    h.page(ctx, 'Estoque', html`
<div class="kpis">${L.kpi('À venda', String(c.available))}${L.kpi('Vendidas / zeradas', String(c.sold))}${L.kpi('Estoque baixo', String(c.low), '', c.low ? 'warn' : '')}${L.kpi('Reservadas agora', String(app.db.value("SELECT COALESCE(SUM(qty),0) FROM stock_reservations WHERE status = 'active' AND expires_at > ?", new Date().toISOString())), 'aguardando pagamento')}</div>
<section class="card"><form class="filters" method="get" action="/admin/estoque"><div class="field"><label for="q">Buscar</label><input id="q" name="q" value="${ctx.query.q || ''}" type="search" placeholder="Nome ou SKU"></div>${selectField({ label: 'Mostrar', name: 'f', value: filter, options: [{ value: 'low', label: 'Estoque baixo' }, { value: 'sold', label: 'Zerados / vendidos' }, { value: 'available', label: 'Disponíveis' }, { value: 'all', label: 'Todos' }], blank: null })}<div class="field"><label>&nbsp;</label><button class="btn" type="submit">Filtrar</button></div></form>
${filter === 'low' && !low.length ? html`<p class="empty-note">Nenhuma peça abaixo do limite de alerta. Defina “Avisar quando restar até” no cadastro do produto.</p>` : L.table(['Produto', { label: 'Em estoque', right: true }, { label: 'Reservado', right: true }, 'Registrar movimentação'], r.items.map((p) => html`<tr><td><a href="/admin/estoque/${p.id}"><strong>${p.name}</strong></a><br><small class="muted">${p.sku}</small></td><td class="r">${p.quantity}</td><td class="r">${p.quantity - p.available}</td><td>${h.can(ctx, 'stock.manage') ? html`<form method="post" action="/admin/estoque/${p.id}" class="inline-form-row">${csrfField(ctx)}<select name="mode" aria-label="Tipo"><option value="in">Entrada (+)</option><option value="out">Saída (−)</option><option value="set">Definir para</option></select><input name="qty" type="number" min="0" value="1" aria-label="Quantidade"><select name="reason" aria-label="Motivo">${Object.entries(REASONS).map(([k, l]) => html`<option value="${k}">${l}</option>`)}</select><input name="note" placeholder="Observação" aria-label="Observação" maxlength="200"><button class="btn btn-small" type="submit">Registrar</button></form>` : ''}</td></tr>`), { empty: 'Nenhum produto neste filtro.' })}
${pager(r, (n) => `/admin/estoque${qs({ q: ctx.query.q, f: filter }, { page: n })}`)}</section>
<p><a href="/admin/estoque/movimentacoes">Ver todas as movimentações</a> · <a href="/admin/estoque/movimentacoes.csv">Exportar CSV</a></p>`);
  }, h.S('stock.view'));
  router.post('/admin/estoque/:id', (ctx) => h.act(ctx, ctx.req.headers.referer ? new URL(ctx.req.headers.referer).pathname + new URL(ctx.req.headers.referer).search : '/admin/estoque', () => {
    const id = int(ctx.params.id); const q = int(ctx.body.qty, NaN);
    if (!Number.isInteger(q) || q < 0) throw new UserError('Informe uma quantidade válida.');
    const reason = REASONS[ctx.body.reason] ? ctx.body.reason : 'ajuste';
    const opts = { reason, note: String(ctx.body.note || '').slice(0, 200) || REASONS[reason], staffId: ctx.staff.id };
    if (ctx.body.mode === 'set') app.stock.adjustTo(id, q, opts);
    else app.stock.change(id, ctx.body.mode === 'out' ? -q : q, opts);
    app.audit.staff(ctx, 'stock.changed', 'product', id, { mode: ctx.body.mode, qty: q, reason });
  }, 'Movimentação registrada.'), h.S('stock.manage'));
  router.get('/admin/estoque/movimentacoes', (ctx) => {
    const rows = app.stock.recentMovements({ limit: 300, reason: ctx.query.motivo || '' });
    h.page(ctx, 'Movimentações de estoque', html`<section class="card">${L.table(['Data', 'Produto', { label: 'Variação', right: true }, { label: 'Saldo', right: true }, 'Motivo', 'Pedido', 'Responsável', 'Obs.'], rows.map((m) => html`<tr><td>${h.ago(m.created_at)}</td><td><a href="/admin/estoque/${m.product_id}">${m.product_name}</a><br><small class="muted">${m.sku}</small></td><td class="r ${m.delta > 0 ? 'pos' : 'neg'}">${m.delta > 0 ? '+' : ''}${m.delta}</td><td class="r">${m.balance_after}</td><td>${m.reason}</td><td>${m.order_number ? html`<a href="/admin/pedidos?q=${m.order_number}">${m.order_number}</a>` : '—'}</td><td>${m.staff_name || 'sistema'}</td><td class="small">${m.note || ''}</td></tr>`), { empty: 'Sem movimentações.' })}</section><p><a href="/admin/estoque/movimentacoes.csv">Exportar CSV</a></p>`);
  }, h.S('stock.view'));
  router.get('/admin/estoque/movimentacoes.csv', (ctx) => { app.audit.staff(ctx, 'export.stock', 'report', 'stock'); ctx.download('movimentacoes-estoque.csv', 'text/csv; charset=utf-8', app.reports.csvStock()); }, h.S('stock.view'));
  router.get('/admin/estoque/:id', (ctx) => {
    const p = app.catalog.byId(int(ctx.params.id));
    if (!p) return ctx.fail(404, 'Produto não encontrado.');
    const rows = app.stock.movements(p.id, 200);
    h.page(ctx, `Estoque: ${p.name}`, html`<section class="card"><p>Em estoque: <strong>${p.quantity}</strong> · Reservado: <strong>${p.quantity - p.available}</strong> · Disponível para venda: <strong>${p.available}</strong> · <a href="/admin/produtos/${p.id}">Abrir produto</a></p>${L.table(['Data', { label: 'Variação', right: true }, { label: 'Saldo', right: true }, 'Motivo', 'Pedido', 'Responsável', 'Obs.'], rows.map((m) => html`<tr><td>${h.ago(m.created_at)}</td><td class="r ${m.delta > 0 ? 'pos' : 'neg'}">${m.delta > 0 ? '+' : ''}${m.delta}</td><td class="r">${m.balance_after}</td><td>${m.reason}</td><td>${m.order_number || '—'}</td><td>${m.staff_name || 'sistema'}</td><td class="small">${m.note || ''}</td></tr>`), { empty: 'Sem movimentações.' })}</section>`);
  }, h.S('stock.view'));

  void formatDate;
}

module.exports = { register };
