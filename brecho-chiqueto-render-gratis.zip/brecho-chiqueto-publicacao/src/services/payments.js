'use strict';
/**
 * Pagamentos Pix.
 * Regras de ouro:
 *  1. Um pedido só vira "pago" depois que o PROVEDOR confirma (consulta autenticada à API do provedor),
 *     com o mesmo número de pedido, o mesmo valor em BRL e a cobrança que nós criamos.
 *  2. O webhook só "avisa": ele é autenticado, deduplicado pelo id do evento e, mesmo assim, o estado real
 *     vem de getPayment(). Reprocessar o mesmo evento (ou outro evento do mesmo pagamento) não faz nada.
 *  3. Redirecionamentos do navegador e comprovantes enviados pelo cliente nunca confirmam pagamento.
 *  4. Baixa de estoque, mudança de status e registro financeiro acontecem numa única transação.
 */
const { now, addMinutes, trunc, UserError, int } = require('../lib/util');
const { ProviderError } = require('../providers/payment/common');

function makePayments(app) {
  const { db, cfg, audit } = app;
  const lastPoll = new Map();
  const refunding = new Set();

  const provider = () => app.providers.active;
  const providerFor = (name) => app.providers.get(name);

  const payments = {
    provider,

    byId: (id) => db.get('SELECT * FROM payments WHERE id = ?', id),
    forOrder: (orderId) => db.all('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC', orderId),
    openPayment: (orderId) => db.get("SELECT * FROM payments WHERE order_id = ? AND status = 'pending'", orderId),
    latest: (orderId) => db.get('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1', orderId),
    refunds: (orderId) => db.all('SELECT r.*, s.name AS staff_name FROM refunds r LEFT JOIN staff_users s ON s.id = r.staff_id WHERE r.order_id = ? ORDER BY r.id DESC', orderId),

    status() {
      const p = provider();
      return { name: p.name, label: p.label, configured: p.configured(), webhookReady: p.webhookReady ? p.webhookReady() : false, sandbox: !!p.sandbox, missing: p.missing(), requiresCpf: !!p.requiresCpf };
    },

    /** Gera (ou reaproveita) a cobrança Pix do pedido. */
    async createPixForOrder(order) {
      const p = provider();
      if (!p.configured()) throw new UserError('Os pagamentos ainda não estão ativos nesta loja.');
      const open = this.openPayment(order.id);
      if (open && open.expires_at > now()) return open;
      const attempt = db.value('SELECT COUNT(*) FROM payments WHERE order_id = ?', order.id) + 1;
      const buyer = { name: order.customer_name, email: order.customer_email, phone: order.customer_phone, cpf: app.cipher.decrypt(order.customer_cpf_enc) };
      let charge;
      try {
        charge = await p.createPixCharge({ order, buyer, expiresAt: order.expires_at, attempt });
      } catch (e) {
        if (e instanceof ProviderError) {
          console.error(`[pagamentos] ${p.name} recusou a criação do Pix do pedido ${order.number}: ${e.detail || e.message}`);
          audit.system('payment.create_failed', 'order', order.id, { provider: p.name, detail: e.detail, status: e.status });
          throw new UserError(e.status >= 400 && e.status < 500 && e.detail?.toLowerCase().includes('cpf') ? 'O provedor não aceitou o CPF informado. Confira e tente novamente.' : 'Não foi possível gerar o Pix agora. Tente novamente em instantes.');
        }
        throw e;
      }
      try {
        const t = now();
        const id = db.run(
          'INSERT INTO payments (order_id, provider, provider_payment_id, method, amount_cents, status, pix_payload, pix_qr_base64, expires_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
          order.id, p.name, charge.providerId, 'pix', order.total_cents, 'pending', charge.pixPayload, charge.qrImage, order.expires_at, t, t
        ).id;
        db.run('INSERT INTO order_history (order_id, from_status, to_status, note, actor, created_at) VALUES (?,?,?,?,?,?)', order.id, order.status, order.status, `Cobrança Pix gerada (${p.label})`, 'sistema', t);
        audit.system('payment.created', 'payment', id, { order: order.number, provider: p.name, amount: order.total_cents });
        return this.byId(id);
      } catch (e) {
        // Perdeu a corrida (já existe cobrança aberta) ou falha de banco: não deixa cobrança órfã no provedor.
        await p.cancelCharge(charge.providerId).catch(() => {});
        throw e;
      }
    },

    /** Reabre um pedido cujo Pix expirou (se as peças ainda estiverem disponíveis) e gera nova cobrança. */
    async reopenExpired(order) {
      if (!(order.status === 'cancelled' && order.payment_status === 'expired')) throw new UserError('Este pedido não pode gerar um novo Pix.');
      if (order.created_at < addMinutes(now(), -60 * 24 * 7)) throw new UserError('Este pedido é antigo demais. Faça um novo pedido.');
      const fresh = db.tx(() => {
        const o = app.orders.get(order.id);
        if (o.status !== 'cancelled' || o.payment_status !== 'expired') throw new UserError('Este pedido já foi atualizado.');
        const t = now();
        const expiresAt = addMinutes(t, app.orders.pixMinutes());
        const items = db.all('SELECT * FROM order_items WHERE order_id = ?', o.id).map((i) => ({ product_id: i.product_id, qty: i.qty, name: i.name }));
        db.run("UPDATE stock_reservations SET status = 'released' WHERE order_id = ?", o.id);
        db.run('DELETE FROM stock_reservations WHERE order_id = ?', o.id);
        app.stock.reserve(o.id, items, addMinutes(expiresAt, app.orders.graceMinutes()));
        if (o.coupon_id) {
          try { app.coupons.redeem(o.coupon_id); } catch { throw new UserError('O cupom deste pedido não está mais disponível. Faça um novo pedido.'); }
        }
        db.run("UPDATE orders SET status = 'awaiting_payment', payment_status = 'pending', cancelled_at = NULL, expires_at = ? WHERE id = ?", expiresAt, o.id);
        app.orders.addHistory(o.id, 'cancelled', 'awaiting_payment', 'Cliente pediu novo Pix', 'cliente');
        return app.orders.get(o.id);
      });
      try {
        await this.createPixForOrder(fresh);
      } catch (e) {
        await app.orders.cancelUnpaid(fresh.id, { actor: 'sistema', reason: 'Falha ao gerar novo Pix', silent: true }).catch(() => {});
        throw e;
      }
      return app.orders.get(order.id);
    },

    async cancelAtProvider(payment) {
      const p = providerFor(payment.provider);
      if (!p || !payment.provider_payment_id || !p.cancelCharge) return;
      try {
        await p.cancelCharge(payment.provider_payment_id);
      } catch (e) {
        console.error(`[pagamentos] não foi possível cancelar a cobrança ${payment.provider_payment_id}: ${e.detail || e.message}`);
      }
    },

    // ───── confirmação ─────
    /** Consulta o provedor e aplica o estado. Nunca lança por erro de rede (retorna outcome 'provider_error'). */
    async refreshFromProvider(paymentId, source = 'poll') {
      const pay = this.byId(paymentId);
      if (!pay || !pay.provider_payment_id) return { outcome: 'unknown_payment' };
      const p = providerFor(pay.provider);
      if (!p || !p.configured()) return { outcome: 'provider_unavailable' };
      let snap;
      try {
        snap = await p.getPayment(pay.provider_payment_id);
      } catch (e) {
        if (e instanceof ProviderError) return { outcome: 'provider_error', error: e.detail || e.message };
        throw e;
      }
      return this.applySnapshot(pay.id, snap, source);
    },

    /**
     * Aplica o retrato do pagamento retornado pelo provedor. Idempotente e transacional.
     * Retorna { outcome }: paid | already_paid | pending | mismatch | refunded | expired | ignored
     */
    applySnapshot(paymentId, snap, source) {
      const after = [];
      let outcome = 'ignored';
      db.tx(() => {
        const pay = this.byId(paymentId);
        const order = app.orders.get(pay.order_id);
        if (snap.reference && snap.reference !== order.number) {
          outcome = 'mismatch';
          return this.mismatch(order, pay, `referência ${snap.reference} diferente do pedido`, after);
        }
        if (snap.amountCents !== pay.amount_cents || pay.amount_cents !== order.total_cents) {
          outcome = 'mismatch';
          return this.mismatch(order, pay, `valor do provedor (${snap.amountCents}) diferente do pedido (${order.total_cents})`, after);
        }
        if (snap.currency && snap.currency !== 'BRL') {
          outcome = 'mismatch';
          return this.mismatch(order, pay, `moeda ${snap.currency}`, after);
        }
        const t = now();
        if (snap.status === 'paid') {
          if (['paid', 'partially_refunded', 'refunded'].includes(pay.status)) {
            // atualiza dados financeiros que podem chegar depois (taxa, liquidação) sem repetir efeitos colaterais
            db.run('UPDATE payments SET fee_cents = COALESCE(?, fee_cents), net_cents = COALESCE(?, net_cents), settlement_date = COALESCE(?, settlement_date), updated_at = ? WHERE id = ?', snap.feeCents ?? null, snap.netCents ?? null, snap.settlementDate ?? null, t, pay.id);
            outcome = 'already_paid';
            return;
          }
          outcome = 'paid';
          const late = order.status !== 'awaiting_payment';
          if (order.status !== 'awaiting_payment' && order.status !== 'cancelled') { outcome = 'already_paid'; return; }
          db.run("UPDATE payments SET status = 'paid', paid_at = ?, fee_cents = ?, net_cents = ?, settlement_date = ?, updated_at = ? WHERE id = ?", snap.paidAt ? new Date(snap.paidAt).toISOString() : t, snap.feeCents ?? null, snap.netCents ?? null, snap.settlementDate ?? null, t, pay.id);
          const res = app.stock.consume(order.id);
          db.run("UPDATE orders SET status = 'paid', payment_status = 'paid', paid_at = ?, cancelled_at = NULL WHERE id = ?", t, order.id);
          // O cancelamento devolveu o uso do cupom; como o pedido (com desconto) foi pago mesmo assim, o uso volta a contar.
          if (order.status === 'cancelled' && order.coupon_id) db.run('UPDATE coupons SET used_count = used_count + 1 WHERE id = ?', order.coupon_id);
          app.orders.addHistory(order.id, order.status, 'paid', late ? `Pagamento confirmado pelo provedor após o prazo (${source})` : `Pagamento confirmado pelo provedor (${source})`, 'sistema');
          audit.system('payment.confirmed', 'payment', pay.id, { order: order.number, provider: pay.provider, source, late, amount: pay.amount_cents });
          const fresh = app.orders.get(order.id);
          if (!res.ok) {
            const names = res.conflicts.map((c) => c.name).join(', ');
            app.orders.flagAttention(order.id, `Pagamento recebido, mas a(s) peça(s) não está(ão) mais disponível(is): ${names}. Reembolse o cliente ou combine uma troca.`);
            after.push(() => app.email.notifyAdmin({ kind: 'attention', title: `Atenção: pedido ${order.number} pago com peça indisponível`, body: `Peças: ${names}. Reembolse ou resolva com a cliente.`, link: `/admin/pedidos/${order.id}` }));
          } else {
            after.push(() => app.email.notifyAdmin({ kind: 'order_paid', title: `Pagamento confirmado — pedido ${order.number}`, body: `${order.customer_name} pagou ${app.fmt.money(order.total_cents)}.`, link: `/admin/pedidos/${order.id}` }));
          }
          after.push(() => app.email.queue('payment_approved', fresh.customer_email, { name: fresh.customer_name, order: fresh }));
          if (fresh.marketing_consent === 0) { /* sem ação */ }
          return;
        }
        if (snap.status === 'refunded') {
          if (pay.status === 'refunded') { outcome = 'already_paid'; return; }
          if (!['paid', 'partially_refunded'].includes(pay.status)) { outcome = 'ignored'; return; }
          // reembolso feito direto no painel do provedor
          const remaining = pay.amount_cents - pay.refunded_cents;
          if (remaining > 0) db.run('INSERT INTO refunds (payment_id, order_id, amount_cents, reason, status, created_at) VALUES (?,?,?,?,?,?)', pay.id, order.id, remaining, 'Reembolso feito diretamente no provedor', 'done', t);
          db.run("UPDATE payments SET status = 'refunded', refunded_cents = amount_cents, updated_at = ? WHERE id = ?", t, pay.id);
          db.run("UPDATE orders SET status = 'refunded', payment_status = 'refunded' WHERE id = ?", order.id);
          app.orders.addHistory(order.id, order.status, 'refunded', 'Reembolso registrado pelo provedor', 'sistema');
          audit.system('payment.refunded_external', 'payment', pay.id, { order: order.number });
          outcome = 'refunded';
          const fresh = app.orders.get(order.id);
          after.push(() => app.email.notifyAdmin({ kind: 'refund', title: `Reembolso no provedor — pedido ${order.number}`, body: 'Reembolso feito direto no painel do provedor. Confira o estoque da peça.', link: `/admin/pedidos/${order.id}` }));
          after.push(() => app.email.queue('order_refunded', fresh.customer_email, { name: fresh.customer_name, order: fresh }));
          return;
        }
        if (snap.status === 'cancelled' || snap.status === 'failed') {
          if (pay.status === 'pending') {
            db.run("UPDATE payments SET status = ?, updated_at = ? WHERE id = ?", snap.status === 'failed' ? 'failed' : 'cancelled', t, pay.id);
            outcome = 'expired';
          }
          return;
        }
        outcome = 'pending';
      });
      for (const f of after) {
        try { f(); } catch (e) { console.error('[pagamentos] pós-processamento:', e.message); }
      }
      // Se o provedor informou cancelamento/expiração de um Pix pendente, encerra também o pedido.
      if (outcome === 'expired') {
        const o = app.orders.get(db.get('SELECT order_id FROM payments WHERE id = ?', paymentId).order_id);
        if (o.status === 'awaiting_payment') app.orders.cancelUnpaid(o.id, { actor: 'sistema', reason: 'Cobrança encerrada pelo provedor', expired: true }).catch(() => {});
      }
      return { outcome };
    },

    mismatch(order, pay, why, after) {
      app.orders.flagAttention(order.id, `Divergência na confirmação do provedor: ${why}. Nada foi marcado como pago.`);
      audit.system('payment.mismatch', 'payment', pay.id, { order: order.number, why });
      after.push(() => app.email.notifyAdmin({ kind: 'attention', title: `Divergência de pagamento — pedido ${order.number}`, body: why, link: `/admin/pedidos/${order.id}` }));
    },

    // ───── webhooks ─────
    /**
     * Recebe um webhook. Retorna { status, body } para a rota responder.
     * 200 = recebido (inclui duplicados); 401 = assinatura/token inválido; 500 = falha ao processar (provedor reenvia).
     */
    async handleWebhook(name, { headers, rawBody, query, body, ip }) {
      const p = providerFor(name);
      if (!p || name === 'none' || (name === 'mock' && cfg.isProd)) return { status: 404, body: { ok: false } };
      if (!p.configured()) return { status: 503, body: { ok: false, error: 'provedor não configurado' } };
      const v = p.verifyWebhook(headers, rawBody.toString('utf8'), query);
      if (!v.ok) {
        audit.log({ type: 'webhook', label: name }, 'webhook.rejected', 'webhook', name, { reason: v.reason }, ip);
        return { status: 401, body: { ok: false, error: 'não autorizado' } };
      }
      const events = p.parseWebhook(body, query);
      let processed = 0, duplicates = 0, failed = 0;
      for (const ev of events) {
        const t = now();
        let row = db.get('SELECT * FROM payment_events WHERE provider = ? AND event_id = ?', name, ev.eventId);
        if (row && (row.status === 'done' || row.status === 'ignored')) { duplicates++; continue; }
        if (row && row.status === 'processing' && addMinutes(row.received_at, 2) > t) { duplicates++; continue; }
        try {
          if (!row) db.run('INSERT INTO payment_events (provider, event_id, event_type, provider_payment_id, payload, status, received_at) VALUES (?,?,?,?,?,?,?)', name, ev.eventId, ev.type, ev.providerPaymentId, rawBody.toString('utf8').slice(0, 4000), 'processing', t);
          else db.run("UPDATE payment_events SET status = 'processing', received_at = ?, error = NULL WHERE id = ?", t, row.id);
        } catch (e) {
          if (/UNIQUE/i.test(e.message)) { duplicates++; continue; } // outra entrega simultânea do mesmo evento
          throw e;
        }
        try {
          const pay = db.get('SELECT id FROM payments WHERE provider = ? AND provider_payment_id = ?', name, ev.providerPaymentId);
          let result = { outcome: 'unknown_payment' };
          if (pay) result = await this.refreshFromProvider(pay.id, `webhook ${ev.type}`);
          if (result.outcome === 'provider_error') throw new Error(result.error || 'erro do provedor');
          db.run("UPDATE payment_events SET status = ?, processed_at = ?, error = NULL WHERE provider = ? AND event_id = ?", result.outcome === 'unknown_payment' ? 'ignored' : 'done', now(), name, ev.eventId);
          processed++;
        } catch (e) {
          failed++;
          db.run("UPDATE payment_events SET status = 'failed', error = ?, processed_at = ? WHERE provider = ? AND event_id = ?", String(e.message).slice(0, 300), now(), name, ev.eventId);
        }
      }
      if (failed) return { status: 500, body: { ok: false, processed, duplicates, failed } };
      return { status: 200, body: { ok: true, processed, duplicates } };
    },

    // ───── reembolso ─────
    async refund(orderId, { amountCents, reason = '', restock = false, ctx }) {
      const order = app.orders.get(orderId);
      if (!order) throw new UserError('Pedido não encontrado.');
      const pay = db.get("SELECT * FROM payments WHERE order_id = ? AND status IN ('paid','partially_refunded') ORDER BY id DESC", orderId);
      if (!pay) throw new UserError('Este pedido não tem pagamento confirmado para reembolsar.');
      if (refunding.has(pay.id)) throw new UserError('Já existe um reembolso em andamento para este pagamento.');
      const remaining = pay.amount_cents - pay.refunded_cents;
      const amount = amountCents ?? remaining;
      if (!Number.isInteger(amount) || amount <= 0 || amount > remaining) throw new UserError(`Informe um valor entre R$ 0,01 e ${app.fmt.money(remaining)}.`);
      const p = providerFor(pay.provider);
      if (!p || !p.configured()) throw new UserError('O provedor de pagamentos não está configurado.');
      refunding.add(pay.id);
      try {
        let r;
        try {
          r = await p.refund(pay.provider_payment_id, amount, trunc(reason, 100));
        } catch (e) {
          if (e instanceof ProviderError) {
            console.error(`[pagamentos] reembolso recusado (${pay.provider_payment_id}): ${e.detail || e.message}`);
            throw new UserError(`O provedor recusou o reembolso${e.detail ? `: ${trunc(e.detail, 160)}` : '.'}`);
          }
          throw e;
        }
        const full = amount === remaining;
        db.tx(() => {
          const t = now();
          db.run('INSERT INTO refunds (payment_id, order_id, amount_cents, reason, provider_refund_id, status, restocked, staff_id, created_at) VALUES (?,?,?,?,?,?,?,?,?)', pay.id, order.id, amount, trunc(reason, 200) || null, r.providerRefundId, 'done', full && restock ? 1 : 0, ctx?.staff?.id ?? null, t);
          db.run('UPDATE payments SET refunded_cents = refunded_cents + ?, status = ?, updated_at = ? WHERE id = ?', amount, full ? 'refunded' : 'partially_refunded', t, pay.id);
          if (full) {
            db.run("UPDATE orders SET status = 'refunded', payment_status = 'refunded', needs_attention = 0, attention_note = NULL WHERE id = ?", order.id);
            if (restock) app.stock.restock(order.id, ctx?.staff?.id ?? null);
          } else {
            db.run("UPDATE orders SET payment_status = 'partially_refunded' WHERE id = ?", order.id);
          }
          app.orders.addHistory(order.id, order.status, full ? 'refunded' : order.status, `${full ? 'Reembolso total' : 'Reembolso parcial'} de ${app.fmt.money(amount)}${reason ? `: ${trunc(reason, 100)}` : ''}`, ctx?.staff?.name || 'sistema');
        });
        if (ctx) audit.staff(ctx, 'payment.refunded', 'order', order.id, { amount, full, restock });
        const fresh = app.orders.get(order.id);
        app.email.queue('order_refunded', fresh.customer_email, { name: fresh.customer_name, order: fresh, note: `Valor reembolsado: ${app.fmt.money(amount)}.` });
        return { full, amount };
      } finally {
        refunding.delete(pay.id);
      }
    },

    // ───── rotinas em segundo plano ─────
    /** Expira Pix vencidos: antes de encerrar, confirma com o provedor que não foi pago. */
    async expireStale() {
      let n = 0;
      const due = db.all("SELECT * FROM payments WHERE status = 'pending' AND expires_at <= ? LIMIT 50", now());
      for (const pay of due) {
        try {
          const r = await this.refreshFromProvider(pay.id, 'expiração');
          if (r.outcome === 'paid') continue;
          if (r.outcome === 'provider_error') continue; // tenta de novo na próxima rodada, sem arriscar cancelar um Pix pago
          const o = app.orders.get(pay.order_id);
          if (o.status === 'awaiting_payment') {
            await app.orders.cancelUnpaid(o.id, { actor: 'sistema', reason: 'Pix expirou sem pagamento', expired: true });
            n++;
          } else {
            db.run("UPDATE payments SET status = 'expired', updated_at = ? WHERE id = ? AND status = 'pending'", now(), pay.id);
          }
        } catch (e) {
          console.error('[pagamentos] expiração:', e.message);
        }
      }
      // pedidos "aguardando" sem cobrança (falha na criação) há mais de 15 minutos
      const orphans = db.all("SELECT id FROM orders WHERE status = 'awaiting_payment' AND created_at < ? AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.order_id = orders.id)", addMinutes(now(), -15));
      for (const o of orphans) await app.orders.cancelUnpaid(o.id, { actor: 'sistema', reason: 'Pedido sem cobrança', expired: true, silent: true }).catch(() => {});
      return n;
    },

    /** Rede de segurança caso o webhook falhe: consulta o provedor pelos Pix pendentes recentes. */
    async pollPending({ minIntervalMs = 25000 } = {}) {
      const rows = db.all("SELECT id FROM payments WHERE status = 'pending' AND provider_payment_id IS NOT NULL AND created_at > ? ORDER BY id DESC LIMIT 40", addMinutes(now(), -60 * 48));
      for (const r of rows) {
        if (Date.now() - (lastPoll.get(r.id) || 0) < minIntervalMs) continue;
        lastPoll.set(r.id, Date.now());
        await this.refreshFromProvider(r.id, 'consulta periódica');
      }
      if (lastPoll.size > 500) lastPoll.clear();
    },

    /** Chamada pela página do pedido: confere no provedor no máximo a cada ~8 s por pagamento. */
    async checkNow(order) {
      const pay = this.openPayment(order.id);
      if (!pay || Date.now() - (lastPoll.get(pay.id) || 0) < 8000) return;
      lastPoll.set(pay.id, Date.now());
      await this.refreshFromProvider(pay.id, 'verificação da página');
    },

    /** Conciliação manual: reconsulta o provedor para todos os pagamentos pendentes. */
    async reconcile() {
      const rows = db.all("SELECT id FROM payments WHERE status = 'pending' AND provider_payment_id IS NOT NULL");
      const out = { checked: rows.length, paid: 0 };
      for (const r of rows) {
        const x = await this.refreshFromProvider(r.id, 'conciliação manual');
        if (x.outcome === 'paid') out.paid++;
      }
      return out;
    },
  };
  return payments;
}

module.exports = { makePayments };
