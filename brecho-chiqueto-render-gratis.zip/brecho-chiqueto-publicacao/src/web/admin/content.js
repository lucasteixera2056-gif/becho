'use strict';
/** Painel: banners e páginas de texto (inclui os textos legais, que são modelos a revisar). */
const { html, raw, richText } = require('../../lib/html');
const { int, UserError } = require('../../lib/util');
const { icon, csrfField, field, selectField, imgUrl, badge } = require('../ui');

function register(router, app, h) {
  const { L } = h;
  const { cfg } = app;
  const PLACEMENT = { hero: 'Destaque principal (topo do início)', news: 'Faixa de avisos (início)' };
  const bid = (ctx) => int(ctx.params.id);
  // O painel grava datas em horário de Brasília; aqui volta para AAAA-MM-DD (o fim é "exclusivo": subtrai um dia).
  const toDate = (iso, end) => (iso ? new Date(new Date(iso).getTime() + cfg.tzOffsetMinutes * 60000 - (end ? 86400000 : 0)).toISOString().slice(0, 10) : '');

  // ───── banners ─────
  const bannerState = (b) => {
    const t = new Date().toISOString();
    if (!b.active) return badge('Desativado', 'neutral');
    if (b.ends_at && b.ends_at <= t) return badge('Encerrado', 'bad');
    if (b.starts_at && b.starts_at > t) return badge('Agendado', 'warn');
    return badge('No ar', 'good');
  };

  router.get('/admin/banners', (ctx) => {
    const list = app.content.banners.list();
    h.page(ctx, 'Banners', html`<section class="card">
<p class="muted small">Sem banners cadastrados, o início mostra o título e o texto de “Configurações → Início”. O primeiro banner de destaque ativo substitui esse texto.</p>
${L.table(['', 'Banner', 'Onde aparece', 'Ordem', 'Situação', ''], list.map((b) => html`<tr><td class="thumb-cell">${b.image ? html`<img src="${imgUrl(b.image)}" alt="" width="64" height="40" loading="lazy">` : ''}</td><td><strong>${b.title}</strong>${b.subtitle ? html`<br><small class="muted">${b.subtitle}</small>` : ''}</td><td>${PLACEMENT[b.placement]}</td><td>${b.sort_order}</td><td>${bannerState(b)}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/banners/${b.id}">Editar</a></td></tr>`), { empty: 'Nenhum banner cadastrado.' })}</section>`, { actions: html`<a class="btn" href="/admin/banners/novo">${icon('plus', 16)} Novo banner</a>` });
  }, h.S('content.manage'));

  const bannerForm = (ctx, b = {}, error = '') => {
    const isNew = !b.id;
    const fromForm = !!b._raw;
    const v = (k, d = '') => b[k] ?? d;
    return html`<section class="card narrow-lg"><h2>${isNew ? 'Novo banner' : 'Editar banner'}</h2>
${error ? html`<div class="flash flash-error" role="alert">${icon('alert', 18)}<span>${error}</span></div>` : ''}
<form method="post" action="${isNew ? '/admin/banners' : `/admin/banners/${b.id}`}" class="stack">${csrfField(ctx)}
${selectField({ label: 'Onde aparece', name: 'placement', value: v('placement', 'hero'), options: Object.entries(PLACEMENT).map(([value, label]) => ({ value, label })), blank: null, required: true })}
${field({ label: 'Título', name: 'title', value: v('title'), required: true, maxlength: 120 })}
${field({ label: 'Subtítulo', name: 'subtitle', value: v('subtitle'), maxlength: 200 })}
<div class="grid2">${field({ label: 'Link ao clicar', name: 'link_url', value: v('link_url'), placeholder: '/loja ou https://…', maxlength: 300, hint: 'Comece com / para páginas da loja.' })}${field({ label: 'Texto do botão', name: 'cta_label', value: v('cta_label'), maxlength: 40, placeholder: 'Ver peças' })}</div>
<div class="grid3">${field({ label: 'Ordem', name: 'sort_order', type: 'number', value: v('sort_order', 0) })}${field({ label: 'Exibir a partir de', name: 'starts_at', type: 'date', value: b.id && !fromForm ? toDate(b.starts_at, false) : v('starts_at') })}${field({ label: 'Exibir até (inclusive)', name: 'ends_at', type: 'date', value: b.id && !fromForm ? toDate(b.ends_at, true) : v('ends_at') })}</div>
<div class="field"><label>Imagem <span class="opt">(opcional)</span></label>${b.image ? html`<img src="${imgUrl(b.image)}" alt="Imagem atual" class="mini-preview">` : ''}
<div class="uploader" data-uploader data-endpoint="/admin/uploads" data-target="#banner_image" data-preview="#banner_preview"><label class="btn btn-ghost btn-small" for="upb">Escolher imagem</label><input id="upb" type="file" accept="image/jpeg,image/png,image/webp" hidden><span class="muted small" data-status role="status"></span></div>
<img id="banner_preview" class="mini-preview" alt="" hidden><input type="hidden" name="image" id="banner_image" value=""><div class="hint">Use uma foto horizontal (ex.: 1600×700). Ela é reduzida no seu navegador antes do envio.</div></div>
<label class="check"><input type="checkbox" name="active" value="1" ${isNew || b.active ? raw('checked') : ''}> Banner ativo</label>
<div><button class="btn" type="submit">Salvar</button> <a class="btn btn-ghost" href="/admin/banners">Cancelar</a></div></form></section>
${isNew ? '' : html`<section class="card narrow-lg"><form method="post" action="/admin/banners/${b.id}/excluir" data-confirm="Excluir este banner?">${csrfField(ctx)}<button class="btn btn-danger" type="submit">Excluir banner</button></form></section>`}`;
  };

  router.get('/admin/banners/novo', (ctx) => h.page(ctx, 'Novo banner', bannerForm(ctx)), h.S('content.manage'));
  router.get('/admin/banners/:id', (ctx) => {
    const b = app.content.banners.get(bid(ctx));
    if (!b) return ctx.fail(404, 'Banner não encontrado.');
    h.page(ctx, 'Editar banner', bannerForm(ctx, b));
  }, h.S('content.manage'));
  const bannerSave = (ctx, id) => {
    try {
      const body = { ...ctx.body, active: !!ctx.body.active };
      const saved = app.content.banners.save(body, id);
      app.audit.staff(ctx, id ? 'banner.updated' : 'banner.created', 'banner', saved, { title: body.title });
      ctx.flash('success', 'Banner salvo.');
      ctx.redirect('/admin/banners');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      const cur = id ? app.content.banners.get(id) : {};
      h.page(ctx, id ? 'Editar banner' : 'Novo banner', bannerForm(ctx, { ...ctx.body, _raw: true, id: id || undefined, image: cur?.image, active: !!ctx.body.active }, e.message), { status: 422 });
    }
  };
  router.post('/admin/banners', (ctx) => bannerSave(ctx, null), h.S('content.manage'));
  router.post('/admin/banners/:id', (ctx) => bannerSave(ctx, bid(ctx)), h.S('content.manage'));
  router.post('/admin/banners/:id/excluir', (ctx) => h.act(ctx, '/admin/banners', () => { app.content.banners.remove(bid(ctx)); app.audit.staff(ctx, 'banner.deleted', 'banner', bid(ctx)); }, 'Banner excluído.'), h.S('content.manage'));

  // ───── páginas ─────
  const reviewed = () => app.settings.get('legal_reviewed') === '1';
  router.get('/admin/paginas', (ctx) => {
    const list = app.content.pages();
    h.page(ctx, 'Páginas e textos', html`
<section class="card">
  <div class="flash ${reviewed() ? 'flash-success' : 'flash-info'}">${icon(reviewed() ? 'check' : 'alert', 18)}<span>${reviewed() ? 'Os textos legais foram marcados como revisados.' : html`<strong>Os textos legais abaixo são modelos iniciais.</strong> Eles seguem a legislação brasileira de forma geral, mas não substituem a revisão de um(a) advogado(a). Complete os dados da loja em Configurações e revise antes de abrir a loja ao público.`}</span></div>
  <form method="post" action="/admin/paginas/revisado" class="inline-form-row">${csrfField(ctx)}<label class="check"><input type="checkbox" name="reviewed" value="1" ${reviewed() ? raw('checked') : ''}> Confirmo que os textos legais foram revisados por profissional habilitado</label><button class="btn btn-ghost btn-small" type="submit">Salvar</button></form>
</section>
<section class="card">${L.table(['Página', 'Endereço no site', 'Atualizada', 'Por', ''], list.map((p) => html`<tr><td><strong>${p.title}</strong></td><td><a href="/p/${p.slug}" target="_blank" rel="noopener">/p/${p.slug}</a></td><td>${h.ago(p.updated_at)}</td><td>${p.updated_by || '—'}</td><td class="r"><a class="btn btn-small btn-ghost" href="/admin/paginas/${p.slug}">Editar</a></td></tr>`), { empty: 'Nenhuma página.' })}</section>`);
  }, h.S('content.manage'));

  router.post('/admin/paginas/revisado', (ctx) => h.act(ctx, '/admin/paginas', () => {
    app.settings.set('legal_reviewed', ctx.body.reviewed ? '1' : '0');
    app.audit.staff(ctx, 'settings.legal_reviewed', 'settings', 'legal_reviewed', { value: !!ctx.body.reviewed });
  }, 'Situação da revisão salva.'), h.S('content.manage'));

  router.get('/admin/paginas/:slug', (ctx) => {
    const p = app.content.page(ctx.params.slug);
    if (!p) return ctx.fail(404, 'Página não encontrada.');
    const hasTemplate = !!app.content.DEFAULT_PAGES[p.slug];
    const preview = ctx.query.previa ? richText(app.content.resolve(p.body)) : null;
    h.page(ctx, p.title, html`
<div class="cols cols-wide"><section class="card"><form method="post" action="/admin/paginas/${p.slug}" class="stack">${csrfField(ctx)}
${field({ label: 'Título', name: 'title', value: p.title, required: true, maxlength: 120 })}
<div class="field"><label for="body">Texto</label><textarea id="body" name="body" rows="24" class="mono" required>${p.body}</textarea>
<div class="hint">Use <code>## Título</code>, <code>### Subtítulo</code>, listas com <code>- </code> e linhas em branco entre parágrafos.</div></div>
<div class="row-actions-wrap"><button class="btn" type="submit">Salvar página</button><a class="btn btn-ghost" href="/p/${p.slug}" target="_blank" rel="noopener">Ver no site ${icon('external', 14)}</a></div></form>
${hasTemplate ? html`<form method="post" action="/admin/paginas/${p.slug}/modelo" data-confirm="Voltar ao texto modelo? As suas alterações serão perdidas.">${csrfField(ctx)}<button class="btn btn-ghost btn-small" type="submit">Restaurar o texto modelo</button></form>` : ''}
</section>
<section class="card"><h2>Marcadores automáticos</h2><p class="small">Escreva estes marcadores no texto; o site os troca pelos dados de Configurações (nada é inventado quando o dado não foi preenchido):</p>
<ul class="small"><li><code>{{loja}}</code> — nome da loja</li><li><code>{{contato}}</code> — e-mail, WhatsApp e Instagram informados</li><li><code>{{identificacao}}</code> — CNPJ/CPF e endereço informados</li></ul>
${preview ? html`<h3>Prévia</h3><div class="prose">${preview}</div>` : html`<p><a class="btn btn-ghost btn-small" href="/admin/paginas/${p.slug}?previa=1">Ver prévia do texto salvo</a></p>`}</section></div>`);
  }, h.S('content.manage'));
  router.post('/admin/paginas/:slug', (ctx) => h.act(ctx, `/admin/paginas/${ctx.params.slug}`, () => { app.content.savePage(ctx.params.slug, { title: ctx.body.title, body: ctx.body.body }, ctx.staff.name); app.audit.staff(ctx, 'page.updated', 'page', ctx.params.slug); }, 'Página salva.'), h.S('content.manage'));
  router.post('/admin/paginas/:slug/modelo', (ctx) => h.act(ctx, `/admin/paginas/${ctx.params.slug}`, () => { app.content.resetPage(ctx.params.slug, ctx.staff.name); app.audit.staff(ctx, 'page.reset', 'page', ctx.params.slug); }, 'Texto modelo restaurado.'), h.S('content.manage'));
}

module.exports = { register };
