'use strict';
/** Utilitários de teste: cria um app isolado (banco em memória, provedor Pix SIMULADO, e-mails capturados). */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { buildConfig } = require('../src/config');
const { buildApp } = require('../src/app');

function makeTestApp(env = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bc-test-'));
  const cfg = buildConfig({
    NODE_ENV: 'test', DATA_DIR: dir, UPLOAD_DIR: path.join(dir, 'uploads'), DB_FILE: ':memory:',
    PAYMENT_PROVIDER: 'mock', EMAIL_TRANSPORT: 'capture', SECRET_KEY: 'k'.repeat(48), JOBS_ENABLED: '0',
    BASE_URL: 'http://loja.test', ...env,
  });
  const app = buildApp(cfg);
  app.testDir = dir;
  return app;
}

/** Catálogo mínimo + formas de entrega para os testes. Dados de TESTE, nunca usados fora do ambiente de teste. */
function seedBasics(app) {
  const catId = app.catalog.saveCategory({ name: 'Vestidos', active: true });
  const mk = (name, price, extra = {}) => {
    const f = app.catalog.parseProductForm({ name, price: String(price), quantity: '1', status: 'published', category_id: String(catId), ...extra });
    return app.catalog.byId(app.catalog.createProduct(f));
  };
  const pickup = app.shipping.saveMethod({ kind: 'pickup', name: 'Retirada', active: true });
  const fixed = app.shipping.saveMethod({ kind: 'fixed', name: 'Frete fixo', price: '15,00', free_over: '300,00', eta_text: '5 a 8 dias úteis', active: true });
  return { catId, mk, pickup, fixed };
}

const ctxFor = (token = 'visitor-token-test') => ({ visitorToken: token, ip: '127.0.0.1' });

/** Faz o pedido completo (carrinho -> entrega -> pedido reservado -> cobrança Pix) como o checkout faria. */
async function placeOrder(app, ctx, { items, shippingKey, zip = '01310100', form = {}, customerId = null } = {}) {
  for (const p of items) app.cart.add(ctx, p.id, 1);
  const cart = app.cart.view(ctx);
  const opt = await app.shipping.resolve({ key: shippingKey, zip, subtotalCents: cart.subtotal_cents, items: [] });
  const f = app.orders.parseCheckout({
    name: 'Maria de Teste', email: 'maria.teste@example.com', phone: '11987654321', zip, state: 'SP', city: 'São Paulo', district: 'Bela Vista',
    street: 'Rua de Teste', number: '10', shipping_key: String(shippingKey), ...form,
  }, { requiresCpf: false });
  if (opt.delivery_kind !== 'pickup') app.orders.requireAddress(f);
  const order = app.orders.createReserved({ cart, form: f, shippingOpt: opt, couponResult: null, customerId });
  const pay = await app.payments.createPixForOrder(order);
  return { order, pay };
}

/** Entrega o webhook ao app como o provedor faria (assinado). */
async function deliverWebhook(app, body, { signature, rawBody } = {}) {
  const raw = Buffer.from(rawBody ?? JSON.stringify(body));
  const p = app.providers.get('mock');
  return app.payments.handleWebhook('mock', { headers: { 'x-mock-signature': signature ?? p.sign(raw.toString('utf8')) }, rawBody: raw, query: {}, body, ip: '127.0.0.1' });
}

/**
 * Simula o caso real "o cliente pagou no banco no mesmo instante em que o prazo/cancelamento aconteceu":
 * o dinheiro entrou no provedor mesmo com a cobrança já cancelada do nosso lado.
 */
function payedDespiteCancel(app, providerId) {
  app.db.run("UPDATE mock_provider_charges SET status = 'paid', paid_at = ? WHERE id = ?", new Date().toISOString(), providerId);
  return { event_id: `evt_late_${providerId}`, type: 'payment.paid', payment_id: providerId };
}

module.exports = { payedDespiteCancel, makeTestApp, seedBasics, ctxFor, placeOrder, deliverWebhook };
