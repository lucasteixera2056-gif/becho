'use strict';
/**
 * Cria (ou redefine a senha de) um acesso ao painel, direto no servidor.
 *
 *   npm run create-admin                                  → pergunta nome, e-mail e senha (superadmin)
 *   npm run create-admin -- --email dona@loja.com --name "Maria" --role superadmin
 *   npm run create-admin -- --email dona@loja.com --reset   → define nova senha para um acesso existente
 *
 * A senha é digitada no terminal (não aparece na tela e não fica em histórico/arquivo).
 * O acesso criado/redefinido é obrigado a trocar a senha no primeiro login.
 * Funções: superadmin | admin | gerente | atendente | estoquista
 */
const readline = require('node:readline');
const { buildConfig } = require('../src/config');
const { buildApp } = require('../src/app');
const { hashPassword, passwordProblem } = require('../src/lib/security');

const ROLES = ['superadmin', 'admin', 'gerente', 'atendente', 'estoquista'];

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  if (i < 0) return undefined;
  const v = process.argv[i + 1];
  return v && !v.startsWith('--') ? v : true;
}

let rl;
let lines; // leitura linha a linha quando a entrada vem de um pipe (sem terminal)
let muted = false;
function openInput() {
  const tty = !!process.stdin.isTTY;
  rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: tty });
  if (tty) rl._writeToOutput = (s) => { if (!muted) process.stdout.write(s); }; // esconde a senha digitada
  else lines = rl[Symbol.asyncIterator]();
}
async function ask(question, { hidden = false } = {}) {
  if (!rl) openInput();
  process.stdout.write(question);
  muted = hidden;
  const answer = process.stdin.isTTY ? await new Promise((resolve) => rl.question('', resolve)) : String((await lines.next()).value ?? '');
  muted = false;
  if (hidden && process.stdin.isTTY) process.stdout.write('\n');
  return answer.trim();
}

async function main() {
  const cfg = buildConfig();
  const app = buildApp(cfg);
  try {
    const reset = arg('reset') === true;
    const email = String((typeof arg('email') === 'string' && arg('email')) || (await ask('E-mail do acesso: '))).trim().toLowerCase();
    if (!email) throw new Error('Informe o e-mail.');
    const existing = app.db.get('SELECT * FROM staff_users WHERE email = ?', email);

    if (reset && !existing) throw new Error(`Não existe acesso com o e-mail ${email}.`);
    if (!reset && existing) throw new Error(`Já existe um acesso com o e-mail ${email}. Use --reset para definir uma nova senha.`);

    const name = reset ? '' : (typeof arg('name') === 'string' && arg('name')) || (await ask('Nome: '));
    const password = await ask('Senha (mínimo 10 caracteres): ', { hidden: true });
    const again = await ask('Repita a senha: ', { hidden: true });
    if (password !== again) throw new Error('As senhas não conferem.');
    const problem = passwordProblem(password, { min: 10, email });
    if (problem) throw new Error(problem);

    if (reset) {
      app.db.run('UPDATE staff_users SET password_hash = ?, must_change_password = 1, active = 1 WHERE id = ?', await hashPassword(password), existing.id);
      app.db.run("DELETE FROM sessions WHERE kind = 'staff' AND user_id = ?", existing.id);
      app.db.run('DELETE FROM rate_limits WHERE key LIKE ?', `%${email}%`);
      app.audit.system('staff.password_reset_cli', 'staff', existing.id, { email });
      console.log(`\nPronto: nova senha definida para ${email}. Ela precisa ser trocada no próximo login. Sessões abertas foram encerradas.`);
    } else {
      const role = (typeof arg('role') === 'string' && arg('role')) || 'superadmin';
      if (!ROLES.includes(role)) throw new Error(`Função inválida. Use uma de: ${ROLES.join(', ')}.`);
      const id = await app.auth.createStaff(null, { name, email, password, role, mustChange: true });
      app.audit.system('staff.created_cli', 'staff', id, { email, role });
      console.log(`\nPronto: acesso criado para ${email} (${role}). A senha precisa ser trocada no primeiro login em ${cfg.baseUrl}/admin/login`);
    }
  } finally {
    rl?.close();
    await app.close();
  }
}

main().catch((e) => {
  console.error(`\nErro: ${e.message}`);
  process.exit(1);
});
