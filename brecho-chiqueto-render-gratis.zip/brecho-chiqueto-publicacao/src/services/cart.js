'use strict';
/**
 * Carrinho persistente: preso ao cookie do visitante (1 ano) e guardado no banco,
 * por isso sobrevive a recarregar a página e a fechar o navegador.
 * O carrinho NÃO reserva a peça (para não travar estoque com carrinhos abandonados);
 * a reserva acontece ao criar o pedido. Preços e disponibilidade são sempre revalidados.
 */
const { now, sha256, int, UserError } = require('../lib/util');

function makeCart(app) {
  const { db } = app;

  function cartRow(ctx, create = false) {
    const hash = sha256(ctx.visitorToken);
    let row = db.get('SELECT * FROM carts WHERE token_hash = ?', hash);
    if (!row && create) {
      const t = now();
      const id = db.run('INSERT INTO carts (token_hash, created_at, updated_at) VALUES (?,?,?)', hash, t, t).id;
      row = db.get('SELECT * FROM carts WHERE id = ?', id);
    }
    return row;
  }

  const touch = (id) => db.run('UPDATE carts SET updated_at = ? WHERE id = ?', now(), id);

  const cart = {
    /** Itens do carrinho com dados atuais do produto, disponibilidade e totais. */
    view(ctx) {
      const row = cartRow(ctx);
      const empty = { items: [], count: 0, subtotal_cents: 0, problems: [], coupon_code: null, cartId: row?.id ?? null };
      if (!row) return empty;
      const lines = db.all('SELECT product_id, qty FROM cart_items WHERE cart_id = ? ORDER BY added_at', row.id);
      const items = [];
      let subtotal = 0;
      const problems = [];
      for (const l of lines) {
        const p = app.catalog.byId(l.product_id);
        if (!p || p.status !== 'published') {
          db.run('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', row.id, l.product_id);
          problems.push('Uma peça deixou de estar disponível e foi removida do carrinho.');
          continue;
        }
        let qty = l.qty;
        const unavailable = p.available < 1;
        if (!unavailable && qty > p.available) {
          qty = p.available;
          db.run('UPDATE cart_items SET qty = ? WHERE cart_id = ? AND product_id = ?', qty, row.id, l.product_id);
          problems.push(`A quantidade de "${p.name}" foi ajustada para ${qty} (disponível).`);
        }
        const line = { product: p, qty, unit_cents: p.effective_cents, total_cents: p.effective_cents * qty, unavailable, max: Math.max(p.available, 0) };
        if (unavailable) problems.push(`"${p.name}" foi vendida ou está reservada por outro cliente. Remova-a para continuar.`);
        else subtotal += line.total_cents;
        items.push(line);
      }
      return { items, count: items.filter((i) => !i.unavailable).reduce((n, i) => n + i.qty, 0), subtotal_cents: subtotal, problems, coupon_code: row.coupon_code, cartId: row.id };
    },

    count(ctx) {
      const row = cartRow(ctx);
      return row ? db.value('SELECT COALESCE(SUM(qty), 0) FROM cart_items WHERE cart_id = ?', row.id) : 0;
    },

    add(ctx, productId, qty = 1) {
      qty = Math.max(1, int(qty, 1));
      const p = app.catalog.byId(productId);
      if (!p || p.status !== 'published') throw new UserError('Esta peça não está disponível.');
      if (p.available < 1) throw new UserError('Esta peça já foi vendida ou está reservada por outro cliente.');
      const row = cartRow(ctx, true);
      const cur = db.get('SELECT qty FROM cart_items WHERE cart_id = ? AND product_id = ?', row.id, p.id)?.qty || 0;
      const next = Math.min(cur + qty, p.available);
      if (cur >= p.available) throw new UserError(p.available === 1 ? 'Esta peça já está no seu carrinho (é única).' : `Você já tem todas as ${p.available} unidades disponíveis no carrinho.`);
      db.run('INSERT INTO cart_items (cart_id, product_id, qty, added_at) VALUES (?,?,?,?) ON CONFLICT(cart_id, product_id) DO UPDATE SET qty = excluded.qty', row.id, p.id, next, now());
      touch(row.id);
      return { qty: next, product: p };
    },

    setQty(ctx, productId, qty) {
      const row = cartRow(ctx);
      if (!row) return;
      qty = int(qty, 1);
      if (qty < 1) return this.remove(ctx, productId);
      const p = app.catalog.byId(productId);
      if (!p || p.status !== 'published') return this.remove(ctx, productId);
      if (qty > p.available) throw new UserError(`Só há ${p.available} unidade(s) disponível(is) desta peça.`);
      db.run('UPDATE cart_items SET qty = ? WHERE cart_id = ? AND product_id = ?', qty, row.id, productId);
      touch(row.id);
    },

    remove(ctx, productId) {
      const row = cartRow(ctx);
      if (!row) return;
      db.run('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', row.id, productId);
      touch(row.id);
    },

    setCoupon(ctx, code) {
      const row = cartRow(ctx, true);
      db.run('UPDATE carts SET coupon_code = ?, updated_at = ? WHERE id = ?', code || null, now(), row.id);
    },

    clear(ctx) {
      const row = cartRow(ctx);
      if (row) db.run('DELETE FROM carts WHERE id = ?', row.id);
    },

    /** Remove carrinhos sem atividade há mais de 60 dias. */
    prune() {
      db.run('DELETE FROM carts WHERE updated_at < ?', new Date(Date.now() - 60 * 86400000).toISOString());
    },
  };
  return cart;
}

module.exports = { makeCart };
