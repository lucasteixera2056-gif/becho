'use strict';
/** E-mails transacionais, conta do cliente e LGPD (consentimento, exportação, anonimização, solicitações). */
const test = require('node:test');
const assert = require('node:assert/strict');
const { makeTestApp, seedBasics, ctxFor, placeOrder, deliverWebhook } = require('./helpers');
const { startServer, Client, staffLogin, customerLogin } = require('./http-helpers');

const mkApp = (t, env) => { const app = makeTestApp(env); t.after(() => app.close()); return app; };
const lastMail = (app, to) => app.db.get('SELECT * FROM emails WHERE to_email = ? ORDER BY id DESC LIMIT 1', to);
const linkIn = (mail, re) => (re.exec(mail.html) || re.exec(mail.text) || [])[0];

test('e-mails: modelos geram assunto/HTML/texto, escapam conteúdo e ficam registrados', async (t) => {
  const app = mkApp(t);
  const { mk, fixed } = seedBasics(app);
  const p = mk('Blusa <script>alert(1)</script>', '40,00');
  const { order } = await placeOrder(app, ctxFor('em-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [p], shippingKey: fixed, form: { name: 'Ana <b>Negrito</b>' } });
  // o checkout (HTTP) enfileira estes dois e-mails; aqui reproduzimos a mesma chamada
  app.email.queue('order_received', order.customer_email, { name: order.customer_name, order, note: 'Pague o Pix no prazo.' });
  app.email.queue('pix_generated', order.customer_email, { name: order.customer_name, order, expiresAt: new Date(Date.now() + 3600000).toISOString() });
  await app.email.idle();
  const rec = app.db.all("SELECT * FROM emails WHERE order_id = ? ORDER BY id", order.id);
  assert.ok(rec.length >= 2, 'pedido gera e-mails');
  assert.ok(rec.every((r) => r.status === 'captured'), 'transporte de teste só captura, não envia');
  const m = rec.find((r) => r.template === 'order_received');
  assert.ok(m, 'e-mail de pedido recebido');
  assert.match(m.subject, new RegExp(order.number));
  assert.ok(!/<script>/i.test(m.html), 'HTML do produto escapado');
  assert.ok(!/<b>Negrito/.test(m.html), 'nome do cliente escapado');
  assert.match(m.html, /&lt;script&gt;/);
  assert.ok(m.text && m.text.includes(order.number), 'versão em texto puro');
  assert.ok(m.html.includes(`/pedido/${order.public_token}`), 'link para acompanhar o pedido');
  assert.ok(rec.some((r) => r.template === 'pix_generated'));
  // endereço inválido não gera registro
  assert.equal(app.email.queue('order_received', 'sem-arroba', { order }), null);
  // modelo desconhecido não derruba quem chamou
  assert.equal(app.email.queue('nao_existe', 'x@y.test', {}), null);
});

test('e-mails: modelo editável no painel e desativável; recuperação de senha nunca é desativada', async (t) => {
  const app = mkApp(t);
  const { mk, fixed } = seedBasics(app);
  app.db.run("INSERT INTO email_templates (key, subject, intro, enabled) VALUES ('order_received','Seu pedido {{pedido}} chegou!','Texto novo da loja.',1)");
  const p = mk('Saia', '30,00');
  const a = await placeOrder(app, ctxFor('em-2-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [p], shippingKey: fixed });
  app.email.queue('order_received', a.order.customer_email, { name: a.order.customer_name, order: a.order });
  await app.email.idle();
  const m = app.db.get("SELECT * FROM emails WHERE order_id = ? AND template = 'order_received'", a.order.id);
  assert.equal(m.subject, `Seu pedido ${a.order.number} chegou!`);
  assert.match(m.html, /Texto novo da loja\./);
  // desativado
  app.db.run("UPDATE email_templates SET enabled = 0 WHERE key = 'order_received'");
  const before = app.db.value('SELECT COUNT(*) FROM emails');
  assert.equal(app.email.queue('order_received', 'a@b.test', { order: a.order }), null);
  assert.equal(app.db.value('SELECT COUNT(*) FROM emails'), before);
  app.db.run("INSERT INTO email_templates (key, subject, intro, enabled) VALUES ('reset_password','x','y',0)");
  assert.ok(app.email.queue('reset_password', 'a@b.test', { name: 'A', resetUrl: 'http://x/y' }), 'e-mail de segurança sempre sai');
});

test('e-mails: sem chave do Resend nada é "fingido"; falha da API fica registrada e pode ser reenviada', async (t) => {
  // sem configuração: registro "skipped" com explicação
  const app = mkApp(t, { EMAIL_TRANSPORT: 'resend', RESEND_API_KEY: '' });
  const id = app.email.queue('contact_ack', 'cli@example.com', { name: 'Cli' });
  await app.email.idle();
  const r = app.email.get(id);
  assert.equal(r.status, 'skipped');
  assert.match(r.error, /RESEND_API_KEY/);

  // com chave mas a API recusa: status failed + mensagem; reenvio depois de corrigir
  const app2 = mkApp(t, { EMAIL_TRANSPORT: 'resend', RESEND_API_KEY: 're_teste_nao_real', EMAIL_FROM: 'loja@example.com' });
  const realFetch = globalThis.fetch;
  const calls = [];
  let mode = 'fail';
  globalThis.fetch = async (url, init) => {
    if (!String(url).startsWith('https://api.resend.com/')) return realFetch(url, init);
    calls.push({ url: String(url), init });
    return mode === 'fail'
      ? new Response(JSON.stringify({ name: 'validation_error', message: 'domínio não verificado' }), { status: 403, headers: { 'content-type': 'application/json' } })
      : new Response(JSON.stringify({ id: 'resend-id-123' }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  t.after(() => { globalThis.fetch = realFetch; });
  const id2 = app2.email.queue('contact_ack', 'cli@example.com', { name: 'Cli' });
  await app2.email.idle();
  let row = app2.email.get(id2);
  assert.equal(row.status, 'failed');
  assert.match(row.error, /403/);
  assert.equal(row.attempts, 1);
  const sent = JSON.parse(calls[0].init.body);
  assert.deepEqual(sent.to, ['cli@example.com']);
  assert.match(sent.from, /<loja@example\.com>$/);
  assert.equal(calls[0].init.headers.Authorization, 'Bearer re_teste_nao_real');
  mode = 'ok';
  const res = await app2.email.resend(id2);
  assert.equal(res.status, 'sent');
  row = app2.email.get(id2);
  assert.equal(row.provider_id, 'resend-id-123');
  assert.equal(row.attempts, 2);
  assert.equal(row.error, null);
});

test('conta do cliente: cadastro exige confirmação; e-mail existente não é revelado; links valem uma vez', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const c = new Client(srv.base);
  await c.get('/minha-conta/cadastrar');
  const form = { name: 'Bia Cliente', email: 'bia@example.com', phone: '11988887777', password: 'SenhaBoa-2026', confirm: 'SenhaBoa-2026', marketing: '1' };
  // senha fraca / divergente
  assert.equal((await c.post('/minha-conta/cadastrar', { ...form, password: '123', confirm: '123' })).status, 422);
  assert.equal((await c.post('/minha-conta/cadastrar', { ...form, confirm: 'outra' })).status, 422);
  assert.equal(app.db.value('SELECT COUNT(*) FROM customers'), 0);
  const ok = await c.post('/minha-conta/cadastrar', form);
  assert.equal(ok.status, 200);
  await app.email.idle();
  const cust = app.db.get('SELECT * FROM customers WHERE email = ?', 'bia@example.com');
  assert.equal(cust.email_verified_at, null, 'nasce sem e-mail confirmado');
  assert.equal(cust.marketing_consent, 1);
  assert.ok(cust.marketing_consent_at, 'data do consentimento registrada');
  assert.ok(!cust.password_hash.includes('SenhaBoa'), 'senha nunca em texto');
  const mail = lastMail(app, 'bia@example.com');
  assert.equal(mail.template, 'verify_email');
  const link = /\/minha-conta\/confirmar-email\/[A-Za-z0-9_-]+/.exec(mail.text)[0];
  // o token no banco é só o hash
  assert.equal(app.db.value('SELECT COUNT(*) FROM auth_tokens WHERE token_hash = ?', link.split('/').pop()), 0);
  // cadastro repetido: mesma resposta, e-mail diferente (não revela existência)
  const c2 = new Client(srv.base);
  await c2.get('/minha-conta/cadastrar');
  const again = await c2.post('/minha-conta/cadastrar', form);
  assert.equal(again.status, ok.status);
  assert.equal(again.text.replace(/<meta[^>]+>/g, '').replace(/name="_csrf" value="[^"]+"/g, ''), ok.text.replace(/<meta[^>]+>/g, '').replace(/name="_csrf" value="[^"]+"/g, ''), 'resposta idêntica');
  await app.email.idle();
  assert.equal(lastMail(app, 'bia@example.com').template, 'account_exists');
  assert.equal(app.db.value('SELECT COUNT(*) FROM customers WHERE email = ?', 'bia@example.com'), 1);
  // confirma uma vez
  const r1 = await c.get(link);
  assert.match(r1.text, /E-mail confirmado/);
  assert.ok(app.db.get('SELECT email_verified_at FROM customers WHERE id = ?', cust.id).email_verified_at);
  assert.match((await c.get(link)).text, /inválido ou expirado/, 'segundo uso do link falha');
  // login
  const bad = await c.post('/minha-conta/entrar', { email: 'bia@example.com', password: 'errada-errada' });
  assert.equal(bad.status, 422);
  assert.equal((await c.post('/minha-conta/entrar', { email: 'bia@example.com', password: form.password })).status, 303);
  assert.match((await c.get('/minha-conta')).text, /Olá, Bia/);
});

test('conta do cliente: recuperação de senha (resposta igual, link único, derruba sessões) e proteção de rotas', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { client: logged, id } = await customerLogin(app, srv.base, { email: 'rec@example.com', password: 'SenhaAntiga-2026' });
  assert.match((await logged.get('/minha-conta')).text, /Olá/);
  const anon = new Client(srv.base);
  await anon.get('/minha-conta/esqueci-senha');
  const known = await anon.post('/minha-conta/esqueci-senha', { email: 'rec@example.com' });
  const unknown = await anon.post('/minha-conta/esqueci-senha', { email: 'ninguem@example.com' });
  assert.equal(known.status, 200);
  assert.equal(unknown.status, 200);
  assert.equal(known.text.replace(/name="_csrf" value="[^"]+"/g, '').replace(/<meta[^>]+>/g, ''), unknown.text.replace(/name="_csrf" value="[^"]+"/g, '').replace(/<meta[^>]+>/g, ''), 'não revela se a conta existe');
  await app.email.idle();
  assert.equal(app.db.value("SELECT COUNT(*) FROM emails WHERE to_email = 'ninguem@example.com'"), 0);
  const mail = lastMail(app, 'rec@example.com');
  assert.equal(mail.template, 'reset_password');
  const link = /\/minha-conta\/redefinir-senha\/[A-Za-z0-9_-]+/.exec(mail.text)[0];
  assert.equal((await anon.get(link)).status, 200);
  assert.equal((await anon.post(link, { password: 'curta', confirm: 'curta' })).status, 422);
  const done = await anon.post(link, { password: 'NovaSenha-2026!', confirm: 'NovaSenha-2026!' });
  assert.equal(done.status, 303);
  assert.equal((await anon.get(link)).status, 410, 'link não funciona de novo');
  assert.equal((await anon.post(link, { password: 'OutraSenha-2026!', confirm: 'OutraSenha-2026!' })).status, 422);
  // sessão antiga foi derrubada
  assert.equal((await logged.get('/minha-conta')).status, 303, 'sessão anterior encerrada');
  assert.equal(app.db.value("SELECT COUNT(*) FROM sessions WHERE kind = 'customer' AND user_id = ?", id), 0);
  // senha antiga não entra mais, a nova sim
  const c = new Client(srv.base);
  await c.get('/minha-conta/entrar');
  assert.equal((await c.post('/minha-conta/entrar', { email: 'rec@example.com', password: 'SenhaAntiga-2026' })).status, 422);
  assert.equal((await c.post('/minha-conta/entrar', { email: 'rec@example.com', password: 'NovaSenha-2026!' })).status, 303);
  // rotas da conta exigem login
  const guest = new Client(srv.base);
  for (const path of ['/minha-conta', '/minha-conta/pedidos', '/minha-conta/dados', '/minha-conta/enderecos']) {
    const r = await guest.get(path);
    assert.equal(r.status, 303, path);
    assert.match(r.location, /entrar/);
  }
});

test('conta do cliente: só vê os próprios pedidos (isolamento) e pedidos só aparecem com e-mail confirmado', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk, fixed } = seedBasics(app);
  const a = await customerLogin(app, srv.base, { email: 'dona@example.com' });
  const b = await customerLogin(app, srv.base, { email: 'outra@example.com' });
  const p = mk('Peça da Dona', '80,00');
  const { order } = await placeOrder(app, ctxFor('iso-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [p], shippingKey: fixed, customerId: a.id, form: { email: 'dona@example.com' } });
  assert.match((await a.client.get('/minha-conta/pedidos')).text, new RegExp(order.number));
  assert.equal((await a.client.get(`/minha-conta/pedidos/${order.number}`)).status, 200);
  assert.equal((await b.client.get(`/minha-conta/pedidos/${order.number}`)).status, 404, 'outra cliente não acessa o pedido');
  assert.ok(!(await b.client.get('/minha-conta/pedidos')).text.includes(order.number));
  // e-mail não confirmado: lista vazia
  app.db.run('UPDATE customers SET email_verified_at = NULL WHERE id = ?', a.id);
  const lista = await a.client.get('/minha-conta/pedidos');
  assert.ok(!lista.text.includes(order.number));
  assert.match(lista.text, /Confirme seu e-mail/);
  assert.equal((await a.client.get(`/minha-conta/pedidos/${order.number}`)).status, 404);
});

test('LGPD: exportação traz os dados do titular (CPF mascarado) e só os dele', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk, fixed } = seedBasics(app);
  const a = await customerLogin(app, srv.base, { email: 'titular@example.com', name: 'Titular Um' });
  const other = await customerLogin(app, srv.base, { email: 'terceiro@example.com', name: 'Terceiro Silva' });
  app.db.run('UPDATE customers SET cpf_enc = ? WHERE id = ?', app.cipher.encrypt('52998224725'), a.id);
  app.auth.saveAddress(a.id, { label: 'Casa', recipient: 'Titular Um', zip: '01310100', street: 'Av. Paulista', number: '1', district: 'Bela Vista', city: 'São Paulo', state: 'SP' });
  const p = mk('Calça jeans', '90,00');
  await placeOrder(app, ctxFor('exp-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [p], shippingKey: fixed, customerId: a.id, form: { email: 'titular@example.com' } });
  const q = mk('Peça de terceiro', '50,00');
  await placeOrder(app, ctxFor('exp-2-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [q], shippingKey: fixed, customerId: other.id, form: { email: 'terceiro@example.com', name: 'Terceiro Silva' } });
  const r = await a.client.post('/minha-conta/dados/exportar', {});
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-disposition'), /attachment; filename="meus-dados-.*\.json"/);
  const data = JSON.parse(r.text);
  assert.equal(data.cadastro.email, 'titular@example.com');
  assert.equal(data.pedidos.length, 1);
  assert.equal(data.pedidos[0].itens[0].nome, 'Calça jeans');
  assert.equal(data.enderecos.length, 1);
  assert.match(data.cadastro.cpf, /\*/, 'CPF mascarado');
  assert.ok(!r.text.includes('52998224725'), 'CPF completo nunca sai na exportação');
  assert.ok(!r.text.includes('terceiro@example.com') && !r.text.includes('Peça de terceiro'), 'nada de outro titular');
  assert.ok(app.db.get("SELECT 1 FROM audit_logs WHERE action = 'customer.data_export'"), 'exportação auditada');
  // CPF fica cifrado no banco
  const raw = app.db.get('SELECT cpf_enc FROM customers WHERE id = ?', a.id).cpf_enc;
  assert.ok(raw && !raw.includes('52998224725'));
});

test('LGPD: solicitação de eliminação → anonimização preserva pedidos, apaga dados pessoais e recusa se houver pedido em andamento', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk, fixed } = seedBasics(app);
  const a = await customerLogin(app, srv.base, { email: 'sair@example.com', name: 'Quem Sai' });
  app.db.run('UPDATE customers SET cpf_enc = ?, phone = ? WHERE id = ?', app.cipher.encrypt('52998224725'), '11999998888', a.id);
  app.auth.saveAddress(a.id, { label: 'Casa', recipient: 'Quem Sai', zip: '01310100', street: 'Rua X', number: '2', district: 'Centro', city: 'São Paulo', state: 'SP' });
  app.crm.subscribe({ email: 'sair@example.com', ip: '1.1.1.1', consentText: 'ok' });
  app.crm.submitContact({ name: 'Quem Sai', email: 'sair@example.com', message: 'Mensagem longa o bastante para valer.' });
  const p = mk('Vestido azul', '120,00');
  const { order, pay } = await placeOrder(app, ctxFor('anon-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [p], shippingKey: fixed, customerId: a.id, form: { email: 'sair@example.com', name: 'Quem Sai' } });
  const staff = await staffLogin(app, srv.base, { role: 'superadmin', email: 'lgpd-admin@example.com' });
  const ctx = { staff: { id: 1, name: 'Admin' }, ip: '127.0.0.1' };

  // pedido de eliminação feito pela conta
  assert.equal((await a.client.post('/minha-conta/dados/eliminar', {})).status, 303);
  assert.equal((await a.client.post('/minha-conta/dados/eliminar', {})).status, 303);
  assert.equal(app.db.value("SELECT COUNT(*) FROM data_requests WHERE email = 'sair@example.com' AND status = 'open'"), 1, 'pedido repetido não duplica');
  assert.ok(app.db.get("SELECT 1 FROM notifications WHERE kind = 'lgpd'"), 'administrador é avisado');
  assert.match((await staff.get('/admin/lgpd')).text, /sair@example\.com/);

  // pedido ainda aguardando pagamento: não anonimiza
  assert.throws(() => app.crm.anonymize(ctx, a.id), /em andamento/i);
  assert.equal(app.crm.customer(a.id).status, 'active');

  // paga, e então está em andamento também (preparação)
  await deliverWebhook(app, app.providers.get('mock').simulatePay(pay.provider_payment_id));
  assert.throws(() => app.crm.anonymize(ctx, a.id), /em andamento/i, 'pedido pago e não entregue ainda é "em andamento"');
  app.db.run("UPDATE orders SET status = 'delivered' WHERE id = ?", order.id);

  app.crm.anonymize(ctx, a.id);
  const c = app.crm.customer(a.id);
  assert.equal(c.status, 'anonymized');
  assert.equal(c.name, 'Cliente removido');
  assert.match(c.email, /@anonimizado\.invalid$/);
  assert.equal(c.cpf_enc, null);
  assert.equal(c.phone, null);
  assert.equal(c.password_hash, null);
  assert.equal(app.db.value('SELECT COUNT(*) FROM addresses WHERE customer_id = ?', a.id), 0);
  assert.equal(app.db.value("SELECT COUNT(*) FROM newsletter_subscribers WHERE email = 'sair@example.com'"), 0);
  assert.equal(app.db.value("SELECT COUNT(*) FROM contact_messages WHERE message LIKE '%bastante%'"), 0, 'mensagem de contato apagada');
  assert.equal(app.db.get('SELECT customer_cpf_enc FROM orders WHERE id = ?', order.id).customer_cpf_enc, null);
  assert.ok(app.db.get('SELECT 1 FROM orders WHERE id = ?', order.id), 'pedido (registro fiscal/financeiro) é mantido');
  assert.equal(app.db.value("SELECT COUNT(*) FROM sessions WHERE kind = 'customer' AND user_id = ?", a.id), 0);
  assert.equal((await a.client.get('/minha-conta')).status, 303, 'sessão não vale mais');
  // não dá para entrar nem reaproveitar o e-mail
  const fresh = new Client(srv.base);
  await fresh.get('/minha-conta/entrar');
  assert.equal((await fresh.post('/minha-conta/entrar', { email: 'sair@example.com', password: 'SenhaCliente-2026' })).status, 422);
  assert.ok(app.db.get("SELECT 1 FROM audit_logs WHERE action = 'customer.anonymize'"));
  // marcar a solicitação como atendida
  const reqId = app.db.get("SELECT id FROM data_requests WHERE email = 'sair@example.com'").id;
  app.crm.resolveDataRequest(ctx, reqId, 'done', 'Dados eliminados.');
  assert.equal(app.db.get('SELECT status FROM data_requests WHERE id = ?', reqId).status, 'done');
});

test('LGPD: formulário público não revela quem é cliente e valida tipo/e-mail', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  await customerLogin(app, srv.base, { email: 'existe@example.com' });
  const c = new Client(srv.base);
  await c.get('/privacidade/solicitacoes');
  const norm = (s) => s.replace(/name="_csrf" value="[^"]+"/g, '').replace(/<meta[^>]+>/g, '').replace(/\s+/g, ' ');
  const a = await c.post('/privacidade/solicitacoes', { email: 'existe@example.com', kind: 'access' });
  const f1 = await c.get('/privacidade/solicitacoes');
  const b = await c.post('/privacidade/solicitacoes', { email: 'nao-existe@example.com', kind: 'access' });
  const f2 = await c.get('/privacidade/solicitacoes');
  assert.equal(a.status, 303);
  assert.equal(b.status, 303);
  assert.equal(norm(f1.text), norm(f2.text), 'mesma resposta para cliente e não-cliente');
  await c.post('/privacidade/solicitacoes', { email: 'sem-arroba', kind: 'access' });
  assert.match((await c.get('/privacidade/solicitacoes')).text, /e-mail válido/);
  await c.post('/privacidade/solicitacoes', { email: 'x@example.com', kind: 'apagar-tudo-agora' });
  assert.equal(app.db.value("SELECT COUNT(*) FROM data_requests WHERE email = 'x@example.com'"), 0, 'tipo inválido recusado');
});

test('newsletter: exige consentimento, registra prova, cancelamento por link e reinscrição; contato valida e usa isca anti-robô', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const c = new Client(srv.base);
  await c.get('/');
  // sem marcar o consentimento: nada é gravado
  await c.post('/newsletter', { email: 'leitor@example.com' });
  assert.equal(app.db.value('SELECT COUNT(*) FROM newsletter_subscribers'), 0);
  await c.post('/newsletter', { email: 'leitor@example.com', consent: '1' });
  await app.email.idle();
  const s = app.db.get("SELECT * FROM newsletter_subscribers WHERE email = 'leitor@example.com'");
  assert.ok(s.consent_at && s.consent_text && s.unsub_token, 'prova de consentimento: data, texto e token');
  const mail = lastMail(app, 'leitor@example.com');
  assert.equal(mail.template, 'newsletter_welcome');
  assert.ok(mail.html.includes(`/newsletter/cancelar/${s.unsub_token}`), 'e-mail traz link de cancelamento');
  // inscrever de novo não duplica
  await c.post('/newsletter', { email: 'LEITOR@example.com', consent: '1' });
  assert.equal(app.db.value("SELECT COUNT(*) FROM newsletter_subscribers WHERE email = 'leitor@example.com'"), 1);
  // cancelar (link público, sem login)
  assert.match((await new Client(srv.base).get(`/newsletter/cancelar/${s.unsub_token}`)).text, /Inscrição cancelada/);
  assert.ok(app.db.get('SELECT unsubscribed_at FROM newsletter_subscribers WHERE id = ?', s.id).unsubscribed_at);
  assert.match((await c.get('/newsletter/cancelar/token-invalido')).text, /Link inválido/);
  assert.ok(!app.crm.subscribersCsv().includes('leitor@example.com'), 'cancelado sai da lista exportada');
  // volta a se inscrever com novo consentimento
  await c.post('/newsletter', { email: 'leitor@example.com', consent: '1' });
  assert.equal(app.db.get('SELECT unsubscribed_at FROM newsletter_subscribers WHERE id = ?', s.id).unsubscribed_at, null);
  assert.ok(app.crm.subscribersCsv().includes('leitor@example.com'));

  // contato
  const bad = await c.post('/contato', { name: 'A', email: 'x', message: 'curta' });
  assert.equal(bad.status, 422);
  assert.equal(app.db.value('SELECT COUNT(*) FROM contact_messages'), 0);
  const good = await c.post('/contato', { name: 'Clara Teste', email: 'clara@example.com', message: 'Gostaria de saber se a peça serve no meu manequim.' });
  assert.equal(good.status, 303);
  await app.email.idle();
  assert.equal(app.db.value('SELECT COUNT(*) FROM contact_messages'), 1);
  assert.equal(lastMail(app, 'clara@example.com').template, 'contact_ack');
  assert.ok(app.db.get("SELECT 1 FROM notifications WHERE kind = 'contact'"), 'sino do painel avisa a loja');
  // isca anti-robô: parece sucesso, mas não grava
  await c.post('/contato', { name: 'Robo Spam', email: 'bot@example.com', message: 'Compre agora o produto milagroso!!', website: 'http://spam.test' });
  assert.equal(app.db.value('SELECT COUNT(*) FROM contact_messages'), 1);
  assert.equal(app.db.value("SELECT COUNT(*) FROM emails WHERE to_email = 'bot@example.com'"), 0);
});

test('painel: histórico de e-mails com erro e reenvio exigem permissão', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const adm = await staffLogin(app, srv.base, { role: 'admin', email: 'mail-admin@example.com' });
  const est = await staffLogin(app, srv.base, { role: 'estoquista', email: 'mail-estq@example.com' });
  const id = app.db.run("INSERT INTO emails (to_email, template, subject, html, text, status, error, attempts, created_at) VALUES ('x@example.com','contact_ack','Teste','<p>oi</p>','oi','failed','Resend 403: domínio não verificado',1,?)", new Date().toISOString()).id;
  const hist = await adm.get('/admin/emails');
  assert.equal(hist.status, 200);
  assert.match(hist.text, /domínio não verificado/);
  assert.equal((await est.get('/admin/emails')).status, 403, 'estoquista não vê o histórico de e-mails');
  const re = await est.post(`/admin/emails/${id}/reenviar`, {});
  assert.equal(re.status, 403);
  const ok = await adm.post(`/admin/emails/${id}/reenviar`, {});
  assert.equal(ok.status, 303);
  assert.equal(app.db.get('SELECT status FROM emails WHERE id = ?', id).status, 'captured');
});
