'use strict';
/**
 * Raiz de composição: cria o banco e todos os serviços e os conecta no objeto `app`.
 * As rotas, a tela e os testes recebem este objeto — não há estado global escondido.
 */
const { openDb } = require('./db');
const { money } = require('./lib/util');
const { makeCipher, makeRateLimiter } = require('./lib/security');
const { makeSettings } = require('./services/settings');
const { makeAudit } = require('./services/audit');
const { makePermissions } = require('./services/permissions');
const { makeEmail } = require('./services/email');
const { makeAuth } = require('./services/auth');
const { makeCatalog } = require('./services/catalog');
const { makeStock } = require('./services/stock');
const { makeCart } = require('./services/cart');
const { makeCoupons } = require('./services/coupons');
const { makeShipping } = require('./services/shipping');
const { makeOrders } = require('./services/orders');
const { makePayments } = require('./services/payments');
const { makeReports } = require('./services/reports');
const { makeContent } = require('./services/content');
const { makeCrm } = require('./services/crm');
const { makeJobs } = require('./services/jobs');
const { makePaymentProviders } = require('./providers/payment');

function buildApp(cfg) {
  const db = openDb(cfg.dbFile);
  db.migrate();
  const app = { cfg, db, fmt: { money } };
  app.settings = makeSettings(app);
  app.audit = makeAudit(app);
  app.permissions = makePermissions(app);
  app.limiter = makeRateLimiter(db);
  app.cipher = makeCipher(cfg.secret);
  app.providers = makePaymentProviders(cfg, db);
  app.email = makeEmail(app);
  app.auth = makeAuth(app);
  app.stock = makeStock(app);
  app.catalog = makeCatalog(app);
  app.cart = makeCart(app);
  app.coupons = makeCoupons(app);
  app.shipping = makeShipping(app);
  app.orders = makeOrders(app);
  app.payments = makePayments(app);
  app.reports = makeReports(app);
  app.content = makeContent(app);
  app.crm = makeCrm(app);
  app.jobs = makeJobs(app);

  app.permissions.seedDefaults();
  app.content.seedPages();
  app.shipping.seedDefaults?.();
  app.close = async () => {
    app.jobs.stop();
    await app.email.idle();
    db.close();
  };
  return app;
}

module.exports = { buildApp };
