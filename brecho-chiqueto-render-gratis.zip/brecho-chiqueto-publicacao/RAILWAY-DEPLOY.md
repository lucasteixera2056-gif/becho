# Publicar no Railway

Esta cópia está preparada para construir com o `Dockerfile` da raiz.

## Serviço

- Build: Dockerfile (detecção automática pelo Railway).
- Start: `npm start` (já definido no Dockerfile).
- Porta: usa a variável `PORT` fornecida pelo Railway; o servidor escuta em `0.0.0.0`.
- Anexe **um Volume** ao serviço no caminho `/data` antes de usar a loja.
- Mantenha apenas uma réplica/instância, pois o banco é SQLite e os jobs rodam em um único processo.

## Variáveis obrigatórias para iniciar em produção

Configure no serviço Railway:

```text
NODE_ENV=production
HOST=0.0.0.0
TRUST_PROXY=1
DATA_DIR=/data
UPLOAD_DIR=/data/uploads
DB_FILE=/data/loja.db
JOBS_ENABLED=1
SECRET_KEY=<gere uma chave aleatória com pelo menos 32 caracteres>
PAYMENT_PROVIDER=none
EMAIL_TRANSPORT=log
```

Gere a `SECRET_KEY` em um terminal confiável com:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

Cole o resultado somente no campo `SECRET_KEY` das variáveis do Railway. Guarde uma cópia segura: ela cifra os CPFs e assina as sessões. Não a troque depois que clientes estiverem cadastrados.

`PAYMENT_PROVIDER=none` e `EMAIL_TRANSPORT=log` permitem apenas deixar a vitrine no ar para configuração e testes. **Não habilitam vendas nem envio de e-mails.** Antes de aceitar pedidos, configure Asaas ou Mercado Pago em produção, segredo do webhook, Resend e um domínio/remetente verificado. Veja `docs/PAGAMENTOS.md` e `docs/EMAIL.md`.

## Primeiro administrador

Antes do primeiro boot, defina temporariamente:

```text
ADMIN_EMAIL=<seu e-mail de administração>
ADMIN_PASSWORD=<senha temporária forte e exclusiva>
ADMIN_NAME=Proprietária
```

Na primeira inicialização, o app cria o primeiro administrador e informa isso nos logs. Entre no painel; a senha temporária deverá ser trocada. Depois, remova `ADMIN_EMAIL` e `ADMIN_PASSWORD` das variáveis do Railway e faça um redeploy.

## Após o primeiro deploy

1. Gere o domínio público Railway e copie o endereço HTTPS.
2. Atualize `BASE_URL` com esse endereço HTTPS e faça redeploy.
3. Abra a loja e entre no painel administrativo.
4. Configure contatos, entrega, produtos e fotos reais.
5. Configure e teste pagamento Pix e e-mail antes de divulgar ou aceitar pedidos.

## Segurança e persistência

- Nunca envie `.env`, chaves de API, senha do administrador ou segredo Pix ao GitHub.
- Não use dados de demonstração em produção.
- Não remova nem substitua o Volume `/data`: ele guarda `loja.db` e fotos em `/data/uploads`.
- Faça backup regular e mantenha uma cópia fora da hospedagem.
- Não configure duas réplicas para este projeto SQLite.

A publicação ainda exige autorização na conta Railway do proprietário e configuração dos segredos acima. Este pacote não contém credenciais de serviços externos.
