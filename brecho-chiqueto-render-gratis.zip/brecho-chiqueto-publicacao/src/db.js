'use strict';
/**
 * Camada de banco de dados (SQLite embutido do Node 22, módulo node:sqlite).
 * - WAL + foreign keys + busy_timeout.
 * - Migrações SQL versionadas em src/migrations.
 * - tx(): transações (aninháveis via SAVEPOINT) para operações financeiras e de estoque.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const norm = (params) => params.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));

class Db {
  constructor(file) {
    this.file = file;
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
    this.cache = new Map();
    this.depth = 0;
  }

  stmt(sql) {
    let s = this.cache.get(sql);
    if (!s) {
      s = this.raw.prepare(sql);
      this.cache.set(sql, s);
    }
    return s;
  }

  run(sql, ...params) {
    const r = this.stmt(sql).run(...norm(params));
    return { changes: Number(r.changes), id: Number(r.lastInsertRowid) };
  }

  get(sql, ...params) {
    const r = this.stmt(sql).get(...norm(params));
    return r ? { ...r } : undefined;
  }

  all(sql, ...params) {
    return this.stmt(sql).all(...norm(params)).map((r) => ({ ...r }));
  }

  value(sql, ...params) {
    const r = this.stmt(sql).get(...norm(params));
    return r ? Object.values(r)[0] : undefined;
  }

  exec(sql) {
    this.raw.exec(sql);
  }

  /** Executa fn dentro de uma transação. Em caso de exceção, desfaz tudo. */
  tx(fn) {
    const outer = this.depth === 0;
    const sp = `sp_${this.depth}`;
    this.raw.exec(outer ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${sp}`);
    this.depth++;
    try {
      const out = fn();
      this.depth--;
      this.raw.exec(outer ? 'COMMIT' : `RELEASE ${sp}`);
      return out;
    } catch (err) {
      this.depth--;
      try {
        this.raw.exec(outer ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
      } catch {
        /* conexão já revertida */
      }
      throw err;
    }
  }

  migrate() {
    this.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
    const dir = path.join(__dirname, 'migrations');
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
    const applied = new Set(this.all('SELECT id FROM schema_migrations').map((r) => r.id));
    for (const f of files) {
      if (applied.has(f)) continue;
      const sql = fs.readFileSync(path.join(dir, f), 'utf8');
      this.exec('BEGIN');
      try {
        this.exec(sql);
        this.run('INSERT INTO schema_migrations (id, applied_at) VALUES (?, ?)', f, new Date().toISOString());
        this.exec('COMMIT');
      } catch (e) {
        this.exec('ROLLBACK');
        throw new Error(`Falha na migração ${f}: ${e.message}`);
      }
    }
  }

  close() {
    this.raw.close();
  }
}

function openDb(file) {
  const db = new Db(file);
  db.migrate();
  return db;
}

module.exports = { openDb, Db };
