'use strict';
/**
 * Clientes (visão do painel), LGPD (acesso/eliminação), newsletter com consentimento,
 * mensagens de contato, solicitações de atendimento e notificações internas.
 */
const { now, trunc, validEmail, validPhone, onlyDigits, randomToken, maskCpf, UserError } = require('../lib/util');

function makeCrm(app) {
  const { db, cfg, audit } = app;
  const ACTIVE_ORDER = "('awaiting_payment','paid','preparing','shipped','in_transit')";

  const like = (s) => `%${trunc(s, 80).replace(/[\\%_]/g, '\\$&')}%`;
  const paginate = (total, page, perPage) => {
    const pages = Math.max(1, Math.ceil(total / perPage));
    const cur = Math.min(Math.max(1, Number.parseInt(page, 10) || 1), pages);
    return { pages, page: cur, offset: (cur - 1) * perPage };
  };

  const crm = {
    // ───── clientes ─────
    customers({ q = '', status = '', page = 1, perPage = 30 } = {}) {
      const where = ["c.status <> 'anonymized'"];
      const params = [];
      if (trunc(q, 80)) {
        where.push("(c.name LIKE ? ESCAPE '\\' OR c.email LIKE ? ESCAPE '\\' OR c.phone LIKE ? ESCAPE '\\')");
        params.push(like(q), like(q), like(onlyDigits(q) || q));
      }
      if (status === 'blocked') where.push("c.status = 'blocked'");
      if (status === 'newsletter') where.push('c.marketing_consent = 1');
      const total = db.value(`SELECT COUNT(*) FROM customers c WHERE ${where.join(' AND ')}`, ...params);
      const pg = paginate(total, page, perPage);
      const rows = db.all(
        `SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id AND o.paid_at IS NOT NULL) AS paid_orders,
                (SELECT COALESCE(SUM(total_cents),0) FROM orders o WHERE o.customer_id = c.id AND o.paid_at IS NOT NULL) AS spent
         FROM customers c WHERE ${where.join(' AND ')} ORDER BY c.id DESC LIMIT ? OFFSET ?`, ...params, perPage, pg.offset);
      return { rows, total, page: pg.page, pages: pg.pages };
    },
    customer: (id) => db.get('SELECT * FROM customers WHERE id = ?', id),
    customerOrders: (id) => db.all('SELECT * FROM orders WHERE customer_id = ? ORDER BY id DESC', id),
    customerAddresses: (id) => db.all('SELECT * FROM addresses WHERE customer_id = ? ORDER BY is_default DESC, id', id),
    cpfMasked(c) {
      const cpf = app.cipher.decrypt(c.cpf_enc);
      return cpf ? maskCpf(cpf) : '';
    },
    saveNotes(ctx, id, notes) {
      db.run('UPDATE customers SET admin_notes = ? WHERE id = ?', trunc(notes, 1000) || null, id);
      audit.staff(ctx, 'customer.notes', 'customer', id);
    },
    setBlocked(ctx, id, blocked, reason = '') {
      const c = this.customer(id);
      if (!c || c.status === 'anonymized') throw new UserError('Cliente não encontrado.');
      db.tx(() => {
        db.run('UPDATE customers SET status = ?, block_reason = ? WHERE id = ?', blocked ? 'blocked' : 'active', blocked ? trunc(reason, 200) || null : null, id);
        if (blocked) db.run("DELETE FROM sessions WHERE kind = 'customer' AND user_id = ?", id);
      });
      audit.staff(ctx, blocked ? 'customer.block' : 'customer.unblock', 'customer', id);
    },

    // ───── LGPD ─────
    /** Exportação dos dados do titular (acesso/portabilidade). O CPF sai mascarado por segurança. */
    exportData(customerId) {
      const c = this.customer(customerId);
      if (!c) throw new UserError('Cliente não encontrado.');
      const orders = db.all('SELECT * FROM orders WHERE customer_id = ? ORDER BY id', customerId).map((o) => ({
        numero: o.number, criado_em: o.created_at, situacao: o.status, pagamento: o.payment_status, total_centavos: o.total_cents,
        entrega: { tipo: o.delivery_kind, cep: o.ship_zip, estado: o.ship_state, cidade: o.ship_city, bairro: o.ship_district, rua: o.ship_street, numero: o.ship_number, complemento: o.ship_complement },
        itens: app.orders.items(o.id).map((i) => ({ sku: i.sku, nome: i.name, quantidade: i.qty, valor_unitario_centavos: i.unit_cents })),
      }));
      return {
        gerado_em: now(),
        cadastro: { nome: c.name, email: c.email, telefone: c.phone, cpf: this.cpfMasked(c) || null, email_confirmado_em: c.email_verified_at, aceita_novidades: !!c.marketing_consent, cadastrado_em: c.created_at },
        enderecos: this.customerAddresses(customerId).map((a) => ({ apelido: a.label, destinatario: a.recipient, cep: a.zip, estado: a.state, cidade: a.city, bairro: a.district, rua: a.street, numero: a.number, complemento: a.complement })),
        pedidos: orders,
        newsletter: db.all('SELECT email, consent_at, unsubscribed_at FROM newsletter_subscribers WHERE email = ?', c.email),
        mensagens_de_contato: db.all('SELECT subject, message, created_at FROM contact_messages WHERE email = ?', c.email),
        solicitacoes: db.all('SELECT kind, message, status, created_at FROM support_requests WHERE customer_id = ?', customerId),
      };
    },

    /**
     * Eliminação/anonimização a pedido do titular. Pedidos já realizados são mantidos (obrigações legais, fiscais e
     * de defesa em processos — LGPD art. 16), porém o vínculo com a conta é removido e o CPF apagado.
     * Recusa se houver pedido em andamento.
     */
    anonymize(ctx, customerId) {
      const c = this.customer(customerId);
      if (!c || c.status === 'anonymized') throw new UserError('Cliente não encontrado.');
      const open = db.value(`SELECT COUNT(*) FROM orders WHERE customer_id = ? AND status IN ${ACTIVE_ORDER}`, customerId);
      if (open) throw new UserError('Este cliente tem pedido em andamento. Conclua ou cancele os pedidos antes de anonimizar.');
      db.tx(() => {
        db.run("UPDATE customers SET name = 'Cliente removido', email = ?, phone = NULL, cpf_enc = NULL, password_hash = NULL, status = 'anonymized', marketing_consent = 0, admin_notes = NULL, block_reason = NULL WHERE id = ?", `removido-${c.id}-${randomToken(4)}@anonimizado.invalid`, customerId);
        db.run('DELETE FROM addresses WHERE customer_id = ?', customerId);
        db.run("DELETE FROM sessions WHERE kind = 'customer' AND user_id = ?", customerId);
        db.run('DELETE FROM auth_tokens WHERE customer_id = ?', customerId);
        db.run('DELETE FROM newsletter_subscribers WHERE email = ?', c.email);
        db.run('UPDATE orders SET customer_cpf_enc = NULL, customer_note = NULL WHERE customer_id = ?', customerId);
        db.run('UPDATE support_requests SET customer_id = NULL, message = ? WHERE customer_id = ?', '[removido a pedido do titular]', customerId);
        db.run("UPDATE contact_messages SET name = 'removido', email = 'removido', phone = NULL, message = '[removido a pedido do titular]' WHERE email = ?", c.email);
      });
      audit.staff(ctx, 'customer.anonymize', 'customer', customerId);
    },

    /** Solicitação feita pelo titular (formulário público ou conta). */
    createDataRequest({ email, kind, customerId = null, note = '' }) {
      email = trunc(email, 254).toLowerCase();
      if (!validEmail(email)) throw new UserError('Informe um e-mail válido.', 'email');
      if (!['access', 'deletion'].includes(kind)) throw new UserError('Tipo de solicitação inválido.');
      const dup = db.get("SELECT id FROM data_requests WHERE email = ? AND kind = ? AND status = 'open'", email, kind);
      if (dup) return dup.id;
      const id = db.run('INSERT INTO data_requests (customer_id, email, kind, note, created_at) VALUES (?,?,?,?,?)', customerId, email, kind, trunc(note, 500) || null, now()).id;
      app.email.notifyAdmin({ kind: 'lgpd', title: kind === 'access' ? 'Solicitação LGPD: acesso aos dados' : 'Solicitação LGPD: eliminação de dados', body: `Titular: ${email}. Prazo legal para resposta: 15 dias.`, link: '/admin/lgpd' });
      return id;
    },
    dataRequests: ({ status = '' } = {}) => db.all(`SELECT * FROM data_requests ${status ? 'WHERE status = ?' : ''} ORDER BY status = 'open' DESC, id DESC LIMIT 300`, ...(status ? [status] : [])),
    resolveDataRequest(ctx, id, status, note) {
      if (!['done', 'rejected'].includes(status)) throw new UserError('Situação inválida.');
      db.run("UPDATE data_requests SET status = ?, note = ?, completed_at = ? WHERE id = ? AND status = 'open'", status, trunc(note, 500) || null, now(), id);
      audit.staff(ctx, `lgpd.${status}`, 'data_request', id);
    },

    // ───── newsletter ─────
    subscribe({ email, ip, consentText }) {
      email = trunc(email, 254).toLowerCase();
      if (!validEmail(email)) throw new UserError('Informe um e-mail válido.');
      const ex = db.get('SELECT * FROM newsletter_subscribers WHERE email = ?', email);
      if (ex && !ex.unsubscribed_at) return { already: true };
      const token = ex?.unsub_token || randomToken(18);
      db.run('INSERT INTO newsletter_subscribers (email, consent_at, consent_text, ip, unsub_token, created_at) VALUES (?,?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET consent_at = excluded.consent_at, consent_text = excluded.consent_text, ip = excluded.ip, unsubscribed_at = NULL', email, now(), trunc(consentText, 200), ip || null, token, now());
      app.email.queue('newsletter_welcome', email, { unsubscribeUrl: `${cfg.baseUrl}/newsletter/cancelar/${token}` });
      return { already: false };
    },
    unsubscribe(token) {
      const r = db.run('UPDATE newsletter_subscribers SET unsubscribed_at = ? WHERE unsub_token = ? AND unsubscribed_at IS NULL', now(), String(token || ''));
      return r.changes > 0 || !!db.get('SELECT 1 FROM newsletter_subscribers WHERE unsub_token = ?', String(token || ''));
    },
    subscribers: () => db.all('SELECT id, email, consent_at, unsubscribed_at, created_at FROM newsletter_subscribers ORDER BY id DESC LIMIT 1000'),
    subscribersCsv() {
      const { toCsv } = require('../lib/util');
      return toCsv(['E-mail', 'Consentimento em', 'Cancelou em'], db.all('SELECT email, consent_at, unsubscribed_at FROM newsletter_subscribers WHERE unsubscribed_at IS NULL ORDER BY id').map((s) => [s.email, s.consent_at, s.unsubscribed_at || '']));
    },

    // ───── contato ─────
    submitContact({ name, email, phone, subject, message }) {
      name = trunc(name, 100); email = trunc(email, 254).toLowerCase(); phone = onlyDigits(phone); message = trunc(message, 2000);
      if (name.length < 2) throw new UserError('Informe seu nome.', 'name');
      if (!validEmail(email)) throw new UserError('Informe um e-mail válido.', 'email');
      if (phone && !validPhone(phone)) throw new UserError('Telefone inválido.', 'phone');
      if (message.length < 10) throw new UserError('Escreva uma mensagem com pelo menos 10 caracteres.', 'message');
      const id = db.run('INSERT INTO contact_messages (name, email, phone, subject, message, created_at) VALUES (?,?,?,?,?,?)', name, email, phone || null, trunc(subject, 120) || null, message, now()).id;
      app.email.notifyAdmin({ kind: 'contact', title: `Nova mensagem de ${name}`, body: message.slice(0, 200), link: '/admin/mensagens' });
      app.email.queue('contact_ack', email, { name });
      return id;
    },
    contacts: ({ status = '' } = {}) => db.all(`SELECT * FROM contact_messages ${status ? 'WHERE status = ?' : ''} ORDER BY id DESC LIMIT 300`, ...(status ? [status] : [])),
    setContactStatus(ctx, id, status) {
      if (!['open', 'answered', 'archived'].includes(status)) throw new UserError('Situação inválida.');
      db.run('UPDATE contact_messages SET status = ? WHERE id = ?', status, id);
      audit.staff(ctx, 'contact.status', 'contact', id, { status });
    },

    // ───── atendimento (pedidos de cancelamento/suporte da conta) ─────
    supportRequests: ({ status = '' } = {}) => db.all(`SELECT s.*, c.name AS customer_name, c.email AS customer_email, o.number AS order_number FROM support_requests s LEFT JOIN customers c ON c.id = s.customer_id LEFT JOIN orders o ON o.id = s.order_id ${status ? 'WHERE s.status = ?' : ''} ORDER BY s.status = 'open' DESC, s.id DESC LIMIT 300`, ...(status ? [status] : [])),
    resolveSupport(ctx, id, note) {
      db.run("UPDATE support_requests SET status = 'done', admin_note = ?, resolved_at = ? WHERE id = ?", trunc(note, 500) || null, now(), id);
      audit.staff(ctx, 'support.done', 'support', id);
    },

    // ───── notificações do painel ─────
    notifications: (limit = 40) => db.all('SELECT * FROM notifications ORDER BY id DESC LIMIT ?', limit),
    unreadCount: () => db.value('SELECT COUNT(*) FROM notifications WHERE read_at IS NULL'),
    markAllRead: () => db.run('UPDATE notifications SET read_at = ? WHERE read_at IS NULL', now()),
    pruneNotifications: () => db.run('DELETE FROM notifications WHERE created_at < ?', new Date(Date.now() - 90 * 86400000).toISOString()),
  };
  return crm;
}

module.exports = { makeCrm };
