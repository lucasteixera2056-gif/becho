'use strict';
/**
 * Pedidos: criação a partir do carrinho (com reserva de estoque e validação no servidor),
 * transições de status controladas e histórico.
 *  - Um pedido só vira "pago" pelo serviço de pagamentos (confirmação do provedor), nunca por ação do navegador ou do painel.
 *  - Cancelamento direto só para pedidos NÃO pagos; pedidos pagos saem por reembolso.
 */
const crypto = require('node:crypto');
const { now, addMinutes, randomToken, validEmail, validPhone, validCpf, onlyDigits, trunc, clamp, int, UFS, UserError, formatDate } = require('../lib/util');

const STATUS = {
  awaiting_payment: 'Aguardando pagamento', paid: 'Pagamento confirmado', preparing: 'Em preparação', shipped: 'Enviado',
  in_transit: 'Em transporte', delivered: 'Entregue', cancelled: 'Cancelado', refunded: 'Reembolsado',
};
const PAYMENT_STATUS = {
  pending: 'Pendente', paid: 'Pago', expired: 'Expirado', failed: 'Falhou', cancelled: 'Cancelado', refunded: 'Reembolsado', partially_refunded: 'Reembolso parcial',
};
// Transições operacionais que o painel pode fazer. "paid" e "refunded" só pelo fluxo financeiro; cancelar pedido pago só via reembolso.
const TRANSITIONS = {
  paid: ['preparing'],
  preparing: ['shipped', 'delivered'],
  shipped: ['in_transit', 'delivered'],
  in_transit: ['delivered'],
};

const statusLabel = (status, kind = 'ship') => {
  if (kind === 'pickup') return { preparing: 'Separando para retirada', shipped: 'Pronto para retirada', in_transit: 'Pronto para retirada', delivered: 'Retirado' }[status] || STATUS[status] || status;
  if (kind === 'local') return { shipped: 'Saiu para entrega', in_transit: 'Saiu para entrega' }[status] || STATUS[status] || status;
  return STATUS[status] || status;
};

function makeOrders(app) {
  const { db, cfg, settings, audit } = app;

  const pixMinutes = () => clamp(int(settings.get('pix_expiry_minutes'), 0) || cfg.payment.pixExpiryMinutes || 30, 10, 1440);
  const graceMinutes = () => clamp(int(settings.get('reservation_grace_minutes'), 10), 0, 120);

  function newNumber() {
    const d = new Date(Date.now() + cfg.tzOffsetMinutes * 60000);
    const p = (n) => String(n).padStart(2, '0');
    const ymd = `${String(d.getUTCFullYear()).slice(2)}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}`;
    return `BC-${ymd}-${String(crypto.randomInt(0, 10000)).padStart(4, '0')}`;
  }

  function addHistory(orderId, from, to, note, actor) {
    db.run('INSERT INTO order_history (order_id, from_status, to_status, note, actor, created_at) VALUES (?,?,?,?,?,?)', orderId, from, to, note || null, actor, now());
  }

  const orders = {
    STATUS, PAYMENT_STATUS, TRANSITIONS, statusLabel, addHistory, pixMinutes, graceMinutes,

    /** Valida os dados do checkout (sem tocar no banco). Retorna os campos normalizados. */
    parseCheckout(b, { requiresCpf, pickupOnly = false } = {}) {
      const f = {
        name: trunc(b.name, 100), email: trunc(b.email, 254).toLowerCase(), phone: onlyDigits(b.phone), cpf: onlyDigits(b.cpf),
        zip: onlyDigits(b.zip), state: trunc(b.state, 2).toUpperCase(), city: trunc(b.city, 80), district: trunc(b.district, 80),
        street: trunc(b.street, 120), number: trunc(b.number, 15), complement: trunc(b.complement, 60),
        note: trunc(b.note, 300), marketing: !!b.marketing, shipping_key: trunc(b.shipping_key, 40), coupon_code: trunc(b.coupon_code, 30).toUpperCase(),
      };
      if (f.name.length < 3 || !/\s/.test(f.name)) throw new UserError('Informe seu nome completo.', 'name');
      if (!validEmail(f.email)) throw new UserError('Informe um e-mail válido.', 'email');
      if (!validPhone(f.phone)) throw new UserError('Informe um telefone válido com DDD.', 'phone');
      if ((requiresCpf || f.cpf) && !validCpf(f.cpf)) throw new UserError(requiresCpf ? 'Informe um CPF válido (exigido pelo meio de pagamento).' : 'CPF inválido.', 'cpf');
      if (!f.shipping_key) throw new UserError('Escolha a forma de entrega.', 'shipping');
      return f;
    },

    requireAddress(f) {
      if (f.zip.length !== 8) throw new UserError('Informe um CEP válido (8 dígitos).', 'zip');
      if (!UFS.includes(f.state)) throw new UserError('Selecione o estado.', 'state');
      for (const [k, label] of [['city', 'a cidade'], ['district', 'o bairro'], ['street', 'a rua'], ['number', 'o número']]) if (!f[k]) throw new UserError(`Informe ${label}.`, k);
    },

    /**
     * Cria o pedido e reserva as peças. Retorna o pedido (ainda sem cobrança Pix).
     * `shippingOpt` já foi resolvido no servidor; `couponResult` idem.
     */
    createReserved({ cart, form, shippingOpt, couponResult, customerId }) {
      const t = now();
      const expiresAt = addMinutes(t, pixMinutes());
      const reserveUntil = addMinutes(expiresAt, graceMinutes());
      const subtotal = cart.items.filter((i) => !i.unavailable).reduce((s, i) => s + i.total_cents, 0);
      const discount = couponResult?.discount_cents || 0;
      const shipping = shippingOpt.price_cents;
      const total = subtotal - discount + shipping;
      if (total <= 0) throw new UserError('O total do pedido precisa ser maior que zero.');
      return db.tx(() => {
        let id = null;
        let number = '';
        for (let i = 0; i < 6 && !id; i++) {
          number = newNumber();
          try {
            const pickup = shippingOpt.delivery_kind === 'pickup';
            id = db.run(
              `INSERT INTO orders (number, public_token, customer_id, status, payment_status, customer_name, customer_email, customer_phone, customer_cpf_enc, delivery_kind,
                ship_zip, ship_state, ship_city, ship_district, ship_street, ship_number, ship_complement, shipping_method_id, shipping_method_name, shipping_eta_text,
                shipping_cents, subtotal_cents, discount_cents, total_cents, coupon_id, coupon_code, customer_note, marketing_consent, created_at, expires_at)
               VALUES (?,?,?, 'awaiting_payment','pending', ?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?, ?,?,?,?, ?,?,?,?, ?,?)`,
              number, randomToken(18), customerId, form.name, form.email, form.phone, form.cpf ? app.cipher.encrypt(form.cpf) : null, shippingOpt.delivery_kind,
              pickup ? null : form.zip, pickup ? null : form.state, pickup ? null : form.city, pickup ? null : form.district, pickup ? null : form.street, pickup ? null : form.number, pickup ? null : form.complement || null,
              shippingOpt.method_id, shippingOpt.name, shippingOpt.eta_text || null,
              shipping, subtotal, discount, total, couponResult?.coupon.id ?? null, couponResult?.coupon.code ?? null, form.note || null, form.marketing ? 1 : 0, t, expiresAt
            ).id;
          } catch (e) {
            if (!/UNIQUE/i.test(e.message)) throw e;
          }
        }
        if (!id) throw new Error('Não foi possível gerar o número do pedido.');
        const reserveItems = [];
        for (const it of cart.items) {
          if (it.unavailable) continue;
          const p = it.product;
          db.run('INSERT INTO order_items (order_id, product_id, sku, name, image, unit_cents, qty) VALUES (?,?,?,?,?,?,?)', id, p.id, p.sku, p.name, p.image || null, it.unit_cents, it.qty);
          reserveItems.push({ product_id: p.id, qty: it.qty, name: p.name });
        }
        app.stock.reserve(id, reserveItems, reserveUntil);
        if (couponResult) app.coupons.redeem(couponResult.coupon.id);
        addHistory(id, null, 'awaiting_payment', 'Pedido criado', 'cliente');
        return db.get('SELECT * FROM orders WHERE id = ?', id);
      });
    },

    // ───── consultas ─────
    get: (id) => db.get('SELECT * FROM orders WHERE id = ?', id),
    byToken: (token) => db.get('SELECT * FROM orders WHERE public_token = ?', String(token || '')),
    byNumber: (n) => db.get('SELECT * FROM orders WHERE number = ?', String(n || '')),
    items: (orderId) => db.all('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', orderId),
    history: (orderId) => db.all('SELECT * FROM order_history WHERE order_id = ? ORDER BY id DESC', orderId),
    forCustomer: (customerId) => db.all('SELECT * FROM orders WHERE customer_id = ? ORDER BY id DESC', customerId),

    adminList({ q, status, payment_status, from, to, page = 1, perPage = 30, attention = false } = {}) {
      const where = ['1 = 1'];
      const params = [];
      const s = trunc(q, 80);
      if (s) {
        const like = `%${s.replace(/[\\%_]/g, '\\$&')}%`;
        where.push("(o.number LIKE ? ESCAPE '\\' OR o.customer_name LIKE ? ESCAPE '\\' OR o.customer_email LIKE ? ESCAPE '\\' OR o.customer_phone LIKE ? ESCAPE '\\')");
        params.push(like, like, like, like);
      }
      if (status && STATUS[status]) { where.push('o.status = ?'); params.push(status); }
      if (payment_status && PAYMENT_STATUS[payment_status]) { where.push('o.payment_status = ?'); params.push(payment_status); }
      const dayStart = (d) => (/^\d{4}-\d{2}-\d{2}$/.test(d || '') ? new Date(new Date(`${d}T00:00:00.000Z`).getTime() - cfg.tzOffsetMinutes * 60000).toISOString() : null);
      const f = dayStart(from);
      const tEnd = dayStart(to);
      if (f) { where.push('o.created_at >= ?'); params.push(f); }
      if (tEnd) { where.push('o.created_at < ?'); params.push(new Date(new Date(tEnd).getTime() + 86400000).toISOString()); }
      if (attention) where.push('o.needs_attention = 1');
      const base = `FROM orders o WHERE ${where.join(' AND ')}`;
      const total = db.value(`SELECT COUNT(*) ${base}`, ...params);
      const pages = Math.max(1, Math.ceil(total / perPage));
      const cur = Math.min(Math.max(1, int(page, 1)), pages);
      const rows = db.all(`SELECT o.*, (SELECT COALESCE(SUM(qty),0) FROM order_items i WHERE i.order_id = o.id) AS items_count ${base} ORDER BY o.id DESC LIMIT ? OFFSET ?`, ...params, perPage, (cur - 1) * perPage);
      return { rows, total, page: cur, pages };
    },

    statusCounts() {
      const out = {};
      for (const r of db.all('SELECT status, COUNT(*) AS n FROM orders GROUP BY status')) out[r.status] = r.n;
      return out;
    },

    // ───── transições ─────
    /** Transição operacional pelo painel. Pagamento/reembolso NÃO passam por aqui. */
    setStatus(orderId, to, { actor, note = '', ctx = null } = {}) {
      const o = this.get(orderId);
      if (!o) throw new UserError('Pedido não encontrado.');
      if (to === 'cancelled') throw new UserError('Para cancelar use a ação "Cancelar pedido" (não pagos) ou "Reembolsar" (pagos).');
      if (['paid', 'refunded', 'awaiting_payment'].includes(to)) throw new UserError('Este status só é definido automaticamente pelo sistema de pagamentos.');
      if (!(TRANSITIONS[o.status] || []).includes(to)) throw new UserError(`Não é possível ir de "${statusLabel(o.status, o.delivery_kind)}" para "${statusLabel(to, o.delivery_kind)}".`);
      db.tx(() => {
        db.run('UPDATE orders SET status = ? WHERE id = ?', to, orderId);
        addHistory(orderId, o.status, to, note, actor);
        if (['shipped', 'in_transit', 'delivered'].includes(to)) {
          app.shipping.upsertShipment(orderId, { status: to, note });
        }
      });
      if (ctx) audit.staff(ctx, 'order.status', 'order', orderId, { from: o.status, to });
      const fresh = this.get(orderId);
      const mail = { preparing: 'order_preparing', shipped: 'order_shipped', delivered: 'order_delivered' }[to];
      if (mail) app.email.queue(mail, fresh.customer_email, { name: fresh.customer_name, order: fresh, shipment: app.shipping.shipment(orderId), note: to === 'delivered' && fresh.delivery_kind === 'pickup' ? 'Obrigada por retirar sua compra!' : '' });
      return fresh;
    },

    /** Código de rastreio / transportadora / link / prazo. */
    updateTracking(orderId, b, ctx) {
      const o = this.get(orderId);
      if (!o) throw new UserError('Pedido não encontrado.');
      if (!['preparing', 'shipped', 'in_transit', 'delivered', 'paid'].includes(o.status)) throw new UserError('O rastreio só pode ser informado após o pagamento.');
      app.shipping.upsertShipment(orderId, { carrier: b.carrier, tracking_code: b.tracking_code, tracking_url: b.tracking_url, eta_text: b.eta_text, status: undefined, note: trunc(b.note, 300) || 'Rastreio atualizado' });
      addHistory(orderId, o.status, o.status, 'Dados de rastreio atualizados', ctx?.staff ? `${ctx.staff.name}` : 'sistema');
      if (ctx) audit.staff(ctx, 'order.tracking', 'order', orderId, { code: b.tracking_code });
      return o;
    },

    /** Altera o status do envio (evento de rastreamento visível ao cliente) sem mudar o status do pedido. */
    addTrackingEvent(orderId, note, ctx) {
      const o = this.get(orderId);
      const s = app.shipping.shipment(orderId);
      if (!o || !s) throw new UserError('Registre o envio antes de adicionar eventos.');
      if (!trunc(note, 300)) throw new UserError('Descreva o evento.');
      app.shipping.upsertShipment(orderId, { status: s.status, note });
      if (ctx) audit.staff(ctx, 'order.tracking_event', 'order', orderId);
    },

    /** Cancela um pedido NÃO pago, libera reservas e devolve o cupom. */
    async cancelUnpaid(orderId, { actor, reason = '', expired = false, silent = false, byCustomer = false } = {}) {
      let o = this.get(orderId);
      if (!o) throw new UserError('Pedido não encontrado.');
      if (o.status !== 'awaiting_payment') throw new UserError('Só é possível cancelar pedidos que ainda não foram pagos.');
      // Antes de cancelar, confirma com o provedor que o Pix não foi pago nesse meio tempo.
      const pay = app.payments.openPayment(orderId);
      if (pay && pay.provider_payment_id) {
        const r = await app.payments.refreshFromProvider(pay.id, 'cancel-check');
        if (r?.outcome === 'paid') throw new UserError('O pagamento deste pedido acabou de ser confirmado e ele não pode mais ser cancelado.');
        await app.payments.cancelAtProvider(pay);
      }
      let result = null;
      db.tx(() => {
        o = this.get(orderId);
        if (o.status !== 'awaiting_payment') return;
        const t = now();
        db.run("UPDATE payments SET status = ?, updated_at = ? WHERE order_id = ? AND status = 'pending'", expired ? 'expired' : 'cancelled', t, orderId);
        db.run("UPDATE orders SET status = 'cancelled', payment_status = ?, cancelled_at = ? WHERE id = ?", expired ? 'expired' : 'cancelled', t, orderId);
        app.stock.release(orderId);
        app.coupons.giveBack(o.coupon_id);
        addHistory(orderId, 'awaiting_payment', 'cancelled', reason || (expired ? 'Pix expirou sem pagamento' : 'Cancelado'), actor);
        result = true;
      });
      if (!result) throw new UserError('O pedido já mudou de situação. Atualize a página.');
      const fresh = this.get(orderId);
      if (!silent) app.email.queue(expired ? 'payment_expired' : 'order_cancelled', fresh.customer_email, { name: fresh.customer_name, order: fresh });
      audit.log({ type: byCustomer ? 'customer' : 'system', label: actor }, expired ? 'order.expired' : 'order.cancelled', 'order', orderId, { reason });
      return fresh;
    },

    flagAttention(orderId, note) {
      db.run('UPDATE orders SET needs_attention = 1, attention_note = ? WHERE id = ?', trunc(note, 500), orderId);
    },
    clearAttention(orderId, ctx) {
      db.run('UPDATE orders SET needs_attention = 0, attention_note = NULL WHERE id = ?', orderId);
      if (ctx) audit.staff(ctx, 'order.attention_cleared', 'order', orderId);
    },

    // ───── pedidos do cliente ─────
    /** O cliente logado só enxerga os próprios pedidos (e só após confirmar o e-mail). */
    ownedBy(customer, number) {
      if (!customer?.email_verified_at) return null;
      const o = this.byNumber(number);
      return o && o.customer_id === customer.id ? o : null;
    },
    expiresLabel: (o) => formatDate(o.expires_at, { offsetMinutes: cfg.tzOffsetMinutes }),

    requestSupport(customer, orderId, kind, message) {
      message = trunc(message, 1000);
      if (message.length < 5) throw new UserError('Descreva o que você precisa.');
      const o = orderId ? this.get(orderId) : null;
      if (o && o.customer_id !== customer.id) throw new UserError('Pedido não encontrado.');
      const id = db.run('INSERT INTO support_requests (customer_id, order_id, kind, message, created_at) VALUES (?,?,?,?,?)', customer.id, o?.id ?? null, kind, message, now()).id;
      app.email.notifyAdmin({ kind: 'support', title: kind === 'cancel' ? `Pedido de cancelamento${o ? ` — ${o.number}` : ''}` : `Novo pedido de atendimento${o ? ` — ${o.number}` : ''}`, body: `${customer.name}: ${message.slice(0, 200)}`, link: '/admin/solicitacoes' });
      return id;
    },
  };
  return orders;
}

module.exports = { makeOrders, STATUS, PAYMENT_STATUS, statusLabel };
