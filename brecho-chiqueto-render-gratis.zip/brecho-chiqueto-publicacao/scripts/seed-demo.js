'use strict';
/**
 * DADOS DE DEMONSTRAÇÃO — somente para desenvolvimento/teste visual.
 * Cria categorias e peças FICTÍCIAS (nome começa com "[DEMO]") com imagens geradas por código.
 * Recusa rodar em produção. Nada aqui representa produto, preço ou estoque reais do brechó.
 * Para remover: apague os produtos "[DEMO]" no painel (ou use um banco novo).
 */
const zlib = require('node:zlib');
const { buildConfig } = require('../src/config');
const { buildApp } = require('../src/app');
const { saveImage } = require('../src/lib/images');

const cfg = buildConfig();
if (cfg.isProd) {
  console.error('seed-demo não pode ser executado em produção.');
  process.exit(1);
}
const app = buildApp(cfg);

function png(w, h, c1, c2) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) {
      const t = (y / h) * 0.7 + (x / w) * 0.3;
      const o = y * (w * 3 + 1) + 1 + x * 3;
      for (let k = 0; k < 3; k++) raw[o + k] = Math.round(c1[k] + (c2[k] - c1[k]) * t);
    }
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

const cats = {
  Vestidos: app.catalog.saveCategory({ name: 'Vestidos' }),
  Blusas: app.catalog.saveCategory({ name: 'Blusas' }),
  Calças: app.catalog.saveCategory({ name: 'Calças' }),
  Bolsas: app.catalog.saveCategory({ name: 'Bolsas e acessórios' }),
};
const palette = [[140, 47, 57, 214, 170, 160], [176, 141, 87, 240, 224, 196], [70, 90, 110, 200, 210, 224], [90, 110, 80, 214, 226, 200], [60, 50, 60, 190, 170, 190], [180, 120, 90, 244, 214, 190]];
const items = [
  ['Vestido midi floral', 'Vestidos', '129,90', null, 'M', 'Muito bom', 'Marca Exemplo', 'Estampado', 1],
  ['Vestido preto básico', 'Vestidos', '89,90', '69,90', 'P', 'Excelente', 'Marca Exemplo', 'Preto', 1],
  ['Blusa de seda', 'Blusas', '64,90', null, 'M', 'Novo com etiqueta', 'Marca Teste', 'Off white', 1],
  ['Camisa listrada', 'Blusas', '49,90', null, 'G', 'Bom', 'Marca Teste', 'Azul', 1],
  ['Calça alfaiataria', 'Calças', '99,90', null, '38', 'Muito bom', 'Marca Exemplo', 'Caramelo', 1],
  ['Jeans reto', 'Calças', '79,90', '59,90', '40', 'Bom', 'Marca Teste', 'Azul', 1],
  ['Bolsa estruturada', 'Bolsas', '149,90', null, 'Único', 'Excelente', 'Marca Exemplo', 'Vinho', 1],
  ['Lenço estampado', 'Bolsas', '29,90', null, 'Único', 'Muito bom', '', 'Colorido', 3],
];
items.forEach(([name, cat, price, promo, size, condition, brand, color, qty], i) => {
  const f = app.catalog.parseProductForm({
    name: `[DEMO] ${name}`, price, promo: promo || '', category_id: String(cats[cat]), size, condition, brand, color, quantity: String(qty),
    status: 'published', featured: i % 3 === 0 ? '1' : '', weight_g: '400', measures: 'Busto 90 cm · Comprimento 100 cm (medidas fictícias de demonstração)',
    defects: i === 3 ? 'Pequena marca discreta na barra (peça de demonstração).' : '', description: 'Peça de DEMONSTRAÇÃO para teste visual da loja. Não existe no estoque real.',
  });
  const id = app.catalog.createProduct(f);
  const c = palette[i % palette.length];
  for (let n = 0; n < 2; n++) {
    const file = saveImage(cfg.uploadDir, png(450, 600, c.slice(0, 3).map((v) => v - n * 20), c.slice(3).map((v) => v - n * 15)));
    app.catalog.addImage(id, file.filename || file, `Foto ${n + 1} de demonstração`);
  }
});
app.shipping.saveMethod({ kind: 'pickup', name: 'Retirada combinada (DEMO)', active: true });
app.shipping.saveMethod({ kind: 'fixed', name: 'Frete fixo (DEMO)', price: '18,00', free_over: '300,00', eta_text: 'Prazo de demonstração', active: true });
console.log(`Dados DEMO criados: ${items.length} peças, ${Object.keys(cats).length} categorias, 2 formas de entrega.`);
app.close();
