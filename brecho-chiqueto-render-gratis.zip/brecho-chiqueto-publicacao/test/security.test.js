'use strict';
/** Segurança HTTP: autenticação, CSRF, permissões por função, acesso a dados de terceiros, XSS, uploads e vazamento de segredos. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { makeTestApp, seedBasics, ctxFor, placeOrder } = require('./helpers');
const { startServer, Client, rawGet, staffLogin, customerLogin, pngBuffer } = require('./http-helpers');

async function boot(t, env) {
  const app = makeTestApp(env);
  const srv = await startServer(app);
  t.after(async () => { await srv.close(); app.close(); });
  return { app, base: srv.base };
}

test('painel exige login; formulários exigem token CSRF e origem do próprio site', async (t) => {
  const { app, base } = await boot(t);
  const c = new Client(base);
  const home = await c.get('/admin');
  assert.equal(home.status, 303);
  assert.match(home.location, /\/admin\/login/);
  for (const p of ['/admin/pedidos', '/admin/produtos', '/admin/configuracoes', '/admin/relatorios/pedidos.csv', '/admin/auditoria']) {
    assert.equal((await c.get(p)).status, 303, `${p} sem login deve redirecionar`);
  }
  // sem token CSRF
  await app.auth.createStaff(null, { name: 'Dona', email: 'dona@loja.test', password: 'SenhaForte-2026!', role: 'admin', mustChange: false });
  await c.get('/admin/login');
  const semToken = await c.req('POST', '/admin/login', { form: { _csrf: 'invalido', email: 'dona@loja.test', password: 'SenhaForte-2026!' } });
  assert.equal(semToken.status, 403);
  // origem de outro site
  const outra = await c.post('/admin/login', { email: 'dona@loja.test', password: 'SenhaForte-2026!' }, { headers: { origin: 'http://evil.test' } });
  assert.equal(outra.status, 403);
  // mesma origem + token: funciona
  const ok = await c.post('/admin/login', { email: 'dona@loja.test', password: 'SenhaForte-2026!' });
  assert.equal(ok.status, 303);
  // cookie do painel: HttpOnly, SameSite e restrito a /admin
  const setc = ok.headers.getSetCookie().find((x) => x.startsWith('bc_as='));
  assert.ok(setc, 'cookie de sessão do painel');
  assert.match(setc, /HttpOnly/);
  assert.match(setc, /SameSite=(Lax|Strict)/);
  assert.match(setc, /Path=\/admin/);
  // POST autenticado sem token também é recusado
  const p = await c.req('POST', '/admin/categorias', { form: { _csrf: 'x', name: 'Hack' } });
  assert.equal(p.status, 403);
  assert.equal(app.db.value('SELECT COUNT(*) FROM categories'), 0);
});

test('login do painel: mensagem genérica, bloqueio por tentativas e sem redirecionamento aberto', async (t) => {
  const { app, base } = await boot(t);
  await app.auth.createStaff(null, { name: 'Gerente', email: 'g@loja.test', password: 'SenhaForte-2026!', role: 'gerente', mustChange: false });
  const c = new Client(base);
  await c.get('/admin/login');
  const semUsuario = await c.post('/admin/login', { email: 'naoexiste@loja.test', password: 'qualquer-senha-123' });
  const senhaErrada = await c.post('/admin/login', { email: 'g@loja.test', password: 'senha-errada-123' });
  assert.equal(semUsuario.status, 422);
  assert.equal(senhaErrada.status, 422);
  const msg = (r) => /E-mail ou senha incorretos/.test(r.text);
  assert.ok(msg(semUsuario) && msg(senhaErrada), 'mesma mensagem para usuário inexistente e senha errada');
  // força bruta
  let travou = false;
  for (let i = 0; i < 10; i++) {
    const r = await c.post('/admin/login', { email: 'g@loja.test', password: `errada-${i}-xxxxx` });
    if (/Muitas tentativas/.test(r.text)) { travou = true; break; }
  }
  assert.ok(travou, 'bloqueia após várias tentativas');
  const certa = await c.post('/admin/login', { email: 'g@loja.test', password: 'SenhaForte-2026!' });
  assert.equal(certa.status, 422, 'enquanto bloqueado, nem a senha certa entra');
  // redirecionamento aberto
  await app.auth.createStaff(null, { name: 'Outra', email: 'o@loja.test', password: 'SenhaForte-2026!', role: 'gerente', mustChange: false });
  const c2 = new Client(base);
  await c2.get('/admin/login');
  const r = await c2.post('/admin/login', { email: 'o@loja.test', password: 'SenhaForte-2026!', next: 'https://evil.test/roubo' });
  assert.equal(r.status, 303);
  assert.ok(!/evil\.test/.test(r.location), `não pode redirecionar para fora: ${r.location}`);
  const r2 = await new Client(base).get('/admin/login?next=//evil.test');
  assert.ok(!/evil\.test/.test(r2.text.replace(/<[^>]+>/g, ' ')) || !/value="\/\/evil/.test(r2.text));
});

test('primeiro acesso com senha temporária obriga a trocar antes de usar o painel', async (t) => {
  const { app, base } = await boot(t);
  await app.auth.createStaff(null, { name: 'Nova', email: 'nova@loja.test', password: 'Temporaria-123!', role: 'admin', mustChange: true });
  const c = new Client(base);
  await c.get('/admin/login');
  const r = await c.post('/admin/login', { email: 'nova@loja.test', password: 'Temporaria-123!' });
  assert.equal(r.status, 303);
  assert.match(r.location, /minha-conta\?troca=1/);
  for (const p of ['/admin', '/admin/pedidos', '/admin/produtos']) {
    const x = await c.get(p);
    assert.equal(x.status, 303, `${p} bloqueado até trocar a senha`);
    assert.match(x.location, /minha-conta/);
  }
  const t1 = await c.get('/admin/minha-conta?troca=1');
  assert.equal(t1.status, 200);
  const fraca = await c.post('/admin/minha-conta/senha', { current: 'Temporaria-123!', password: '123', confirm: '123' });
  assert.equal(fraca.status, 303);
  assert.equal((await c.get('/admin/pedidos')).status, 303, 'senha fraca não libera o painel');
  const boa = await c.post('/admin/minha-conta/senha', { current: 'Temporaria-123!', password: 'MinhaNovaSenha-2026', confirm: 'MinhaNovaSenha-2026' });
  assert.equal(boa.status, 303);
  assert.equal((await c.get('/admin/pedidos')).status, 200);
});

const MATRIX = [
  // [função, caminho, status esperado]
  ['estoquista', '/admin/produtos', 200], ['estoquista', '/admin/estoque', 200], ['estoquista', '/admin/pedidos', 403], ['estoquista', '/admin/clientes', 403],
  ['estoquista', '/admin/relatorios', 403], ['estoquista', '/admin/configuracoes', 403], ['estoquista', '/admin/funcionarios', 403], ['estoquista', '/admin/auditoria', 403],
  ['estoquista', '/admin/emails', 403], ['estoquista', '/admin/pagamentos', 403], ['estoquista', '/admin/categorias', 403], ['estoquista', '/admin/cupons', 403],
  ['atendente', '/admin/pedidos', 200], ['atendente', '/admin/clientes', 200], ['atendente', '/admin/mensagens', 200], ['atendente', '/admin/emails', 200],
  ['atendente', '/admin/produtos', 403], ['atendente', '/admin/relatorios', 403], ['atendente', '/admin/configuracoes', 403], ['atendente', '/admin/cupons', 403],
  ['atendente', '/admin/relatorios/clientes.csv', 403], ['atendente', '/admin/funcionarios', 403], ['atendente', '/admin/pagamentos', 403],
  ['gerente', '/admin/produtos', 200], ['gerente', '/admin/relatorios', 200], ['gerente', '/admin/cupons', 200], ['gerente', '/admin/pedidos', 200],
  ['gerente', '/admin/configuracoes', 403], ['gerente', '/admin/funcionarios', 403], ['gerente', '/admin/pagamentos', 403], ['gerente', '/admin/auditoria', 403],
  ['gerente', '/admin/relatorios/clientes.csv', 403], ['gerente', '/admin/lgpd', 403],
  ['admin', '/admin/configuracoes', 200], ['admin', '/admin/funcionarios', 200], ['admin', '/admin/auditoria', 200], ['admin', '/admin/pagamentos', 200],
  ['admin', '/admin/funcionarios/permissoes', 403],
];

test('permissões por função (RBAC) valem no servidor, não só no menu', async (t) => {
  const { app, base } = await boot(t);
  const clients = {};
  for (const role of ['estoquista', 'atendente', 'gerente', 'admin']) clients[role] = await staffLogin(app, base, { role, email: `${role}@loja.test` });
  for (const [role, path, expected] of MATRIX) {
    const r = await clients[role].get(path);
    assert.equal(r.status, expected, `${role} GET ${path}`);
  }
  // o menu só mostra o que a função pode usar
  const menu = (await clients.estoquista.get('/admin/produtos')).text;
  assert.ok(!/href="\/admin\/pedidos"/.test(menu) && !/href="\/admin\/configuracoes"/.test(menu), 'menu do estoquista esconde áreas proibidas');
  assert.match(menu, /href="\/admin\/estoque"/);
});

test('ações sensíveis negadas sem permissão: reembolso, configurações, funcionários, cupons', async (t) => {
  const { app, base } = await boot(t);
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido seguro', '80,00');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  await require('./helpers').deliverWebhook(app, app.providers.get('mock').simulatePay(pay.provider_payment_id));
  assert.equal(app.orders.get(order.id).status, 'paid');

  const gerente = await staffLogin(app, base, { role: 'gerente', email: 'gerente@loja.test' });
  const atendente = await staffLogin(app, base, { role: 'atendente', email: 'atendente@loja.test' });
  const estoquista = await staffLogin(app, base, { role: 'estoquista', email: 'estoquista@loja.test' });

  for (const [who, c] of [['gerente', gerente], ['atendente', atendente], ['estoquista', estoquista]]) {
    const r = await c.post(`/admin/pedidos/${order.id}/reembolsar`, { amount: '10,00' });
    assert.equal(r.status, 403, `${who} não reembolsa`);
  }
  assert.equal(app.db.value('SELECT COUNT(*) FROM refunds'), 0);
  assert.equal((await gerente.post('/admin/configuracoes/loja', { store_name: 'Invadida' })).status, 403);
  assert.notEqual(app.settings.get('store_name'), 'Invadida');
  assert.equal((await atendente.post('/admin/cupons', { code: 'GRATIS100', kind: 'percent', value: '100', active: '1' })).status, 403);
  assert.equal(app.db.value('SELECT COUNT(*) FROM coupons'), 0);
  assert.equal((await gerente.post('/admin/funcionarios', { name: 'X', email: 'x@loja.test', password: 'SenhaForte-2026!', role: 'admin' })).status, 403);
  assert.equal((await estoquista.post(`/admin/pedidos/${order.id}/status`, { to: 'preparing' })).status, 403);
  assert.equal(app.orders.get(order.id).status, 'paid');
});

test('painel não permite marcar pagamento como recebido nem cancelar pedido pago', async (t) => {
  const { app, base } = await boot(t);
  const { mk, fixed } = seedBasics(app);
  const p = mk('Saia', '60,00');
  const { order } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  for (const to of ['paid', 'delivered', 'refunded', 'shipped']) {
    await adm.post(`/admin/pedidos/${order.id}/status`, { to });
    assert.equal(app.orders.get(order.id).status, 'awaiting_payment', `status "${to}" não pode ser forçado em pedido não pago`);
  }
  assert.equal(app.orders.get(order.id).payment_status, 'pending');
  assert.equal(app.db.value("SELECT COUNT(*) FROM payments WHERE status = 'paid'"), 0);
  const html = (await adm.get(`/admin/pedidos/${order.id}`)).text;
  assert.ok(!/marcar como pago|dar baixa|confirmar pagamento manual/i.test(html));
});

test('escalonamento de privilégio: funcionários só gerenciam funções abaixo da sua', async (t) => {
  const { app, base } = await boot(t);
  await app.auth.createStaff(null, { name: 'Super', email: 'super@loja.test', password: 'SenhaForte-2026!', role: 'superadmin', mustChange: false });
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  const ger = await staffLogin(app, base, { role: 'gerente', email: 'ger@loja.test' });
  const superId = app.db.get("SELECT id FROM staff_users WHERE email = 'super@loja.test'").id;
  const admId = app.db.get("SELECT id FROM staff_users WHERE email = 'adm@loja.test'").id;
  const gerId = app.db.get("SELECT id FROM staff_users WHERE email = 'ger@loja.test'").id;

  // admin não cria superadmin nem outro admin
  for (const role of ['superadmin', 'admin']) {
    await adm.post('/admin/funcionarios', { name: 'Intruso', email: `${role}-novo@loja.test`, password: 'SenhaForte-2026!', role });
    assert.equal(app.db.get('SELECT 1 FROM staff_users WHERE email = ?', `${role}-novo@loja.test`), undefined, `admin não cria ${role}`);
  }
  // admin não mexe no superadmin (rebaixar, desativar, redefinir senha)
  await adm.post(`/admin/funcionarios/${superId}`, { name: 'Super', role: 'atendente', active: '' });
  assert.equal(app.db.get('SELECT role, active FROM staff_users WHERE id = ?', superId).role, 'superadmin');
  assert.equal(app.db.get('SELECT active FROM staff_users WHERE id = ?', superId).active, 1);
  const antes = app.db.get('SELECT password_hash FROM staff_users WHERE id = ?', superId).password_hash;
  await adm.post(`/admin/funcionarios/${superId}/senha`, { password: 'SenhaDoInvasor-123' });
  assert.equal(app.db.get('SELECT password_hash FROM staff_users WHERE id = ?', superId).password_hash, antes);
  // ninguém altera a própria função
  await adm.post(`/admin/funcionarios/${admId}`, { name: 'Eu', role: 'superadmin', active: '1' });
  assert.equal(app.db.get('SELECT role FROM staff_users WHERE id = ?', admId).role, 'admin');
  // gerente não acessa gestão de funcionários
  assert.equal((await ger.post(`/admin/funcionarios/${gerId}`, { name: 'Eu', role: 'admin', active: '1' })).status, 403);
  assert.equal(app.db.get('SELECT role FROM staff_users WHERE id = ?', gerId).role, 'gerente');
  // matriz de permissões: só o superadmin
  assert.equal((await adm.post('/admin/funcionarios/permissoes', { p_gerente: 'orders.refund' })).status, 403);
  assert.ok(!app.permissions.forRole('gerente').has('orders.refund'));
  // superadmin pode
  const sup = await staffLogin(app, base, { role: 'superadmin', email: 'super@loja.test' });
  await sup.post('/admin/funcionarios/permissoes', { p_gerente: ['orders.view', 'orders.refund'] });
  assert.ok(app.permissions.forRole('gerente').has('orders.refund'));
  // e o último superadmin ativo não pode ser desativado por outro superadmin sem restar nenhum
  assert.ok(app.db.value("SELECT COUNT(*) FROM staff_users WHERE role = 'superadmin' AND active = 1") >= 1);
});

test('cliente só vê os próprios pedidos (sem acesso a pedidos de terceiros)', async (t) => {
  const { app, base } = await boot(t);
  const { mk, fixed } = seedBasics(app);
  const a = await customerLogin(app, base, { email: 'ana@cliente.test', name: 'Ana Cliente' });
  const b = await customerLogin(app, base, { email: 'bia@cliente.test', name: 'Bia Cliente' });
  const pa = mk('Peça da Ana', '50,00');
  const pb = mk('Peça da Bia', '70,00');
  const oa = (await placeOrder(app, ctxFor('visit-a'), { items: [pa], shippingKey: fixed, customerId: a.id, form: { email: 'ana@cliente.test' } })).order;
  const ob = (await placeOrder(app, ctxFor('visit-b'), { items: [pb], shippingKey: fixed, customerId: b.id, form: { email: 'bia@cliente.test' } })).order;

  assert.equal((await a.client.get(`/minha-conta/pedidos/${oa.number}`)).status, 200);
  const roubo = await a.client.get(`/minha-conta/pedidos/${ob.number}`);
  assert.ok([403, 404].includes(roubo.status), `Ana não pode ver pedido da Bia (veio ${roubo.status})`);
  assert.ok(!roubo.text.includes('Peça da Bia') && !roubo.text.includes('bia@cliente.test'));
  const lista = (await a.client.get('/minha-conta/pedidos')).text;
  assert.ok(lista.includes(oa.number) && !lista.includes(ob.number));
  // solicitação de atendimento em pedido alheio não grava nada
  await a.client.post(`/minha-conta/pedidos/${ob.number}/solicitacao`, { kind: 'cancel', message: 'Quero cancelar o pedido de outra pessoa' });
  assert.equal(app.db.value('SELECT COUNT(*) FROM support_requests WHERE order_id = ?', ob.id), 0);
  // endereço de outra pessoa não pode ser editado/excluído
  const addrB = app.db.run("INSERT INTO addresses (customer_id, label, recipient, zip, state, city, district, street, number) VALUES (?,?,?,?,?,?,?,?,?)", b.id, 'Casa', 'Bia', '01310100', 'SP', 'São Paulo', 'Bela Vista', 'Rua B', '1').id;
  await a.client.post(`/minha-conta/enderecos/${addrB}/excluir`, {});
  assert.ok(app.db.get('SELECT 1 FROM addresses WHERE id = ?', addrB), 'endereço da Bia continua existindo');
  // sem login nada disso abre
  const anon = new Client(base);
  assert.equal((await anon.get(`/minha-conta/pedidos/${oa.number}`)).status, 303);
  // página pública do pedido exige o token secreto (número não basta)
  assert.equal((await anon.get(`/pedido/${oa.number}`)).status, 404);
  assert.equal((await anon.get(`/pedido/${oa.public_token}`)).status, 200);
  assert.equal((await anon.get('/pedido/token-que-nao-existe-123456')).status, 404);
  // cliente não entra no painel
  const painel = await a.client.get('/admin/pedidos');
  assert.equal(painel.status, 303);
});

test('XSS: nomes, buscas e mensagens com HTML são escapados na loja e no painel', async (t) => {
  const { app, base } = await boot(t);
  const { mk } = seedBasics(app);
  const evil = '<img src=x onerror=alert(1)> "><script>alert(7)</script>';
  const p = mk(evil, '10,00', { brand: '<b>Marca</b>' });
  const anon = new Client(base);
  for (const path of ['/', '/loja', `/loja?q=${encodeURIComponent('<script>alert(2)</script>')}`, `/produto/${p.slug}`]) {
    const r = await anon.get(path);
    assert.equal(r.status, 200, path);
    assert.ok(!r.text.includes('<img src=x onerror'), `${path}: HTML do nome deve estar escapado`);
    assert.ok(!r.text.includes('<script>alert('), `${path}: sem script injetado`);
    assert.ok(!r.text.includes('</script><script>'), `${path}: JSON-LD não pode fechar o script`);
  }
  // CSP bloqueia script inline mesmo que algo escape
  const csp = (await anon.get('/')).headers.get('content-security-policy');
  assert.match(csp, /script-src 'self';/);
  assert.ok(!/script-src[^;]*unsafe-inline/.test(csp), 'scripts inline não são permitidos');
  // formulário de contato (vira mensagem no painel)
  await anon.get('/contato');
  await anon.post('/contato', { name: '<script>alert(3)</script> Maria', email: 'm@cliente.test', message: 'Olá <img src=x onerror=alert(4)> tudo bem?', subject: '<i>assunto</i>' });
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  for (const path of ['/admin/mensagens', '/admin/produtos', `/admin/produtos/${p.id}`, '/admin/estoque?f=all']) {
    const r = await adm.get(path);
    assert.equal(r.status, 200, path);
    assert.ok(!r.text.includes('<script>alert('), `${path}: painel sem script injetado`);
    assert.ok(!r.text.includes('<img src=x onerror'), `${path}: painel escapa HTML`);
  }
});

test('cabeçalhos de segurança e páginas do painel não ficam em cache', async (t) => {
  const { app, base } = await boot(t);
  const c = new Client(base);
  const home = await c.get('/');
  assert.equal(home.headers.get('x-frame-options'), 'DENY');
  assert.equal(home.headers.get('x-content-type-options'), 'nosniff');
  assert.match(home.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.ok(home.headers.get('referrer-policy'));
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  const page = await adm.get('/admin/pedidos');
  assert.match(page.headers.get('cache-control') || '', /no-store/);
  assert.match(page.text, /<meta name="robots" content="noindex/);
  // painel nunca é indexável
  const robots = (await c.get('/robots.txt')).text;
  assert.match(robots, /Disallow: \/admin/);
  // erro 404 não vaza detalhes internos
  const nf = await c.get('/rota/que/nao/existe');
  assert.equal(nf.status, 404);
  assert.ok(!/at .*\.js:\d+|node_modules|SQLITE/.test(nf.text));
});

test('envio de imagens: valida o conteúdo real do arquivo e serve com isolamento', async (t) => {
  const { app, base } = await boot(t);
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  const html = await adm.upload('/admin/uploads', Buffer.from('<html><script>alert(1)</script></html>'));
  assert.equal(html.status, 422);
  const svg = await adm.upload('/admin/uploads', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'));
  assert.equal(svg.status, 422);
  const fake = await adm.upload('/admin/uploads', Buffer.concat([Buffer.from('GIF89a'), Buffer.from('<script>alert(1)</script>')]));
  assert.ok([200, 422].includes(fake.status));
  const grande = await adm.upload('/admin/uploads', Buffer.concat([pngBuffer(), Buffer.alloc(9 * 1024 * 1024)]));
  assert.ok([413, 422].includes(grande.status), `arquivo grande demais deve ser recusado (veio ${grande.status})`);
  const ok = await adm.upload('/admin/uploads', pngBuffer());
  assert.equal(ok.status, 200);
  const { filename } = JSON.parse(ok.text);
  assert.match(filename, /^[a-f0-9]{24}\.(png|jpg|webp|gif)$/, 'nome aleatório gerado no servidor');
  const served = await new Client(base).get(`/uploads/${filename}`);
  assert.equal(served.status, 200);
  assert.match(served.headers.get('content-type'), /^image\//);
  assert.match(served.headers.get('content-security-policy'), /sandbox/);
  assert.equal(served.headers.get('x-content-type-options'), 'nosniff');
  // sem permissão: estoquista não sobe imagens soltas; sem login também não
  const est = await staffLogin(app, base, { role: 'estoquista', email: 'est@loja.test' });
  assert.equal((await est.upload('/admin/uploads', pngBuffer())).status, 403);
  const anon = new Client(base);
  await anon.get('/');
  assert.ok([401, 403].includes((await anon.upload('/admin/uploads', pngBuffer())).status));
  // upload sem token CSRF
  const semCsrf = await adm.req('POST', '/admin/uploads', { body: pngBuffer(), headers: { 'content-type': 'application/octet-stream' } });
  assert.equal(semCsrf.status, 403);
});

test('travessia de diretório e arquivos internos não são servidos', async (t) => {
  const { base } = await boot(t);
  for (const p of ['/uploads/..%2f..%2fserver.js', '/css/..%2f..%2fserver.js', '/js/..%2f..%2fpackage.json', '/uploads/%2e%2e%2f%2e%2e%2fserver.js', '/uploads/..\\..\\server.js', '/.env', '/server.js', '/package.json', '/src/config.js', '/data/brecho.db']) {
    const r = await rawGet(base, p);
    assert.equal(r.status, 404, `${p} deve ser 404 (veio ${r.status})`);
    assert.ok(!/require\(|"name": "brecho/.test(r.text), `${p} não pode vazar código`);
  }
});

test('webhook: assinatura inválida é recusada e não altera o pedido', async (t) => {
  const { app, base } = await boot(t);
  const { mk, fixed } = seedBasics(app);
  const p = mk('Casaco', '120,00');
  const { order, pay } = await placeOrder(app, ctxFor(), { items: [p], shippingKey: fixed });
  const ev = app.providers.get('mock').simulatePay(pay.provider_payment_id);
  const body = JSON.stringify(ev);
  const c = new Client(base);
  const sem = await c.req('POST', '/webhooks/mock', { body, headers: { 'content-type': 'application/json' } });
  const ruim = await c.req('POST', '/webhooks/mock', { body, headers: { 'content-type': 'application/json', 'x-mock-signature': 'assinatura-falsa' } });
  const desconhecido = await c.req('POST', '/webhooks/provedor-inexistente', { body, headers: { 'content-type': 'application/json' } });
  assert.ok([400, 401, 403].includes(sem.status), `sem assinatura: ${sem.status}`);
  assert.ok([400, 401, 403].includes(ruim.status), `assinatura falsa: ${ruim.status}`);
  assert.ok([400, 404].includes(desconhecido.status));
  assert.equal(app.orders.get(order.id).status, 'awaiting_payment', 'pedido segue aguardando');
  assert.equal(app.db.value("SELECT COUNT(*) FROM payments WHERE status = 'paid'"), 0);
  // webhook não exige CSRF/cookies (é chamado pelo provedor) mas com assinatura válida funciona
  const boa = await c.req('POST', '/webhooks/mock', { body, headers: { 'content-type': 'application/json', 'x-mock-signature': app.providers.get('mock').sign(body) } });
  assert.equal(boa.status, 200);
  assert.equal(app.orders.get(order.id).status, 'paid');
});

test('segredos do provedor (chaves de API e tokens) nunca aparecem em nenhuma página', async (t) => {
  const SECRETS = ['sk_test_SEGREDO_API_123456', 'whsec_SEGREDO_WEBHOOK_789'];
  const { app, base } = await boot(t, { PAYMENT_PROVIDER: 'asaas', ASAAS_API_KEY: SECRETS[0], ASAAS_WEBHOOK_TOKEN: SECRETS[1], ASAAS_ENV: 'sandbox', EMAIL_TRANSPORT: 'capture', RESEND_API_KEY: 're_SEGREDO_EMAIL_555' });
  seedBasics(app);
  const adm = await staffLogin(app, base, { role: 'superadmin', email: 'sa@loja.test' });
  const pages = ['/admin', '/admin/pagamentos', '/admin/configuracoes?aba=loja', '/admin/configuracoes?aba=email', '/admin/configuracoes?aba=entrega', '/admin/configuracoes?aba=pedidos', '/admin/emails', '/admin/auditoria', '/admin/funcionarios'];
  for (const p of pages) {
    const r = await adm.get(p);
    assert.equal(r.status, 200, p);
    for (const s of [...SECRETS, 're_SEGREDO_EMAIL_555']) assert.ok(!r.text.includes(s), `${p} vazou um segredo`);
  }
  const anon = new Client(base);
  for (const p of ['/', '/loja', '/checkout', '/contato']) {
    const r = await anon.get(p);
    for (const s of [...SECRETS, 're_SEGREDO_EMAIL_555']) assert.ok(!r.text.includes(s), `${p} vazou um segredo`);
  }
  const status = (await adm.get('/admin/pagamentos')).text;
  assert.match(status, /Asaas/i);
  assert.match(status, /\/webhooks\/asaas/);
});

test('dados pessoais: CPF só completo para quem tem permissão específica', async (t) => {
  const { app, base } = await boot(t);
  const cpf = '52998224725';
  const id = app.db.run('INSERT INTO customers (name, email, phone, cpf_enc, email_verified_at, created_at) VALUES (?,?,?,?,?,?)', 'Cliente Com CPF', 'cpf@cliente.test', '11987654321', app.cipher.encrypt(cpf), new Date().toISOString(), new Date().toISOString()).id;
  const raw = app.db.get('SELECT cpf_enc FROM customers WHERE id = ?', id).cpf_enc;
  assert.ok(!raw.includes(cpf), 'CPF é gravado criptografado');
  const aten = await staffLogin(app, base, { role: 'atendente', email: 'aten@loja.test' });
  const adm = await staffLogin(app, base, { role: 'admin', email: 'adm@loja.test' });
  const a = (await aten.get(`/admin/clientes/${id}`)).text;
  assert.ok(!a.includes('529.982.247-25') && !a.includes(cpf), 'atendente não vê CPF completo');
  const b = (await adm.get(`/admin/clientes/${id}`)).text;
  assert.ok(b.includes('529.982.247-25'), 'admin vê o CPF completo');
  assert.equal((await aten.get(`/admin/clientes/${id}/exportar.json`)).status, 200, 'atendente tem customers.manage e exporta (CPF mascarado)');
  const exp = JSON.parse((await aten.get(`/admin/clientes/${id}/exportar.json`)).text);
  assert.ok(!JSON.stringify(exp).includes(cpf), 'exportação nunca traz CPF completo');
  assert.equal((await aten.get('/admin/relatorios/clientes.csv')).status, 403);
});
