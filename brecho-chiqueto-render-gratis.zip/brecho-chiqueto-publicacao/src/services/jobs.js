'use strict';
/**
 * Rotinas em segundo plano (processo único):
 *  - a cada 30 s: expira Pix vencidos (conferindo antes com o provedor) e consulta Pix pendentes (rede de segurança do webhook)
 *  - a cada 5 min: libera reservas vencidas
 *  - a cada hora: limpeza de sessões, limites de tentativas, logs antigos e corpo de e-mails antigos
 * Cada rotina roda sem sobreposição e um erro nunca derruba o servidor.
 */
function makeJobs(app) {
  const timers = [];
  const running = new Set();
  const guard = (name, fn) => async () => {
    if (running.has(name)) return;
    running.add(name);
    try {
      await fn();
    } catch (e) {
      console.error(`[rotina:${name}]`, e.message);
    } finally {
      running.delete(name);
    }
  };

  const jobs = {
    tasks: {
      payments: async () => {
        await app.payments.pollPending();
        await app.payments.expireStale();
      },
      reservations: async () => {
        app.stock.releaseExpired();
      },
      housekeeping: async () => {
        app.auth.pruneSessions();
        app.limiter.prune();
        app.audit.prune();
        app.email.prune();
        app.crm.pruneNotifications();
      },
    },
    /** Executa uma rotina agora (usado nos testes e pelo botão "conciliar"). */
    run: (name) => guard(name, jobs.tasks[name])(),
    start() {
      if (!app.cfg.jobsEnabled || timers.length) return;
      const every = (name, ms) => {
        const t = setInterval(guard(name, jobs.tasks[name]), ms);
        t.unref();
        timers.push(t);
      };
      every('payments', 30_000);
      every('reservations', 5 * 60_000);
      every('housekeeping', 60 * 60_000);
      setTimeout(guard('payments', jobs.tasks.payments), 3000).unref();
    },
    stop() {
      while (timers.length) clearInterval(timers.pop());
    },
  };
  return jobs;
}

module.exports = { makeJobs };
