'use strict';
/**
 * Autenticação de funcionários (painel) e clientes (loja).
 * Sessões opacas guardadas no banco (somente o hash do token), cookies HttpOnly/SameSite.
 */
const { now, addMinutes, randomToken, sha256, validEmail, validPhone, onlyDigits, validCpf, UserError, trunc } = require('../lib/util');
const { hashPassword, verifyPassword, dummyVerify, passwordProblem } = require('../lib/security');

const STAFF = { idleMin: 4 * 60, absMin: 12 * 60, cookie: 'bc_as', path: '/admin' };
const CUSTOMER = { idleMin: 14 * 24 * 60, absMin: 30 * 24 * 60, cookie: 'bc_cs', path: '/' };
const WINDOW = 15 * 60;

function makeAuth(app) {
  const { db, cfg, audit, limiter, cipher } = app;

  const kindCfg = (kind) => (kind === 'staff' ? STAFF : CUSTOMER);

  function createSession(ctx, kind, userId) {
    const k = kindCfg(kind);
    const token = randomToken(32);
    const t = now();
    db.run('INSERT INTO sessions (id, kind, user_id, created_at, last_seen_at, expires_at, ip, user_agent) VALUES (?,?,?,?,?,?,?,?)', sha256(token), kind, userId, t, t, addMinutes(t, k.idleMin), ctx.ip, ctx.userAgent);
    const opts = { path: k.path };
    if (kind === 'customer') opts.maxAge = k.absMin * 60;
    ctx.setCookie(k.cookie, token, opts);
    return token;
  }

  function lookupSession(ctx, kind) {
    const k = kindCfg(kind);
    const token = ctx.cookies[k.cookie];
    if (!token || !/^[A-Za-z0-9_-]{30,64}$/.test(token)) return null;
    const id = sha256(token);
    const s = db.get('SELECT * FROM sessions WHERE id = ? AND kind = ?', id, kind);
    if (!s) return null;
    const t = now();
    if (s.expires_at <= t || addMinutes(s.created_at, k.absMin) <= t) {
      db.run('DELETE FROM sessions WHERE id = ?', id);
      return null;
    }
    if (new Date(t) - new Date(s.last_seen_at) > 60000) {
      const exp = addMinutes(t, k.idleMin);
      const cap = addMinutes(s.created_at, k.absMin);
      db.run('UPDATE sessions SET last_seen_at = ?, expires_at = ? WHERE id = ?', t, exp < cap ? exp : cap, id);
    }
    return s;
  }

  function destroySession(ctx, kind) {
    const k = kindCfg(kind);
    const token = ctx.cookies[k.cookie];
    if (token) db.run('DELETE FROM sessions WHERE id = ?', sha256(token));
    ctx.clearCookie(k.cookie, { path: k.path });
  }

  const dropUserSessions = (kind, userId, exceptId = null) =>
    db.run('DELETE FROM sessions WHERE kind = ? AND user_id = ? AND id <> ?', kind, userId, exceptId || '');

  const tooMany = (r) => new UserError(`Muitas tentativas. Aguarde ${Math.max(1, Math.ceil(r.retryAfter / 60))} minuto(s) e tente de novo.`);

  const auth = {
    // ───────────── funcionários ─────────────
    getStaff(ctx) {
      const s = lookupSession(ctx, 'staff');
      if (!s) return null;
      const u = db.get('SELECT id, name, email, role, active, must_change_password FROM staff_users WHERE id = ?', s.user_id);
      if (!u || !u.active) return null;
      return { ...u, sessionId: s.id };
    },

    async staffLogin(ctx, email, password) {
      email = trunc(email, 254).toLowerCase();
      const a = limiter.hit(`staff-login:ip:${ctx.ip}`, 30, WINDOW);
      const b = limiter.hit(`staff-login:email:${email}`, 6, WINDOW);
      if (!a.ok) throw tooMany(a);
      if (!b.ok) throw tooMany(b);
      const u = db.get('SELECT * FROM staff_users WHERE email = ?', email);
      const ok = u && u.active ? await verifyPassword(password, u.password_hash) : (await dummyVerify(password), false);
      if (!ok) {
        audit.log({ type: 'system', label: email }, 'staff.login_failed', 'staff', u?.id ?? null, null, ctx.ip);
        throw new UserError('E-mail ou senha incorretos.');
      }
      limiter.reset(`staff-login:email:${email}`);
      createSession(ctx, 'staff', u.id);
      db.run('UPDATE staff_users SET last_login_at = ? WHERE id = ?', now(), u.id);
      audit.log({ type: 'staff', id: u.id, label: `${u.name} <${u.email}>` }, 'staff.login', 'staff', u.id, null, ctx.ip);
      return u;
    },

    staffLogout(ctx) {
      const s = ctx.staff;
      if (s) audit.staff(ctx, 'staff.logout', 'staff', s.id);
      destroySession(ctx, 'staff');
      ctx.staff = null;
    },

    async changeOwnPassword(ctx, current, next, confirm) {
      const s = ctx.staff;
      const row = db.get('SELECT * FROM staff_users WHERE id = ?', s.id);
      if (!(await verifyPassword(current, row.password_hash))) throw new UserError('A senha atual está incorreta.');
      if (next !== confirm) throw new UserError('A confirmação da nova senha não confere.');
      const problem = passwordProblem(next, { min: 10, email: row.email });
      if (problem) throw new UserError(problem);
      if (current === next) throw new UserError('Escolha uma senha diferente da atual.');
      db.run('UPDATE staff_users SET password_hash = ?, must_change_password = 0 WHERE id = ?', await hashPassword(next), s.id);
      dropUserSessions('staff', s.id, s.sessionId);
      audit.staff(ctx, 'staff.password_changed', 'staff', s.id);
    },

    listStaff() {
      return db.all('SELECT id, name, email, role, active, must_change_password, created_at, last_login_at FROM staff_users ORDER BY active DESC, name');
    },
    getStaffById(id) {
      return db.get('SELECT id, name, email, role, active, must_change_password, created_at, last_login_at FROM staff_users WHERE id = ?', id);
    },

    async createStaff(actor, { name, email, password, role, mustChange = true }, ctx = null) {
      name = trunc(name, 100);
      email = trunc(email, 254).toLowerCase();
      if (!name) throw new UserError('Informe o nome.');
      if (!validEmail(email)) throw new UserError('E-mail inválido.');
      if (actor && !app.permissions.canManageRole(actor, role)) throw new UserError('Você não pode criar um acesso com essa função.');
      const problem = passwordProblem(password, { min: 10, email });
      if (problem) throw new UserError(problem);
      if (db.get('SELECT 1 FROM staff_users WHERE email = ?', email)) throw new UserError('Já existe um funcionário com este e-mail.');
      const r = db.run('INSERT INTO staff_users (name, email, password_hash, role, must_change_password, created_by, created_at) VALUES (?,?,?,?,?,?,?)', name, email, await hashPassword(password), role, mustChange ? 1 : 0, actor?.id ?? null, now());
      if (ctx) audit.staff(ctx, 'staff.created', 'staff', r.id, { email, role });
      return r.id;
    },

    /** Edição por outro funcionário. Ninguém altera a própria função/status (evita escalonamento de privilégio). */
    updateStaff(ctx, id, { name, role, active }) {
      const actor = ctx.staff;
      const target = db.get('SELECT * FROM staff_users WHERE id = ?', id);
      if (!target) throw new UserError('Funcionário não encontrado.');
      if (target.id === actor.id) throw new UserError('Você não pode alterar a sua própria função ou situação. Peça a outro administrador.');
      if (!app.permissions.canManageRole(actor, target.role)) throw new UserError('Você não pode gerenciar este funcionário.');
      if (role !== undefined && role !== target.role && !app.permissions.canManageRole(actor, role)) throw new UserError('Você não pode atribuir essa função.');
      const newRole = role ?? target.role;
      const newActive = active === undefined ? target.active : active ? 1 : 0;
      if (target.role === 'superadmin' && (newRole !== 'superadmin' || !newActive)) {
        if (db.value("SELECT COUNT(*) FROM staff_users WHERE role = 'superadmin' AND active = 1 AND id <> ?", id) < 1) throw new UserError('É preciso manter pelo menos um superadministrador ativo.');
      }
      db.run('UPDATE staff_users SET name = ?, role = ?, active = ? WHERE id = ?', trunc(name ?? target.name, 100) || target.name, newRole, newActive, id);
      if (!newActive || newRole !== target.role) dropUserSessions('staff', id);
      audit.staff(ctx, 'staff.updated', 'staff', id, { role: newRole, active: newActive });
    },

    async resetStaffPassword(ctx, id, password) {
      const actor = ctx.staff;
      const target = db.get('SELECT * FROM staff_users WHERE id = ?', id);
      if (!target) throw new UserError('Funcionário não encontrado.');
      if (target.id === actor.id) throw new UserError('Use "Minha conta" para trocar a sua senha.');
      if (!app.permissions.canManageRole(actor, target.role)) throw new UserError('Você não pode gerenciar este funcionário.');
      const problem = passwordProblem(password, { min: 10, email: target.email });
      if (problem) throw new UserError(problem);
      db.run('UPDATE staff_users SET password_hash = ?, must_change_password = 1 WHERE id = ?', await hashPassword(password), id);
      dropUserSessions('staff', id);
      audit.staff(ctx, 'staff.password_reset', 'staff', id);
    },

    staffSessions(userId) {
      return db.all("SELECT id, created_at, last_seen_at, ip, user_agent FROM sessions WHERE kind = 'staff' AND user_id = ? ORDER BY last_seen_at DESC", userId);
    },
    revokeStaffSession(ctx, sessionId) {
      const s = db.get("SELECT * FROM sessions WHERE id = ? AND kind = 'staff'", sessionId);
      if (!s) return;
      const own = s.user_id === ctx.staff.id;
      if (!own && !app.permissions.can(ctx.staff, 'staff.manage')) throw new UserError('Sem permissão.');
      db.run('DELETE FROM sessions WHERE id = ?', sessionId);
      audit.staff(ctx, 'staff.session_revoked', 'staff', s.user_id);
    },

    async ensureBootstrapAdmin() {
      if (db.value('SELECT COUNT(*) FROM staff_users') > 0) return false;
      const { email, password, name } = cfg.adminBootstrap;
      if (!email || !password) return false;
      await this.createStaff(null, { name, email, password, role: 'superadmin', mustChange: true });
      audit.system('staff.bootstrap_admin', 'staff', null, { email });
      return true;
    },

    // ───────────── clientes ─────────────
    getCustomer(ctx) {
      const s = lookupSession(ctx, 'customer');
      if (!s) return null;
      const u = db.get("SELECT * FROM customers WHERE id = ? AND status = 'active'", s.user_id);
      if (!u || !u.password_hash) return null;
      return { ...u, sessionId: s.id };
    },

    findCustomerByEmail: (email) => db.get('SELECT * FROM customers WHERE email = ?', String(email || '').trim().toLowerCase()),

    /** Cria/atualiza o registro de cliente a partir de um pedido (checkout como visitante também gera o cadastro, sem senha). */
    upsertCustomerFromOrder({ name, email, phone, cpf, marketing }) {
      email = email.trim().toLowerCase();
      const row = db.get('SELECT * FROM customers WHERE email = ?', email);
      if (row) {
        if (row.status === 'anonymized') throw new UserError('Não foi possível usar este e-mail. Use outro e-mail ou entre em contato com a loja.');
        db.run('UPDATE customers SET name = COALESCE(NULLIF(name, ?), name), phone = COALESCE(?, phone), cpf_enc = COALESCE(?, cpf_enc), marketing_consent = CASE WHEN ? = 1 THEN 1 ELSE marketing_consent END, marketing_consent_at = CASE WHEN ? = 1 AND marketing_consent = 0 THEN ? ELSE marketing_consent_at END WHERE id = ?', '', phone || null, cpf ? cipher.encrypt(onlyDigits(cpf)) : null, marketing ? 1 : 0, marketing ? 1 : 0, now(), row.id);
        return row.id;
      }
      return db.run('INSERT INTO customers (name, email, phone, cpf_enc, marketing_consent, marketing_consent_at, created_at) VALUES (?,?,?,?,?,?,?)', name, email, phone || null, cpf ? cipher.encrypt(onlyDigits(cpf)) : null, marketing ? 1 : 0, marketing ? now() : null, now()).id;
    },

    async register(ctx, { name, email, password, confirm, phone, marketing }) {
      name = trunc(name, 100);
      email = trunc(email, 254).toLowerCase();
      const lim = limiter.hit(`register:ip:${ctx.ip}`, 10, 3600);
      if (!lim.ok) throw tooMany(lim);
      if (!name) throw new UserError('Informe seu nome.', 'name');
      if (!validEmail(email)) throw new UserError('Informe um e-mail válido.', 'email');
      if (phone && !validPhone(phone)) throw new UserError('Telefone inválido. Use DDD + número.', 'phone');
      if (password !== confirm) throw new UserError('A confirmação da senha não confere.', 'confirm');
      const problem = passwordProblem(password, { min: 8, email });
      if (problem) throw new UserError(problem, 'password');
      const existing = db.get('SELECT * FROM customers WHERE email = ?', email);
      if (existing && existing.status === 'anonymized') throw new UserError('Não foi possível concluir o cadastro com este e-mail.');
      if (existing) {
        // Resposta idêntica à de um cadastro novo (não revela se o e-mail existe).
        // Quem é dono do e-mail define/redefine a senha pelo link enviado.
        await hashPassword(password);
        const token = this.createAuthToken(existing.id, 'reset_password', 60);
        app.email.queue('account_exists', email, { name: existing.name, resetUrl: `${cfg.baseUrl}/minha-conta/redefinir-senha/${token}` }, { customerId: existing.id });
        return { pending: true };
      }
      const hash = await hashPassword(password);
      const id = db.run('INSERT INTO customers (name, email, phone, password_hash, marketing_consent, marketing_consent_at, created_at) VALUES (?,?,?,?,?,?,?)', name, email, phone ? onlyDigits(phone) : null, hash, marketing ? 1 : 0, marketing ? now() : null, now()).id;
      const token = this.createAuthToken(id, 'verify_email', 60 * 24 * 3);
      app.email.queue('verify_email', email, { name, verifyUrl: `${cfg.baseUrl}/minha-conta/confirmar-email/${token}` }, { customerId: id });
      audit.log({ type: 'customer', id, label: email }, 'customer.registered', 'customer', id, null, ctx.ip);
      return { pending: true, id };
    },

    createAuthToken(customerId, purpose, ttlMinutes) {
      const token = randomToken(32);
      db.run('INSERT INTO auth_tokens (token_hash, customer_id, purpose, expires_at) VALUES (?,?,?,?)', sha256(token), customerId, purpose, addMinutes(now(), ttlMinutes));
      return token;
    },

    consumeAuthToken(token, purpose) {
      return db.tx(() => {
        const r = db.get('SELECT * FROM auth_tokens WHERE token_hash = ? AND purpose = ?', sha256(token || ''), purpose);
        if (!r || r.used_at || r.expires_at <= now()) return null;
        db.run('UPDATE auth_tokens SET used_at = ? WHERE token_hash = ?', now(), r.token_hash);
        return r.customer_id;
      });
    },

    verifyEmail(token) {
      const id = this.consumeAuthToken(token, 'verify_email');
      if (!id) return false;
      db.run('UPDATE customers SET email_verified_at = COALESCE(email_verified_at, ?) WHERE id = ?', now(), id);
      audit.log({ type: 'customer', id }, 'customer.email_verified', 'customer', id);
      return true;
    },

    resendVerification(ctx, customer) {
      if (customer.email_verified_at) return;
      const lim = limiter.hit(`resend-verify:${customer.id}`, 3, 3600);
      if (!lim.ok) throw tooMany(lim);
      const token = this.createAuthToken(customer.id, 'verify_email', 60 * 24 * 3);
      app.email.queue('verify_email', customer.email, { name: customer.name, verifyUrl: `${cfg.baseUrl}/minha-conta/confirmar-email/${token}` }, { customerId: customer.id });
    },

    async login(ctx, email, password) {
      email = trunc(email, 254).toLowerCase();
      const a = limiter.hit(`login:ip:${ctx.ip}`, 40, WINDOW);
      const b = limiter.hit(`login:email:${email}`, 8, WINDOW);
      if (!a.ok) throw tooMany(a);
      if (!b.ok) throw tooMany(b);
      const u = db.get('SELECT * FROM customers WHERE email = ?', email);
      const ok = u && u.password_hash && u.status === 'active' ? await verifyPassword(password, u.password_hash) : (await dummyVerify(password), false);
      if (!ok) throw new UserError('E-mail ou senha incorretos.');
      limiter.reset(`login:email:${email}`);
      createSession(ctx, 'customer', u.id);
      db.run('UPDATE customers SET last_login_at = ? WHERE id = ?', now(), u.id);
      return u;
    },

    logout(ctx) {
      destroySession(ctx, 'customer');
      ctx.customer = null;
    },

    requestPasswordReset(ctx, email) {
      email = trunc(email, 254).toLowerCase();
      const lim = limiter.hit(`reset:ip:${ctx.ip}`, 8, 3600);
      if (!lim.ok) throw tooMany(lim);
      const lim2 = limiter.hit(`reset:email:${email}`, 3, 3600);
      const u = db.get("SELECT * FROM customers WHERE email = ? AND status = 'active'", email);
      if (u && lim2.ok) {
        const token = this.createAuthToken(u.id, 'reset_password', 60);
        app.email.queue('reset_password', email, { name: u.name, resetUrl: `${cfg.baseUrl}/minha-conta/redefinir-senha/${token}` }, { customerId: u.id });
        audit.log({ type: 'customer', id: u.id, label: email }, 'customer.password_reset_requested', 'customer', u.id, null, ctx.ip);
      }
      // Resposta sempre igual, exista ou não a conta.
    },

    tokenIsValid(token, purpose) {
      const r = db.get('SELECT * FROM auth_tokens WHERE token_hash = ? AND purpose = ?', sha256(token || ''), purpose);
      return !!(r && !r.used_at && r.expires_at > now());
    },

    async resetPassword(ctx, token, password, confirm) {
      if (password !== confirm) throw new UserError('A confirmação da senha não confere.');
      const row = db.get("SELECT c.email FROM auth_tokens t JOIN customers c ON c.id = t.customer_id WHERE t.token_hash = ? AND t.purpose = 'reset_password'", sha256(token || ''));
      const problem = passwordProblem(password, { min: 8, email: row?.email });
      if (problem) throw new UserError(problem);
      const hash = await hashPassword(password);
      const id = this.consumeAuthToken(token, 'reset_password');
      if (!id) throw new UserError('Este link expirou ou já foi utilizado. Solicite um novo.');
      // O link chegou à caixa de entrada do dono do e-mail: isso também confirma o e-mail.
      db.run("UPDATE customers SET password_hash = ?, email_verified_at = COALESCE(email_verified_at, ?) WHERE id = ? AND status = 'active'", hash, now(), id);
      dropUserSessions('customer', id);
      audit.log({ type: 'customer', id }, 'customer.password_reset', 'customer', id, null, ctx.ip);
      return id;
    },

    async changePassword(ctx, current, next, confirm) {
      const c = ctx.customer;
      if (!(await verifyPassword(current, c.password_hash))) throw new UserError('A senha atual está incorreta.');
      if (next !== confirm) throw new UserError('A confirmação da nova senha não confere.');
      const problem = passwordProblem(next, { min: 8, email: c.email });
      if (problem) throw new UserError(problem);
      db.run('UPDATE customers SET password_hash = ? WHERE id = ?', await hashPassword(next), c.id);
      dropUserSessions('customer', c.id, c.sessionId);
      audit.log({ type: 'customer', id: c.id }, 'customer.password_changed', 'customer', c.id, null, ctx.ip);
    },

    updateProfile(ctx, { name, phone, marketing }) {
      const c = ctx.customer;
      name = trunc(name, 100);
      if (!name) throw new UserError('Informe seu nome.');
      if (phone && !validPhone(phone)) throw new UserError('Telefone inválido. Use DDD + número.');
      const consent = marketing ? 1 : 0;
      db.run('UPDATE customers SET name = ?, phone = ?, marketing_consent = ?, marketing_consent_at = CASE WHEN ? = 1 AND marketing_consent = 0 THEN ? ELSE marketing_consent_at END WHERE id = ?', name, phone ? onlyDigits(phone) : null, consent, consent, now(), c.id);
    },

    // endereços
    addresses: (customerId) => db.all('SELECT * FROM addresses WHERE customer_id = ? ORDER BY is_default DESC, id', customerId),
    saveAddress(customerId, a, id = null) {
      const f = {
        label: trunc(a.label, 40), recipient: trunc(a.recipient, 100), zip: onlyDigits(a.zip), state: trunc(a.state, 2).toUpperCase(),
        city: trunc(a.city, 80), district: trunc(a.district, 80), street: trunc(a.street, 120), number: trunc(a.number, 15), complement: trunc(a.complement, 60),
      };
      if (!f.recipient || f.zip.length !== 8 || !f.state || !f.city || !f.district || !f.street || !f.number) throw new UserError('Preencha todos os campos obrigatórios do endereço (CEP com 8 dígitos).');
      return db.tx(() => {
        const isDefault = a.is_default ? 1 : db.value('SELECT COUNT(*) FROM addresses WHERE customer_id = ?', customerId) === 0 ? 1 : 0;
        if (isDefault) db.run('UPDATE addresses SET is_default = 0 WHERE customer_id = ?', customerId);
        if (id) {
          const r = db.run('UPDATE addresses SET label=?, recipient=?, zip=?, state=?, city=?, district=?, street=?, number=?, complement=?, is_default = CASE WHEN ? = 1 THEN 1 ELSE is_default END WHERE id = ? AND customer_id = ?', f.label, f.recipient, f.zip, f.state, f.city, f.district, f.street, f.number, f.complement, isDefault, id, customerId);
          if (!r.changes) throw new UserError('Endereço não encontrado.');
          return id;
        }
        return db.run('INSERT INTO addresses (customer_id, label, recipient, zip, state, city, district, street, number, complement, is_default) VALUES (?,?,?,?,?,?,?,?,?,?,?)', customerId, f.label, f.recipient, f.zip, f.state, f.city, f.district, f.street, f.number, f.complement, isDefault).id;
      });
    },
    deleteAddress(customerId, id) {
      db.run('DELETE FROM addresses WHERE id = ? AND customer_id = ?', id, customerId);
    },

    validCpfOrNull: (cpf) => (cpf && validCpf(cpf) ? onlyDigits(cpf) : null),

    pruneSessions() {
      db.run('DELETE FROM sessions WHERE expires_at < ?', now());
      db.run('DELETE FROM auth_tokens WHERE expires_at < ?', addMinutes(now(), -60 * 24));
    },
  };
  return auth;
}

module.exports = { makeAuth };
