'use strict';
/** Painel: relatórios financeiros e de vendas (faturado, recebido e liquidado são medidas separadas). */
const { html } = require('../../lib/html');
const { money } = require('../../lib/util');
const { icon, selectField } = require('../ui');

function register(router, app, h) {
  const { L } = h;
  const KIND = { ship: 'Envio', pickup: 'Retirada na loja', local: 'Entrega local' };
  const PRESETS = [{ value: 'today', label: 'Hoje' }, { value: '7d', label: 'Últimos 7 dias' }, { value: '30d', label: 'Últimos 30 dias' }, { value: 'month', label: 'Este mês' }, { value: 'all', label: 'Todo o período' }];
  const rangeOf = (ctx) => app.reports.range({ from: ctx.query.de, to: ctx.query.ate, preset: ctx.query.periodo });

  router.get('/admin/relatorios', (ctx) => {
    const r = rangeOf(ctx);
    const f = app.reports.finance(r);
    const daily = app.reports.daily(r);
    const top = app.reports.topProducts(r, 10);
    const cats = app.reports.byCategory(r);
    const deliv = app.reports.byDelivery(r);
    const pay = app.payments.status();
    const label = r.from || r.to ? `${r.from ? h.day(`${r.from}T12:00:00Z`) : 'início'} a ${r.to ? h.day(`${r.to}T12:00:00Z`) : 'hoje'}` : 'todo o período';
    const q = new URLSearchParams(); if (r.from) q.set('de', r.from); if (r.to) q.set('ate', r.to);
    const csvQ = q.toString() ? `?${q}` : '';
    const feeNote = f.received.count === 0 ? '' : f.net.complete ? '' : f.fees.unknownCount === f.received.count ? 'O provedor não informou taxas para estes pagamentos.' : `O provedor não informou a taxa de ${f.fees.unknownCount} de ${f.received.count} pagamento(s); os totais abaixo consideram só o que foi informado.`;

    h.page(ctx, 'Relatórios', html`
<section class="card no-print">
  <form class="filters" method="get" action="/admin/relatorios">
    ${selectField({ label: 'Período', name: 'periodo', value: ctx.query.periodo || (ctx.query.de || ctx.query.ate ? '' : '30d'), options: PRESETS, blank: 'Datas personalizadas' })}
    <div class="field"><label for="de">De</label>${L.dateInput('de', ctx.query.de)}</div>
    <div class="field"><label for="ate">Até</label>${L.dateInput('ate', ctx.query.ate)}</div>
    <div class="field"><label>&nbsp;</label><button class="btn" type="submit">Atualizar</button></div>
  </form>
</section>
<p class="print-only"><strong>Brechó — relatório financeiro</strong> · período: ${label} · gerado em ${h.ago(new Date().toISOString())}</p>
<h2 class="section-h">Resumo de ${label}</h2>
${pay.sandbox ? html`<div class="flash flash-info"><span>O provedor de pagamentos está em modo de teste: os valores abaixo NÃO são dinheiro real.</span></div>` : ''}
<div class="kpis">
  ${L.kpi('Pedidos criados', String(f.created.count), money(f.created.cents) + ' em pedidos feitos')}
  ${L.kpi('Faturado', money(f.billed.cents), `${f.billed.count} pedido(s) com pagamento confirmado`)}
  ${L.kpi('Recebido (Pix)', money(f.received.cents), f.received.refunded ? `${money(f.received.gross)} pagos − ${money(f.received.refunded)} reembolsados` : `${f.received.count} pagamento(s) confirmado(s)`)}
  ${L.kpi('Reembolsos', money(f.refunds.cents), `${f.refunds.count} reembolso(s)`)}
  ${L.kpi('Ticket médio', money(f.avgTicket), 'sobre os pedidos faturados')}
  ${L.kpi('Pendente agora', money(f.pending.cents), `${f.pending.count} pedido(s) aguardando Pix`, f.pending.count ? 'warn' : '')}
  ${L.kpi('Pix expirados', String(f.expired.count), `${money(f.expired.cents)} não pagos no período`)}
</div>
<section class="card"><h2>Taxas e valor líquido</h2>
  <div class="kpis kpis-sm">
    ${L.kpi('Taxas do provedor', f.fees.unknownCount === f.received.count && f.received.count ? 'não informado' : money(f.fees.cents), feeNote)}
    ${L.kpi('Líquido', f.fees.unknownCount === f.received.count && f.received.count ? 'não informado' : money(f.net.cents), (f.net.complete ? 'após taxas' : 'parcial') + ', antes de reembolsos')}
  </div>
  <p class="muted small">Só mostramos taxa e líquido quando o provedor informa. Nada é estimado.</p>
</section>
<section class="card"><h2>Liquidação (dinheiro na conta)</h2>
  <div class="kpis kpis-sm">
    ${L.kpi('Liquidado', money(f.settled.cents), `${f.settled.count} pagamento(s) com data de liquidação já passada`)}
    ${L.kpi('A liquidar', money(f.toSettle.cents), `${f.toSettle.count} pagamento(s) sem data informada ou com data futura`, f.toSettle.count ? 'warn' : '')}
  </div>
  <p class="muted small">Quando o dinheiro cai na conta depende das regras do provedor de pagamentos. Confira sempre o extrato do provedor; este painel usa apenas a data que ele informa.</p>
</section>
<div class="cols">
  <section class="card"><h2>Pedidos pagos por dia</h2>${L.barChart(daily.map((d) => ({ value: d.cents, label: h.day(`${d.date}T12:00:00Z`).slice(0, 5), tick: `${d.date.slice(8)}/${d.date.slice(5, 7)}` })), { label: 'Valor faturado por dia' })}</section>
  <section class="card"><h2>Entrega</h2>${L.table(['Tipo', { label: 'Pedidos', right: true }, { label: 'Valor', right: true }], deliv.map((d) => html`<tr><td>${KIND[d.kind] || d.kind}</td><td class="r">${d.n}</td><td class="r">${money(d.cents)}</td></tr>`), { empty: 'Sem vendas no período.' })}</section>
</div>
<div class="cols">
  <section class="card"><h2>Peças mais vendidas</h2>${L.table(['Peça', { label: 'Qtd', right: true }, { label: 'Valor', right: true }], top.map((t) => html`<tr><td>${t.name}<br><small class="muted">${t.sku}</small></td><td class="r">${t.qty}</td><td class="r">${money(t.cents)}</td></tr>`), { empty: 'Sem vendas no período.' })}</section>
  <section class="card"><h2>Por categoria</h2>${L.table(['Categoria', { label: 'Qtd', right: true }, { label: 'Valor', right: true }], cats.map((t) => html`<tr><td>${t.name}</td><td class="r">${t.qty}</td><td class="r">${money(t.cents)}</td></tr>`), { empty: 'Sem vendas no período.' })}</section>
</div>
<section class="card no-print"><h2>Exportar</h2><div class="row-actions-wrap">
  <a class="btn btn-ghost" href="/admin/relatorios/pedidos.csv${csvQ}">${icon('download', 16)} Pedidos (CSV)</a>
  <a class="btn btn-ghost" href="/admin/relatorios/pagamentos.csv${csvQ}">${icon('download', 16)} Pagamentos (CSV)</a>
  <a class="btn btn-ghost" href="/admin/relatorios/produtos.csv">${icon('download', 16)} Produtos e estoque (CSV)</a>
  ${h.can(ctx, 'customers.pii') ? html`<a class="btn btn-ghost" href="/admin/relatorios/clientes.csv">${icon('download', 16)} Clientes (CSV)</a>` : ''}
  <button class="btn btn-ghost" type="button" data-print>${icon('print', 16)} Imprimir este relatório</button></div>
  <details class="defs"><summary>Como cada número é calculado</summary><ul>
    <li><strong>Pedidos criados:</strong> pedidos feitos no período, em qualquer situação.</li>
    <li><strong>Faturado:</strong> valor dos pedidos cujo pagamento foi confirmado no período (sem descontar reembolsos).</li>
    <li><strong>Recebido:</strong> pagamentos confirmados pelo provedor no período, menos os reembolsos feitos no período.</li>
    <li><strong>Liquidado / A liquidar:</strong> conforme a data de liquidação informada pelo provedor.</li>
    <li>Datas e horários no fuso de Brasília.</li></ul></details>
</section>`, { actions: '' });
  }, h.S('reports.view'));

  const csv = (name, make, extra = {}) => router.get(`/admin/relatorios/${name}.csv`, (ctx) => {
    app.audit.staff(ctx, `export.${name}`, 'report', name);
    ctx.download(`${name}-brecho.csv`, 'text/csv; charset=utf-8', make(rangeOf(ctx)));
  }, h.S(extra.perm || 'reports.view'));
  csv('pedidos', (r) => app.reports.csvOrders(r));
  csv('pagamentos', (r) => app.reports.csvPayments(r));
  csv('produtos', () => app.reports.csvProducts());
  csv('clientes', () => app.reports.csvCustomers(), { perm: 'customers.pii' });
}

module.exports = { register };
