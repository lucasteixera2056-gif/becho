'use strict';
/**
 * SOMENTE DESENVOLVIMENTO (provedor Pix simulado): "paga" o Pix de um pedido e dispara o webhook assinado
 * para o servidor local, exatamente como um provedor real faria.  Uso: node scripts/dev-pay.js BC-250101-1234
 */
const { buildConfig } = require('../src/config');
const { buildApp } = require('../src/app');

async function main() {
  const cfg = buildConfig();
  if (cfg.isProd || cfg.payment.provider !== 'mock') throw new Error('Este utilitário só funciona com PAYMENT_PROVIDER=mock fora de produção.');
  const number = process.argv[2];
  if (!number) throw new Error('Informe o número do pedido. Ex.: node scripts/dev-pay.js BC-250101-1234');
  const app = buildApp(cfg);
  const order = app.orders.byNumber(number);
  const pay = order && app.payments.openPayment(order.id);
  if (!pay) throw new Error('Pedido não encontrado ou sem Pix pendente.');
  const mock = app.providers.get('mock');
  const body = mock.simulatePay(pay.provider_payment_id);
  const raw = JSON.stringify(body);
  const res = await fetch(`${cfg.baseUrl}/webhooks/mock`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-mock-signature': mock.sign(raw) }, body: raw });
  console.log(`webhook -> ${res.status}`, await res.text());
  app.db.close();
}
main().catch((e) => { console.error(e.message); process.exit(1); });
