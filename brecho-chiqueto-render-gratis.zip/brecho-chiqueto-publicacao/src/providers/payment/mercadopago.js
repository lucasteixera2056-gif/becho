'use strict';
/**
 * Provedor Mercado Pago (API v1/payments) — Pix.
 *  - Autenticação: Bearer <Access Token> (somente no servidor).
 *  - Pix: payment_method_id = "pix"; o QR Code vem em point_of_interaction.transaction_data.
 *  - Webhook: POST com ?data.id=<id do pagamento> e cabeçalhos x-signature (ts=...,v1=...) e x-request-id.
 *    A assinatura é HMAC-SHA256 (hex) do manifest `id:<data.id>;request-id:<x-request-id>;ts:<ts>;`
 *    usando a "assinatura secreta" do painel. Em qualquer caso a loja NÃO confia no corpo da notificação:
 *    ela sempre consulta GET /v1/payments/{id} com o Access Token para confirmar status, valor e referência.
 *  - Validade mínima do Pix no Mercado Pago é de 30 minutos; a loja controla a validade real e cancela a cobrança ao expirar.
 * Documentação: https://www.mercadopago.com.br/developers
 */
const crypto = require('node:crypto');
const { ProviderError, httpJson, brIsoWithOffset, toCents, fromCents } = require('./common');
const { safeEqual } = require('../../lib/security');
const { onlyDigits } = require('../../lib/util');

const BASE = 'https://api.mercadopago.com';

function makeMercadoPago(cfg) {
  const c = cfg.payment.mercadopago;
  const hdr = (idem) => ({ Authorization: `Bearer ${c.accessToken}`, ...(idem ? { 'X-Idempotency-Key': idem } : {}) });

  async function call(method, path, body, idem) {
    const r = await httpJson(`${BASE}${path}`, { method, headers: hdr(idem), body });
    if (!r.ok) {
      const msg = r.data?.message || r.data?.error || `HTTP ${r.status}`;
      throw new ProviderError('O provedor de pagamentos recusou a operação.', { status: r.status, detail: `${msg}${r.data?.cause ? ` ${JSON.stringify(r.data.cause).slice(0, 200)}` : ''}`, retryable: r.status >= 500 });
    }
    return r.data;
  }

  const STATUS = { approved: 'paid', authorized: 'paid', pending: 'pending', in_process: 'pending', in_mediation: 'paid', rejected: 'failed', cancelled: 'cancelled', refunded: 'refunded', charged_back: 'refunded' };

  return {
    name: 'mercadopago',
    label: 'Mercado Pago',
    requiresCpf: false,
    sandbox: /^TEST-/.test(c.accessToken),
    configured: () => !!c.accessToken,
    webhookReady: () => !!c.webhookSecret && cfg.baseUrl.startsWith('https://'),
    missing: () => [!c.accessToken && 'MP_ACCESS_TOKEN', !c.webhookSecret && 'MP_WEBHOOK_SECRET'].filter(Boolean),

    async createPixCharge({ order, buyer, expiresAt, attempt = 1 }) {
      const parts = String(buyer.name || '').trim().split(/\s+/);
      const first = parts.shift() || 'Cliente';
      const last = parts.join(' ') || first;
      const cpf = onlyDigits(buyer.cpf);
      // O Mercado Pago exige validade mínima de 30 min; usamos uma folga e a loja cancela ao expirar.
      const minExp = new Date(Date.now() + 35 * 60000).toISOString();
      const exp = expiresAt > minExp ? expiresAt : minExp;
      const body = {
        transaction_amount: fromCents(order.total_cents), description: `Pedido ${order.number}`, payment_method_id: 'pix',
        external_reference: order.number, date_of_expiration: brIsoWithOffset(exp, cfg.tzOffsetMinutes),
        payer: { email: buyer.email, first_name: first, last_name: last, ...(cpf.length === 11 ? { identification: { type: 'CPF', number: cpf } } : {}) },
      };
      if (cfg.baseUrl.startsWith('https://')) body.notification_url = `${cfg.baseUrl}/webhooks/mercadopago`;
      const p = await call('POST', '/v1/payments', body, `${order.number}-${attempt}`);
      const td = p.point_of_interaction?.transaction_data;
      if (!td?.qr_code) throw new ProviderError('O Pix não foi gerado pelo provedor.', { detail: 'sem qr_code na resposta' });
      return { providerId: String(p.id), pixPayload: td.qr_code, qrImage: td.qr_code_base64 ? `data:image/png;base64,${td.qr_code_base64}` : null, raw: { status: p.status } };
    },

    async getPayment(providerId) {
      const p = await call('GET', `/v1/payments/${encodeURIComponent(providerId)}`);
      const amount = toCents(p.transaction_amount);
      const refunded = toCents(p.transaction_amount_refunded) || 0;
      let status = STATUS[p.status] || 'pending';
      if (status === 'paid' && refunded > 0 && amount !== null && refunded >= amount) status = 'refunded';
      const fee = Array.isArray(p.fee_details) ? p.fee_details.reduce((s, f) => s + (toCents(f.amount) || 0), 0) : null;
      return {
        providerId: String(p.id), status, rawStatus: `${p.status}/${p.status_detail || ''}`, amountCents: amount, currency: p.currency_id || 'BRL',
        reference: p.external_reference || null, feeCents: fee, netCents: toCents(p.transaction_details?.net_received_amount),
        paidAt: p.date_approved || null, settlementDate: p.money_release_date || null, refundedCents: refunded,
      };
    },

    async cancelCharge(providerId) {
      try {
        await call('PUT', `/v1/payments/${encodeURIComponent(providerId)}`, { status: 'cancelled' });
      } catch (e) {
        if (e.status === 404 || e.status === 400) return; // inexistente ou já finalizada
        throw e;
      }
    },

    async refund(providerId, amountCents) {
      const r = await call('POST', `/v1/payments/${encodeURIComponent(providerId)}/refunds`, { amount: fromCents(amountCents) }, `refund-${providerId}-${amountCents}-${Date.now()}`);
      return { providerRefundId: r?.id ? String(r.id) : null, status: 'done' };
    },

    verifyWebhook(headers, rawBody, query) {
      if (!c.webhookSecret) return { ok: false, reason: 'MP_WEBHOOK_SECRET não configurado' };
      const sig = String(headers['x-signature'] || '');
      const ts = /(?:^|,)\s*ts=([^,]+)/.exec(sig)?.[1];
      const v1 = /(?:^|,)\s*v1=([^,]+)/.exec(sig)?.[1];
      if (!ts || !v1) return { ok: false, reason: 'assinatura ausente' };
      let dataId = String(query['data.id'] || '');
      if (/^[a-z0-9]+$/i.test(dataId)) dataId = dataId.toLowerCase();
      let manifest = '';
      if (dataId) manifest += `id:${dataId};`;
      if (headers['x-request-id']) manifest += `request-id:${headers['x-request-id']};`;
      manifest += `ts:${ts};`;
      const expected = crypto.createHmac('sha256', c.webhookSecret).update(manifest).digest('hex');
      return safeEqual(expected, v1) ? { ok: true } : { ok: false, reason: 'assinatura inválida' };
    },

    parseWebhook(body, query) {
      const topic = body?.type || query?.type || query?.topic;
      if (topic !== 'payment') return [];
      const id = body?.data?.id ?? query['data.id'] ?? query.id;
      if (!id) return [];
      const eventId = body?.id ? `n${body.id}` : `${body?.action || 'payment'}:${id}:${body?.date_created || ''}`;
      return [{ eventId: String(eventId), type: String(body?.action || 'payment'), providerPaymentId: String(id) }];
    },
  };
}

module.exports = { makeMercadoPago };
