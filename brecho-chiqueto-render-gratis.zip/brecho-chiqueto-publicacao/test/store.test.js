'use strict';
/** Loja: catálogo, carrinho, cupons, estoque, entrega, checkout pelo HTTP e cadastro de produtos pelo painel. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { makeTestApp, seedBasics, ctxFor, placeOrder, deliverWebhook, payedDespiteCancel } = require('./helpers');
const { startServer, Client, staffLogin, pngBuffer } = require('./http-helpers');

const mkApp = (t, env) => { const app = makeTestApp(env); t.after(() => app.close()); return app; };

test('catálogo: só peças publicadas e com estoque; filtros, preço efetivo (promoção) e ordenação', (t) => {
  const app = mkApp(t);
  const { mk, catId } = seedBasics(app);
  const sub = app.catalog.saveCategory({ name: 'Midi', parent_id: catId, active: true });
  const a = mk('Vestido Floral Azul', '100,00', { size: 'M', brand: 'Zara', color: 'Azul' });
  const b = mk('Vestido Preto Liso', '200,00', { size: 'G', promo: '150,00', category_id: String(sub) });
  mk('Rascunho invisível', '50,00', { status: 'draft' });
  mk('Arquivada invisível', '50,00', { status: 'archived' });
  const sold = mk('Já vendida', '60,00');
  app.stock.markSoldOffline(sold.id, null);

  const all = app.catalog.list({});
  assert.deepEqual(all.items.map((p) => p.name).sort(), ['Vestido Floral Azul', 'Vestido Preto Liso']);
  assert.equal(app.catalog.list({ sold: '1' }).total, 3, 'com "mostrar vendidas" inclui a vendida, mas nunca rascunho/arquivada');
  assert.equal(app.catalog.list({ category: 'vestidos' }).total, 2, 'categoria-mãe inclui subcategorias');
  assert.equal(app.catalog.list({ category: 'midi' }).total, 1);
  assert.equal(app.catalog.list({ size: 'M' }).items[0].name, 'Vestido Floral Azul');
  assert.equal(app.catalog.list({ q: 'FLORAL' }).total, 1);
  assert.equal(app.catalog.list({ q: 'vestído' }).total, 2, 'busca ignora acentos e maiúsculas');
  const barato = app.catalog.list({ price_max: '120' });
  assert.deepEqual(barato.items.map((p) => p.name), ['Vestido Floral Azul'], 'filtro de preço usa o valor efetivo: 150 (promo) fica de fora, 100 entra');
  const caro = app.catalog.list({ price_min: '120' });
  assert.deepEqual(caro.items.map((p) => p.name), ['Vestido Preto Liso']);
  assert.equal(caro.items[0].effective_cents, 15000, 'preço efetivo é o promocional');
  assert.deepEqual(app.catalog.list({ sort: 'menor_preco' }).items.map((p) => p.id), [a.id, b.id]);
  assert.deepEqual(app.catalog.list({ sort: 'maior_preco' }).items.map((p) => p.id), [b.id, a.id]);
  assert.equal(app.catalog.list({ promo: '1' }).total, 1);
});

test('cadastro de produto: valida preço, promoção, SKU único e quantidade', (t) => {
  const app = mkApp(t);
  const base = { name: 'Blusa', price: '50,00', quantity: '1', status: 'published' };
  assert.throws(() => app.catalog.parseProductForm({ ...base, price: '0' }), /preço/i);
  assert.throws(() => app.catalog.parseProductForm({ ...base, price: 'abc' }), /preço/i);
  assert.throws(() => app.catalog.parseProductForm({ ...base, promo: '50,00' }), /promocional/i);
  assert.throws(() => app.catalog.parseProductForm({ ...base, promo: '80,00' }), /promocional/i);
  assert.throws(() => app.catalog.parseProductForm({ ...base, quantity: '-1' }), /quantidade/i);
  assert.throws(() => app.catalog.parseProductForm({ ...base, name: '   ' }), /nome/i);
  const ok = app.catalog.parseProductForm({ ...base, sku: 'bc-777' });
  assert.equal(ok.price, 5000);
  assert.equal(ok.sku, 'BC-777');
  app.catalog.createProduct(ok);
  assert.throws(() => app.catalog.createProduct(app.catalog.parseProductForm({ ...base, sku: 'BC-777' })), /SKU/i);
  const p1 = app.catalog.byId(app.catalog.createProduct(app.catalog.parseProductForm(base)));
  const p2 = app.catalog.byId(app.catalog.createProduct(app.catalog.parseProductForm(base)));
  assert.notEqual(p1.sku, p2.sku, 'SKU automático é sequencial e único');
  assert.notEqual(p1.slug, p2.slug);
});

test('carrinho: peça única, persistência por visitante, isolamento e peça vendida some com aviso', (t) => {
  const app = mkApp(t);
  const { mk } = seedBasics(app);
  const p = mk('Peça única', '40,00');
  const q = mk('Outra peça', '30,00');
  const v1 = ctxFor('visitante-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxx');
  const v2 = ctxFor('visitante-2-xxxxxxxxxxxxxxxxxxxxxxxxxxxx');
  app.cart.add(v1, p.id, 1);
  assert.throws(() => app.cart.add(v1, p.id, 1), /único|carrinho/i, 'não adiciona a mesma peça única duas vezes');
  assert.equal(app.cart.view(v1).count, 1);
  assert.equal(app.cart.view(v2).count, 0, 'carrinhos de visitantes são independentes');
  app.cart.add(v2, q.id, 1);
  assert.equal(app.cart.view(v1).items.length, 1);
  assert.equal(app.cart.view(ctxFor('visitante-1-xxxxxxxxxxxxxxxxxxxxxxxxxxxx')).subtotal_cents, 4000, 'o mesmo visitante recupera o carrinho');
  // peça vendida por outro canal enquanto estava no carrinho
  app.stock.markSoldOffline(p.id, null);
  const v = app.cart.view(v1);
  assert.equal(v.items[0].unavailable, true);
  assert.equal(v.subtotal_cents, 0);
  assert.ok(v.problems.length >= 1);
  // peça despublicada some do carrinho
  app.catalog.setStatus(q.id, 'draft');
  assert.equal(app.cart.view(v2).items.length, 0);
  assert.throws(() => app.cart.add(v2, q.id, 1), /dispon/i);
});

test('cupons: percentual, fixo, mínimo, validade, limite de usos, restrição por peça e devolução ao cancelar', async (t) => {
  const app = mkApp(t);
  const { mk, fixed } = seedBasics(app);
  const a = mk('Calça', '100,00');
  const b = mk('Camisa', '60,00');
  const lines = (...ps) => ps.map((p) => ({ product_id: p.id, unit_cents: p.price_cents, qty: 1 }));
  const sub = (...ps) => ps.reduce((s, p) => s + p.price_cents, 0);

  app.coupons.save({ code: 'dez', kind: 'percent', value: '10', active: true });
  assert.equal(app.coupons.evaluate('DEZ', lines(a), sub(a)).discount_cents, 1000, 'código não diferencia maiúsculas');
  assert.equal(app.coupons.evaluate('dez', lines(a, b), sub(a, b)).discount_cents, 1600);

  app.coupons.save({ code: 'CINCO', kind: 'fixed', value: '5,00', min_subtotal: '90,00', active: true });
  assert.equal(app.coupons.evaluate('CINCO', lines(a), sub(a)).discount_cents, 500);
  assert.throws(() => app.coupons.evaluate('CINCO', lines(b), sub(b)), /a partir de/i);

  app.coupons.save({ code: 'SOCALCA', kind: 'percent', value: '50', active: true, product_ids: [a.id] });
  assert.equal(app.coupons.evaluate('SOCALCA', lines(a, b), sub(a, b)).discount_cents, 5000, 'só incide sobre as peças da restrição');
  assert.throws(() => app.coupons.evaluate('SOCALCA', lines(b), sub(b)), /não vale/i);

  app.coupons.save({ code: 'GRATIS', kind: 'percent', value: '100', active: true });
  const g = app.coupons.evaluate('GRATIS', lines(b), sub(b));
  assert.ok(g.discount_cents <= sub(b) - 100, 'o pedido nunca fica de graça: sobra pelo menos R$ 1,00');

  app.coupons.save({ code: 'VENCIDO', kind: 'percent', value: '10', active: true, expires_at: '2020-01-01' });
  assert.throws(() => app.coupons.evaluate('VENCIDO', lines(a), sub(a)), /expirou/i);
  app.coupons.save({ code: 'FUTURO', kind: 'percent', value: '10', active: true, starts_at: '2099-01-01' });
  assert.throws(() => app.coupons.evaluate('FUTURO', lines(a), sub(a)), /ainda não/i);
  app.coupons.save({ code: 'OFF', kind: 'percent', value: '10', active: false });
  assert.throws(() => app.coupons.evaluate('OFF', lines(a), sub(a)), /inválido/i);
  assert.throws(() => app.coupons.evaluate('NAOEXISTE', lines(a), sub(a)), /inválido/i);

  // limite de usos: conta no pedido e devolve ao cancelar
  const id1 = app.coupons.save({ code: 'UMA', kind: 'fixed', value: '10,00', max_uses: 1, active: true });
  const ctx1 = ctxFor('visitante-c1-xxxxxxxxxxxxxxxxxxxxxxxxxxx');
  app.cart.add(ctx1, a.id, 1);
  const cart = app.cart.view(ctx1);
  const opt = await app.shipping.resolve({ key: fixed, zip: '01310100', subtotalCents: cart.subtotal_cents, items: [] });
  const f = app.orders.parseCheckout({ name: 'Maria de Teste', email: 'm@example.com', phone: '11987654321', zip: '01310100', state: 'SP', city: 'São Paulo', district: 'Centro', street: 'Rua A', number: '1', shipping_key: String(fixed) }, { requiresCpf: false });
  const cr = app.coupons.evaluate('UMA', lines(a), cart.subtotal_cents);
  const order = app.orders.createReserved({ cart, form: f, shippingOpt: opt, couponResult: cr, customerId: null });
  assert.equal(order.discount_cents, 1000);
  assert.equal(order.total_cents, 10000 - 1000 + opt.price_cents);
  assert.equal(app.coupons.byId(id1).used_count, 1);
  assert.throws(() => app.coupons.evaluate('UMA', lines(b), sub(b)), /limite/i, 'esgotado');
  await app.orders.cancelUnpaid(order.id, { actor: 'teste', reason: 'teste' });
  assert.equal(app.coupons.byId(id1).used_count, 0, 'cancelar devolve o uso');
  assert.ok(app.coupons.evaluate('UMA', lines(b), sub(b)));
  assert.throws(() => app.coupons.remove(id1), /usado em pedidos/i, 'cupom já usado em pedido não pode ser excluído');
});

test('estoque: movimentações registradas, sem saldo negativo, reserva expira e libera a peça', (t) => {
  const app = mkApp(t);
  const { mk } = seedBasics(app);
  const p = mk('Lote de camisetas', '25,00', { quantity: '5' });
  const staff = app.db.run("INSERT INTO staff_users (name, email, password_hash, role, created_at) VALUES ('Estq','e@x.test','x','estoquista',?)", new Date().toISOString()).id;
  app.stock.change(p.id, 3, { reason: 'compra', note: 'novo lote', staffId: staff });
  assert.equal(app.catalog.byId(p.id).quantity, 8);
  app.stock.change(p.id, -2, { reason: 'perda', staffId: staff });
  app.stock.adjustTo(p.id, 4, { reason: 'ajuste', staffId: staff });
  assert.equal(app.catalog.byId(p.id).quantity, 4);
  assert.throws(() => app.stock.change(p.id, -10, { reason: 'perda', staffId: staff }), /estoque|insuficiente|negativ/i);
  assert.equal(app.catalog.byId(p.id).quantity, 4, 'saldo não muda quando a saída é recusada');
  const mv = app.stock.movements(p.id);
  assert.deepEqual(mv.map((m) => m.delta), [-2, -2, 3, 5], 'mais recente primeiro: ajuste para 4 (−2), perda (−2), compra (+3), cadastro (+5)');
  assert.deepEqual(mv.map((m) => m.balance_after), [4, 6, 8, 5]);
  assert.equal(mv[0].staff_name, 'Estq');
  assert.equal(mv.at(-1).reason, 'cadastro');
  // reserva vencida libera a disponibilidade
  const o = app.db.run("INSERT INTO orders (number, public_token, status, payment_status, customer_name, customer_email, delivery_kind, subtotal_cents, total_cents, created_at) VALUES ('BC-T-0001','tok-1','awaiting_payment','pending','A B','a@b.test','pickup',2500,2500,?)", new Date().toISOString()).id;
  app.stock.reserve(o, [{ product_id: p.id, qty: 3, name: p.name }], new Date(Date.now() + 60000).toISOString());
  assert.equal(app.stock.available(p.id), 1);
  app.db.run("UPDATE stock_reservations SET expires_at = ? WHERE order_id = ?", new Date(Date.now() - 1000).toISOString(), o);
  assert.equal(app.stock.available(p.id), 4, 'reserva vencida deixa de segurar a peça');
});

test('entrega: frete grátis acima do valor, retirada, entrega local por CEP e opção inválida recusada', async (t) => {
  const app = mkApp(t);
  const { fixed, pickup } = seedBasics(app);
  const local = app.shipping.saveMethod({ kind: 'local', name: 'Motoboy', price: '8,00', zip_prefixes: '13000, 13010', active: true });
  const q = (zip, subtotal) => app.shipping.quote({ zip, subtotalCents: subtotal, items: [] });
  let r = await q('01310100', 10000);
  assert.deepEqual(r.options.map((o) => o.key).sort(), [String(fixed), String(pickup)].sort());
  assert.equal(r.options.find((o) => o.key === String(fixed)).price_cents, 1500);
  r = await q('01310100', 30000);
  assert.equal(r.options.find((o) => o.key === String(fixed)).price_cents, 0, 'frete grátis a partir de R$ 300,00');
  r = await q('13010050', 5000);
  assert.ok(r.options.some((o) => o.key === String(local)), 'entrega local no CEP atendido');
  assert.ok(!(await q('01310100', 5000)).options.some((o) => o.key === String(local)), 'entrega local fora da área não aparece');
  r = await q('', 5000);
  assert.deepEqual(r.options.map((o) => o.key), [String(pickup)], 'sem CEP só a retirada');
  await assert.rejects(() => app.shipping.resolve({ key: '9999', zip: '01310100', subtotalCents: 1000, items: [] }), /entrega válida/i);
  // Melhor Envio sem token: não oferece e não inventa preço
  app.shipping.saveMethod({ kind: 'melhorenvio', name: 'Transportadoras', active: true });
  r = await q('01310100', 5000);
  assert.ok(!r.options.some((o) => /Transportadoras/.test(o.name)), 'sem credenciais não aparece cotação');
});

test('checkout pelo HTTP: preço vem do servidor, Pix é gerado e a página do pedido mostra QR e copia-e-cola', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk, fixed } = seedBasics(app);
  const p = mk('Vestido do HTTP', '120,00');
  const c = new Client(srv.base);
  const prod = await c.get(`/produto/${p.slug}`);
  assert.equal(prod.status, 200);
  assert.match(prod.text, /Vestido do HTTP/);
  const add = await c.post('/carrinho/adicionar', { product_id: String(p.id), buy_now: '0' });
  assert.ok([200, 303].includes(add.status), `adicionar ao carrinho: ${add.status}`);
  const cart = await c.get('/carrinho');
  assert.match(cart.text, /Vestido do HTTP/);
  // tenta adulterar valores: o servidor ignora
  const r = await c.post('/checkout', {
    name: 'Cliente HTTP Teste', email: 'http@cliente.test', phone: '11987654321', zip: '01310100', state: 'SP', city: 'São Paulo', district: 'Bela Vista',
    street: 'Rua do Teste', number: '99', shipping_key: String(fixed), place: '1', total: '1', total_cents: '1', price: '1', shipping_cents: '0',
  });
  assert.equal(r.status, 303, `checkout deveria redirecionar (veio ${r.status}): ${r.text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 300)}`);
  assert.match(r.location, /^\/pedido\/[A-Za-z0-9_-]+$/);
  const order = app.db.get('SELECT * FROM orders ORDER BY id DESC LIMIT 1');
  assert.equal(order.total_cents, 12000 + 1500, 'total calculado no servidor');
  assert.equal(order.status, 'awaiting_payment');
  assert.equal(app.stock.available(p.id), 0);
  const page = await c.get(r.location);
  assert.equal(page.status, 200);
  assert.match(page.text, /data-copy|copia e cola|Copiar/i);
  const payload = app.payments.openPayment(order.id).pix_payload;
  assert.ok(payload && page.text.includes(payload.slice(0, 20)), 'código Pix exibido');
  // outro visitante não consegue comprar a mesma peça
  const c2 = new Client(srv.base);
  await c2.get('/');
  const again = await c2.post('/carrinho/adicionar', { product_id: String(p.id), buy_now: '0' });
  assert.ok(again.status >= 300 || /reservad|vendid/i.test(again.text));
  assert.equal(app.cart.view({ visitorToken: [...c2.jar].find(([k]) => k === 'bc_vid')[1], ip: '1' }).count, 0);
  // página do pedido informa o status via API
  const st = await c.get(`/api/pedido/${order.public_token}/status`, { headers: { accept: 'application/json' } });
  assert.equal(st.status, 200);
  assert.equal(JSON.parse(st.text).done, false);
  // pagamento confirma por webhook e a página reflete
  await deliverWebhook(app, app.providers.get('mock').simulatePay(app.payments.openPayment(order.id).provider_payment_id));
  const done = await c.get(`/api/pedido/${order.public_token}/status`, { headers: { accept: 'application/json' } });
  assert.equal(JSON.parse(done.text).done, true);
  assert.match((await c.get(r.location)).text, /Pagamento confirmado/i);
});

test('checkout recusa dados inválidos e entrega sem endereço', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk, fixed, pickup } = seedBasics(app);
  const p = mk('Saia midi', '70,00');
  const c = new Client(srv.base);
  await c.get('/'); // abre a sessão do visitante e carrega o token CSRF
  await c.post('/carrinho/adicionar', { product_id: String(p.id), buy_now: '0' });
  assert.equal(app.cart.view({ visitorToken: c.jar.get('bc_vid'), ip: '1' }).count, 1, 'peça está no carrinho');
  const base = { name: 'Cliente Valido', email: 'ok@cliente.test', phone: '11987654321', zip: '01310100', state: 'SP', city: 'São Paulo', district: 'Centro', street: 'Rua A', number: '1', shipping_key: String(fixed), place: '1' };
  for (const [campo, valor] of [['email', 'sem-arroba'], ['name', 'Um'], ['phone', '123'], ['shipping_key', '9999']]) {
    const r = await c.post('/checkout', { ...base, [campo]: valor });
    assert.equal(r.status, 422, `${campo} inválido deve ser recusado`);
  }
  const semRua = await c.post('/checkout', { ...base, street: '', number: '' });
  assert.equal(semRua.status, 422, 'envio exige endereço completo');
  assert.equal(app.db.value('SELECT COUNT(*) FROM orders'), 0, 'nenhum pedido criado por dados inválidos');
  assert.equal(app.stock.available(p.id), 1, 'peça não ficou reservada');
  const retirada = await c.post('/checkout', { ...base, shipping_key: String(pickup), street: '', number: '', district: '', city: '', state: '', zip: '' });
  assert.equal(retirada.status, 303, `retirada dispensa endereço (veio ${retirada.status})`);
});

test('Pix expirado: novo Pix reabre o pedido se a peça estiver livre; pagamento tardio recontabiliza o cupom', async (t) => {
  const app = mkApp(t);
  const { mk, fixed } = seedBasics(app);
  const p = mk('Jaqueta', '200,00');
  app.coupons.save({ code: 'VINTE', kind: 'percent', value: '20', active: true });
  const ctx = ctxFor('visitante-x-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
  app.cart.add(ctx, p.id, 1);
  const cart = app.cart.view(ctx);
  const opt = await app.shipping.resolve({ key: fixed, zip: '01310100', subtotalCents: cart.subtotal_cents, items: [] });
  const f = app.orders.parseCheckout({ name: 'Maria de Teste', email: 'maria.teste@example.com', phone: '11987654321', zip: '01310100', state: 'SP', city: 'São Paulo', district: 'Centro', street: 'Rua A', number: '1', shipping_key: String(fixed) }, { requiresCpf: false });
  const cr = app.coupons.evaluate('VINTE', [{ product_id: p.id, unit_cents: p.price_cents, qty: 1 }], cart.subtotal_cents);
  const order = app.orders.createReserved({ cart, form: f, shippingOpt: opt, couponResult: cr, customerId: null });
  const pay = await app.payments.createPixForOrder(order);
  const cupom = () => app.db.get("SELECT used_count FROM coupons WHERE code = 'VINTE'").used_count;
  assert.equal(cupom(), 1);
  // expira
  await app.orders.cancelUnpaid(order.id, { actor: 'sistema', reason: 'Pix expirou', expired: true, silent: true });
  assert.equal(cupom(), 0);
  assert.equal(app.stock.available(p.id), 1);
  // reabrir: gera nova cobrança e volta a reservar e a contar o cupom
  const reopened = await app.payments.reopenExpired(app.orders.get(order.id));
  assert.equal(reopened.status, 'awaiting_payment');
  assert.equal(cupom(), 1);
  assert.equal(app.stock.available(p.id), 0);
  const novo = app.payments.openPayment(order.id);
  assert.ok(novo && novo.id !== pay.id);
  // cancela de novo e simula o dinheiro entrando no provedor depois do cancelamento
  await app.orders.cancelUnpaid(order.id, { actor: 'sistema', reason: 'expirou de novo', expired: true, silent: true });
  assert.equal(cupom(), 0);
  const ev = payedDespiteCancel(app, novo.provider_payment_id);
  await deliverWebhook(app, ev);
  const final = app.orders.get(order.id);
  assert.equal(final.status, 'paid', 'pagamento tardio com a peça livre reativa o pedido');
  assert.equal(cupom(), 1, 'o uso do cupom volta a contar quando o pedido com desconto é pago');
  // reabrir um pedido que não está expirado é recusado
  await assert.rejects(() => app.payments.reopenExpired(final), /não pode gerar/i);
});

test('painel: cadastro de produto com foto aparece na loja; estoque gera movimentações; vendida fora some; exclusão protegida', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { catId } = seedBasics(app);
  const adm = await staffLogin(app, srv.base, { role: 'admin', email: 'adm@loja.test' });
  const novo = await adm.post('/admin/produtos', { name: 'Vestido do Painel', category_id: String(catId), brand: 'Marca', size: 'P', price: '99,90', promo: '89,90', quantity: '1', status: 'published', description: 'Peça de teste.' });
  assert.equal(novo.status, 303, novo.text.slice(0, 200));
  const id = Number(/\/admin\/produtos\/(\d+)/.exec(novo.location)[1]);
  assert.equal(app.db.value('SELECT COUNT(*) FROM product_images WHERE product_id = ?', id), 0);
  // aparece na loja mesmo sem foto (sem foto = imagem padrão), e não é vendável com preço errado
  const pub = new Client(srv.base);
  assert.match((await pub.get('/loja')).text, /Vestido do Painel/);
  // foto
  const up = await adm.upload(`/admin/produtos/${id}/imagens`, pngBuffer());
  assert.equal(up.status, 200, up.text);
  assert.equal(app.db.value('SELECT COUNT(*) FROM product_images WHERE product_id = ? AND is_primary = 1', id), 1, 'primeira foto vira principal');
  await adm.upload(`/admin/produtos/${id}/imagens`, pngBuffer(8, 8, [1, 2, 3]));
  const imgs = app.catalog.images(id);
  assert.equal(imgs.length, 2);
  await adm.post(`/admin/produtos/${id}/imagens/${imgs[1].id}/principal`, {});
  assert.equal(app.catalog.images(id)[0].id, imgs[1].id, 'trocar principal');
  await adm.post(`/admin/produtos/${id}/imagens/${imgs[0].id}/excluir`, {});
  assert.equal(app.catalog.images(id).length, 1);
  // produto de outro id inexistente
  assert.equal((await adm.upload('/admin/produtos/99999/imagens', pngBuffer())).status, 404);
  // edição inválida mostra erro e não altera
  const ruim = await adm.post(`/admin/produtos/${id}`, { name: 'Vestido do Painel', price: '50,00', promo: '60,00', quantity: '1', status: 'published' });
  assert.equal(ruim.status, 422);
  assert.equal(app.catalog.byId(id).price_cents, 9990);
  // estoque
  await adm.post(`/admin/estoque/${id}`, { mode: 'in', qty: '2', reason: 'compra', note: 'chegaram mais' });
  assert.equal(app.catalog.byId(id).quantity, 3);
  await adm.post(`/admin/estoque/${id}`, { mode: 'out', qty: '1', reason: 'perda' });
  assert.equal(app.catalog.byId(id).quantity, 2);
  await adm.post(`/admin/estoque/${id}`, { mode: 'out', qty: '50', reason: 'perda' });
  assert.equal(app.catalog.byId(id).quantity, 2, 'saída maior que o saldo é recusada');
  assert.ok(app.stock.movements(id).length >= 3);
  const csv = (await adm.get('/admin/estoque/movimentacoes.csv')).text;
  assert.match(csv, /Vestido do Painel/);
  // vendida fora do site
  await adm.post(`/admin/produtos/${id}/vendida-fora`, {});
  assert.equal(app.catalog.byId(id).quantity, 0);
  assert.ok(!(await pub.get('/loja')).text.includes('Vestido do Painel'), 'peça zerada sai da vitrine');
  // produto com venda não pode ser excluído; sem venda pode
  const { fixed } = { fixed: app.shipping.methods()[1].id };
  app.catalog.setStatus(id, 'published'); app.stock.change(id, 1, { reason: 'ajuste' });
  await placeOrder(app, ctxFor('v-del-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'), { items: [app.catalog.byId(id)], shippingKey: fixed });
  await adm.post(`/admin/produtos/${id}/excluir`, {});
  assert.ok(app.catalog.byId(id), 'produto com pedido não é excluído');
  const livre = app.catalog.createProduct(app.catalog.parseProductForm({ name: 'Sem venda', price: '10,00', quantity: '1', status: 'draft' }));
  await adm.post(`/admin/produtos/${livre}/excluir`, {});
  assert.equal(app.catalog.byId(livre), undefined);
  // auditoria registrou
  assert.ok(app.db.get("SELECT 1 FROM audit_logs WHERE action = 'product.created'"));
  assert.ok(app.db.get("SELECT 1 FROM audit_logs WHERE action = 'stock.changed'"));
});

test('páginas públicas essenciais abrem, têm SEO e não expõem rascunhos', async (t) => {
  const app = mkApp(t);
  const srv = await startServer(app);
  t.after(() => srv.close());
  const { mk } = seedBasics(app);
  const pub = mk('Peça pública', '30,00');
  const rasc = mk('Peça rascunho', '30,00', { status: 'draft' });
  const c = new Client(srv.base);
  for (const path of ['/', '/loja', '/contato', '/carrinho', '/p/politica-de-privacidade', '/p/termos-de-uso', '/p/trocas-e-devolucoes', '/p/cancelamento-e-reembolso', '/p/entrega-e-retirada', '/minha-conta/entrar', '/minha-conta/cadastrar', '/privacidade/solicitacoes']) {
    const r = await c.get(path);
    assert.equal(r.status, 200, path);
    assert.match(r.text, /<title>[^<]+<\/title>/, `${path} tem título`);
  }
  const prod = await c.get(`/produto/${pub.slug}`);
  assert.match(prod.text, /og:title/);
  assert.match(prod.text, /application\/ld\+json/);
  assert.match(prod.text, /"@type":\s*"Product"/);
  assert.equal((await c.get(`/produto/${rasc.slug}`)).status, 404, 'rascunho não é acessível');
  assert.equal((await c.get('/produto/nao-existe')).status, 404);
  const map = await c.get('/sitemap.xml');
  assert.match(map.text, new RegExp(pub.slug));
  assert.ok(!map.text.includes(rasc.slug), 'sitemap não lista rascunho');
  assert.ok(!map.text.includes('/admin'), 'sitemap não lista o painel');
  assert.match((await c.get('/robots.txt')).text, /Sitemap:/);
});
