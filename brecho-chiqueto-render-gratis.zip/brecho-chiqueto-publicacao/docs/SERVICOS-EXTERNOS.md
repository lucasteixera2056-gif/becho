# Contas e serviços externos que o brechó precisa ter

Esta lista separa o que é **obrigatório para vender**, o que é **recomendado** e o que é **opcional**. Preços, taxas e planos mudam e são definidos por cada empresa — **este projeto não informa valores**; consulte os sites oficiais antes de contratar.

## Obrigatórios para vender

| Serviço | Para quê | O que você fornece | Como entra no sistema |
|---|---|---|---|
| **Domínio próprio** (ex.: registro.br) | Endereço da loja e remetente dos e-mails | Domínio registrado em seu nome/CPF/CNPJ | DNS aponta para o servidor; `BASE_URL` |
| **Hospedagem com disco persistente e HTTPS** | Rodar a loja | Conta em VPS ou plataforma de aplicações | [`PUBLICACAO.md`](PUBLICACAO.md) |
| **Provedor de Pix — Asaas _ou_ Mercado Pago** | Gerar cobrança Pix, avisar o pagamento, reembolsar | Conta aprovada (cadastro/verificação do provedor), chave de API/Access Token e segredo do webhook | `.env`: `PAYMENT_PROVIDER` + credenciais ([`PAGAMENTOS.md`](PAGAMENTOS.md)) |
| **Resend** (e-mails automáticos) | Confirmação de conta, pedido, Pix, rastreio… | Conta Resend, **domínio verificado** (registros DNS SPF/DKIM), chave de API | `.env`: `RESEND_API_KEY`, `EMAIL_FROM` ([`EMAIL.md`](EMAIL.md)) |
| **Caixa de e-mail comum** | **Receber** as respostas dos clientes (o Resend só envia) | Um endereço real, ex.: `contato@seu-dominio` | `EMAIL_REPLY_TO` e e-mail de contato nas Configurações |

## Recomendados

| Serviço | Para quê |
|---|---|
| **Armazenamento externo para backup** (nuvem ou outro disco) | Guardar cópias de `backups/` fora do servidor |
| **Gerenciador de senhas** | Guardar a `SECRET_KEY`, chaves de API e a senha do superadministrador |
| **Advogado(a)** | Revisar Política de Privacidade, Termos, Trocas/Devoluções, Cancelamento/Reembolso, Entrega/Retirada (os textos do sistema são **modelos**) |
| **Contador(a)** | Emissão de nota fiscal e enquadramento fiscal — **a loja não emite nota fiscal** |
| **Google Search Console** | Acompanhar a loja no Google (envie o `sitemap.xml`) |

## Opcionais

| Serviço | Para quê | Observação |
|---|---|---|
| **Melhor Envio** | Cotação de frete em tempo real | Conta + token (`MELHORENVIO_TOKEN`) + CEP de origem; **integração não validada com conta real** |
| **Correios** | Frete direto | **Não integrado.** Exige contrato próprio; hoje use frete fixo ou o Melhor Envio |
| **ViaCEP** (gratuito, sem conta) | Preencher endereço ao digitar o CEP no checkout | O navegador do cliente consulta direto; se estiver fora do ar, o cliente digita o endereço |
| **Cloudflare / CDN** | Proteção e cache | Se usar, o proxy precisa entregar o IP real do cliente (veja `PUBLICACAO.md`) |

## O que você precisa me fornecer / decidir (informações comerciais)

Nada abaixo foi inventado — a loja só exibe o que você preencher:

- Nome da razão social/CNPJ ou CPF a exibir no rodapé (se quiser), e-mail, telefone/WhatsApp, endereço e horário (se houver ponto físico ou retirada).
- **Políticas reais**: prazo de troca/devolução, regras de cancelamento, condições de retirada, prazo de postagem.
- **Formas de entrega e valores** (frete fixo, grátis a partir de R$ X, entrega local e CEPs atendidos).
- Tempo para pagar o Pix (padrão 30 min) e tolerância de reserva.
- **Identidade visual** (logo, cores, imagem de capa, fotos das peças) — logo e capa são enviados em *Configurações → Aparência e início*; o projeto traz apenas uma paleta inicial editável (vinho e dourado, fundo claro). As fotos e peças reais vêm de você.
- Cupons e promoções.
