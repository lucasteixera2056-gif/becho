'use strict';
/** Vitrine pública: início, catálogo, produto, páginas institucionais, contato, newsletter, SEO. */
const { html, raw, escape, richText, paragraphs } = require('../lib/html');
const { money, UserError, formatDate, int } = require('../lib/util');
const { icon, csrfField, imgUrl, pager, qs, field, badge } = require('./ui');
const { storeLayout, orgJsonLd, waLink, abs } = require('./layout');

function register(router, app) {
  const { cfg } = app;

  // ───── componentes ─────
  const discount = (p) => Math.round((1 - p.effective_cents / p.price_cents) * 100);

  const card = (p) => html`<article class="card${p.sold_out ? ' is-sold' : ''}">
  <a href="/produto/${p.slug}" class="card-link">
    <div class="ph">${p.image ? html`<img src="${imgUrl(p.image)}" alt="${p.name}" loading="lazy" decoding="async">` : html`<span class="ph-empty" aria-hidden="true">${app.settings.get('store_name').slice(0, 1)}</span>`}
      ${p.on_sale ? html`<span class="tag tag-sale">-${discount(p)}%</span>` : ''}${p.sold_out ? html`<span class="tag tag-sold">Vendida</span>` : ''}
    </div>
    <h3>${p.name}</h3>
    <p class="meta">${[p.size && `Tam. ${p.size}`, p.brand].filter(Boolean).join(' · ') || raw('&nbsp;')}</p>
    <p class="price">${p.on_sale ? html`<s>${money(p.price_cents)}</s> ` : ''}<strong>${money(p.effective_cents)}</strong></p>
  </a>
</article>`;

  const shelf = (title, items, more) => (items.length ? html`<section class="shelf wrap"><header><h2>${title}</h2>${more ? html`<a href="${more}">Ver tudo ${icon('chevron', 16)}</a>` : ''}</header><div class="grid-cards">${items.map(card)}</div></section>` : '');

  // ───── início ─────
  router.get('/', (ctx) => {
    const s = app.settings.all();
    const hero = app.content.banners.active('hero');
    const news = app.content.banners.active('news');
    const tree = app.catalog.categoryTree();
    const latest = app.catalog.latest(8);
    const featured = app.catalog.featured(8);
    const promos = app.catalog.promos(8);
    const best = app.catalog.bestSellers(8);
    const h0 = hero[0];
    const heroTitle = h0?.title || s.hero_title;
    const heroSub = h0 ? h0.subtitle : s.hero_subtitle;
    const heroImg = h0?.image || s.hero_image;
    const heroUrl = h0?.link_url || s.hero_cta_url || '/loja';
    const heroCta = h0?.cta_label || s.hero_cta_label || 'Ver peças';
    const total = app.catalog.list({}).total;
    const wa = waLink(s);

    const main = html`
<section class="hero${heroImg ? ' has-img' : ''}">
  ${heroImg ? html`<img class="hero-img" src="${imgUrl(heroImg)}" alt="" fetchpriority="high">` : ''}
  <div class="wrap hero-in"><div class="hero-copy"><h1>${heroTitle}</h1>${heroSub ? html`<p>${heroSub}</p>` : ''}<p><a class="btn btn-light" href="${heroUrl}">${heroCta}</a></p></div></div>
</section>
<section class="wrap perks" aria-label="Como funciona">
  <ul>
    <li>${icon('tag', 22)}<span><strong>Peças únicas</strong> Cada item é selecionado e tem fotos reais.</span></li>
    <li>${icon('pix', 22)}<span><strong>Pague com Pix</strong> Confirmação automática, sem enviar comprovante.</span></li>
    <li>${icon('truck', 22)}<span><strong>Entrega ou retirada</strong> Opções calculadas no checkout.</span></li>
  </ul>
</section>
${news.length ? html`<section class="wrap news-strip" aria-label="Avisos">${news.map((b) => html`<a class="news-card" href="${b.link_url || '/loja'}">${b.image ? html`<img src="${imgUrl(b.image)}" alt="" loading="lazy">` : ''}<span><strong>${b.title}</strong>${b.subtitle ? html`<small>${b.subtitle}</small>` : ''}</span></a>`)}</section>` : ''}
${tree.length ? html`<section class="wrap cats" aria-labelledby="h-cats"><h2 id="h-cats" class="sr">Categorias</h2><ul>${tree.map((c) => html`<li><a href="/loja/${c.slug}">${c.image ? html`<img src="${imgUrl(c.image)}" alt="" loading="lazy">` : html`<span class="cat-mono" aria-hidden="true">${c.name.slice(0, 1)}</span>`}<span>${c.name}</span></a></li>`)}</ul></section>` : ''}
${total === 0 ? html`<section class="wrap narrow center empty-store"><h2>Estamos preparando as primeiras peças</h2><p>Em breve o catálogo estará por aqui. Enquanto isso, acompanhe as novidades${s.store_instagram ? ' no Instagram' : ''}.</p>${s.store_instagram ? html`<p><a class="btn" href="${s.store_instagram}" target="_blank" rel="noopener noreferrer">Ver o Instagram</a></p>` : ''}</section>` : ''}
${shelf('Novidades', latest, '/loja?sort=novidades')}
${shelf('Em destaque', featured, '/loja?featured=1')}
${shelf('Promoções', promos, '/loja?promo=1')}
${shelf('Mais vendidas', best, '/loja')}
${s.about_text ? html`<section class="about"><div class="wrap narrow"><h2>${s.about_title}</h2>${paragraphs(s.about_text)}</div></section>` : ''}
${s.store_instagram ? html`<section class="insta"><div class="wrap narrow center">${icon('instagram', 30)}<h2>${s.instagram_cta_title}</h2><p>${s.instagram_cta_text}</p><p><a class="btn" href="${s.store_instagram}" target="_blank" rel="noopener noreferrer">Seguir no Instagram</a>${wa ? html` <a class="btn btn-ghost" href="${wa}" target="_blank" rel="noopener noreferrer">Chamar no WhatsApp</a>` : ''}</p></div></section>` : ''}`;
    ctx.html(storeLayout(ctx, app, { path: '/', main, jsonld: [orgJsonLd(app)], description: s.store_description || s.store_tagline }), 200, { 'Cache-Control': 'no-cache' });
  });

  // ───── catálogo ─────
  const FILTER_KEYS = ['q', 'size', 'brand', 'color', 'condition', 'price_min', 'price_max', 'promo', 'featured', 'sold', 'sort'];
  const catalogPage = (ctx) => {
    const slug = ctx.params.cat || '';
    const cat = slug ? app.catalog.categoryBySlug(slug) : null;
    if (slug && !cat) return ctx.fail(404, 'Categoria não encontrada.');
    const q = {};
    for (const k of FILTER_KEYS) if (ctx.url.searchParams.has(k)) q[k] = ['size', 'brand', 'color', 'condition'].includes(k) ? ctx.url.searchParams.getAll(k) : ctx.url.searchParams.get(k);
    const res = app.catalog.list({ ...q, category: slug, page: ctx.query.page });
    const facets = app.catalog.facets();
    const base = slug ? `/loja/${slug}` : '/loja';
    const link = (override = {}) => `${base}${qs(q, { page: '', ...override })}`;
    const parent = cat?.parent_id ? app.catalog.categoryById(cat.parent_id) : null;
    const children = cat ? app.catalog.categories().filter((c) => c.parent_id === cat.id) : [];
    const title = q.q ? `Busca: ${q.q}` : q.promo ? 'Promoções' : cat ? cat.name : 'Todas as peças';
    const chips = [];
    for (const k of ['size', 'brand', 'color', 'condition']) for (const v of [].concat(q[k] || [])) chips.push({ label: `${v}`, href: link({ [k]: [].concat(q[k]).filter((x) => x !== v) }) });
    if (q.price_min) chips.push({ label: `a partir de R$ ${q.price_min}`, href: link({ price_min: '' }) });
    if (q.price_max) chips.push({ label: `até R$ ${q.price_max}`, href: link({ price_max: '' }) });
    if (q.promo) chips.push({ label: 'Promoção', href: link({ promo: '' }) });
    if (q.q) chips.push({ label: `“${q.q}”`, href: link({ q: '' }) });
    const group = (label, key, list) => (list.length ? html`<fieldset><legend>${label}</legend>${list.map((o) => html`<label class="check"><input type="checkbox" name="${key}" value="${o.v}" ${[].concat(q[key] || []).includes(o.v) ? raw('checked') : ''}> ${o.v} <small>(${o.n})</small></label>`)}</fieldset>` : '');
    const sortOpts = [['novidades', 'Novidades'], ['menor_preco', 'Menor preço'], ['maior_preco', 'Maior preço'], ...(q.q ? [['relevancia', 'Mais relevantes']] : [])];

    const main = html`
<div class="wrap crumbs"><nav aria-label="Você está em"><a href="/">Início</a> › <a href="/loja">Loja</a>${parent ? html` › <a href="/loja/${parent.slug}">${parent.name}</a>` : ''}${cat ? html` › <span aria-current="page">${cat.name}</span>` : ''}</nav></div>
<div class="wrap catalog">
  <aside class="filters">
    <details ${chips.length ? raw('open') : ''} class="filters-box">
      <summary>Filtrar${chips.length ? html` <span class="count-pill">${chips.length}</span>` : ''}</summary>
      <form method="get" action="${base}">
        ${q.q ? html`<input type="hidden" name="q" value="${q.q}">` : ''}${q.sort ? html`<input type="hidden" name="sort" value="${q.sort}">` : ''}${q.promo ? html`<input type="hidden" name="promo" value="1">` : ''}
        ${group('Tamanho', 'size', facets.sizes)}${group('Marca', 'brand', facets.brands)}${group('Cor', 'color', facets.colors)}${group('Estado', 'condition', facets.conditions)}
        <fieldset><legend>Preço (R$)</legend><div class="row2"><label class="sr" for="pmin">Mínimo</label><input id="pmin" name="price_min" inputmode="decimal" placeholder="Mín." value="${q.price_min || ''}"><label class="sr" for="pmax">Máximo</label><input id="pmax" name="price_max" inputmode="decimal" placeholder="Máx." value="${q.price_max || ''}"></div></fieldset>
        <label class="check"><input type="checkbox" name="sold" value="1" ${q.sold ? raw('checked') : ''}> Mostrar também peças vendidas</label>
        <div class="filter-actions"><button class="btn btn-small" type="submit">Aplicar</button> ${chips.length ? html`<a class="btn btn-ghost btn-small" href="${base}">Limpar</a>` : ''}</div>
      </form>
    </details>
  </aside>
  <div class="results">
    <header class="results-head">
      <div><h1>${title}</h1><p class="muted">${res.total} ${res.total === 1 ? 'peça' : 'peças'}</p></div>
      <form method="get" action="${base}" class="sort"><label for="sort">Ordenar</label>${['q', 'price_min', 'price_max', 'promo', 'sold'].map((k) => (q[k] ? html`<input type="hidden" name="${k}" value="${q[k]}">` : ''))}${['size', 'brand', 'color', 'condition'].flatMap((k) => [].concat(q[k] || []).map((v) => html`<input type="hidden" name="${k}" value="${v}">`))}<select id="sort" name="sort" data-autosubmit>${sortOpts.map(([v, l]) => html`<option value="${v}" ${res.sort === v ? raw('selected') : ''}>${l}</option>`)}</select><noscript><button class="btn btn-small">OK</button></noscript></form>
    </header>
    ${children.length ? html`<ul class="subcats">${children.map((c) => html`<li><a href="/loja/${c.slug}">${c.name}</a></li>`)}</ul>` : ''}
    ${chips.length ? html`<ul class="chips">${chips.map((c) => html`<li><a href="${c.href}" aria-label="Remover filtro ${c.label}">${c.label} ${icon('close', 14)}</a></li>`)}</ul>` : ''}
    ${res.items.length ? html`<div class="grid-cards">${res.items.map(card)}</div>${pager(res, (n) => link({ page: n }))}` : html`<div class="empty"><h2>Nenhuma peça encontrada</h2><p>${chips.length ? 'Tente remover alguns filtros ou buscar por outro termo.' : 'Ainda não há peças nesta seção. Volte em breve!'}</p>${chips.length ? html`<a class="btn" href="${base}">Limpar filtros</a>` : html`<a class="btn" href="/loja">Ver todas as peças</a>`}</div>`}
  </div>
</div>`;
    ctx.html(storeLayout(ctx, app, { title, path: link({ page: res.page > 1 ? res.page : '' }), main, noindex: !!q.q, description: cat?.description || undefined, jsonld: [{ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Início', item: cfg.baseUrl }, { '@type': 'ListItem', position: 2, name: 'Loja', item: `${cfg.baseUrl}/loja` }, ...(cat ? [{ '@type': 'ListItem', position: 3, name: cat.name, item: `${cfg.baseUrl}/loja/${cat.slug}` }] : [])] }] }));
  };
  router.get('/loja', catalogPage);
  router.get('/loja/:cat', catalogPage);

  // ───── produto ─────
  router.get('/produto/:slug', (ctx) => {
    const p = app.catalog.bySlug(ctx.params.slug);
    if (!p) return ctx.fail(404, 'Esta peça não existe ou foi removida.');
    const s = app.settings.all();
    const images = app.catalog.images(p.id);
    const related = app.catalog.related(p, 4);
    const crumbs = app.catalog.categoryPath(p.category_id);
    const url = `${cfg.baseUrl}/produto/${p.slug}`;
    const wa = waLink(s, `Olá! Tenho uma dúvida sobre a peça "${p.name}" (${p.sku}): ${url}`);
    const share = `https://wa.me/?text=${encodeURIComponent(`${p.name} — ${money(p.effective_cents)} ${url}`)}`;
    const attrs = [['Tamanho', p.size], ['Marca', p.brand], ['Cor', p.color], ['Estado', p.condition], ['Medidas', p.measures], ['Código', p.sku]].filter(([, v]) => v);
    const jsonld = [{
      '@context': 'https://schema.org', '@type': 'Product', name: p.name, sku: p.sku, description: (p.description || p.name).slice(0, 500),
      ...(images.length ? { image: images.map((i) => abs(cfg, imgUrl(i.filename))) } : {}), ...(p.brand ? { brand: { '@type': 'Brand', name: p.brand } } : {}),
      ...(p.color ? { color: p.color } : {}),
      offers: { '@type': 'Offer', url, priceCurrency: 'BRL', price: (p.effective_cents / 100).toFixed(2), itemCondition: /^novo/i.test(p.condition || '') ? 'https://schema.org/NewCondition' : 'https://schema.org/UsedCondition', availability: p.available > 0 ? 'https://schema.org/InStock' : 'https://schema.org/SoldOut' },
    }, { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Início', item: cfg.baseUrl }, ...crumbs.map((c, i) => ({ '@type': 'ListItem', position: i + 2, name: c.name, item: `${cfg.baseUrl}/loja/${c.slug}` })), { '@type': 'ListItem', position: crumbs.length + 2, name: p.name }] }];

    const main = html`
<div class="wrap crumbs"><nav aria-label="Você está em"><a href="/">Início</a> › <a href="/loja">Loja</a>${crumbs.map((c) => html` › <a href="/loja/${c.slug}">${c.name}</a>`)} › <span aria-current="page">${p.name}</span></nav></div>
<article class="wrap product">
  <div class="gallery" data-gallery>
    <div class="gallery-main ph">${images.length ? html`<img id="main-img" src="${imgUrl(images[0].filename)}" alt="${images[0].alt || p.name}" fetchpriority="high">` : html`<span class="ph-empty" aria-hidden="true">${s.store_name.slice(0, 1)}</span>`}${p.on_sale && !p.sold_out ? html`<span class="tag tag-sale">-${discount(p)}%</span>` : ''}${p.sold_out ? html`<span class="tag tag-sold">Vendida</span>` : ''}</div>
    ${images.length > 1 ? html`<ul class="thumbs">${images.map((im, i) => html`<li><a href="${imgUrl(im.filename)}" data-thumb data-src="${imgUrl(im.filename)}" data-alt="${im.alt || p.name}" ${i === 0 ? raw('aria-current="true"') : ''}><img src="${imgUrl(im.filename)}" alt="Foto ${i + 1} de ${images.length}" loading="lazy"></a></li>`)}</ul>` : ''}
  </div>
  <div class="info">
    <h1>${p.name}</h1>
    <p class="price big">${p.on_sale ? html`<s>${money(p.price_cents)}</s> ` : ''}<strong>${money(p.effective_cents)}</strong>${p.on_sale ? html` <span class="tag tag-sale inline">-${discount(p)}%</span>` : ''}</p>
    <p class="pix-note">${icon('pix', 16)} Pague com Pix — confirmação automática.</p>
    ${p.sold_out
    ? html`<div class="notice notice-sold"><strong>Esta peça já foi vendida ou está reservada por outro cliente.</strong><p>Peças reservadas voltam ao catálogo se o pagamento não for feito no prazo. Veja peças parecidas abaixo.</p></div>`
    : html`<form method="post" action="/carrinho/adicionar" class="buy">${csrfField(ctx)}<input type="hidden" name="product_id" value="${p.id}">
        ${p.available > 1 ? html`<div class="field qty"><label for="qty">Quantidade</label><input id="qty" name="qty" type="number" min="1" max="${p.available}" value="1" inputmode="numeric"></div>` : html`<input type="hidden" name="qty" value="1">`}
        <div class="buy-btns"><button class="btn" type="submit" name="buy_now" value="0" data-add-to-cart>${icon('cart', 18)} Adicionar ao carrinho</button><button class="btn btn-dark" type="submit" name="buy_now" value="1">Comprar agora</button></div></form>
      ${p.available === 1 ? html`<p class="muted small">Peça única — só temos 1 unidade.</p>` : html`<p class="muted small">${p.available} unidades disponíveis.</p>`}`}
    <dl class="attrs">${attrs.map(([k, v]) => html`<div><dt>${k}</dt><dd>${v}</dd></div>`)}</dl>
    ${p.defects ? html`<div class="notice notice-defects"><strong>${icon('alert', 16)} Detalhes e defeitos</strong><p>${p.defects}</p></div>` : ''}
    ${p.description ? html`<section class="desc"><h2>Sobre a peça</h2>${paragraphs(p.description)}</section>` : ''}
    <div class="share"><span>Compartilhar:</span>
      <a href="${share}" target="_blank" rel="noopener noreferrer">${icon('whatsapp', 16)} WhatsApp</a>
      <button type="button" class="linklike" data-copy="${url}">${icon('copy', 16)} Copiar link</button>
      <button type="button" class="linklike" data-share data-title="${p.name}" data-url="${url}" hidden>${icon('share', 16)} Mais…</button>
      ${wa ? html`<a href="${wa}" target="_blank" rel="noopener noreferrer">${icon('whatsapp', 16)} Perguntar sobre a peça</a>` : ''}
    </div>
    <ul class="trust"><li>${icon('shield', 18)} Compra protegida pelo Código de Defesa do Consumidor. <a href="/p/trocas-e-devolucoes">Trocas e devoluções</a></li><li>${icon('truck', 18)} Frete e prazo calculados no checkout. <a href="/p/entrega-e-retirada">Entrega e retirada</a></li></ul>
  </div>
</article>
${shelf('Você também pode gostar', related, null)}`;
    ctx.html(storeLayout(ctx, app, { title: p.name, description: (p.description || `${p.name} — ${money(p.effective_cents)}`).replace(/\s+/g, ' ').slice(0, 200), path: `/produto/${p.slug}`, image: images[0] ? imgUrl(images[0].filename) : '', ogType: 'product', jsonld, main, bodyClass: 'page-product' }));
  });

  // ───── páginas institucionais ─────
  router.get('/p/:slug', (ctx) => {
    const page = app.content.page(ctx.params.slug);
    if (!page) return ctx.fail(404, 'Página não encontrada.');
    const s = app.settings.all();
    const main = html`<article class="wrap narrow prose"><h1>${page.title}</h1>${richText(app.content.resolve(page.body))}<p class="muted small">Última atualização: ${formatDate(page.updated_at, { time: false, offsetMinutes: cfg.tzOffsetMinutes })}${s.legal_reviewed === '1' ? '' : ''}</p></article>`;
    ctx.html(storeLayout(ctx, app, { title: page.title, main, path: `/p/${page.slug}` }));
  });

  // ───── contato ─────
  const contactForm = (ctx, v = {}, err = {}) => html`
<section class="wrap narrow"><h1>Fale com a gente</h1>
<p class="lead">Tem dúvida sobre uma peça, um pedido ou a entrega? Escreva abaixo. ${app.settings.get('store_email') ? '' : 'Responderemos por e-mail.'}</p>
<form method="post" action="/contato" class="form-card" novalidate>
  ${csrfField(ctx)}
  <div class="hp" aria-hidden="true"><label>Não preencha <input name="website" tabindex="-1" autocomplete="off"></label></div>
  ${field({ label: 'Seu nome', name: 'name', value: v.name, required: true, autocomplete: 'name', error: err.name, maxlength: 100 })}
  ${field({ label: 'E-mail', name: 'email', type: 'email', value: v.email, required: true, autocomplete: 'email', error: err.email })}
  ${field({ label: 'Telefone / WhatsApp', name: 'phone', type: 'tel', value: v.phone, autocomplete: 'tel', inputmode: 'tel', error: err.phone })}
  ${field({ label: 'Assunto', name: 'subject', value: v.subject, maxlength: 120 })}
  <div class="field${err.message ? ' has-error' : ''}"><label for="f_message">Mensagem</label><textarea id="f_message" name="message" rows="6" required maxlength="2000">${v.message || ''}</textarea><div class="hint">${err.message ? html`<span class="err">${err.message}</span>` : 'Se for sobre um pedido, informe o número (BC-...).'}</div></div>
  <p class="small muted">Usaremos seus dados apenas para responder a esta mensagem. Veja a <a href="/p/politica-de-privacidade">Política de Privacidade</a>.</p>
  <button class="btn" type="submit">Enviar mensagem</button>
</form></section>`;

  router.get('/contato', (ctx) => ctx.html(storeLayout(ctx, app, { title: 'Contato', main: contactForm(ctx, ctx.customer ? { name: ctx.customer.name, email: ctx.customer.email } : {}) })));
  router.post('/contato', (ctx) => {
    const b = ctx.body;
    if (b.website) { ctx.flash('success', 'Mensagem enviada. Obrigada!'); return ctx.redirect('/contato'); } // isca anti-robô
    const lim = app.limiter.hit(`contact:${ctx.ip}`, 5, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas mensagens em pouco tempo. Tente novamente mais tarde.');
    try {
      app.crm.submitContact(b);
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      return ctx.html(storeLayout(ctx, app, { title: 'Contato', main: contactForm(ctx, b, { [e.field || 'message']: e.message }), noindex: true }), 422);
    }
    ctx.flash('success', 'Mensagem enviada! Enviamos uma confirmação para o seu e-mail.');
    ctx.redirect('/contato');
  });

  // ───── newsletter ─────
  router.post('/newsletter', (ctx) => {
    const lim = app.limiter.hit(`newsletter:${ctx.ip}`, 6, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas tentativas. Tente novamente mais tarde.');
    const back = ctx.req.headers.referer && ctx.req.headers.referer.startsWith(cfg.baseUrl) ? new URL(ctx.req.headers.referer).pathname : '/';
    if (ctx.body.consent !== '1') { ctx.flash('error', 'Marque a caixa de consentimento para receber novidades.'); return ctx.redirect(back); }
    try {
      const r = app.crm.subscribe({ email: ctx.body.email, ip: ctx.ip, consentText: 'Quero receber novidades do brechó por e-mail. Posso cancelar quando quiser.' });
      ctx.flash('success', r.already ? 'Este e-mail já está inscrito.' : 'Inscrição feita! Enviamos uma confirmação para o seu e-mail.');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      ctx.flash('error', e.message);
    }
    ctx.redirect(back);
  });
  router.get('/newsletter/cancelar/:token', (ctx) => {
    const ok = app.crm.unsubscribe(ctx.params.token);
    const main = html`<section class="wrap narrow center"><h1>${ok ? 'Inscrição cancelada' : 'Link inválido'}</h1><p>${ok ? 'Você não receberá mais nossas novidades por e-mail.' : 'Não encontramos esta inscrição.'}</p><p><a class="btn" href="/">Voltar à loja</a></p></section>`;
    ctx.html(storeLayout(ctx, app, { title: 'Cancelar inscrição', main, noindex: true }));
  });

  // ───── LGPD: pedido de acesso/eliminação (sem login) ─────
  router.get('/privacidade/solicitacoes', (ctx) => {
    const main = html`<section class="wrap narrow"><h1>Seus dados pessoais (LGPD)</h1>
<p class="lead">Você pode pedir acesso aos seus dados ou a eliminação deles. Responderemos no prazo legal. Se você tem conta, também pode fazer isso em <a href="/minha-conta/dados">Minha conta</a>.</p>
<form method="post" action="/privacidade/solicitacoes" class="form-card">${csrfField(ctx)}
${field({ label: 'E-mail cadastrado na loja', name: 'email', type: 'email', required: true, value: ctx.customer?.email || '', autocomplete: 'email' })}
<fieldset class="radio-group"><legend>O que você precisa?</legend><label class="check"><input type="radio" name="kind" value="access" checked> Receber uma cópia dos meus dados</label><label class="check"><input type="radio" name="kind" value="deletion"> Eliminar meus dados</label></fieldset>
<p class="small muted">Por segurança, a resposta é enviada apenas ao e-mail informado. Pedidos já realizados podem ser mantidos pelo prazo exigido em lei (obrigações fiscais e defesa em processos).</p>
<button class="btn" type="submit">Enviar solicitação</button></form></section>`;
    ctx.html(storeLayout(ctx, app, { title: 'Solicitações de privacidade', main, noindex: true }));
  });
  router.post('/privacidade/solicitacoes', (ctx) => {
    const lim = app.limiter.hit(`lgpd:${ctx.ip}`, 5, 3600);
    if (!lim.ok) return ctx.fail(429, 'Muitas tentativas. Tente novamente mais tarde.');
    try {
      app.crm.createDataRequest({ email: ctx.body.email, kind: ctx.body.kind, customerId: ctx.customer?.id ?? null });
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      ctx.flash('error', e.message);
      return ctx.redirect('/privacidade/solicitacoes');
    }
    // Resposta idêntica exista ou não cadastro (não revela quem é cliente).
    ctx.flash('success', 'Solicitação registrada. Entraremos em contato pelo e-mail informado dentro do prazo legal.');
    ctx.redirect('/privacidade/solicitacoes');
  });

  // ───── SEO ─────
  router.get('/robots.txt', (ctx) => ctx.text(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /carrinho\nDisallow: /checkout\nDisallow: /pedido/\nDisallow: /minha-conta\nDisallow: /api/\nDisallow: /webhooks/\n\nSitemap: ${cfg.baseUrl}/sitemap.xml\n`, 200, 'text/plain; charset=utf-8', { 'Cache-Control': 'public, max-age=3600' }));

  router.get('/sitemap.xml', (ctx) => {
    const urls = [{ loc: '/', pr: '1.0' }, { loc: '/loja', pr: '0.9' }, { loc: '/contato', pr: '0.3' }];
    for (const c of app.catalog.categories()) urls.push({ loc: `/loja/${c.slug}`, pr: '0.7' });
    for (const p of app.db.all("SELECT slug, updated_at FROM products WHERE status = 'published' ORDER BY id DESC LIMIT 5000")) urls.push({ loc: `/produto/${p.slug}`, last: p.updated_at, pr: '0.8' });
    for (const p of app.content.pages()) urls.push({ loc: `/p/${p.slug}`, pr: '0.2' });
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `<url><loc>${escape(cfg.baseUrl + u.loc)}</loc>${u.last ? `<lastmod>${u.last.slice(0, 10)}</lastmod>` : ''}<priority>${u.pr}</priority></url>`).join('\n')}\n</urlset>\n`;
    ctx.text(xml, 200, 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
  });

  void int;
  void badge;
}

module.exports = { register };
