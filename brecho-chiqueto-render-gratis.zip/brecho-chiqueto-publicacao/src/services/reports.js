'use strict';
/**
 * Relatórios e indicadores. Tudo é calculado a partir de pedidos/pagamentos REAIS do banco.
 * Definições (mantidas separadas de propósito, como pede o briefing):
 *   Pedidos criados  = pedidos feitos no período (qualquer situação)
 *   Faturado         = valor dos pedidos com pagamento confirmado (paid_at no período), sem descontar reembolsos
 *   Recebido (Pix)   = pagamentos confirmados pelo provedor no período, menos reembolsos feitos
 *   Pendente         = pedidos aguardando pagamento e dentro do prazo
 *   Taxas / Líquido  = SOMENTE quando o provedor informou; senão fica "não informado"
 *   Liquidado        = pagamentos cuja data de liquidação informada pelo provedor já passou
 *   A liquidar       = pagos, mas sem data de liquidação informada ou com data futura
 * A liquidação (quando o dinheiro cai na conta) depende das regras do provedor de pagamentos.
 */
const { now, toCsv, int } = require('../lib/util');

function makeReports(app) {
  const { db, cfg } = app;
  const off = cfg.tzOffsetMinutes;
  const dayExpr = (col) => `date(${col}, '${off} minutes')`;

  const localDate = (iso = new Date().toISOString()) => new Date(new Date(iso).getTime() + off * 60000).toISOString().slice(0, 10);
  const dayStartIso = (d) => new Date(new Date(`${d}T00:00:00.000Z`).getTime() - off * 60000).toISOString();
  const addDays = (d, n) => new Date(new Date(`${d}T00:00:00.000Z`).getTime() + n * 86400000).toISOString().slice(0, 10);
  const valid = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d || '') && !Number.isNaN(new Date(`${d}T00:00:00Z`).getTime());

  /** Converte filtros de data (AAAA-MM-DD, horário local) em intervalo [from, to) em UTC. */
  function range({ from, to, preset } = {}) {
    const today = localDate();
    let f = valid(from) ? from : null;
    let t = valid(to) ? to : null;
    if (preset === 'today') { f = today; t = today; }
    else if (preset === '7d') { f = addDays(today, -6); t = today; }
    else if (preset === '30d') { f = addDays(today, -29); t = today; }
    else if (preset === 'month') { f = `${today.slice(0, 7)}-01`; t = today; }
    else if (preset === 'all') { f = null; t = null; }
    if (!f && !t && !preset) { f = addDays(today, -29); t = today; }
    if (f && t && f > t) [f, t] = [t, f];
    return { from: f, to: t, fromIso: f ? dayStartIso(f) : '0000', toIso: t ? dayStartIso(addDays(t, 1)) : '9999', preset: preset || '' };
  }

  const money = (c) => (c / 100).toFixed(2).replace('.', ',');

  const reports = {
    range, localDate,

    /** Visão financeira do período. */
    finance(r) {
      const created = db.get("SELECT COUNT(*) AS n, COALESCE(SUM(total_cents),0) AS v FROM orders WHERE created_at >= ? AND created_at < ?", r.fromIso, r.toIso);
      const paidOrders = db.get("SELECT COUNT(*) AS n, COALESCE(SUM(total_cents),0) AS v, COALESCE(SUM(shipping_cents),0) AS ship, COALESCE(SUM(discount_cents),0) AS disc FROM orders WHERE paid_at >= ? AND paid_at < ?", r.fromIso, r.toIso);
      const pay = db.get(`SELECT COUNT(*) AS n, COALESCE(SUM(amount_cents),0) AS gross, COALESCE(SUM(refunded_cents),0) AS refunded,
          COALESCE(SUM(fee_cents),0) AS fees, COALESCE(SUM(net_cents),0) AS net,
          SUM(CASE WHEN fee_cents IS NULL THEN 1 ELSE 0 END) AS no_fee
        FROM payments WHERE status IN ('paid','partially_refunded','refunded') AND paid_at >= ? AND paid_at < ?`, r.fromIso, r.toIso);
      const today = localDate();
      const settled = db.get(`SELECT COUNT(*) AS n, COALESCE(SUM(COALESCE(net_cents, amount_cents - refunded_cents)),0) AS v FROM payments
        WHERE status IN ('paid','partially_refunded') AND paid_at >= ? AND paid_at < ? AND settlement_date IS NOT NULL AND settlement_date <= ?`, r.fromIso, r.toIso, today);
      const toSettle = db.get(`SELECT COUNT(*) AS n, COALESCE(SUM(COALESCE(net_cents, amount_cents - refunded_cents)),0) AS v FROM payments
        WHERE status IN ('paid','partially_refunded') AND paid_at >= ? AND paid_at < ? AND (settlement_date IS NULL OR settlement_date > ?)`, r.fromIso, r.toIso, today);
      const refunds = db.get('SELECT COUNT(*) AS n, COALESCE(SUM(amount_cents),0) AS v FROM refunds WHERE created_at >= ? AND created_at < ?', r.fromIso, r.toIso);
      const pending = db.get("SELECT COUNT(*) AS n, COALESCE(SUM(total_cents),0) AS v FROM orders WHERE status = 'awaiting_payment' AND (expires_at IS NULL OR expires_at > ?)", now());
      const expired = db.get("SELECT COUNT(*) AS n, COALESCE(SUM(total_cents),0) AS v FROM orders WHERE payment_status = 'expired' AND created_at >= ? AND created_at < ?", r.fromIso, r.toIso);
      const received = pay.gross - refunds.v;
      return {
        created: { count: created.n, cents: created.v },
        billed: { count: paidOrders.n, cents: paidOrders.v, shipping: paidOrders.ship, discounts: paidOrders.disc },
        received: { count: pay.n, gross: pay.gross, refunded: refunds.v, cents: received },
        fees: { cents: pay.fees, unknownCount: pay.no_fee },
        net: { cents: pay.net, complete: pay.no_fee === 0 && pay.n > 0 },
        settled: { count: settled.n, cents: settled.v },
        toSettle: { count: toSettle.n, cents: toSettle.v },
        refunds: { count: refunds.n, cents: refunds.v },
        pending: { count: pending.n, cents: pending.v },
        expired: { count: expired.n, cents: expired.v },
        avgTicket: paidOrders.n ? Math.round(paidOrders.v / paidOrders.n) : 0,
      };
    },

    /** Série diária (dias sem movimento aparecem zerados). */
    daily(r) {
      const from = r.from || localDate(db.value("SELECT COALESCE(MIN(created_at), ?) FROM orders", now()));
      const to = r.to || localDate();
      const days = [];
      for (let d = from, i = 0; d <= to && i < 400; d = addDays(d, 1), i++) days.push(d);
      const paid = new Map(db.all(`SELECT ${dayExpr('paid_at')} AS d, COUNT(*) AS n, SUM(total_cents) AS v FROM orders WHERE paid_at >= ? AND paid_at < ? GROUP BY d`, r.fromIso, r.toIso).map((x) => [x.d, x]));
      const made = new Map(db.all(`SELECT ${dayExpr('created_at')} AS d, COUNT(*) AS n FROM orders WHERE created_at >= ? AND created_at < ? GROUP BY d`, r.fromIso, r.toIso).map((x) => [x.d, x]));
      return days.map((d) => ({ date: d, orders: made.get(d)?.n || 0, paidOrders: paid.get(d)?.n || 0, cents: paid.get(d)?.v || 0 }));
    },

    topProducts(r, limit = 10) {
      return db.all(`SELECT i.name, i.sku, SUM(i.qty) AS qty, SUM(i.qty * i.unit_cents) AS cents
        FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.paid_at >= ? AND o.paid_at < ? AND o.status <> 'refunded'
        GROUP BY i.product_id, i.name, i.sku ORDER BY cents DESC LIMIT ?`, r.fromIso, r.toIso, limit);
    },
    byCategory(r) {
      return db.all(`SELECT COALESCE(c.name, 'Sem categoria') AS name, SUM(i.qty) AS qty, SUM(i.qty * i.unit_cents) AS cents
        FROM order_items i JOIN orders o ON o.id = i.order_id LEFT JOIN products p ON p.id = i.product_id LEFT JOIN categories c ON c.id = p.category_id
        WHERE o.paid_at >= ? AND o.paid_at < ? AND o.status <> 'refunded' GROUP BY COALESCE(c.name, 'Sem categoria') ORDER BY cents DESC`, r.fromIso, r.toIso);
    },
    byDelivery(r) {
      return db.all("SELECT delivery_kind AS kind, COUNT(*) AS n, SUM(total_cents) AS cents FROM orders WHERE paid_at >= ? AND paid_at < ? AND status <> 'refunded' GROUP BY delivery_kind", r.fromIso, r.toIso);
    },

    /** Indicadores da tela inicial do painel (dados reais; zero é zero). */
    dashboard() {
      const today = this.range({ preset: 'today' });
      const d30 = this.range({ preset: '30d' });
      const m = this.range({ preset: 'month' });
      const prod = db.get("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) AS published, SUM(CASE WHEN status = 'published' AND quantity > 0 THEN 1 ELSE 0 END) AS available, SUM(CASE WHEN status = 'published' AND quantity = 0 THEN 1 ELSE 0 END) AS sold FROM products WHERE status <> 'archived'");
      const stockValue = db.value("SELECT COALESCE(SUM(quantity * COALESCE(promo_cents, price_cents)), 0) FROM products WHERE status = 'published'");
      return {
        today: this.finance(today), month: this.finance(m), d30: this.finance(d30),
        series: this.daily(d30), top: this.topProducts(d30, 5),
        products: { total: prod.total || 0, published: prod.published || 0, available: prod.available || 0, sold: prod.sold || 0, stockValue },
        statusCounts: app.orders.statusCounts(),
        attention: db.value('SELECT COUNT(*) FROM orders WHERE needs_attention = 1'),
        toShip: db.value("SELECT COUNT(*) FROM orders WHERE status IN ('paid','preparing')"),
        openSupport: db.value("SELECT COUNT(*) FROM support_requests WHERE status = 'open'"),
        openContacts: db.value("SELECT COUNT(*) FROM contact_messages WHERE status = 'open'"),
        openData: db.value("SELECT COUNT(*) FROM data_requests WHERE status = 'open'"),
        customers: db.value("SELECT COUNT(*) FROM customers WHERE status <> 'anonymized'"),
        newsletter: db.value('SELECT COUNT(*) FROM newsletter_subscribers WHERE unsubscribed_at IS NULL'),
        lowStock: app.stock.lowStock().slice(0, 8),
        failedEmails: db.value("SELECT COUNT(*) FROM emails WHERE status = 'failed' AND created_at > ?", new Date(Date.now() - 7 * 86400000).toISOString()),
      };
    },

    // ───── CSV ─────
    csvOrders(r) {
      const rows = db.all(`SELECT o.*, p.provider, p.fee_cents, p.net_cents, p.settlement_date FROM orders o
        LEFT JOIN payments p ON p.id = (SELECT id FROM payments WHERE order_id = o.id ORDER BY (status IN ('paid','partially_refunded','refunded')) DESC, id DESC LIMIT 1)
        WHERE o.created_at >= ? AND o.created_at < ? ORDER BY o.id`, r.fromIso, r.toIso);
      const local = (iso) => (iso ? new Date(new Date(iso).getTime() + off * 60000).toISOString().replace('T', ' ').slice(0, 19) : '');
      return toCsv(
        ['Pedido', 'Criado em', 'Pago em', 'Situação', 'Pagamento', 'Cliente', 'E-mail', 'Telefone', 'Entrega', 'Cidade/UF', 'Subtotal', 'Desconto', 'Frete', 'Total', 'Cupom', 'Provedor', 'Taxa', 'Líquido', 'Liquidação prevista/informada'],
        rows.map((o) => [o.number, local(o.created_at), local(o.paid_at), app.orders.STATUS[o.status], app.orders.PAYMENT_STATUS[o.payment_status], o.customer_name, o.customer_email, o.customer_phone, o.shipping_method_name, o.ship_city ? `${o.ship_city}/${o.ship_state}` : '', money(o.subtotal_cents), money(o.discount_cents), money(o.shipping_cents), money(o.total_cents), o.coupon_code, o.provider, o.fee_cents === null || o.fee_cents === undefined ? 'não informado' : money(o.fee_cents), o.net_cents === null || o.net_cents === undefined ? 'não informado' : money(o.net_cents), o.settlement_date])
      );
    },
    csvPayments(r) {
      const rows = db.all(`SELECT p.*, o.number FROM payments p JOIN orders o ON o.id = p.order_id WHERE p.created_at >= ? AND p.created_at < ? ORDER BY p.id`, r.fromIso, r.toIso);
      const local = (iso) => (iso ? new Date(new Date(iso).getTime() + off * 60000).toISOString().replace('T', ' ').slice(0, 19) : '');
      return toCsv(
        ['Pedido', 'Provedor', 'ID no provedor', 'Situação', 'Criado em', 'Pago em', 'Valor', 'Reembolsado', 'Taxa', 'Líquido', 'Liquidação'],
        rows.map((p) => [p.number, p.provider, p.provider_payment_id, p.status, local(p.created_at), local(p.paid_at), money(p.amount_cents), money(p.refunded_cents), p.fee_cents === null ? 'não informado' : money(p.fee_cents), p.net_cents === null ? 'não informado' : money(p.net_cents), p.settlement_date])
      );
    },
    csvProducts() {
      const rows = db.all('SELECT p.*, c.name AS category FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.status <> \'archived\' ORDER BY p.id');
      return toCsv(
        ['SKU', 'Nome', 'Categoria', 'Marca', 'Tamanho', 'Cor', 'Condição', 'Preço', 'Preço promocional', 'Estoque', 'Situação'],
        rows.map((p) => [p.sku, p.name, p.category, p.brand, p.size, p.color, p.condition, money(p.price_cents), p.promo_cents ? money(p.promo_cents) : '', p.quantity, p.status])
      );
    },
    csvStock(limit = 5000) {
      const rows = app.stock.recentMovements({ limit });
      const local = (iso) => new Date(new Date(iso).getTime() + off * 60000).toISOString().replace('T', ' ').slice(0, 19);
      return toCsv(['Data', 'SKU', 'Produto', 'Variação', 'Saldo', 'Motivo', 'Pedido', 'Responsável', 'Observação'], rows.map((m) => [local(m.created_at), m.sku, m.product_name, m.delta, m.balance_after, m.reason, m.order_number, m.staff_name, m.note]));
    },
    csvCustomers() {
      const rows = db.all("SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id AND o.paid_at IS NOT NULL) AS paid_orders, (SELECT COALESCE(SUM(total_cents),0) FROM orders o WHERE o.customer_id = c.id AND o.paid_at IS NOT NULL) AS spent FROM customers c WHERE c.status <> 'anonymized' ORDER BY c.id");
      return toCsv(['Nome', 'E-mail', 'Telefone', 'Cadastro', 'E-mail confirmado', 'Aceita novidades', 'Pedidos pagos', 'Total gasto'], rows.map((c) => [c.name, c.email, c.phone, c.created_at.slice(0, 10), c.email_verified_at ? 'sim' : 'não', c.marketing_consent ? 'sim' : 'não', c.paid_orders, money(c.spent)]));
    },
  };
  void int;
  return reports;
}

module.exports = { makeReports };
