'use strict';
const { makeAsaas } = require('./asaas');
const { makeMercadoPago } = require('./mercadopago');
const { makeMock } = require('./mock');

/** Provedor "nenhum": a loja funciona (catálogo, carrinho), mas não aceita pagamento até configurar um provedor real. */
const none = {
  name: 'none', label: 'Nenhum configurado', requiresCpf: false, sandbox: false,
  configured: () => false, webhookReady: () => false, missing: () => ['PAYMENT_PROVIDER (asaas ou mercadopago)'],
};

function makePaymentProviders(cfg, db) {
  const all = { asaas: makeAsaas(cfg), mercadopago: makeMercadoPago(cfg), mock: makeMock(cfg, db), none };
  return {
    all,
    active: all[cfg.payment.provider] || none,
    get: (name) => all[name] || null,
  };
}

module.exports = { makePaymentProviders };
