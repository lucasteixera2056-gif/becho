'use strict';
/** Catálogo: categorias, produtos, filtros, imagens. Preços sempre em centavos. */
const { now, slugify, searchNorm, parseMoney, int, trunc, UserError } = require('../lib/util');
const { removeImage } = require('../lib/images');

const CONDITIONS = ['Novo com etiqueta', 'Novo sem etiqueta', 'Excelente', 'Muito bom', 'Bom', 'Com detalhes'];
const PER_PAGE = 24;

function makeCatalog(app) {
  const { db, cfg } = app;
  const T = () => now();

  // Disponível = quantidade - reservas ativas (não expiradas) de pedidos aguardando pagamento.
  const AVAIL = `(p.quantity - COALESCE((SELECT SUM(r.qty) FROM stock_reservations r WHERE r.product_id = p.id AND r.status = 'active' AND r.expires_at > @now), 0))`;
  const IMG = `(SELECT i.filename FROM product_images i WHERE i.product_id = p.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1)`;
  const SELECT = `SELECT p.*, ${AVAIL} AS available, ${IMG} AS image, c.name AS category_name, c.slug AS category_slug FROM products p LEFT JOIN categories c ON c.id = p.category_id`;
  // node:sqlite não suporta @now repetido sem objeto nomeado; usamos substituição segura da constante ISO.
  const sel = (extra = '', params = []) => ({ sql: `${SELECT.replace(/@now/g, `'${T()}'`)} ${extra}`, params });

  const decorate = (p) => {
    if (!p) return p;
    p.effective_cents = p.promo_cents && p.promo_cents < p.price_cents ? p.promo_cents : p.price_cents;
    p.on_sale = p.effective_cents < p.price_cents;
    p.available = Math.max(0, p.available ?? p.quantity);
    p.sold_out = p.available <= 0;
    return p;
  };

  const catalog = {
    CONDITIONS,
    PER_PAGE,

    // ───── categorias ─────
    categories(includeInactive = false) {
      return db.all(`SELECT * FROM categories ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort_order, name`);
    },
    categoryTree(includeInactive = false) {
      const all = this.categories(includeInactive);
      const roots = all.filter((c) => !c.parent_id);
      for (const r of roots) r.children = all.filter((c) => c.parent_id === r.id);
      return roots;
    },
    categoryBySlug: (slug) => db.get('SELECT * FROM categories WHERE slug = ? AND active = 1', slug),
    categoryById: (id) => db.get('SELECT * FROM categories WHERE id = ?', id),
    categoryIdsWithChildren(id) {
      return [id, ...db.all('SELECT id FROM categories WHERE parent_id = ?', id).map((r) => r.id)];
    },
    categoryPath(id) {
      const out = [];
      let cur = id ? this.categoryById(id) : null;
      for (let i = 0; cur && i < 4; i++) {
        out.unshift(cur);
        cur = cur.parent_id ? this.categoryById(cur.parent_id) : null;
      }
      return out;
    },
    uniqueSlug(table, base, ignoreId = null) {
      let slug = slugify(base);
      let n = 1;
      while (db.get(`SELECT id FROM ${table} WHERE slug = ? AND id <> ?`, slug, ignoreId ?? -1)) slug = `${slugify(base)}-${++n}`;
      return slug;
    },
    saveCategory({ id, name, parent_id, description, sort_order, active, image }) {
      name = trunc(name, 80);
      if (!name) throw new UserError('Informe o nome da categoria.');
      let parent = parent_id ? int(parent_id) : null;
      if (parent) {
        const pc = this.categoryById(parent);
        if (!pc) throw new UserError('Categoria-mãe inválida.');
        if (pc.parent_id) throw new UserError('Subcategorias podem ter apenas um nível.');
        if (id && parent === id) throw new UserError('Uma categoria não pode ser mãe de si mesma.');
        if (id && db.get('SELECT 1 FROM categories WHERE parent_id = ?', id)) throw new UserError('Esta categoria já tem subcategorias; não pode virar subcategoria.');
      }
      if (id) {
        const cur = this.categoryById(id);
        if (!cur) throw new UserError('Categoria não encontrada.');
        const slug = cur.name === name ? cur.slug : this.uniqueSlug('categories', name, id);
        db.run('UPDATE categories SET name=?, slug=?, parent_id=?, description=?, sort_order=?, active=?, image=COALESCE(?, image) WHERE id=?', name, slug, parent, trunc(description, 400), int(sort_order), active ? 1 : 0, image || null, id);
        return id;
      }
      return db.run('INSERT INTO categories (name, slug, parent_id, description, sort_order, active, image) VALUES (?,?,?,?,?,?,?)', name, this.uniqueSlug('categories', name), parent, trunc(description, 400), int(sort_order), active === undefined ? 1 : active ? 1 : 0, image || null).id;
    },
    deleteCategory(id) {
      const used = db.value('SELECT COUNT(*) FROM products WHERE category_id = ? OR category_id IN (SELECT id FROM categories WHERE parent_id = ?)', id, id);
      if (used > 0) throw new UserError('Esta categoria possui produtos. Mova os produtos para outra categoria antes de excluir.');
      if (db.get('SELECT 1 FROM categories WHERE parent_id = ?', id)) throw new UserError('Exclua ou mova as subcategorias primeiro.');
      db.run('DELETE FROM categories WHERE id = ?', id);
    },

    // ───── consulta pública ─────
    /** Lista produtos publicados com filtros do catálogo. */
    list(f = {}) {
      const where = ["p.status = 'published'"];
      const params = [];
      const q = searchNorm(f.q || '');
      if (q) {
        for (const term of q.split(' ').slice(0, 6)) {
          where.push("p.search_text LIKE ? ESCAPE '\\'");
          params.push(`%${term.replace(/[\\%_]/g, '\\$&')}%`);
        }
      }
      if (f.category) {
        const cat = this.categoryBySlug(f.category);
        if (cat) {
          const ids = this.categoryIdsWithChildren(cat.id);
          where.push(`p.category_id IN (${ids.map(() => '?').join(',')})`);
          params.push(...ids);
        } else where.push('0 = 1');
      }
      const multi = (col, v) => {
        const vals = [].concat(v || []).map((x) => String(x).trim()).filter(Boolean).slice(0, 20);
        if (vals.length) {
          where.push(`p.${col} IN (${vals.map(() => '?').join(',')})`);
          params.push(...vals);
        }
      };
      multi('size', f.size);
      multi('brand', f.brand);
      multi('color', f.color);
      multi('condition', f.condition);
      const pmin = parseMoney(f.price_min);
      const pmax = parseMoney(f.price_max);
      const eff = 'COALESCE(p.promo_cents, p.price_cents)';
      if (pmin !== null) { where.push(`${eff} >= ?`); params.push(pmin); }
      if (pmax !== null) { where.push(`${eff} <= ?`); params.push(pmax); }
      if (f.promo) where.push('p.promo_cents IS NOT NULL');
      if (f.featured) where.push('p.featured = 1');
      const base = `FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ${where.join(' AND ')}`;
      const availWhere = f.sold ? '' : ` AND ${AVAIL.replace(/@now/g, `'${T()}'`)} > 0`;

      const orders = {
        novidades: 'p.published_at DESC, p.id DESC',
        menor_preco: `${eff} ASC, p.id DESC`,
        maior_preco: `${eff} DESC, p.id DESC`,
        relevancia: q ? `instr(p.search_text, '${q.split(' ')[0].replace(/'/g, "''")}') ASC, p.featured DESC, p.published_at DESC` : 'p.featured DESC, p.published_at DESC, p.id DESC',
      };
      const sort = orders[f.sort] ? f.sort : q ? 'relevancia' : 'novidades';
      const total = db.value(`SELECT COUNT(*) ${base}${availWhere}`, ...params);
      const page = Math.max(1, int(f.page, 1));
      const pages = Math.max(1, Math.ceil(total / PER_PAGE));
      const cur = Math.min(page, pages);
      const items = db.all(`SELECT p.*, ${AVAIL.replace(/@now/g, `'${T()}'`)} AS available, ${IMG} AS image, c.name AS category_name, c.slug AS category_slug ${base}${availWhere} ORDER BY ${orders[sort]} LIMIT ? OFFSET ?`, ...params, PER_PAGE, (cur - 1) * PER_PAGE).map(decorate);
      return { items, total, page: cur, pages, sort };
    },

    /** Opções de filtro disponíveis (apenas valores que existem em produtos publicados). */
    facets() {
      const col = (c) => db.all(`SELECT ${c} AS v, COUNT(*) AS n FROM products WHERE status = 'published' AND ${c} IS NOT NULL AND ${c} <> '' GROUP BY ${c} ORDER BY ${c}`);
      return { sizes: col('size'), brands: col('brand'), colors: col('color'), conditions: col('condition') };
    },

    latest(limit = 8) {
      const f = this.list({ sort: 'novidades' });
      return f.items.slice(0, limit);
    },
    featured(limit = 8) {
      return this.list({ featured: 1, sort: 'novidades' }).items.slice(0, limit);
    },
    promos(limit = 8) {
      return this.list({ promo: 1, sort: 'novidades' }).items.slice(0, limit);
    },
    bestSellers(limit = 8) {
      const ids = db.all(`SELECT oi.product_id AS id, SUM(oi.qty) AS n FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.paid_at IS NOT NULL AND o.status NOT IN ('refunded','cancelled') AND oi.product_id IS NOT NULL GROUP BY oi.product_id ORDER BY n DESC LIMIT ?`, limit * 2);
      if (!ids.length) return [];
      const out = [];
      for (const { id } of ids) {
        const p = this.byId(id);
        if (p && p.status === 'published') out.push(p);
        if (out.length >= limit) break;
      }
      return out;
    },

    byId(id) {
      const q = sel('WHERE p.id = ?');
      return decorate(db.get(q.sql, id));
    },
    bySlug(slug) {
      const q = sel("WHERE p.slug = ? AND p.status IN ('published')");
      return decorate(db.get(q.sql, slug));
    },
    bySku(sku) {
      const q = sel('WHERE p.sku = ?');
      return decorate(db.get(q.sql, sku));
    },
    images: (productId) => db.all('SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order, id', productId),
    related(p, limit = 4) {
      const ids = p.category_id ? this.categoryIdsWithChildren(p.category_id) : [];
      const parent = p.category_id ? this.categoryById(p.category_id)?.parent_id : null;
      const all = parent ? this.categoryIdsWithChildren(parent) : ids;
      let rows = [];
      if (all.length) {
        rows = db.all(`SELECT p2.*, ${AVAIL.replace(/@now/g, `'${T()}'`).replace(/\bp\./g, 'p2.')} AS available, (SELECT i.filename FROM product_images i WHERE i.product_id = p2.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS image FROM products p2 WHERE p2.status = 'published' AND p2.id <> ? AND p2.category_id IN (${all.map(() => '?').join(',')}) ORDER BY p2.published_at DESC LIMIT 12`, p.id, ...all);
      }
      return rows.map(decorate).filter((r) => r.available > 0).slice(0, limit);
    },

    // ───── administração de produtos ─────
    adminList({ q, status, category, stock, page = 1, perPage = 30 } = {}) {
      const where = ['1 = 1'];
      const params = [];
      const n = searchNorm(q || '');
      if (n) for (const t of n.split(' ').slice(0, 5)) { where.push("(p.search_text LIKE ? ESCAPE '\\' OR LOWER(p.sku) LIKE ? ESCAPE '\\')"); const e = `%${t.replace(/[\\%_]/g, '\\$&')}%`; params.push(e, e); }
      if (status && ['draft', 'published', 'archived'].includes(status)) { where.push('p.status = ?'); params.push(status); }
      if (category) { const ids = this.categoryIdsWithChildren(int(category)); where.push(`p.category_id IN (${ids.map(() => '?').join(',')})`); params.push(...ids); }
      if (stock === 'sold') where.push('p.quantity = 0');
      if (stock === 'low') where.push('p.restock_alert_qty IS NOT NULL AND p.quantity <= p.restock_alert_qty AND p.quantity > 0');
      if (stock === 'available') where.push('p.quantity > 0');
      const base = `FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ${where.join(' AND ')}`;
      const total = db.value(`SELECT COUNT(*) ${base}`, ...params);
      const pages = Math.max(1, Math.ceil(total / perPage));
      const cur = Math.min(Math.max(1, int(page, 1)), pages);
      const items = db.all(`SELECT p.*, ${AVAIL.replace(/@now/g, `'${T()}'`)} AS available, ${IMG} AS image, c.name AS category_name ${base} ORDER BY p.id DESC LIMIT ? OFFSET ?`, ...params, perPage, (cur - 1) * perPage).map(decorate);
      return { items, total, page: cur, pages };
    },

    /** Normaliza e valida os dados do formulário de produto. */
    parseProductForm(b, { existing = null } = {}) {
      const name = trunc(b.name, 140);
      if (!name) throw new UserError('Informe o nome do produto.', 'name');
      const price = parseMoney(b.price);
      if (!price || price <= 0) throw new UserError('Informe um preço de venda válido.', 'price');
      let promo = b.promo === '' || b.promo === undefined ? null : parseMoney(b.promo);
      if (b.promo && promo === null) throw new UserError('Preço promocional inválido.', 'promo');
      if (promo !== null && promo >= price) throw new UserError('O preço promocional precisa ser menor que o preço de venda.', 'promo');
      if (promo === 0) promo = null;
      const cost = b.cost === '' || b.cost === undefined ? null : parseMoney(b.cost);
      if (b.cost && cost === null) throw new UserError('Preço de custo inválido.', 'cost');
      const quantity = b.quantity === '' || b.quantity === undefined ? 1 : int(b.quantity, NaN);
      if (!Number.isInteger(quantity) || quantity < 0 || quantity > 9999) throw new UserError('Quantidade inválida.', 'quantity');
      const alert = b.restock_alert_qty === '' || b.restock_alert_qty === undefined ? null : int(b.restock_alert_qty, NaN);
      if (alert !== null && (!Number.isInteger(alert) || alert < 0)) throw new UserError('Alerta de estoque inválido.', 'restock_alert_qty');
      const weight = b.weight_g === '' || b.weight_g === undefined ? null : int(b.weight_g, NaN);
      if (weight !== null && (!Number.isInteger(weight) || weight <= 0)) throw new UserError('Peso inválido (em gramas).', 'weight_g');
      let categoryId = b.subcategory_id ? int(b.subcategory_id) : b.category_id ? int(b.category_id) : null;
      if (categoryId && !this.categoryById(categoryId)) throw new UserError('Categoria inválida.', 'category_id');
      const status = ['draft', 'published', 'archived'].includes(b.status) ? b.status : 'draft';
      const condition = b.condition && CONDITIONS.includes(b.condition) ? b.condition : trunc(b.condition, 40) || null;
      const sku = trunc(b.sku, 40).toUpperCase().replace(/[^A-Z0-9._-]/g, '');
      if (sku && !/^[A-Z0-9][A-Z0-9._-]{0,39}$/.test(sku)) throw new UserError('Código SKU inválido.', 'sku');
      return {
        name, description: trunc(b.description, 5000), sku, price, promo, cost, quantity, alert, weight, categoryId, status,
        brand: trunc(b.brand, 60) || null, size: trunc(b.size, 20) || null, color: trunc(b.color, 40) || null, condition,
        measures: trunc(b.measures, 300) || null, defects: trunc(b.defects, 1000) || null, featured: b.featured ? 1 : 0,
      };
    },

    searchText(f, categoryId) {
      const cats = this.categoryPath(categoryId).map((c) => c.name).join(' ');
      return searchNorm([f.name, f.brand, f.color, f.size, f.condition, f.sku, cats].filter(Boolean).join(' '));
    },

    nextSku() {
      const last = db.value("SELECT MAX(CAST(SUBSTR(sku, 3) AS INTEGER)) FROM products WHERE sku GLOB 'BC[0-9]*'") || 0;
      return `BC${String(last + 1).padStart(5, '0')}`;
    },

    createProduct(f, staffId = null) {
      return db.tx(() => {
        const sku = f.sku || this.nextSku();
        if (db.get('SELECT 1 FROM products WHERE sku = ?', sku)) throw new UserError('Já existe um produto com este SKU.', 'sku');
        const t = now();
        const id = db.run(
          `INSERT INTO products (sku, slug, name, description, category_id, brand, size, color, condition, measures, defects, cost_cents, price_cents, promo_cents, quantity, restock_alert_qty, weight_g, status, featured, search_text, created_at, updated_at, published_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          sku, this.uniqueSlug('products', `${f.name} ${sku}`), f.name, f.description, f.categoryId, f.brand, f.size, f.color, f.condition, f.measures, f.defects, f.cost, f.price, f.promo, f.quantity, f.alert, f.weight, f.status, f.featured, this.searchText(f, f.categoryId), t, t, f.status === 'published' ? t : null
        ).id;
        if (f.quantity > 0) app.stock.record(id, f.quantity, f.quantity, 'cadastro', { staffId, note: 'Cadastro inicial' });
        return id;
      });
    },

    updateProduct(id, f) {
      return db.tx(() => {
        const cur = db.get('SELECT * FROM products WHERE id = ?', id);
        if (!cur) throw new UserError('Produto não encontrado.');
        const sku = f.sku || cur.sku;
        if (db.get('SELECT 1 FROM products WHERE sku = ? AND id <> ?', sku, id)) throw new UserError('Já existe um produto com este SKU.', 'sku');
        const t = now();
        const publishedAt = f.status === 'published' ? cur.published_at || t : cur.published_at;
        db.run(
          `UPDATE products SET sku=?, name=?, description=?, category_id=?, brand=?, size=?, color=?, condition=?, measures=?, defects=?, cost_cents=?, price_cents=?, promo_cents=?, restock_alert_qty=?, weight_g=?, status=?, featured=?, search_text=?, updated_at=?, published_at=? WHERE id=?`,
          sku, f.name, f.description, f.categoryId, f.brand, f.size, f.color, f.condition, f.measures, f.defects, f.cost, f.price, f.promo, f.alert, f.weight, f.status, f.featured, this.searchText({ ...f, sku }, f.categoryId), t, publishedAt, id
        );
        // Quantidade só muda aqui se o formulário a enviou; sempre via movimentação de estoque.
        if (f.quantity !== undefined && f.quantity !== cur.quantity) {
          app.stock.adjustTo(id, f.quantity, { reason: 'ajuste', note: 'Ajuste pelo cadastro do produto', staffId: f.staffId });
        }
        return id;
      });
    },

    setStatus(id, status) {
      if (!['draft', 'published', 'archived'].includes(status)) throw new UserError('Status inválido.');
      const t = now();
      db.run('UPDATE products SET status = ?, updated_at = ?, published_at = CASE WHEN ? = ? AND published_at IS NULL THEN ? ELSE published_at END WHERE id = ?', status, t, status, 'published', t, id);
    },

    duplicate(id, staffId) {
      const p = db.get('SELECT * FROM products WHERE id = ?', id);
      if (!p) throw new UserError('Produto não encontrado.');
      return db.tx(() => {
        const f = {
          name: `${p.name} (cópia)`, description: p.description, sku: '', price: p.price_cents, promo: p.promo_cents, cost: p.cost_cents, quantity: p.quantity > 0 ? p.quantity : 1,
          alert: p.restock_alert_qty, weight: p.weight_g, categoryId: p.category_id, status: 'draft', brand: p.brand, size: p.size, color: p.color, condition: p.condition,
          measures: p.measures, defects: p.defects, featured: 0,
        };
        return this.createProduct(f, staffId);
      });
    },

    /** Exclui apenas produtos que nunca foram vendidos; caso contrário, arquive. */
    deleteProduct(id) {
      if (db.get('SELECT 1 FROM order_items WHERE product_id = ?', id)) throw new UserError('Este produto já está em pedidos. Arquive-o em vez de excluir.');
      const imgs = this.images(id);
      db.run('DELETE FROM products WHERE id = ?', id);
      for (const i of imgs) removeImage(cfg.uploadDir, i.filename);
    },

    // ───── imagens ─────
    addImage(productId, filename, alt = '') {
      return db.tx(() => {
        const n = db.value('SELECT COUNT(*) FROM product_images WHERE product_id = ?', productId);
        if (n >= 12) throw new UserError('Limite de 12 fotos por produto.');
        const order = (db.value('SELECT COALESCE(MAX(sort_order), 0) FROM product_images WHERE product_id = ?', productId)) + 1;
        const id = db.run('INSERT INTO product_images (product_id, filename, alt, sort_order, is_primary) VALUES (?,?,?,?,?)', productId, filename, trunc(alt, 140), order, n === 0 ? 1 : 0).id;
        return id;
      });
    },
    setPrimaryImage(productId, imageId) {
      db.tx(() => {
        if (!db.get('SELECT 1 FROM product_images WHERE id = ? AND product_id = ?', imageId, productId)) throw new UserError('Imagem não encontrada.');
        db.run('UPDATE product_images SET is_primary = 0 WHERE product_id = ?', productId);
        db.run('UPDATE product_images SET is_primary = 1 WHERE id = ?', imageId);
      });
    },
    moveImage(productId, imageId, dir) {
      db.tx(() => {
        const imgs = db.all('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order, id', productId);
        const i = imgs.findIndex((x) => x.id === imageId);
        const j = dir === 'up' ? i - 1 : i + 1;
        if (i < 0 || j < 0 || j >= imgs.length) return;
        [imgs[i], imgs[j]] = [imgs[j], imgs[i]];
        imgs.forEach((x, k) => db.run('UPDATE product_images SET sort_order = ? WHERE id = ?', k + 1, x.id));
      });
    },
    deleteImage(productId, imageId) {
      const img = db.get('SELECT * FROM product_images WHERE id = ? AND product_id = ?', imageId, productId);
      if (!img) return;
      db.tx(() => {
        db.run('DELETE FROM product_images WHERE id = ?', imageId);
        if (img.is_primary) {
          const next = db.get('SELECT id FROM product_images WHERE product_id = ? ORDER BY sort_order, id LIMIT 1', productId);
          if (next) db.run('UPDATE product_images SET is_primary = 1 WHERE id = ?', next.id);
        }
      });
      removeImage(cfg.uploadDir, img.filename);
    },

    counts() {
      return {
        total: db.value('SELECT COUNT(*) FROM products'),
        published: db.value("SELECT COUNT(*) FROM products WHERE status = 'published'"),
        available: db.value("SELECT COUNT(*) FROM products WHERE status = 'published' AND quantity > 0"),
        sold: db.value("SELECT COUNT(*) FROM products WHERE quantity = 0 AND status <> 'archived'"),
        low: db.value("SELECT COUNT(*) FROM products WHERE status <> 'archived' AND restock_alert_qty IS NOT NULL AND quantity > 0 AND quantity <= restock_alert_qty"),
      };
    },
  };
  return catalog;
}

module.exports = { makeCatalog, CONDITIONS };
