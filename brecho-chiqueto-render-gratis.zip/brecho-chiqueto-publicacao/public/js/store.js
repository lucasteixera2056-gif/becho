/* Melhorias progressivas da loja. Tudo funciona sem JavaScript; aqui só deixamos mais confortável. */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // menu móvel
  var mt = $('[data-menu-toggle]'), menu = $('[data-menu]');
  if (mt && menu) mt.addEventListener('click', function () {
    var open = menu.classList.toggle('open');
    mt.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  // galeria do produto
  $$('[data-thumb]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var img = $('#main-img');
      if (!img) return;
      img.src = a.getAttribute('data-src'); img.alt = a.getAttribute('data-alt') || '';
      $$('[data-thumb]').forEach(function (x) { x.removeAttribute('aria-current'); });
      a.setAttribute('aria-current', 'true');
    });
  });

  // copiar link / código Pix
  function copy(text, btn) {
    var done = function () {
      if (!btn) return;
      var old = btn.innerHTML; btn.setAttribute('data-old', old);
      btn.textContent = 'Copiado!';
      setTimeout(function () { btn.innerHTML = btn.getAttribute('data-old') || old; }, 1800);
    };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(done, function () { fallback(text); done(); });
    else { fallback(text); done(); }
  }
  function fallback(text) {
    var t = document.createElement('textarea'); t.value = text; t.setAttribute('readonly', ''); t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (e) { /* sem suporte */ } document.body.removeChild(t);
  }
  $$('[data-copy]').forEach(function (b) { b.addEventListener('click', function () { copy(b.getAttribute('data-copy'), b); }); });
  $$('[data-copy-target]').forEach(function (b) {
    b.addEventListener('click', function () { var el = $(b.getAttribute('data-copy-target')); if (el) { el.focus(); el.select && el.select(); copy(el.value, b); } });
  });
  $$('[data-share]').forEach(function (b) {
    if (!navigator.share) return;
    b.hidden = false;
    b.addEventListener('click', function () { navigator.share({ title: b.getAttribute('data-title'), url: b.getAttribute('data-url') }).catch(function () {}); });
  });

  // ordenação envia sozinha
  $$('[data-autosubmit]').forEach(function (s) { s.addEventListener('change', function () { s.form.submit(); }); });

  // confirmação em formulários destrutivos
  $$('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
  });

  // adicionar ao carrinho sem recarregar (se falhar, o formulário normal funciona)
  var buy = $('form.buy');
  if (buy && window.fetch) {
    buy.addEventListener('submit', function (e) {
      var sub = e.submitter;
      if (!sub || sub.getAttribute('value') === '1' || !sub.hasAttribute('data-add-to-cart')) return;
      e.preventDefault();
      var fd = new URLSearchParams(new FormData(buy)); fd.set('buy_now', '0');
      sub.disabled = true;
      fetch(buy.action, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'fetch', Accept: 'application/json' }, body: fd.toString(), credentials: 'same-origin' })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (x) {
          if (!x.ok) { window.location.href = '/carrinho'; return; }
          var c = $('[data-cart-count]'); if (c) { c.textContent = x.j.count; c.hidden = false; }
          sub.textContent = 'Adicionada ao carrinho ✓';
          setTimeout(function () { window.location.href = '/carrinho'; }, 700);
        })
        .catch(function () { buy.submit(); });
    });
  }

  // checkout: CEP -> endereço (ViaCEP) e opções de entrega
  var co = $('[data-checkout]');
  if (co) {
    var zip = $('[data-zip]', co), choices = $('[data-ship-choices]', co);
    var money = function (c) { return c ? 'R$ ' + (c / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.') : 'Grátis'; };
    var totals = $('[data-totals]', co);
    var updateTotals = function () {
      if (!totals) return;
      var sel = $('input[name="shipping_key"]:checked', co);
      var ship = sel ? parseInt(sel.getAttribute('data-price'), 10) : null;
      var st = parseInt(totals.getAttribute('data-subtotal'), 10), d = parseInt(totals.getAttribute('data-discount'), 10);
      $('[data-ship-total]', co).textContent = ship === null ? '—' : money(ship);
      $('[data-grand]', co).textContent = money(st - d + (ship || 0));
      var addr = $('[data-address]', co); if (addr && sel) addr.hidden = sel.getAttribute('data-kind') === 'pickup';
    };
    co.addEventListener('change', function (e) { if (e.target.name === 'shipping_key') updateTotals(); });
    updateTotals();
    var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var lastZip = '';
    var onZip = function () {
      var d = zip.value.replace(/\D/g, '');
      if (d.length !== 8 || d === lastZip) return;
      lastZip = d;
      zip.value = d.slice(0, 5) + '-' + d.slice(5);
      fetch('/api/frete?zip=' + d, { credentials: 'same-origin', headers: { Accept: 'application/json' } }).then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok || !choices) return;
        var chosen = ($('input[name="shipping_key"]:checked', co) || {}).value;
        var html = j.options.length ? j.options.map(function (o) {
          return '<label class="choice"><input type="radio" name="shipping_key" value="' + esc(o.key) + '" data-price="' + o.price_cents + '" data-kind="' + esc(o.kind) + '"' + (o.key === chosen ? ' checked' : '') + '><span><strong>' + esc(o.name) + '</strong>' + (o.eta ? '<small>' + esc(o.eta) + '</small>' : '') + '</span><b>' + esc(o.price) + '</b></label>';
        }).join('') : '<p class="err">Não encontramos opção de entrega para este CEP.</p>';
        choices.innerHTML = html + (j.warnings || []).map(function (w) { return '<p class="err small">' + esc(w) + '</p>'; }).join('');
        updateTotals();
      }).catch(function () {});
      fetch('https://viacep.com.br/ws/' + d + '/json/').then(function (r) { return r.json(); }).then(function (a) {
        if (!a || a.erro) return;
        var set = function (n, v) { var el = $('[name="' + n + '"]', co); if (el && !el.value && v) el.value = v; };
        set('street', a.logradouro); set('district', a.bairro); set('city', a.localidade); set('state', a.uf);
      }).catch(function () {});
    };
    if (zip) { zip.addEventListener('input', onZip); zip.addEventListener('blur', onZip); }
  }

  // página do Pix: contagem regressiva e verificação automática
  var op = $('[data-order-poll]');
  if (op) {
    var url = op.getAttribute('data-order-poll'), box = $('[data-expires]', op), rem = $('[data-remaining]', op);
    var tick = function () {
      if (!box || !rem) return;
      var left = Math.max(0, Math.floor((new Date(box.getAttribute('data-expires')).getTime() - Date.now()) / 1000));
      var m = Math.floor(left / 60), s = left % 60;
      rem.textContent = left ? '(' + m + ':' + (s < 10 ? '0' : '') + s + ')' : '(expirado — atualize a página)';
    };
    tick(); setInterval(tick, 1000);
    var delay = 4000, tries = 0;
    var poll = function () {
      if (document.hidden) { setTimeout(poll, 5000); return; }
      fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json', 'X-Requested-With': 'fetch' } })
        .then(function (r) { return r.json(); })
        .then(function (j) { if (j && j.done) window.location.reload(); else { tries++; delay = Math.min(15000, 4000 + tries * 500); setTimeout(poll, delay); } })
        .catch(function () { setTimeout(poll, 10000); });
    };
    setTimeout(poll, delay);
  }
})();
