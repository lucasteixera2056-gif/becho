'use strict';
/** Cliente HTTP de teste com cookies + servidor real em porta efêmera (sem rede externa). */
const http = require('node:http');
const zlib = require('node:zlib');
const { buildServer } = require('../src/web');
const { hashPassword } = require('../src/lib/security');

async function startServer(app) {
  const server = buildServer(app, { log() {}, info() {}, warn() {}, error() {} });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const close = () => new Promise((r) => { server.closeAllConnections?.(); server.close(() => r()); });
  return { server, base, close };
}

class Client {
  constructor(base) { this.base = base; this.jar = new Map(); this.csrf = ''; }

  async req(method, path, { form, body, headers = {} } = {}) {
    const h = { ...headers };
    const cookie = [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ');
    if (cookie) h.cookie = cookie;
    let payload;
    if (form) {
      h['content-type'] = 'application/x-www-form-urlencoded';
      const all = { ...(this.csrf && !('_csrf' in form) ? { _csrf: this.csrf } : {}), ...form };
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(all)) for (const x of [].concat(v)) params.append(k, x);
      payload = params.toString();
    } else if (body !== undefined) payload = body;
    const res = await fetch(this.base + path, { method, headers: h, body: payload, redirect: 'manual' });
    for (const c of res.headers.getSetCookie()) {
      const kv = c.split(';')[0];
      const i = kv.indexOf('=');
      const k = kv.slice(0, i);
      if (/Max-Age=0/i.test(c)) this.jar.delete(k); else this.jar.set(k, kv.slice(i + 1));
    }
    const buf = Buffer.from(await res.arrayBuffer());
    const text = buf.toString('utf8');
    const m = /<meta name="csrf" content="([^"]+)"/.exec(text) || /name="_csrf" value="([^"]+)"/.exec(text);
    if (m) this.csrf = m[1];
    return { status: res.status, headers: res.headers, text, buf, location: res.headers.get('location') || '' };
  }

  get(path, o) { return this.req('GET', path, o); }
  post(path, form, o = {}) { return this.req('POST', path, { form, ...o }); }
  /** Envio binário (upload de imagem do painel). */
  upload(path, buf) { return this.req('POST', path, { body: buf, headers: { 'content-type': 'application/octet-stream', 'x-csrf-token': this.csrf } }); }
  cookieNames() { return [...this.jar.keys()]; }
}

/** Requisição HTTP "crua" (sem normalizar o caminho), para testar travessia de diretório. */
function rawGet(base, rawPath) {
  const u = new URL(base);
  return new Promise((resolve, reject) => {
    const r = http.request({ host: u.hostname, port: u.port, method: 'GET', path: rawPath }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
    });
    r.on('error', reject);
    r.end();
  });
}

/** Cria o funcionário já liberado (sem troca obrigatória de senha) e devolve um cliente logado. */
async function staffLogin(app, base, { role, email, password = 'SenhaForte-2026!' }) {
  const exists = app.db.get('SELECT id FROM staff_users WHERE email = ?', email);
  if (!exists) await app.auth.createStaff(null, { name: `Teste ${role}`, email, password, role, mustChange: false });
  const c = new Client(base);
  await c.get('/admin/login');
  const r = await c.post('/admin/login', { email, password });
  if (r.status !== 303) throw new Error(`login de ${role} falhou: ${r.status} ${r.text.slice(0, 200)}`);
  await c.get('/admin/minha-conta'); // carrega o token CSRF
  return c;
}

/** Cria cliente (loja) com e-mail confirmado e devolve um cliente HTTP logado. */
async function customerLogin(app, base, { email, name = 'Cliente Teste', password = 'SenhaCliente-2026' }) {
  let row = app.db.get('SELECT id FROM customers WHERE email = ?', email);
  if (!row) {
    const id = app.db.run('INSERT INTO customers (name, email, password_hash, email_verified_at, created_at) VALUES (?,?,?,?,?)', name, email, await hashPassword(password), new Date().toISOString(), new Date().toISOString()).id;
    row = { id };
  }
  const c = new Client(base);
  await c.get('/minha-conta/entrar');
  const r = await c.post('/minha-conta/entrar', { email, password });
  if (r.status !== 303) throw new Error(`login do cliente falhou: ${r.status} ${r.text.slice(0, 200)}`);
  await c.get('/minha-conta');
  return { client: c, id: row.id };
}

/** PNG válido mínimo (cor sólida) para testes de envio. */
function pngBuffer(w = 8, h = 8, rgb = [200, 120, 80]) {
  const row = Buffer.concat([Buffer.from([0]), Buffer.from(Array.from({ length: w }, () => rgb).flat())]);
  const raw = Buffer.concat(Array.from({ length: h }, () => row));
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

module.exports = { startServer, Client, rawGet, staffLogin, customerLogin, pngBuffer };
