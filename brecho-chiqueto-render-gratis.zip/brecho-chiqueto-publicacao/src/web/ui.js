'use strict';
/** Peças de interface compartilhadas pela loja, pela área do cliente e pelo painel. */
const { html, raw, escape } = require('../lib/html');
const { money } = require('../lib/util');

const PATHS = {
  cart: '<path d="M6 7h13l-1.6 8.2a2 2 0 0 1-2 1.6H9.2a2 2 0 0 1-2-1.6L5.5 4H3"/><circle cx="9.5" cy="20" r="1.2"/><circle cx="16.5" cy="20" r="1.2"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
  user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20.5c.6-3.6 3.7-5.5 7.5-5.5s6.9 1.9 7.5 5.5"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  check: '<path d="m5 12.5 4.2 4.2L19 7"/>',
  alert: '<path d="M12 4 2.8 19.5h18.4L12 4Z"/><path d="M12 10v4.5M12 17.4v.1"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.7v.1"/>',
  truck: '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3.2v2.8h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
  shield: '<path d="M12 3 4.5 6v5.6c0 4.4 3.1 7.8 7.5 9.4 4.4-1.6 7.5-5 7.5-9.4V6L12 3Z"/><path d="m8.8 12 2.4 2.4 4-4.4"/>',
  copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7.5a2 2 0 0 0 2 2h2.5"/>',
  trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12.5h9.4L17.5 7M10 11v5.5M14 11v5.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  edit: '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m13.5 7.5 3 3"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>',
  download: '<path d="M12 4v11m0 0-4-4m4 4 4-4M5 19.5h14"/>',
  lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="m4 7 8 6 8-6"/>',
  box: '<path d="M3.5 7.5 12 3l8.5 4.5v9L12 21l-8.5-4.5v-9Z"/><path d="m3.7 7.6 8.3 4.5 8.3-4.5M12 12.1V21"/>',
  chevron: '<path d="m9 6 6 6-6 6"/>',
  chevdown: '<path d="m6 9 6 6 6-6"/>',
  home: '<path d="M4 11 12 4l8 7M6 9.5V20h12V9.5"/>',
  tag: '<path d="M3.5 12.5v-8h8l9 9-8 8-9-9Z"/><circle cx="8" cy="9" r="1.2"/>',
  chart: '<path d="M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6"/>',
  users: '<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c.5-3 3-4.7 6-4.7s5.5 1.7 6 4.7M16 5.6a3.2 3.2 0 0 1 0 5.8M18 14.9c1.8.6 3 2.2 3.3 4.6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>',
  instagram: '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r=".6"/>',
  whatsapp: '<path d="M4 20l1.2-4.1A8 8 0 1 1 8.2 19L4 20Z"/><path d="M9 8.8c.3 2.8 2.6 5 5.4 5.4l1.1-1.3-1.9-1-.8.6c-.9-.4-1.7-1.2-2.1-2.1l.6-.8-1-1.9L9 8.8Z"/>',
  pix: '<path d="m12 3.2 3.4 3.4a1.6 1.6 0 0 0 1.1.5H18l2.8 2.8a1.6 1.6 0 0 1 0 2.2L18 14.9h-1.5a1.6 1.6 0 0 0-1.1.5L12 20.8l-3.4-5.4a1.6 1.6 0 0 0-1.1-.5H6l-2.8-2.8a1.6 1.6 0 0 1 0-2.2L6 7.1h1.5a1.6 1.6 0 0 0 1.1-.5L12 3.2Z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/>',
  share: '<circle cx="6" cy="12" r="2.3"/><circle cx="18" cy="6" r="2.3"/><circle cx="18" cy="18" r="2.3"/><path d="m8 11 8-4M8 13l8 4"/>',
  bell: '<path d="M6 17.5h12l-1.4-2.2V11a4.6 4.6 0 0 0-9.2 0v4.3L6 17.5ZM10 20.5h4"/>',
  external: '<path d="M14 4.5h5.5V10M19.5 4.5 11 13M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 5 18.5v-10A1.5 1.5 0 0 1 6.5 7H11"/>',
  receipt: '<path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8v-17ZM9 8.5h6M9 12h6"/>',
  print: '<path d="M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6.5H7V14Z"/>',
  refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4.2h-4.2"/>',
};

const icon = (name, size = 20, cls = '') =>
  raw(`<svg class="icon ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${PATHS[name] || ''}</svg>`);

const csrfField = (ctx) => raw(`<input type="hidden" name="_csrf" value="${escape(ctx.csrf)}">`);

const imgUrl = (f) => (f ? `/uploads/${f}` : '');

/** Mensagem de retorno (flash) gravada em cookie assinado. */
function flashBox(ctx) {
  const f = ctx.flashIn;
  if (!f) return '';
  const type = ['success', 'error', 'info'].includes(f.type) ? f.type : 'info';
  return html`<div class="flash flash-${type}" role="${type === 'error' ? 'alert' : 'status'}">${icon(type === 'success' ? 'check' : type === 'error' ? 'alert' : 'info', 18)}<span>${f.message}</span></div>`;
}

/**
 * Campo de formulário com rótulo, dica e erro. `value` já deve vir do que o usuário digitou (reexibição após erro).
 */
function field({ label, name, type = 'text', value = '', required = false, hint = '', error = '', autocomplete = '', inputmode = '', maxlength = '', placeholder = '', attrs = '', cls = '', id = '' }) {
  const fid = id || `f_${name}`;
  const a = [
    required ? 'required' : '', autocomplete ? `autocomplete="${escape(autocomplete)}"` : '', inputmode ? `inputmode="${escape(inputmode)}"` : '',
    maxlength ? `maxlength="${escape(maxlength)}"` : '', placeholder ? `placeholder="${escape(placeholder)}"` : '', attrs,
    error ? 'aria-invalid="true"' : '', `aria-describedby="${fid}_d"`,
  ].filter(Boolean).join(' ');
  return html`<div class="field ${cls}${error ? ' has-error' : ''}"><label for="${fid}">${label}${required ? '' : html` <span class="opt">(opcional)</span>`}</label><input id="${fid}" name="${name}" type="${type}" value="${value ?? ''}" ${raw(a)}><div class="hint" id="${fid}_d">${error ? html`<span class="err">${error}</span>` : hint}</div></div>`;
}

function selectField({ label, name, value = '', options = [], required = false, hint = '', error = '', autocomplete = '', cls = '', blank = '' }) {
  const fid = `f_${name}`;
  return html`<div class="field ${cls}${error ? ' has-error' : ''}"><label for="${fid}">${label}${required ? '' : html` <span class="opt">(opcional)</span>`}</label><select id="${fid}" name="${name}" ${required ? raw('required') : ''} ${autocomplete ? raw(`autocomplete="${escape(autocomplete)}"`) : ''}>${blank !== null && blank !== undefined ? html`<option value="">${blank}</option>` : ''}${options.map((o) => { const v = typeof o === 'object' ? o.value : o; const l = typeof o === 'object' ? o.label : o; return html`<option value="${v}" ${String(v) === String(value) ? raw('selected') : ''}>${l}</option>`; })}</select><div class="hint">${error ? html`<span class="err">${error}</span>` : hint}</div></div>`;
}

/** Paginação acessível. `href(page)` devolve a URL da página. */
function pager({ page, pages }, href) {
  if (pages <= 1) return '';
  const nums = [];
  for (let i = 1; i <= pages; i++) if (i === 1 || i === pages || Math.abs(i - page) <= 1) nums.push(i);
  const out = [];
  let last = 0;
  for (const n of nums) {
    if (n - last > 1) out.push(html`<span class="gap" aria-hidden="true">…</span>`);
    out.push(n === page ? html`<span class="cur" aria-current="page">${n}</span>` : html`<a href="${href(n)}" aria-label="Página ${n}">${n}</a>`);
    last = n;
  }
  return html`<nav class="pager" aria-label="Paginação">${page > 1 ? html`<a href="${href(page - 1)}" rel="prev">‹ Anterior</a>` : ''}${out}${page < pages ? html`<a href="${href(page + 1)}" rel="next">Próxima ›</a>` : ''}</nav>`;
}

/** Monta uma query string preservando filtros (ignora vazios). */
function qs(params, override = {}) {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries({ ...params, ...override })) {
    for (const x of [].concat(v ?? [])) if (x !== '' && x !== null && x !== undefined) u.append(k, x);
  }
  const s = u.toString();
  return s ? `?${s}` : '';
}

const badge = (text, tone = 'neutral') => html`<span class="badge badge-${tone}">${text}</span>`;

const fmtDate = (iso, cfg, opts) => require('../lib/util').formatDate(iso, { offsetMinutes: cfg.tzOffsetMinutes, ...opts });

module.exports = { icon, csrfField, imgUrl, flashBox, field, selectField, pager, qs, badge, money, fmtDate, html, raw, escape };
