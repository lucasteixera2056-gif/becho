'use strict';
/**
 * Controle de acesso baseado em funções (RBAC).
 * O superadministrador sempre tem acesso total. As demais funções usam a matriz
 * gravada em role_permissions (editável pelo superadministrador).
 */
const ROLES = {
  superadmin: { label: 'Superadministrador', rank: 100 },
  admin: { label: 'Administrador', rank: 80 },
  gerente: { label: 'Gerente', rank: 60 },
  atendente: { label: 'Atendente', rank: 40 },
  estoquista: { label: 'Estoquista', rank: 40 },
};

const PERMISSIONS = {
  'dashboard.view': 'Ver painel com indicadores',
  'products.view': 'Ver produtos',
  'products.edit': 'Cadastrar e editar produtos',
  'products.delete': 'Excluir produtos',
  'categories.manage': 'Gerenciar categorias',
  'stock.view': 'Ver estoque e movimentações',
  'stock.manage': 'Registrar entradas, saídas e ajustes de estoque',
  'orders.view': 'Ver pedidos',
  'orders.manage': 'Atualizar status, rastreio e cancelar pedidos não pagos',
  'orders.refund': 'Reembolsar pagamentos',
  'customers.view': 'Ver clientes',
  'customers.manage': 'Editar clientes, observações e bloquear contas',
  'customers.pii': 'Ver dados pessoais completos (CPF) e exportar dados',
  'coupons.manage': 'Gerenciar cupons',
  'reports.view': 'Ver e exportar relatórios',
  'content.manage': 'Editar banners, textos e páginas',
  'settings.manage': 'Alterar configurações da loja, entrega, e-mails e aparência',
  'settings.payments': 'Ver status da integração de pagamentos e conciliar',
  'staff.manage': 'Gerenciar funcionários',
  'audit.view': 'Ver registro de atividades',
  'emails.view': 'Ver histórico de e-mails e reenviar',
  'support.manage': 'Atendimento: mensagens, solicitações, newsletter e LGPD',
};

const DEFAULT_ROLE_PERMISSIONS = {
  admin: Object.keys(PERMISSIONS),
  gerente: [
    'dashboard.view', 'products.view', 'products.edit', 'categories.manage', 'stock.view', 'stock.manage',
    'orders.view', 'orders.manage', 'coupons.manage', 'reports.view',
  ],
  atendente: ['customers.view', 'customers.manage', 'orders.view', 'orders.manage', 'support.manage', 'emails.view'],
  estoquista: ['products.view', 'products.edit', 'stock.view', 'stock.manage'],
};

function makePermissions(app) {
  const { db } = app;
  let cache = null;
  const load = () => {
    const map = {};
    for (const r of db.all('SELECT role, permission FROM role_permissions')) (map[r.role] ||= new Set()).add(r.permission);
    cache = map;
    return map;
  };

  return {
    ROLES,
    PERMISSIONS,
    seedDefaults() {
      if (db.value('SELECT COUNT(*) FROM role_permissions') > 0) return;
      db.tx(() => {
        for (const [role, perms] of Object.entries(DEFAULT_ROLE_PERMISSIONS)) {
          for (const p of perms) db.run('INSERT OR IGNORE INTO role_permissions (role, permission) VALUES (?, ?)', role, p);
        }
      });
    },
    can(staff, perm) {
      if (!staff || !staff.active && staff.active !== undefined) return false;
      if (staff.role === 'superadmin') return true;
      return (cache || load())[staff.role]?.has(perm) || false;
    },
    forRole(role) {
      if (role === 'superadmin') return new Set(Object.keys(PERMISSIONS));
      return new Set((cache || load())[role] || []);
    },
    setRolePermissions(role, perms) {
      if (!(role in DEFAULT_ROLE_PERMISSIONS)) throw new Error('Função inválida.');
      const valid = perms.filter((p) => p in PERMISSIONS);
      db.tx(() => {
        db.run('DELETE FROM role_permissions WHERE role = ?', role);
        for (const p of valid) db.run('INSERT INTO role_permissions (role, permission) VALUES (?, ?)', role, p);
      });
      cache = null;
    },
    /** Quem pode atribuir/gerenciar a função `target`? Superadmin: todas. Admin: somente funções abaixo de admin. */
    canManageRole(actor, target) {
      if (!actor || !(target in ROLES)) return false;
      if (actor.role === 'superadmin') return true;
      if (actor.role === 'admin') return ROLES[target].rank < ROLES.admin.rank;
      return false;
    },
    /** Primeira área do painel acessível para a função (para o redirecionamento pós-login). */
    landing(staff) {
      const order = [['dashboard.view', '/admin'], ['orders.view', '/admin/pedidos'], ['products.view', '/admin/produtos'], ['customers.view', '/admin/clientes'], ['support.manage', '/admin/mensagens'], ['reports.view', '/admin/relatorios']];
      for (const [p, url] of order) if (this.can(staff, p)) return url;
      return '/admin/minha-conta';
    },
  };
}

module.exports = { makePermissions, ROLES, PERMISSIONS, DEFAULT_ROLE_PERMISSIONS };
