# Publicar uma prévia pública grátis no Render

Este projeto inclui `render.yaml` para criar um Web Service no plano Free. Ao terminar, o Render entrega um endereço HTTPS `*.onrender.com`, que qualquer pessoa com o link consegue abrir.

## Limites importantes do plano grátis

- O serviço suspende automaticamente após 15 minutos sem tráfego e pode levar cerca de 1 minuto para acordar na próxima visita.
- O sistema de arquivos do serviço gratuito é efêmero. O banco SQLite e as fotos enviados para `/tmp/brecho-chiqueto` podem ser perdidos ao suspender, reiniciar ou publicar uma nova versão.
- Portanto, use esta opção para visualizar e compartilhar uma **prévia**, sem dados de clientes, pedidos ou pagamentos reais. Não opere a loja com dados comerciais nesse plano.

## Como criar o serviço

1. Coloque os arquivos deste projeto em um repositório GitHub privado.
2. No Render, escolha **New + → Blueprint** e conecte esse repositório.
3. O Render lê `render.yaml`. Se solicitar variáveis, preencha `ADMIN_EMAIL` e `ADMIN_PASSWORD` com seu próprio e-mail e uma senha forte e exclusiva. Nunca publique essas credenciais no GitHub nem as envie em uma conversa.
4. Crie o serviço com o plano **Free** e aguarde o deploy terminar.
5. Abra o endereço público `https://...onrender.com` exibido no painel do Render. Compartilhe esse endereço com quem deve ver a loja.
6. Acesse `/admin` no mesmo domínio para entrar no painel; troque a senha provisória após o primeiro login.

## Estado desta prévia

`PAYMENT_PROVIDER=none` e `EMAIL_TRANSPORT=log` deixam a vitrine acessível, mas não ativam cobranças Pix nem envio real de e-mails. Não aceite pedidos pagos até configurar e testar os serviços reais de pagamento e e-mail e mover banco/fotos para armazenamento persistente.

O Render fornece `RENDER_EXTERNAL_URL`; a configuração deste projeto usa essa URL automaticamente para gerar links e cookies HTTPS quando `BASE_URL` não for definido manualmente.
