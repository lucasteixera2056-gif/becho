# Colocando a loja no ar

## O que a hospedagem precisa ter

- **Node.js 22.13 ou superior.**
- **Disco persistente** para `data/` (banco SQLite) e `uploads/` (fotos). Hospedagem “serverless” ou com disco que apaga a cada deploy **não serve** (perderia pedidos e fotos).
- **Um único processo** da loja (o SQLite e as rotinas de expiração do Pix rodam nele). Não suba duas cópias ao mesmo tempo apontando para o mesmo banco.
- **HTTPS** com domínio próprio (obrigatório para os webhooks dos provedores e para os cookies seguros).
- Poucos recursos bastam: um servidor de **512 MB a 1 GB de RAM** atende uma loja deste porte.

Caminhos comuns: uma **VPS** (qualquer provedor Linux) com Caddy ou Nginx na frente; ou uma plataforma de contêiner/aplicação que ofereça **volume persistente** (Render, Railway, Fly.io etc. — confira se o plano inclui disco persistente e quanto custa; este projeto não define nenhuma dessas contas).

---

## Passo a passo em uma VPS Linux (Ubuntu/Debian)

### 1. Preparar o servidor

```bash
# Node 22 (exemplo com NodeSource; use o método oficial que preferir)
sudo apt update && sudo apt install -y curl ca-certificates
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -
sudo apt install -y nodejs
node --version        # precisa ser v22.13 ou maior

sudo useradd --system --create-home --shell /usr/sbin/nologin brecho
```

### 2. Enviar o projeto

Copie a pasta do projeto para `/opt/brecho-chiqueto` (zip, `scp` ou `git`) e ajuste o dono:

```bash
sudo chown -R brecho:brecho /opt/brecho-chiqueto
```

Não há `npm install` (o projeto não tem dependências).

### 3. Configurar

```bash
cd /opt/brecho-chiqueto
sudo -u brecho cp .env.example .env
sudo -u brecho nano .env       # preencha; veja os comentários do arquivo
sudo chmod 600 .env
```

Mínimo para abrir a loja: `NODE_ENV=production`, `BASE_URL` (https), `TRUST_PROXY=1`, `SECRET_KEY` (gere com o comando indicado no arquivo e **guarde uma cópia fora do servidor**), `PAYMENT_PROVIDER` + credenciais ([`PAGAMENTOS.md`](PAGAMENTOS.md)), e-mail ([`EMAIL.md`](EMAIL.md)).
Em produção a loja **recusa subir** com provedor `mock`, `EMAIL_TRANSPORT=capture` ou `SECRET_KEY` curta.

### 4. Primeiro acesso ao painel

```bash
cd /opt/brecho-chiqueto
sudo -u brecho npm run create-admin     # pergunta nome, e-mail e senha (a senha não aparece nem fica gravada em arquivo)
```

A senha é de uso único: no primeiro login o painel obriga a trocá-la.

### 5. Rodar como serviço (systemd)

`/etc/systemd/system/brecho-chiqueto.service`:

```ini
[Unit]
Description=Loja Brecho Chiqueto
After=network.target

[Service]
Type=simple
User=brecho
WorkingDirectory=/opt/brecho-chiqueto
ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning server.js
Restart=always
RestartSec=3
Environment=NODE_ENV=production
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=/opt/brecho-chiqueto

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now brecho-chiqueto
sudo systemctl status brecho-chiqueto
journalctl -u brecho-chiqueto -f          # acompanhar os avisos da inicialização
```

Na inicialização a loja imprime avisos claros se faltar algo (provedor de Pix, e-mail, HTTPS).

### 6. HTTPS com Caddy (o mais simples)

Aponte o DNS do domínio (registro **A**) para o IP da VPS. `/etc/caddy/Caddyfile`:

```
www.seu-dominio.com.br {
    encode gzip
    reverse_proxy 127.0.0.1:3000
}
seu-dominio.com.br {
    redir https://www.seu-dominio.com.br{uri} permanent
}
```

O Caddy obtém e renova o certificado sozinho. Com `TRUST_PROXY=1` a loja lê o IP real do cliente (limite de tentativas e auditoria dependem disso). Com Nginx o princípio é o mesmo: `proxy_pass http://127.0.0.1:3000;` com `proxy_set_header X-Forwarded-For $remote_addr;` e `proxy_set_header X-Forwarded-Proto $scheme;`. **Importante:** o proxy deve **substituir** o `X-Forwarded-For` enviado pelo cliente (como acima), não acrescentar a ele — a loja usa o primeiro endereço da lista. Só ative `TRUST_PROXY=1` se a loja **só** for acessível através desse proxy (porta 3000 fechada para a internet; por isso `HOST=127.0.0.1`).

Libere só as portas 80 e 443 no firewall.

---

## Atualizar a loja

```bash
npm run backup                    # sempre antes de atualizar
# substitua os arquivos do projeto (NÃO apague data/, uploads/ nem .env)
sudo systemctl restart brecho-chiqueto
```

As migrações do banco rodam sozinhas na inicialização e ficam registradas.

---

## Backup e restauração

**Gerar:** `npm run backup` cria `backups/AAAA-MM-DD_HHMMSS/` com `loja.db` (cópia íntegra, conferida com `integrity_check`, **sem parar a loja**) e `uploads/` (fotos); guarda as 14 mais recentes (`--keep 30` para mais).
**Automatizar** (todo dia às 3h, pelo usuário `brecho`):

```bash
sudo -u brecho mkdir -p /opt/brecho-chiqueto/backups
sudo -u brecho crontab -e
0 3 * * *  cd /opt/brecho-chiqueto && /usr/bin/node --disable-warning=ExperimentalWarning scripts/backup.js >> backups/backup.log 2>&1
```

**Copie a pasta `backups/` para FORA do servidor** (outro disco, armazenamento em nuvem). Backup que está só na mesma máquina não protege de falha da máquina. O backup **não inclui a `SECRET_KEY`** de propósito: guarde-a separadamente — sem ela os CPFs cifrados não podem ser lidos.

**Restaurar** (testado: o banco restaurado abre normalmente):

```bash
sudo systemctl stop brecho-chiqueto
cd /opt/brecho-chiqueto
mv data/loja.db data/loja.db.antigo 2>/dev/null; rm -f data/loja.db-wal data/loja.db-shm
cp backups/AAAA-MM-DD_HHMMSS/loja.db data/loja.db
cp -r backups/AAAA-MM-DD_HHMMSS/uploads/. uploads/
chown -R brecho:brecho data uploads
sudo systemctl start brecho-chiqueto
```

Use a **mesma `SECRET_KEY`** de antes. Faça um teste de restauração de vez em quando (numa pasta separada) para ter certeza de que o backup funciona.

---

## Lista antes de abrir ao público

1. [ ] Domínio com **HTTPS** funcionando e `BASE_URL` com `https://`.
2. [ ] `SECRET_KEY` forte, **cópia guardada fora do servidor**; `.env` com permissão `600`.
3. [ ] Pix em **produção** (painel: “Pagamentos (Pix)” sem aviso de TESTE) e **teste real de baixo valor feito e reembolsado**.
4. [ ] Webhook cadastrado no provedor, **protegido por segredo**, e um evento “Processado” visto em *Últimos eventos*.
5. [ ] E-mails: domínio verificado no Resend, e-mail de teste recebido (confirmação de conta), caixa de **respostas** funcionando.
6. [ ] Pelo menos uma **forma de entrega** cadastrada e testada no checkout (e a retirada, se oferecida).
7. [ ] **Dados reais** em Configurações: contato, WhatsApp, endereço/horário (se quiser exibir), textos do início.
8. [ ] **Textos legais revisados por advogado(a)** e marcados como revisados.
9. [ ] Peças reais cadastradas com **fotos reais** e informações verdadeiras (nada de peça fictícia: apague qualquer item “[DEMO]”).
10. [ ] Contas de funcionários criadas **uma para cada pessoa**; a senha provisória do superadministrador já foi trocada; `ADMIN_EMAIL/ADMIN_PASSWORD` removidos do `.env`.
11. [ ] **Backup diário** agendado, copiado para fora do servidor, e restauração testada.
12. [ ] Testar no **celular** (a maior parte dos clientes de brechó chega pelo Instagram).
13. [ ] Enviar o `https://seu-dominio.com.br/sitemap.xml` ao Google Search Console (opcional) e colocar o link da loja na bio do Instagram.

---

## Problemas comuns

| Sintoma | Causa provável |
|---|---|
| A loja não sobe e mostra “PAYMENT_PROVIDER=mock é proibido em produção” | Ajuste o `.env` para `asaas` ou `mercadopago`. |
| “SECRET_KEY é obrigatória em produção” | Defina a chave (mínimo 32 caracteres). |
| Cliente paga e o pedido não muda | Veja *Pagamentos (Pix) → Últimos eventos*. “assinatura/token inválido” = segredo do webhook diferente do cadastrado no provedor. Mesmo assim a conferência automática (30 s) reconhece o pagamento; use também o botão “Conferir Pix pendentes”. |
| Muitos bloqueios de “muitas tentativas” para todo mundo | `TRUST_PROXY=1` ausente atrás de proxy (todos parecem ter o mesmo IP). |
| Fotos somem depois de um deploy | `uploads/` não está em disco persistente. |
| E-mails “não enviados” | Falta `RESEND_API_KEY`/`EMAIL_FROM` (veja *E-mails enviados*). |
