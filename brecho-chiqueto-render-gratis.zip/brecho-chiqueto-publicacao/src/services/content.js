'use strict';
/**
 * Conteúdo editável: banners (início) e páginas institucionais/legais.
 *
 * ATENÇÃO — textos legais: os modelos abaixo são pontos de partida redigidos com base na legislação brasileira
 * (CDC, Marco Civil da Internet, LGPD). Não substituem a revisão de um(a) advogado(a). Eles não inventam dados
 * da loja: o que depende do proprietário (CNPJ/CPF, e-mail de contato, prazos próprios) usa os campos
 * preenchidos em Configurações. O painel exibe um aviso até que o proprietário marque "textos revisados".
 */
const { now, trunc, int, UserError } = require('../lib/util');

const DEFAULT_PAGES = {
  'politica-de-privacidade': {
    title: 'Política de Privacidade',
    body: `## Quem somos
{{loja}} é a loja responsável pelo tratamento dos dados pessoais coletados neste site. {{identificacao}}

## Quais dados coletamos
- Dados de cadastro e compra: nome, e-mail, telefone, endereço de entrega e, quando exigido pelo meio de pagamento, CPF.
- Dados de pagamento: não recebemos nem guardamos dados de cartão. O pagamento por Pix é processado pelo provedor de pagamentos escolhido pela loja, que nos informa apenas se o pagamento foi confirmado, o valor e eventuais taxas.
- Dados de navegação essenciais: cookies necessários para manter o carrinho, a sessão de login e a proteção contra ataques. Não usamos cookies de publicidade neste site.
- Mensagens que você nos envia pelo formulário de contato e solicitações feitas na sua conta.
- E-mail para novidades, somente se você marcar o consentimento. Você pode cancelar a qualquer momento pelo link no final de cada e-mail.

## Para que usamos
- Processar e entregar seus pedidos, confirmar pagamentos e emitir comunicações sobre a compra (execução de contrato).
- Atender solicitações e prestar suporte.
- Cumprir obrigações legais, fiscais e contábeis.
- Prevenir fraudes e garantir a segurança do site (legítimo interesse).
- Enviar novidades, apenas com o seu consentimento.

## Com quem compartilhamos
Compartilhamos somente o necessário com: provedor de pagamentos (cobrança Pix), serviço de envio de e-mails, transportadoras ou serviços de entrega e prestadores de hospedagem/infraestrutura. Não vendemos dados pessoais.

## Por quanto tempo guardamos
Mantemos os dados enquanto a conta existir e pelo prazo necessário para cumprir obrigações legais e exercer direitos em processos (por exemplo, registros de pedidos e pagamentos). Depois disso, os dados são eliminados ou anonimizados.

## Seus direitos (LGPD, art. 18)
Você pode solicitar confirmação de tratamento, acesso, correção, anonimização, portabilidade, eliminação de dados tratados com base em consentimento, informação sobre compartilhamento e revogação do consentimento. Faça a solicitação em "Meus dados" (/minha-conta) ou na página de solicitações de privacidade, ou entre em contato: {{contato}}.

## Segurança
Usamos conexão segura (HTTPS), senhas armazenadas com criptografia irreversível, CPF armazenado de forma criptografada e controle de acesso ao painel administrativo.

## Alterações
Esta política pode ser atualizada. A data da última atualização fica registrada nesta página.`,
  },
  'termos-de-uso': {
    title: 'Termos de Uso e de Compra',
    body: `## Sobre as peças
Trabalhamos com peças de segunda mão, normalmente únicas. A descrição de cada peça informa estado de conservação, medidas e, quando houver, detalhes e defeitos. As fotos fazem parte da descrição; pequenas variações de cor podem ocorrer conforme a tela.

## Disponibilidade e reserva
Cada peça costuma ter uma única unidade. Ao finalizar o pedido, as peças ficam reservadas para você durante o prazo de pagamento exibido na tela. Se o pagamento não for confirmado nesse prazo, o pedido é cancelado e as peças voltam a ficar disponíveis. O pedido só é confirmado após a confirmação do pagamento pelo provedor de pagamentos.

## Preços e pagamento
Os preços são exibidos em reais (R$). O pagamento é feito por Pix. A confirmação é automática; não é necessário enviar comprovante. Em raras situações em que a peça tenha sido vendida por outro canal, o pedido poderá ser cancelado com reembolso integral.

## Entrega e retirada
As condições estão na página "Entrega e retirada". Prazos informados pelas transportadoras são estimativas.

## Trocas, devoluções e cancelamentos
Veja as páginas "Trocas e devoluções" e "Cancelamento e reembolso".

## Conta e uso do site
Você é responsável pela veracidade dos dados informados e pela guarda da sua senha. É proibido usar o site para fraudes, tentar acessar áreas restritas ou prejudicar o funcionamento do serviço.

## Contato
{{contato}}`,
  },
  'trocas-e-devolucoes': {
    title: 'Trocas e devoluções',
    body: `## Direito de arrependimento
Para compras feitas pela internet, o Código de Defesa do Consumidor (art. 49) garante o direito de desistir da compra em até 7 dias corridos, contados do recebimento da peça, sem precisar justificar. A peça deve ser devolvida no mesmo estado em que foi recebida, com as etiquetas e sem sinais de uso.

## Peça diferente do descrito
Se a peça chegar com defeito não informado ou diferente da descrição, entre em contato em até 7 dias corridos do recebimento, com fotos, e resolveremos com troca por outra peça, crédito ou reembolso, conforme a sua preferência e a disponibilidade.

## Peças de segunda mão
Sinais naturais de uso informados na descrição (estado de conservação, medidas e defeitos) não são considerados defeito. Confira as medidas antes de comprar.

## Como solicitar
Abra uma solicitação na sua conta (/minha-conta) ou entre em contato: {{contato}}. Informe o número do pedido.

## Custos de envio da devolução
Nos casos de arrependimento, a devolução segue a lei: o consumidor não deve ser onerado indevidamente. Combinaremos a forma mais simples de devolução com você.`,
  },
  'cancelamento-e-reembolso': {
    title: 'Cancelamento e reembolso',
    body: `## Pedido ainda não pago
Enquanto o Pix não for pago, você pode simplesmente não pagar: ao fim do prazo, o pedido é cancelado automaticamente e as peças são liberadas. Também é possível cancelar antes, na página do pedido.

## Pedido já pago
Depois da confirmação do pagamento, solicite o cancelamento pela sua conta (/minha-conta) ou pelo contato: {{contato}}. Se o pedido ainda não tiver sido enviado, faremos o cancelamento e o reembolso integral.

## Como o reembolso é feito
O reembolso é feito pelo mesmo meio de pagamento (Pix), pelo provedor de pagamentos, para a conta de origem do pagamento. O prazo para o valor aparecer na sua conta depende do provedor e do seu banco.

## Pagamento duplicado ou peça indisponível
Se houver cobrança em duplicidade ou se não for possível entregar a peça, o valor é reembolsado integralmente.`,
  },
  'entrega-e-retirada': {
    title: 'Entrega e retirada',
    body: `## Formas de entrega
As opções disponíveis para o seu CEP aparecem no checkout, com valor e prazo calculados no momento da compra. Podem existir envio por transportadora, entrega local e retirada, conforme configurado pela loja.

## Prazos
O prazo de entrega começa a contar depois da confirmação do pagamento e da postagem. Os prazos são estimativas fornecidas pelo serviço de entrega e podem variar.

## Rastreamento
Quando houver código de rastreio, ele é enviado por e-mail e fica disponível na página do pedido.

## Retirada
Quando a retirada estiver disponível, as instruções são informadas no checkout e na confirmação do pedido. Só retire após receber o aviso de que o pedido está pronto.

## Endereço
Confira o endereço antes de finalizar. Endereço incorreto ou incompleto pode atrasar ou impedir a entrega.`,
  },
};

function makeContent(app) {
  const { db, settings } = app;

  const content = {
    DEFAULT_PAGES,

    // ───── banners ─────
    banners: {
      list: () => db.all('SELECT * FROM banners ORDER BY placement, sort_order, id'),
      get: (id) => db.get('SELECT * FROM banners WHERE id = ?', id),
      active(placement) {
        const t = now();
        return db.all("SELECT * FROM banners WHERE placement = ? AND active = 1 AND (starts_at IS NULL OR starts_at <= ?) AND (ends_at IS NULL OR ends_at > ?) ORDER BY sort_order, id", placement, t, t);
      },
      save(b, id = null) {
        const placement = b.placement === 'news' ? 'news' : 'hero';
        const title = trunc(b.title, 120);
        if (title.length < 2) throw new UserError('Informe o título do banner.');
        let link = trunc(b.link_url, 300);
        if (link && !/^(\/(?!\/)|https?:\/\/)/i.test(link)) throw new UserError('O link deve começar com / (página da loja) ou https://.');
        const day = (d, end) => {
          if (!d) return null;
          const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
          if (!m) throw new UserError('Data inválida.');
          return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3] + (end ? 1 : 0), 3, 0, 0)).toISOString();
        };
        const vals = [placement, title, trunc(b.subtitle, 200) || null, b.image ? trunc(b.image, 120) : null, link || null, trunc(b.cta_label, 40) || null, b.active === undefined || b.active ? 1 : 0, int(b.sort_order, 0), day(b.starts_at, false), day(b.ends_at, true)];
        if (id) {
          db.run('UPDATE banners SET placement=?, title=?, subtitle=?, image=COALESCE(?, image), link_url=?, cta_label=?, active=?, sort_order=?, starts_at=?, ends_at=? WHERE id=?', ...vals, id);
          return id;
        }
        return db.run('INSERT INTO banners (placement, title, subtitle, image, link_url, cta_label, active, sort_order, starts_at, ends_at) VALUES (?,?,?,?,?,?,?,?,?,?)', ...vals).id;
      },
      setImage(id, filename) {
        db.run('UPDATE banners SET image = ? WHERE id = ?', filename, id);
      },
      remove: (id) => db.run('DELETE FROM banners WHERE id = ?', id),
    },

    // ───── páginas ─────
    seedPages() {
      for (const [slug, p] of Object.entries(DEFAULT_PAGES)) {
        db.run('INSERT OR IGNORE INTO pages (slug, title, body, updated_at, updated_by) VALUES (?,?,?,?,?)', slug, p.title, p.body, now(), 'modelo inicial');
      }
    },
    pages: () => db.all('SELECT slug, title, updated_at, updated_by FROM pages ORDER BY title'),
    page: (slug) => db.get('SELECT * FROM pages WHERE slug = ?', String(slug || '')),
    /** Substitui marcadores por dados reais das configurações; nada é inventado quando o campo está vazio. */
    resolve(body) {
      const s = settings.all();
      const contatos = [s.store_email && `e-mail ${s.store_email}`, s.store_whatsapp && `WhatsApp ${s.store_whatsapp}`, s.store_instagram && `Instagram ${s.store_instagram}`].filter(Boolean);
      const ident = [s.store_document && `Documento (CNPJ/CPF): ${s.store_document}.`, s.store_address && `Endereço: ${s.store_address}.`].filter(Boolean).join(' ');
      return String(body)
        .replace(/\{\{loja\}\}/g, s.store_name)
        .replace(/\{\{contato\}\}/g, contatos.length ? contatos.join(', ') : 'pelo formulário de contato deste site (/contato)')
        .replace(/\{\{identificacao\}\}/g, ident);
    },
    savePage(slug, { title, body }, staffName) {
      const p = this.page(slug);
      if (!p) throw new UserError('Página não encontrada.');
      title = trunc(title, 120);
      body = String(body ?? '').slice(0, 30000);
      if (title.length < 2 || body.trim().length < 10) throw new UserError('Informe o título e o texto da página.');
      db.run('UPDATE pages SET title = ?, body = ?, updated_at = ?, updated_by = ? WHERE slug = ?', title, body, now(), staffName || null, slug);
    },
    resetPage(slug, staffName) {
      const d = DEFAULT_PAGES[slug];
      if (!d) throw new UserError('Esta página não tem modelo padrão.');
      db.run('UPDATE pages SET title = ?, body = ?, updated_at = ?, updated_by = ? WHERE slug = ?', d.title, d.body, now(), staffName || null, slug);
    },
  };
  return content;
}

module.exports = { makeContent, DEFAULT_PAGES };
